# class

## Etymology
- From Middle French classe, from Latin classis (“a class or division of the people, assembly of people, the whole body of citizens called to arms, the army, the fleet, later a class or division in general”), from Proto-Indo-European *kelh₁- (“to call, shout”). Doublet of clas and classis.


## Definition
### Noun
1. (countable) A group, collection, category or set sharing characteristics or attributes. 
2. (sociology, countable) A social grouping, based on job, wealth, etc. In Britain, society is commonly split into three main classes: upper class, middle class and working class. 
3. (uncountable) The division of society into classes. 
4. (uncountable) Admirable behavior; elegance. 
5. (education, countable and uncountable) A group of students in a regularly scheduled meeting with a teacher. 
6. A series of lessons covering a single subject. 
7. (countable) A group of students who commenced or completed their education during a particular year. A school class. 
8. (countable) A category of seats in an airplane, train or other means of mass transportation. 
9. (taxonomy, countable) A rank in the classification of organisms, below phylum and above order; a taxon of that rank. 
10. Best of its kind. 
11. (statistics) A grouping of data values in an interval, often used for computation of a frequency distribution. 
12. (set theory) A collection of sets definable by a shared property. 
13. (military) A group of people subject to be conscripted in the same military draft, or more narrowly those persons actually conscripted in a particular draft. 
14. (object-oriented programming, countable) A set of objects having the same behavior (but typically differing in state), or a template defining such a set in terms of its common properties, functions, etc. 
15. One of the sections into which a Methodist church or congregation is divided, supervised by a class leader. 
16. (astronomy) Abbreviation of Cosmology Large Angular Scale Surveyor. 
17. (astronomy) Abbreviation of Cosmology Large Angular Scale Survey. 

### Verb
1. (transitive) To assign to a class; to classify. 
2. (intransitive) To be grouped or classed. 
3. (transitive) To divide into classes, as students; to form into, or place in, a class or classes. 

### Adjective
1. (Ireland, Tyneside, slang) great; fabulous 

## Synonyms
[[family]] | [[course]] | [[form]] | [[year]] | [[separate]] | [[grade]] | [[division]] | [[category]] | [[sort]] | [[classify]]