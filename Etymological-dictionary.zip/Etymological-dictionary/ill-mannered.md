# ill-mannered

## Etymology
- Compare Middle English ille-ymanerite.


## Definition
### Adjective
1. Having bad manners; impolite. 

## Synonyms
[[rude]]