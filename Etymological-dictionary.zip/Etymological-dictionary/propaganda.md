# propaganda

## Etymology
- From New Latin propāganda, short for Congregātiō dē Prōpāgandā Fidē, "congregation for propagating the faith", a committee of cardinals established in 1622 by Gregory XV to supervise foreign missions, and properly the ablative feminine gerundive of Latin prōpāgō (“propagate”). Doublet of propagation. Modern political sense dates from World War I, not originally pejorative.


## Definition
### Noun
1. A concerted set of messages aimed at influencing the opinions or behavior of large numbers of people. 

## Synonyms
