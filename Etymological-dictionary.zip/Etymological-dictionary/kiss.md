# kiss

## Etymology
- From Middle English kissen, kussen, from Old English cyssan (“to kiss”), from Proto-West Germanic *kussijan, from Proto-Germanic *kussijaną (“to kiss”).

- From Middle English kis, kys, kus, forms of cos influenced by kissen, from Old English coss, from Proto-West Germanic *koss, from Proto-Germanic *kussaz.


## Definition
### Verb
1. (transitive) To touch with the lips or press the lips against, usually to show love or affection or passion, or as part of a greeting. 
2. (transitive, intransitive) To (cause to) touch lightly or slightly; to come into contact. 
3. (intransitive) Of two or more people, to touch each other's lips together, usually to express love or affection or passion. 
4. (transitive, archaic) To treat with fondness. 
5. Acronym of keep it simple, stupid. 

### Noun
1. A touch with the lips, usually to express love or affection, or as a greeting. 
2. An 'X' mark placed at the end of a letter or other type of message, signifying the bestowal of a kiss from the sender to the receiver. 
3. A type of filled chocolate candy, shaped as if someone had kissed the top. See Hershey's Kisses. 
4. (astronomy) The alignment of two bodies in the solar system such that they have the same longitude when seen from Earth, conjunction. 
5. (aviation) A low-speed mid-air collision between the envelopes of two hot air balloons, generally causing no damage or injury. 
6. The KISS principle. 
7. A surname from Hungarian. 

## Synonyms
[[brush]] | [[osculate]] | [[buss]]