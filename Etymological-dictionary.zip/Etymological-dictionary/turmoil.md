# turmoil

## Etymology
- Unknown. First recorded in 1520. Perhaps from Old French tremouille (“the hopper of a mill”).


## Definition
### Noun
1. A state of great disorder or uncertainty. 
2. Harassing labour; trouble; disturbance. 

### Verb
1. (obsolete, intransitive) To be disquieted or confused; to be in commotion. 
2. (obsolete, transitive) To harass with commotion; to disquiet; to worry. 

## Synonyms
[[stir]] | [[commotion]] | [[tumult]] | [[upheaval]] | [[disruption]] | [[agitation]] | [[excitement]] | [[disturbance]] | [[hullabaloo]]