# barrage

## Etymology
- Borrowed from French barrage (“barrage, barrier”). Compare barrier.


## Definition
### Noun
1. An artificial obstruction, such as a dam, in a river designed to increase its depth or to divert its flow. 
2. (military) A heavy curtain of artillery fire directed in front of one's own troops to screen and protect them. 
3. A concentrated discharge of projectile weapons. 
4. (by extension) An overwhelming outburst of words, especially of criticism. 
5. (fencing) A "next hit wins" contest to determine the winner of a bout in case of a tie. 
6. Type of firework containing a mixture of firework types in one single-ignition package. 

### Verb
1. (transitive) To direct a barrage at. 

## Synonyms
[[battery]] | [[onslaught]]