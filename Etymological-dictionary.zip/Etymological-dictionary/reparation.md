# reparation

## Etymology
- Borrowed from Latin reparatio, reparationis.


## Definition
### Noun
1. (usually in the plural) A payment of time, effort or money to compensate for past transgression(s). 
2. (archaic) The act of renewing, restoring, etc., or the state of being renewed or repaired. 

## Synonyms
[[fix]] | [[repair]] | [[amends]]