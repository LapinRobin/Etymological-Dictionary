# transcribe

## Etymology
- From Latin trānscrībō (“to write again in another place, transcribe, copy”), from trans (“over”) + scrībō (“to write”). See scribe.


## Definition
### Verb
1. To convert a representation of language, typically speech but also sign language, etc., to another representation. The term now usually implies the conversion of speech to text by a human transcriptionist with the assistance of a computer for word processing and sometimes also for speech recognition, the process of a computer interpreting speech and converting it to text. 
2. (dictation) To make such a conversion from live or recorded speech to text. 
3. (computing) To transfer data from one recording medium to another. 
4. (music) To adapt a composition for a voice or instrument other than the original; to notate live or recorded music. 
5. (biochemistry) To cause DNA to undergo transcription. 
6. (linguistics) To represent speech by phonetic symbols. 

## Synonyms
[[adapt]]