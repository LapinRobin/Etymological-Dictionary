# superlative

## Etymology
- From Middle English superlatyf, from Old French superlatif, from Late Latin superlātīvus, from Latin superlātus (“extravagant, of hyperbole”), past participle of superfero (“carry over”), from super (“above”) + fero (“bear, carry”).


## Definition
### Noun
1. The extreme (e.g. highest, lowest, deepest, farthest, etc) extent or degree of something. 
2. (grammar) The form of an adjective that expresses which of several items has the highest degree of the quality expressed by the adjective; in English, formed by appending "-est" to the end of the adjective (for some short adjectives only) or putting "most" before it. 
3. (informal) An adjective used to praise something exceptional. 

### Adjective
1. Exceptionally good; of the highest quality; superb. 
2. (grammar) Of or relating to a superlative. 

## Synonyms
[[top]] | [[peak]] | [[superior]] | [[pinnacle]] | [[summit]] | [[acme]] | [[height]] | [[sterling]] | [[elevation]]