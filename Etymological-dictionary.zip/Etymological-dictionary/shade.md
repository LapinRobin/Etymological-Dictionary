# shade

## Etymology
- Noun from Middle English schade, from Old English sċeadu, sċadu (“shadow; shade”), from Proto-West Germanic *skadu, from Proto-Germanic *skadwaz (“shadow; shade”). More at shadow.


## Definition
### Noun
1. (uncountable) Darkness where light, particularly sunlight, is blocked. 
2. (countable) Something that blocks light, particularly in a window. 
3. (countable) A variety of a colour/color, in particular one obtained by adding black (compare tint). 
4. (figuratively) A subtle variation in a concept. 
5. (figuratively) An aspect that is reminiscent of something. 
6. A very small degree of a quantity, or variety of meaning 
7. (chiefly literary and fantasy) A ghost or specter; a spirit. 
8. (countable) A postage stamp showing an obvious difference in colour/color to the original printing and needing a separate catalogue/catalog entry. 
9. (uncountable, originally gay slang) Subtle insults. 
10. (countable) A cover around or above a light bulb, a lampshade. 
11. (historical) A candle-shade. 
12. A surname. 

### Verb
1. (transitive) To shield (someone or something) from light. 
2. (intransitive, rare) To shield oneself from light. 
3. (transitive) To alter slightly. 
4. (intransitive) To vary or approach something slightly, particularly in color. 
5. (intransitive, baseball, of a defensive player) To move slightly from one's normal fielding position. 
6. (transitive) To darken, particularly in drawing. 
7. To surpass by a narrow margin. 
8. (transitive, graphical user interface) To reduce (a window) so that only its title bar is visible. 
9. (transitive, slang) To throw shade, to subtly insult someone. 
10. (transitive, obsolete) To shelter; to cover from injury; to protect; to screen. 
11. (transitive, obsolete) To present a shadow or image of; to shadow forth; to represent. 

## Synonyms
[[nuance]] | [[tone]] | [[shadow]] | [[ghost]] | [[spectre]] | [[tincture]] | [[specter]] | [[wraith]] | [[spook]] | [[tint]] | [[subtlety]] | [[refinement]]