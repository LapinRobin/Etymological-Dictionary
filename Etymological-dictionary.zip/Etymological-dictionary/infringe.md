# infringe

## Etymology
- Borrowed from Latin infringere (“to break off, break, bruise, weaken, destroy”), from in (“in”) + frangere (“to break”).


## Definition
### Verb
1. (transitive) Break or violate a treaty, a law, a right etc. 
2. (intransitive) Break in or encroach on something. 

## Synonyms
[[conflict]] | [[impinge]] | [[encroach]] | [[contravene]]