# numeric

## Etymology
- From French numérique, from Latin numerus (“number”).


## Definition
### Adjective
1. Of or relating to numbers, especially the characters 0 to 9. 
2. (obsolete) Alternative form of numerical (“the same; identical”)  

### Noun
1. (mathematics) Any number, proper or improper fraction, or incommensurable ratio. 

## Synonyms
[[quantitative]] | [[numeral]]