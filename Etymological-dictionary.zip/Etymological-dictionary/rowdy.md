# rowdy

## Etymology
- Possibly from row (“noisy argument”).


## Definition
### Adjective
1. Loud and disorderly; riotous; boisterous. 

### Noun
1. A boisterous person; a brawler. 
2. (Victorian slang) money; ready money. 

## Synonyms
[[tough]] | [[bully]] | [[raucous]] | [[ruffian]] | [[hooligan]]