# statue

## Etymology
- From Old French statue, from Latin statua, derived from statuō (“set up or erect”).


## Definition
### Noun
1. A three-dimensional work of art, usually representing a person or animal, usually created by sculpting, carving, molding, or casting. 
2. (dated) A portrait. 

### Verb
1. (transitive) To form a statue of; to make into a statue. 

## Synonyms
