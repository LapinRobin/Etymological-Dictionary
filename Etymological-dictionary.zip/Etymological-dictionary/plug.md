# plug

## Etymology
- From Dutch plug, from Middle Dutch plugge (“peg, plug”), from Old Dutch *pluggi, from Proto-West Germanic *plugi. Further origin unknown. Possibly from Proto-Germanic *plugjaz, but the word seems originally restricted to northern continental West Germanic: compare German Low German Plüg, Norwegian plug (“peg, wedge”, probably borrowed from Middle Low German), German Pflock (“peg”, restricted to Central German and phonetically divergent). Possibly akin to Lithuanian plúkti (“to strike, hew”).


## Definition
### Noun
1. (electricity) A pronged connecting device which fits into a mating socket, especially an electrical one. 
2. (loosely) An electric socket: wall plug. 
3. Any piece of wood, metal, or other substance used to stop or fill a hole. 
4. (US) A flat oblong cake of pressed tobacco. 
5. (US, slang) A high, tapering silk hat. 
6. (US, slang) A worthless horse. 
7. (dated) Any worn-out or useless article. 
8. (dated, slang) A book that fails to sell. 
9. (construction) A block of wood let into a wall to afford a hold for nails. 
10. (slang) A promotion (act of promoting) a product (such as a book, film or play) or other thing (concept, etc), for example during an interview or a commercial. 
11. (geology) A body of once molten rock that hardened in a volcanic vent. Usually round or oval in shape. 
12. (fishing) A type of lure consisting of a rigid, buoyant or semi-buoyant body and one or more hooks. 
13. (horticulture) A small seedling grown in a tray from expanded polystyrene or polythene filled usually with a peat or compost substrate. 
14. (jewelry) A short cylindrical piece of jewellery commonly worn in larger-gauge body piercings, especially in the ear. 
15. (slang) A drug dealer. 
16. A branch from a water-pipe to supply a hose. 
17. (aviation) A standard, modular fuselage component that can be added or removed. 

### Verb
1. (transitive) To stop with a plug; to make tight by stopping a hole. 
2. (transitive) To blatantly mention a particular product or service as if advertising it. 
3. (intransitive, informal) To persist or continue with something. 
4. (transitive) To shoot a bullet into something with a gun. 
5. (slang, transitive) To have sex with, penetrate sexually. 

## Synonyms
[[hack]] | [[secure]] | [[punch]] | [[hype]] | [[nag]] | [[jade]] | [[quid]] | [[wad]] | [[chew]] | [[cud]] | [[ballyhoo]] | [[hoopla]]