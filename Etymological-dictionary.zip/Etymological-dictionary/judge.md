# judge

## Etymology
- From Middle English juge, jugge, borrowed from Old French juge, from Latin iūdex. Displaced native Old English dēma.

- From Middle English jugen, borrowed from Anglo-Norman juger, from Old French jugier, from Latin iūdicāre.


## Definition
### Noun
1. A public official whose duty it is to administer the law, especially by presiding over trials and rendering judgments; a justice. 
2. A person who decides the fate of someone or something that has been called into question. 
3. A person officiating at a sports event, a contest, or similar. 
4. A person who evaluates something or forms an opinion. 
5. (historical, biblical) A shophet, a temporary leader appointed in times of crisis in ancient Israel. 
6. A surname originating as an occupation. 
7. (Christianity) epithet of God or Jesus in his role as supreme arbiter 
8. An unincorporated community in Olmsted County, Minnesota, United States, named after Edward Judge. 
9. An unincorporated community in Osage County, Missouri, United States, named for a local judge who owned the town site. 

### Verb
1. (transitive) To sit in judgment on; to pass sentence on (a person or matter). 
2. (intransitive) To sit in judgment, to act as judge. 
3. (transitive) To judicially rule or determine. 
4. (transitive, obsolete) To sentence to punishment, to judicially condemn. 
5. (transitive, obsolete) To award judicially; to adjudge. 
6. (transitive) To form an opinion on; to appraise. 
7. (transitive, obsolete) To constitute a fitting appraisal or criterion of; to provide a basis for forming an opinion on. 
8. (intransitive) To arbitrate; to pass opinion on something, especially to settle a dispute etc. 
9. (transitive) To have as an opinion; to consider, suppose. 
10. (transitive, intransitive) To form an opinion; to infer. 
11. (transitive, intransitive) To criticize or label another person or thing. 
12. (transitive, intransitive) To govern as biblical judge or shophet (over some jurisdiction). 

## Synonyms
[[gauge]] | [[justice]] | [[label]] | [[estimate]] | [[try]] | [[guess]] | [[pronounce]] | [[approximate]] | [[adjudicate]] | [[magistrate]] | [[jurist]]