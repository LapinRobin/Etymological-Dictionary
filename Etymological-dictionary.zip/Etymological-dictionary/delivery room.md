# delivery room

## Definition
### Noun
1. (medicine) An operating theatre or similar room in a hospital or other medical facility, furnished with suitable equipment and staffed by physicians, surgeons, or other medical workers, for the purpose of assisting mothers with the births of their babies. 

## Synonyms
