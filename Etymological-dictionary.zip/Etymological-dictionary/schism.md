# schism

## Etymology
- From Middle English scisme, from Old French cisme or scisme, from Ancient Greek σχίσμα (skhísma, “division”), from σχίζω (skhízō, “I split”). Doublet of schisma.


## Definition
### Noun
1. A split or separation within a group or organization, typically caused by discord. 
2. (religion) A formal division or split within a religious body. 
3. (Catholicism) a split within Christianity whereby a group no longer recognizes the Bishop of Rome as the head of the Church, but shares essentially the same beliefs with the Church of Rome. In other words, a political split without the introduction of heresy. 

## Synonyms
[[split]]