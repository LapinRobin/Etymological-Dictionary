# tier

## Etymology
- tie +‎ -er

- From Middle French tier, from Old French tire (“rank, sequence, order, kind”), probably from tirer (“to draw, draw out”). Alternatively, from a Germanic source related to Middle English tir (“honour, glory, power, rule”), Old English tīr (“glory, honour, fame”), Old Norse tírr (“glory, honour, renown”).


## Definition
### Noun
1. One who ties (knots, etc). 
2. Something that ties. 
3. (archaic) A child's apron. 
4. A layer or rank, especially of seats or a wedding cake. 

### Verb
1. (transitive) To arrange in layers. 
2. (transitive) To cascade in an overlapping sequence. 
3. (transitive, computing) To move (data) from one storage medium to another as an optimization, based on how frequently it is accessed. 

## Synonyms
[[level]] | [[grade]]