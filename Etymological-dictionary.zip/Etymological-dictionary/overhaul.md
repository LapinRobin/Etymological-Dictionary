# overhaul

## Etymology
- over- +‎ haul.


## Definition
### Noun
1. A major repair, renovation, or revision. 
2. (firefighting) The process after the fire appears extinguished in which the firefighters search the structure for signs of hot spots that may cause the structure to reignite. Often this includes the process of salvage under the blanket term, salvage and overhaul. 

### Verb
1. To modernize, repair, renovate, or revise completely. 
2. To pass, overtake, or travel past. 
3. (nautical) To keep (running rigging) clear, and see that no hitch occurs. 
4. (transitive) To search (a ship) for contraband goods. 

## Synonyms
[[service]] | [[pass]] | [[overtake]]