# proficient

## Etymology
- From Latin proficiens, present participle of proficere (“to go forward, advance, make progress, succeed, be profitable or useful”), from pro (“forth, forward”) + facere (“to make, do”); see fact.


## Definition
### Adjective
1. Good at something; skilled; fluent; practiced, especially in relation to a task or skill. 

### Noun
1. An expert. 

## Synonyms
[[good]] | [[adept]] | [[expert]] | [[skillful]]