# sadistic

## Etymology
- sadist +‎ -ic


## Definition
### Adjective
1. Delighting in or feeling pleasure from the pain or humiliation of others. 
2. Of behaviour which gives pleasure in the pain or humiliation of others. 
3. (colloquial) Causing a high degree of pain or humiliation. 

## Synonyms
