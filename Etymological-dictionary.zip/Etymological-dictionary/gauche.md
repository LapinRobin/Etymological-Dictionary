# gauche

## Etymology
- Borrowed from French gauche (“left, awkward”), from gauchir (“to veer, turn”), from Old French gaucher (“to trample, walk clumsily”), from Frankish *walkan (“to full, trample”), from Proto-Germanic *walkaną (“to full, roll up”). Akin to Old High German walchan (“to knead”), Old English wealcian (“to roll up, curl”) and English walk, Old Norse valka (“to drag about”). More at walk.


## Definition
### Adjective
1. Awkward or lacking in social graces; bumbling. 
2. (mathematics, archaic) Skewed, not plane. 
3. (chemistry) Describing a torsion angle of 60°. 

## Synonyms
