# salary

## Etymology
- From Middle English salarie, from Anglo-Norman salarie, from Old French salaire, from Latin salārium (“wages”), the neuter form of the adjective salārius (“related to salt”), from sal (“salt”). There have been various attempts to explain how the Latin term for “wages” came from the adjective “related to salt”. It is generally assumed that salārium was an abbreviation of salārium argentum (“salt money”), though that phrase is not attested. A commonly cited theory is that the phrase meant “money consisting of salt”, because Roman soldiers were sometimes paid in salt, but there is no evidence for this from ancient sources. Another is that the phrase meant “money used to buy salt ”.


## Definition
### Noun
1. A fixed amount of money paid to a worker, usually calculated on a monthly or annual basis, not hourly, as wages. Implies a degree of professionalism and/or autonomy. 

### Verb
1. To pay on the basis of a period of a week or longer, especially to convert from another form of compensation. 

### Adjective
1. (obsolete) Saline. 

## Synonyms
[[pay]] | [[remuneration]] | [[wage]] | [[earnings]]