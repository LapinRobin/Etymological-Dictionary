# deconstructionist

## Etymology
- deconstruction +‎ -ist


## Definition
### Adjective
1. (chiefly philosophy) Characteristic of, related to, or supporting deconstructionism 

### Noun
1. (philosophy) A proponent of deconstructionism 

## Synonyms
