# flit

## Etymology
- From Middle English flitten, flytten, from Old Norse flytja (“to move”), from Proto-Germanic *flutjaną, from Proto-Indo-European *plewd- (“to flow; run”). Cognate Icelandic flytja, Swedish flytta, Danish flytte, Norwegian flytte, Faroese flyta. Compare also Saterland Frisian flitskje (“to rush; run quickly”).


## Definition
### Noun
1. A fluttering or darting movement. 
2. (physics) A particular, unexpected, short lived change of state. 
3. (dated, slang) A homosexual. 

### Verb
1. To move about rapidly and nimbly. 
2. (physics) To unpredictably change state for short periods of time. 
3. (UK, dialect) To move house (sometimes a sudden move to avoid debts). 
4. To move a tethered animal to a new, grazing location. 
5. To be unstable; to be easily or often moved. 

### Adjective
1. (poetic, obsolete) Fast, nimble. 

## Synonyms
[[fleet]] | [[flutter]] | [[dart]]