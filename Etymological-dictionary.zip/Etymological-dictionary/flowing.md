# flowing

## Etymology
- From Middle English flowyng; equivalent to flow +‎ -ing.


## Definition
### Noun
1. The action of the verb to flow 

### Adjective
1. Tending to flow. 
2. Moving, proceeding or shaped smoothly, gracefully, or continuously. 

## Synonyms
[[flow]] | [[fluid]] | [[smooth]] | [[liquid]] | [[graceful]] | [[fluent]] | [[moving]] | [[streaming]]