# terrorize

## Etymology
- terror +‎ -ize


## Definition
### Verb
1. To fill (someone) with terror; to terrify. 
2. To coerce (someone) by using threats or violence. 

## Synonyms
