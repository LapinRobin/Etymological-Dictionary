# elastic

## Etymology
- From French élastique, from New Latin elasticus (“elastic”), from Ancient Greek ἐλαστός (elastós), alternative form of ἐλατός (elatós, “ductile”) (cf. ἐλατήρ (elatḗr, “a driver, hurler”)), from ἐλαύνω (elaúnō, “to drive, set in motion, push, strike, beat out”).


## Definition
### Adjective
1. Capable of stretching; particularly, capable of stretching so as to return to an original shape or size when force is released. 
2. Made of elastic. 
3. Of clothing, elasticated. 
4. (economics) Sensitive to changes in price. 
5. springy; bouncy; vivacious 
6. Pervasive, all-encompassing. 
7. Able to return quickly to a former state or condition, after being depressed or overtaxed; having power to recover easily from shocks and trials. 

### Noun
1. (uncountable) An elastic material used in clothing, particularly in waistbands and cuffs. 
2. (countable) An elastic band. 

## Synonyms
[[live]] | [[resilient]] | [[stretch]] | [[flexible]] | [[malleable]] | [[plastic]] | [[lively]] | [[pliable]] | [[ductile]] | [[pliant]] | [[adaptable]] | [[tensile]]