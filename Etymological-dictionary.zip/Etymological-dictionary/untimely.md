# untimely

## Etymology
- un- +‎ timely


## Definition
### Adjective
1. At an inopportune time. 
2. Early; premature. 

### Adverb
1. Prematurely. 

## Synonyms
[[wrong]] | [[early]] | [[premature]]