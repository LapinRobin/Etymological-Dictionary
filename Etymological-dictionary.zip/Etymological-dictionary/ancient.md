# ancient

## Etymology
- From Middle English auncyen, borrowed from Old French ancien (“old”), from Vulgar Latin root *anteanus, from Latin ante (“before”). Compare antique.

- Corruption of ensign.


## Definition
### Adjective
1. Having lasted from a remote period; having been of long duration; of great age, very old. 
2. Existent or occurring in time long past, usually in remote ages; belonging to or associated with antiquity; old, as opposed to modern. 
3. (historical) Relating to antiquity as a primarily European historical period; the time before the Middle Ages. 
4. (obsolete) Experienced; versed. 
5. (obsolete) Former; sometime. 

### Noun
1. A person who is very old. 
2. A person who lived in ancient times. 
3. (UK, law) One of the senior members of the Inns of Court or of Chancery. 
4. (obsolete) A senior; an elder; a predecessor. 
5. (heraldry, archaic) A flag, banner, standard or ensign. 
6. (obsolete, rare) the bearer of a flag; ensign 

## Synonyms
[[past]] | [[old]] | [[antique]]