# gatekeeper

## Etymology
- From gate +‎ keeper.


## Definition
### Noun
1. A person or group who controls access to something or somebody. 
2. A person who guards or monitors passage through a gate. 
3. A common orange and brown butterfly with eyespots, Pyronia tithonus, of the family Nymphalidae. 
4. (psychology) In dissociative identity disorder, an aspect of the personality that controls access to the various identities. 
5. One who gatekeeps. 

## Synonyms
[[porter]]