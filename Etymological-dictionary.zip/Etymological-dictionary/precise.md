# precise

## Etymology
- From Middle French précis, from Latin praecisus, perfect passive participle of praecīdere, from prae- (“before, in front”) +‎ caedere (“cut; strike”), cognate with English hit. Related to English incise. Doublet of précis.


## Definition
### Adjective
1. exact, accurate 
2. (sciences, of experimental results) consistent, clustered close together, agreeing with each other (this does not mean that they cluster near the true, correct, or accurate value) 
3. adhering too much to rules; prim or punctilious 

### Verb
1. (nonstandard, non-native speakers' English or European Union documents, transitive) To make or render precise; to specify. 

## Synonyms
[[right]] | [[fine]] | [[nice]] | [[dead]] | [[meticulous]] | [[accurate]] | [[correct]] | [[exact]] | [[punctilious]] | [[skillful]]