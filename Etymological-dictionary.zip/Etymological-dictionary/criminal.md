# criminal

## Etymology
- From Middle English cryminal, borrowed from Anglo-Norman criminal, from Late Latin criminalis, from Latin crimen (“crime”).


## Definition
### Adjective
1. Against the law; forbidden by law. 
2. Guilty of breaking the law. 
3. Of or relating to crime or penal law. 
4. (figuratively) Abhorrent or very undesirable. 

### Noun
1. A person who is guilty of a crime, notably breaking the law. 

## Synonyms
[[wrong]] | [[crook]] | [[reprehensible]] | [[deplorable]] | [[outlaw]] | [[illegal]] | [[guilty]] | [[felon]] | [[malefactor]]