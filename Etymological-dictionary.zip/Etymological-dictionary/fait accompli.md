# fait accompli

## Etymology
- Borrowed from French fait accompli (“an accomplished fact”), from fait (“a fact”) + accompli (“accomplished”).


## Definition
### Noun
1. An accomplished fact, something that has already occurred. 

## Synonyms
