# duplex

## Etymology
- Borrowed from Latin duplex (“double, two-fold”), from duo (“two”) + plico (“fold together”); compare the roots of διπλόος (diplóos, “double”); compare also πλέκω (plékō, “twist, braid”). Surface analysis, duo- +‎ -plex.


## Definition
### Adjective
1. (architecture) Having two floors 
2. (architecture) Having two units, divisions, suites, apartments 
3. (telecommunications) Bidirectional (in two directions). 
4. (soil science) Having horizons with contrasting textures. 

### Noun
1. (US, Canada) A house made up of two dwelling units. 
2. (US) A dwelling unit with two floors 
3. (philately) A cancellation combining a numerical cancellation with a second mark showing time, date, and place of posting. 
4. (juggling) A throwing motion where two balls are thrown with one hand at the same time. 
5. (biochemistry) A double-stranded polynucleotide. 
6. (geology) A system of multiple thrust faults bounded above and below by a roof thrust and floor thrust. 

### Verb
1. To make duplex. 
2. To make into a duplex. 
3. (juggling) To make a series of duplex throws. 

## Synonyms
[[multiple]]