# designate

## Etymology
- Borrowed from Latin designatus, past participle of designare. Doublet of design.


## Definition
### Adjective
1. Designated; appointed; chosen. 
2. (UK) Used after a role title to indicate that the person has been selected but has yet to take up the role. 

### Verb
1. To mark out and make known; to point out; to indicate; to show; to distinguish by marks or description 
2. To call by a distinctive title; to name. 
3. To indicate or set apart for a purpose or duty; — with to or for; to designate an officer for or to the command of a post or station. 

## Synonyms
[[assign]] | [[delegate]] | [[fate]] | [[intend]] | [[doom]] | [[specify]] | [[destine]]