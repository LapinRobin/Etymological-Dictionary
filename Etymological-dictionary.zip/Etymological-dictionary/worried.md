# worried

## Definition
### Adjective
1. Thinking about unpleasant things that have happened or that might happen; feeling afraid and unhappy. 

## Synonyms
[[upset]] | [[distressed]] | [[disturbed]]