# warrior

## Etymology
- From Middle English werreour, from Anglo-Norman guerreier, Old French guerroiier (“fighter, combattant”), from Medieval Latin werra, from Frankish *werru (“confusion; quarrel”), from Proto-Indo-European *wers- (“to mix up, confuse, beat, thresh”). Displaced native Old English cempa.


## Definition
### Noun
1. A person who is actively engaged in battle, conflict or warfare; a soldier or combatant. 
2. (figuratively) A person who is aggressively, courageously, or energetically involved in an activity, such as athletics. 
3. A surname. 

## Synonyms
