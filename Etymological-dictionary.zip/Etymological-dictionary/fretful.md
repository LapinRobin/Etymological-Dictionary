# fretful

## Etymology
- fret +‎ -ful


## Definition
### Adjective
1. Irritable, bad-tempered, grumpy or peevish. 
2. Unable to relax; fidgety or restless. 

## Synonyms
[[querulous]] | [[restless]] | [[whining]]