# commemorative

## Etymology
- From commemorate +‎ -ive.


## Definition
### Adjective
1. Serving to commemorate something. 

### Noun
1. An object made to commemorate a person, mark an event, etc. 
2. (philately) A postage stamp issued to commemorate, usually a person or event; also commonly applied to thematic (topical) stamp issues. 

## Synonyms
