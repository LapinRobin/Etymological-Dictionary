# dalliance

## Etymology
- From Middle English daliaunce et al., from dalien (“to exchange pleasantries, to chat; to flirt”), from Old French dalier, dailer. Synchronically dally +‎ -ance.


## Definition
### Noun
1. Playful flirtation; amorous play. 
2. A episode of dabbling. 
3. A wasting of time in idleness or trifles. 
4. A sexual relationship, not serious but often illicit. 

## Synonyms
[[flirt]] | [[trifling]]