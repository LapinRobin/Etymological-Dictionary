# confederacy

## Etymology
- From Middle English confederacie, from Anglo-Norman confederacie, from Latin cōnfoederātiō. Doublet of confederation.


## Definition
### Noun
1. An alliance. 
2. (politics) A state where the sovereign constituent units delegate their authority to the centre. As opposed to a federation, where the central and regional governments are each equal and sovereign in their own sphere. 
3. Specifically, an instance of a decentralized governing structure among the indigenous peoples of North America. 
4. (historical) The Confederate States of America, the collection of American states that seceded from the United States in 1860-61, and fought against the Union in the American Civil War. 

## Synonyms
[[conspiracy]] | [[south]] | [[federation]] | [[dixie]]