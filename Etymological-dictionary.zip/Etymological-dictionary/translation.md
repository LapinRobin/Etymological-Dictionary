# translation

## Etymology
- From Middle English translacioun (“transfer, translation”), from Anglo-Norman translacioun, from Latin trānslātiō, from trānslāt-, the supine stem of trānsferō (“to transfer, transport, transform, translate”). Displaced native Old English wending.


## Definition
### Noun
1. The conversion of text from one language to another. 
2. (translation studies) The discipline or study of translating written language (as opposed to interpretation, which concerns itself with spoken language). 
3. The conversion of something from one form or medium to another. 
4. (physics, mathematics) A motion or compulsion to motion in a straight line without rotation or other deformation. 
5. (mathematics) A relation between two mathematical figures such as a straight line where the coordinates of each point in one figure is a constant added to the coordinates of a corresponding point in the other figure. 
6. (genetics) The process whereby a strand of mRNA directs assembly of amino acids into proteins within a ribosome. 
7. (physics) A transfer of motion occurring within a gearbox. 
8. The automatic retransmission of a telegraph message. 
9. The conveyance of something from one place to another, especially: 
10. (countable) The product or end result of an act of translating, in its various senses. 

## Synonyms
[[version]] | [[transformation]] | [[rendering]] | [[displacement]]