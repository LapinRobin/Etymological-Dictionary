# plague

## Etymology
- From Middle English plage, borrowed from Old French plage, from Latin plāga (“blow, wound”), from plangō (“to strike”). Cognate with Middle Dutch plāghe (> Dutch plaag), plāghen (> Dutch plagen); Middle Low German plāge; Middle High German plāge, pflāge (> German Plage); plāgen (> German plagen); Swedish plåga; French plaie, Occitan plaga. Doublet of plaga. Displaced native Old English wōl.


## Definition
### Noun
1. (often used with the, sometimes capitalized: the Plague) The bubonic plague, the pestilent disease caused by the virulent bacterium Yersinia pestis. 
2. (pathology) An epidemic or pandemic caused by any pestilence, but specifically by the above disease. 
3. A widespread affliction, calamity or destructive influx, especially when seen as divine retribution. 
4. (figuratively) A grave nuisance, whatever greatly irritates. 
5. (ornithology) A group of common grackles. 

### Verb
1. (transitive) To harass, pester or annoy someone persistently or incessantly. 
2. (transitive) To afflict with a disease or other calamity. 

## Synonyms
[[blight]] | [[hassle]] | [[beset]] | [[provoke]] | [[harass]] | [[harry]] | [[pestilence]] | [[molest]] | [[chevy]]