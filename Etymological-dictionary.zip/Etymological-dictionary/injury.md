# injury

## Etymology
- From Middle English injurie, from Anglo-Norman injurie, from Latin iniūria (“injustice; wrong; offense”), from in- (“not”) + iūs, iūris (“right, law”). Doublet of injuria.


## Definition
### Noun
1. Damage to the body of a living thing. 
2. Other forms of damage sustained by a living thing, e.g. psychologically. 
3. The violation of a person's reputation, rights, property, or interests. 
4. (archaic) Injustice. 

### Verb
1. (obsolete) To wrong, to injure. 

## Synonyms
[[hurt]] | [[wound]] | [[trauma]] | [[harm]]