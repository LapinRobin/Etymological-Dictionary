# ossuary

## Etymology
- From Late Latin ossuārium (“charnel house”), from ossuārius (“of or for bones”), from compound of Latin os (“bone”) + adjectival suffix -ārius (“of, related to”).


## Definition
### Noun
1. A container, receptacle, or building, such as an urn or vault, for holding the bones of the dead. 

## Synonyms
