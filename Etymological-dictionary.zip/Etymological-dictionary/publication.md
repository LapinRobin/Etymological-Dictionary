# publication

## Etymology
- From Middle English publicacioun, from Old French publicacion, from Latin pūblicātiō.


## Definition
### Noun
1. The act of publishing printed or other matter. 
2. An issue of printed or other matter, offered for sale or distribution. 
3. The communication of information to the general public etc. 

## Synonyms
[[issue]]