# folklore

## Etymology
- From folk +‎ lore, coined by British writer William Thoms in 1846 to replace terms such as "popular antiquities". Thoms imitated German terms such as Volklehre (“people's customs”) and Volksüberlieferung (“popular tradition”). Compare also Old English folclar (“popular instruction; homily”) and West Frisian folkloare (“folklore”).


## Definition
### Noun
1. The tales, legends, superstitions, and traditions of a particular ethnic population. 
2. (by extension) The tales, superstitions etc. of any particular group or community. 

## Synonyms
