# mumble

## Etymology
- From Middle English momelen, a frequentative of mum (sense 3) (“silent”). Compare German mümmeln, Middle Dutch mommelen and Dutch mompelen.


## Definition
### Verb
1. (transitive, intransitive) To speak unintelligibly or inaudibly; to fail to articulate. 
2. To chew something gently with closed lips. 

### Noun
1. A quiet or unintelligible vocalization; a low tone of voice. 

## Synonyms
[[gum]] | [[mutter]]