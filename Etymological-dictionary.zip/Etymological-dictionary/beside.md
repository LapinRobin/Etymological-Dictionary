# beside

## Etymology
- From Middle English beside, besiden, bisyde (also besides > besides), from Old English be sīdan, bī sīdan (“by the side (of), on the side (of)”), equivalent to be- +‎ side. Compare Saterland Frisian biesiede (“aside”), German Low German bisied (“aside”), German beiseite (“aside, to one side”). Compare also Dutch terzijde (“aside”).


## Definition
### Adverb
1. Otherwise; else; besides. 

## Synonyms
