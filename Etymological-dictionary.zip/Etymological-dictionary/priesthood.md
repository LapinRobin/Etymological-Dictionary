# priesthood

## Etymology
- From Middle English presthed, presthede, presthod, presthode, from Old English prēosthād (“priesthood”), equivalent to priest +‎ -hood. Compare Dutch priesterheid (“priesthood”).


## Definition
### Noun
1. The role or office of a priest. 
2. Priests as a group; the clergy. 
3. Authority to act in the name of God or the divine in general. 

## Synonyms
