# traffic

## Etymology
- From Middle French trafique, traffique (“traffic”), from Italian traffico (“traffic”) from trafficare (“to carry on trade”). Potentially from Vulgar Latin *trānsfrīcāre (“to rub across”); Klein instead suggests the Italian has ultimate origin in Arabic تَفْرِيق‎ (tafrīq, “distribution, dispersion”), reshaped to match the native prefix tra- (“trans-”).


## Definition
### Noun
1. Moving pedestrians or vehicles, or the flux or passage thereof. 
2. Commercial transportation or exchange of goods, or the movement of passengers or people. 
3. Illegal trade or exchange of goods, often drugs. 
4. In CB radio, formal written messages relayed on behalf of others. 
5. (advertising) The amount of attention paid to a particular printed page etc. in a publication. 
6. Commodities of the market. 

### Verb
1. (intransitive) To pass goods and commodities from one person to another for an equivalent in goods or money; to buy or sell goods. 
2. (intransitive) To trade meanly or mercenarily; to bargain. 
3. (transitive) To exchange in traffic; to effect by a bargain or for a consideration. 

### Adjective
1. (Philippines) congested 

## Synonyms
