# wont

## Etymology
- Origin uncertain; apparently a conflation of wone (“custom, habit, practice”) and wont (participle adjective, below). Compare German Low German Gewohnte (“custom, habit”) and Dutch gewoonte. Likely related to wone, wonder, wean, and win, ultimately from Proto-Indo-European *wenh₁- (“to wish for, strive for, pursue; to succeed, win”); more there.

- From Middle English wont, iwoned, from Old English ġewunod, past participle of ġewunian. 

- From Middle English wonten (“to accustom”), from wont (adjective). See above.


## Definition
### Noun
1. (archaic) One's habitual way of doing things; custom, habit, practice. 

### Adjective
1. Accustomed or used (to or with a thing), accustomed or apt (to do something). 

### Verb
1. (transitive, archaic) To make (someone) used to; to accustom. 
2. (intransitive, archaic) To be accustomed (to something), to be in the habit (of doing something). 

## Synonyms
[[use]] | [[habit]]