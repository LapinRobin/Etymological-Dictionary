# freely

## Etymology
- From Middle English frely, freelich, from Old English frēolīc (“free, freeborn, glorious, stately, magnificent, noble, beautiful, charming”), equivalent to free +‎ -ly. Compare Middle Low German vrilik, vrigelik (“free”), Middle High German vrīlich (“free”).

- From Middle English frely, freliche, from Old English frēolīċe (“freely, readily, as a festival”), equivalent to free +‎ -ly. Compare Dutch vrijelijk (“freely”), German freilich (“certainly, of course”).


## Definition
### Adjective
1. Free; frank. 
2. Generous; noble; excellent; beautiful; lovely. 

### Adverb
1. In a free manner. 
2. Without interference or restriction. 
3. Of one's own free will. 

## Synonyms
