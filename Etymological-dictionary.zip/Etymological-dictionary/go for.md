# go for

## Definition
### Verb
1. Used other than figuratively or idiomatically: see go, for. 
2. (transitive) To try for, to attempt to reach. 
3. (transitive) To undertake (an action); to choose an option. 
4. (transitive) To attack. 
5. (transitive) To develop a strong interest in, especially in a sudden manner; to be infatuated with. 
6. To favor, accept; to have a preference for. 
7. (transitive) To apply equally to. 
8. (transitive) To suffice to be used for; to serve as. 

## Synonyms
