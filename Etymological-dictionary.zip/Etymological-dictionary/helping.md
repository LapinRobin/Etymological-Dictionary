# helping

## Definition
### Noun
1. (countable) A portion or serving, especially of food that one takes for oneself, or to which one helps oneself. 
2. (figuratively, countable) An amount or quantity 

## Synonyms
[[help]] | [[aid]] | [[assist]] | [[portion]] | [[assistance]] | [[serving]]