# bribe

## Etymology
- From Old French briber (“go begging”).


## Definition
### Noun
1. Something (usually money) given in exchange for influence or as an inducement to breaking the law. 
2. That which seduces; seduction; allurement. 

### Verb
1. (transitive) To give a bribe to; specifically, to ask a person to do something against his/her original will, in exchange for some type of reward or relief from potential trouble. 
2. (transitive) To gain by a bribe; to induce as by a bribe. 

## Synonyms
[[buy]] | [[corrupt]] | [[payoff]]