# slum

## Etymology
- First attested in  1812.; originally slang, in the sense "room", especially "backroom", of unknown origin.

- See slumgullion.


## Definition
### Noun
1. (countable) A dilapidated neighborhood where many people live in a state of poverty. 
2. (slang, uncountable) Inexpensive trinkets awarded as prizes in a carnival game. 
3. (slang) Slumgullion; a meat-based stew. 

### Verb
1. (intransitive) To visit a neighborhood of a status below one's own. 
2. (intransitive, UK, slang, dated) To saunter about in a disreputable manner. 

## Synonyms
