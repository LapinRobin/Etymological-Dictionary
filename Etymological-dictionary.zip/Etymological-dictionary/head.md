# head

## Etymology
- From Middle English hed, heed, heved, heaved, from Old English hēafd-, hēafod (“head; top; source, origin; chief, leader; capital”), from Proto-West Germanic *haubud, from Proto-Germanic *haubudą (“head”), from Proto-Indo-European *káput-. The modern word comes from Old English oblique stem hēafd-, the expected Modern English outcome for hēafod would be *heaved (similar to the Middle English word), with irregular pronunciation of /ˈheɪvd/. Doublet of caput, cape, chef and chief.

- From Middle English heed, from Old English hēafod- (“main”), from Proto-West Germanic *haubida-, derived from the noun *haubid (“head”). Cognate with Saterland Frisian hööft-, West Frisian haad-, Dutch hoofd-, German Low German höövd-, German haupt-.


## Definition
### Noun
1. (people) To do with heads. 
2. (animals) To do with heads. 
3. The end of a table. 
4. (countable) The principal operative part of a machine or tool. 
5. (uncountable, countable) The foam that forms on top of beer or other carbonated beverages. 
6. (engineering) The end cap of a cylindrically-shaped pressure vessel. 
7. (geology) The uppermost part of a valley. 
8. (Britain, geology) Deposits near the top of a geological succession. 
9. (medicine) The end of an abscess where pus collects. 
10. (music) The headstock of a guitar. 
11. (nautical) A leading component. 
12. (Britain) A headland. 
13. The place of honour, or of command; the most important or foremost position; the front. 
14. (metonymically) Leader; chief; mastermind. 
15. (metonymically) A headmaster or headmistress. 
16. (music, slang, figuratively, metonymically) A person with an extensive knowledge of hip hop. 
17. A beginning or end, a protuberance. 
18. A component. 
19. Headway; progress. 
20. Topic; subject. 
21. (only in the singular) Denouement; crisis. 
22. (uncountable, countable) A buildup of fluid pressure, often quantified as pressure head. 
23. The difference in elevation between two points in a column of fluid, and the resulting pressure of the fluid at the lower point. 
24. More generally, energy in a mass of fluid divided by its weight. 
25. (slang, uncountable) Fellatio or cunnilingus; oral sex. 
26. (slang) The glans penis. 
27. (slang, countable) A heavy or habitual user of illicit drugs. 
28. (obsolete) Power; armed force. 
29. A surname from Middle English, from residence near a hilltop or the head of a river, or a byname for someone with an odd-looking head. 
30. (journalism) Short for headline.  

### Adjective
1. Of, relating to, or intended for the head. 
2. Foremost in rank or importance. 
3. Placed at the top or the front. 
4. Coming from in front. 

### Verb
1. (transitive) To be in command of. (See also head up.) 
2. (transitive) To come at the beginning or front of; to commence. 
3. (transitive) To strike with the head; as in soccer, to head the ball 
4. (intransitive) To move in a specified direction. 
5. (fishing) To remove the head from a fish. 
6. (intransitive) To originate; to spring; to have its course, as a river. 
7. (intransitive) To form a head. 
8. (transitive) To form a head to; to fit or furnish with a head. 
9. (transitive) To cut off the top of; to lop off. 
10. (transitive, obsolete) To behead; to decapitate. 
11. To go in front of. 
12. To get in the front of, so as to hinder or stop; to oppose. 
13. (by extension) To check or restrain. 
14. To set on the head. 

## Synonyms
[[point]] | [[lead]] | [[mind]] | [[top]] | [[pass]] | [[principal]] | [[arch]] | [[question]] | [[direct]] | [[guide]] | [[maneuver]] | [[steer]] | [[boss]] | [[brain]] | [[chief]] | [[psyche]] | [[nous]] | [[forefront]] | [[headway]] | [[heading]] | [[caput]] | [[straits]]