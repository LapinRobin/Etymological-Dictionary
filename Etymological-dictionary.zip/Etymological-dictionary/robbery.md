# robbery

## Etymology
- From Middle English robberie, robry, roberie, from Old French roberie, from the verb rober (“to steal; to pillage”) + -ie. Ultimately from unattested Frankish *raubōn. Synchronically analyzable as rob +‎ -ery. Compare Dutch roverij (“robbery”), Norwegian Bokmål røveri (“robbery”), German Räuberei (“robbery, banditry”).


## Definition
### Noun
1. The act or practice of robbing. 
2. (law) The offense of taking or attempting to take the property of another by force or threat of force. 

## Synonyms
