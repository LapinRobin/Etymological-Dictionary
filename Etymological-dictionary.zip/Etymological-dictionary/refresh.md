# refresh

## Etymology
- From Middle English refreshen, refreschen, refrisschen, from Old French refrescher (“to refresh”) (modern French rafraîchir), equivalent to re- +‎ fresh.


## Definition
### Verb
1. (transitive) To renew or revitalize. 
2. (intransitive) To become fresh again; to be revitalized. 
3. (computing, transitive, intransitive) To reload (a document, especially a webpage) and show any new changes. 
4. (computing, transitive, intransitive) To cause (a web browser or similar software) to refresh its display. 
5. To perform the periodic energizing required to maintain the contents of computer memory, the display luminance of a computer screen, etc. 
6. (intransitive, colloquial, dated) To take refreshment; to eat or drink. 

### Noun
1. The periodic energizing required to maintain the contents of computer memory, the display luminance of a computer screen, etc. 
2. (computing) The update of a display (in a web browser or similar software) to show the latest version of the data. 
3. The process of modernizing something. 

## Synonyms
[[review]]