# authority

## Etymology
- From Middle English auctorite, autorite (“authority, book or quotation that settles an argument”), from Old French auctorité, from Latin stem of auctōritās (“invention, advice, opinion, influence, command”), from auctor (“master, leader, author”). For the presence of the h, compare the etymology of author.


## Definition
### Noun
1. (uncountable) Power or right to make or enforce rules or give orders; or a position having such power or right. 
2. (plural) Persons, regarded collectively, who occupy official positions of power; police or law enforcement. 
3. (countable) A reliable, definitive source of information on a subject. 
4. (uncountable) Status as a trustworthy source of information, reputation for mastery or expertise; or claim to such status or reputation. 
5. (uncountable) Official permission; authorisation to act in some capacity on behalf of a ruling entity. 
6. (countable) A government-owned agency that runs a revenue-generating activity for public benefit. 

## Synonyms
[[office]] | [[agency]] | [[sanction]] | [[confidence]] | [[assurance]] | [[bureau]] | [[dominance]]