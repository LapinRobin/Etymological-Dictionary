# hold up

## Definition
### Verb
1. (intransitive, informal) To wait or delay. 
2. (transitive) To impede; detain. 
3. (transitive) To support or lift. 
4. (idiomatic) To withstand; to stand up to; to survive. 
5. (transitive, idiomatic) To fulfil or complete one's part of an agreement. 
6. (transitive, idiomatic) To rob at gunpoint. 
7. To keep up; not to fall behind; not to lose ground. 
8. (transitive) (Of an artistic work) To continue to be seen as good, to avoid seeming dated. 

## Synonyms
