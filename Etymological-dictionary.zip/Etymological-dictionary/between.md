# between

## Etymology
- From Middle English betwene, from Old English betwēonum (“between, among”, dative plural, literally “by the two, near both”), from Proto-Germanic *bi- (“be-”) + *twīhnaz (“two each”), corresponding to be- +‎ twain. Cognate with Scots between (“between”), Scots atween (“between”), Gothic 𐍄𐍅𐌴𐌹𐌷𐌽𐌰𐌹 (tweihnai, “two each”), Old English betweohs (“between”), Old English twinn (“double, twofold”). More at betwixt, twin.


## Definition
### Noun
1. A kind of needle, shorter than a sharp, with a small rounded eye, used for making fine stitches on heavy fabrics. 

## Synonyms
