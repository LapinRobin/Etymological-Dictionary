# desist

## Etymology
- From Middle French desister.


## Definition
### Verb
1. (transitive, intransitive, formal) To cease to proceed or act; to stop (often with from). 

## Synonyms
[[refrain]] | [[abstain]]