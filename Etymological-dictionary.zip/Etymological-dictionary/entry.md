# entry

## Etymology
- Inherited from Middle English entre, from Old French entree (feminine past participle of the verb entrer, Modern French entrée). From Latin intrō.


## Definition
### Noun
1. The act of entering. 
2. (uncountable) Permission to enter. 
3. A doorway that provides a means of entering a building. 
4. (law) The act of taking possession. 
5. (insurance) The start of an insurance contract. 
6. (Midlands) A passageway between terraced houses that provides a means of entering a back garden or yard. 
7. A small room immediately inside the front door of a house or other building, often having an access to a stairway and leading on to other rooms 
8. A small group formed within a church, especially Episcopal, for simple dinner and fellowship, and to help facilitate new friendships 
9. An item in a list, such as an article in a dictionary or encyclopedia. 
10. A record made in a log, diary or anything similarly organized; (computing) a datum in a database. 
11. (linear algebra) A term at any position in a matrix. 
12. The exhibition or depositing of a ship's papers at the customhouse, to procure licence to land goods; or the giving an account of a ship's cargo to the officer of the customs, and obtaining his permission to land the goods. 
13. (music) The point when a musician starts to play or sing; entrance. 
14. (hunting) The introduction of new hounds into a pack. 

## Synonyms
[[debut]] | [[submission]] | [[ingress]] | [[entree]] | [[entrance]] | [[introduction]] | [[incoming]]