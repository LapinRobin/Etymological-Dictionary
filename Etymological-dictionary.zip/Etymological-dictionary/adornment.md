# adornment

## Etymology
- adorn +‎ -ment


## Definition
### Noun
1. A decoration; that which adorns. 
2. The act of decorating. 

## Synonyms
