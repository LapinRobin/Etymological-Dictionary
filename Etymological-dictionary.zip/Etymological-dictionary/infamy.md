# infamy

## Etymology
- From late Middle English infamie, from Old French infamie, from Latin īnfāmia (“infamy”), from īnfāmis (“infamous”), from in- (“not”) + fāma (“fame, renown”). Displaced native Old English unhlīsa (literally “bad fame”).


## Definition
### Noun
1. The state of being infamous. 
2. The state of having a reputation as being evil. 
3. A reprehensible occurrence or situation. 
4. (law) A stigma attaching to a person's character that disqualifies them from being a witness. 

## Synonyms
[[opprobrium]]