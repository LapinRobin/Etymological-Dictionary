# tangle

## Etymology
- From Middle English tanglen, probably of North Germanic origin, compare Swedish taggla (“to disorder”), Old Norse þǫngull, þang (“tangle; seaweed”), see Etymology 2 below.

- Of North Germanic origin, such as Danish tang or Swedish tång, from Old Norse þongull, þang.  See also Norwegian tongul, Faroese tongul, Icelandic þöngull.


## Definition
### Verb
1. (transitive) To mix together or intertwine. 
2. (intransitive) To become mixed together or intertwined. 
3. (intransitive, figuratively) To enter into an argument, conflict, dispute, or fight. 
4. (transitive) To catch and hold. 

### Noun
1. A tangled twisted mass. 
2. A complicated or confused state or condition. 
3. An argument, conflict, dispute, or fight. 
4. (mathematics) A region of the projection of a knot such that the knot crosses its perimeter exactly four times. 
5. A form of art which consists of sections filled with repetitive patterns. 
6. Any large type of seaweed, especially a species of Laminaria. 
7. (in the plural) An instrument consisting essentially of an iron bar to which are attached swabs, or bundles of frayed rope, or other similar substances, used to capture starfishes, sea urchins, and other similar creatures living at the bottom of the sea. 
8. (Scotland) Any long hanging thing, even a lanky person. 

## Synonyms
[[sweep]] | [[knot]] | [[drag]] | [[mat]] | [[snarl]] | [[ravel]] | [[embroil]] | [[entangle]] | [[complication]]