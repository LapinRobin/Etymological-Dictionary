# reprehensible

## Etymology
- Borrowed from Late Latin reprehensibilis, from Latin reprehendo; equivalent to reprehend +‎ -ible.


## Definition
### Adjective
1. Blameworthy, censurable, guilty. 
2. Deserving of reprehension. 

### Noun
1. A reprehensible person; a villain. 

## Synonyms
[[wrong]] | [[deplorable]] | [[criminal]]