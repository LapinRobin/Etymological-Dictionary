# cockeyed

## Etymology
- cock +‎ eyed


## Definition
### Adjective
1. Having both eyes oriented inward, cross-eyed. 
2. Crooked or askew. 
3. (informal) Absurd, silly, or stupid; usually used in reference to ideas rather than people. 
4. Drunk. 

## Synonyms
[[wonky]] | [[awry]] | [[crooked]] | [[askew]] | [[lopsided]]