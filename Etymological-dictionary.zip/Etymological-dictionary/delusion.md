# delusion

## Etymology
- From Latin delusio.


## Definition
### Noun
1. A false belief that is resistant to confrontation with actual facts. 
2. The state of being deluded or misled, or process of deluding somebody. 
3. That which is falsely or delusively believed or propagated; false belief; error in belief. 
4. A fixed, false belief, that will not change, despite evidence to the contrary. 

## Synonyms
