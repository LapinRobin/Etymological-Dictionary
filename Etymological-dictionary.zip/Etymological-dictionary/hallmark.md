# hallmark

## Etymology
- 1721. hall +‎ mark, from Goldsmiths' Hall in London, the site of the assay office, official stamp of purity in gold and silver articles. The general sense of "mark of quality" first recorded 1864. Use as a verb from 1773.


## Definition
### Noun
1. A distinguishing characteristic. 
2. An official marking made by a trusted party, usually an assay office, on items made of precious metals. 
3. A surname. 

### Verb
1. To provide or stamp with a hallmark. 

## Synonyms
[[earmark]] | [[trademark]] | [[authentication]]