# shyster

## Etymology
- US origin, 19th century. The etymology of the word is not generally agreed upon. The Oxford English Dictionary describes it as "of obscure origin," possibly deriving from a historical sense of shy meaning "disreputable", equivalent to shy +‎ -ster. Other sources suggest the word derives from the German Scheißer (“incompetent worthless person”), from scheißen (“to defecate”), probably influenced by -ster. Not related to shylock.


## Definition
### Noun
1. Someone who acts in a disreputable, unethical, or unscrupulous way, especially in the practice of law and politics. 

### Verb
1. (intransitive) To act in a disreputable, unethical, or unscrupulous way, especially in the practice of law and politics. 
2. (transitive) To exploit (someone or something) in this way. 

## Synonyms
