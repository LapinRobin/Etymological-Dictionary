# rarely

## Etymology
- From rare +‎ -ly.


## Definition
### Adverb
1. Not occurring at a regular interval; seldom; not often. 
2. Unusually well; excellently. 
3. To a rare degree; very. 

## Synonyms
[[seldom]]