# intimation

## Etymology
- From Middle French intimation, from Latin intimatio.


## Definition
### Noun
1. The act of intimating. 
2. The thing intimated. 
3. Announcement; declaration. 
4. A hint; an obscure or indirect suggestion or notice; a remote or ambiguous reference. 

## Synonyms
[[breath]] | [[hint]] | [[inkling]]