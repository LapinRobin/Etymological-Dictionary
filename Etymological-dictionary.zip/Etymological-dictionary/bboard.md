# bboard

## Etymology
- Shortening.


## Definition
### Noun
1. bulletin board (electronic message system) 

## Synonyms
