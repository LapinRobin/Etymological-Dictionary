# mobster

## Etymology
- mob +‎ -ster


## Definition
### Noun
1. A member of a mob or Mafia. 

## Synonyms
