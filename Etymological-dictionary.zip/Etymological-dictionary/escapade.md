# escapade

## Etymology
- Borrowed from French escapade (“the act of escaping; a trick”), itself borrowed from Old Spanish escapada, from escapar (“to escape”), from Vulgar Latin *excappāre.


## Definition
### Noun
1. A daring or adventurous act; an undertaking which goes against convention. 

## Synonyms
[[adventure]] | [[lark]]