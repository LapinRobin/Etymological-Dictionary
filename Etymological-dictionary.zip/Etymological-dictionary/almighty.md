# almighty

## Etymology
- From Middle English almyghty, almighty, from Old English ælmihtiġ (“all-powerful”), from Proto-Germanic *alamahtīgaz, equivalent to al- +‎ might +‎ -y.


## Definition
### Adjective
1. (sometimes postpositive) Unlimited in might; omnipotent; all-powerful 
2. (slang) Great; extreme; terrible. 
3. (by extension) Having very great power, influence, etc. 

### Adverb
1. (slang, colloquial) Extremely; thoroughly. 

### Noun
1. God, the supreme being. 

## Synonyms
[[divine]] | [[lord]] | [[omnipotent]] | [[powerful]] | [[creator]]