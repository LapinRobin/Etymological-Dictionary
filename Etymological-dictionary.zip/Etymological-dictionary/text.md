# text

## Etymology
- From Middle English text, from Old French texte (“text”), from Medieval Latin textus (“the Scriptures, text, treatise”), from Latin textus (“style or texture of a work”), perfect passive participle of texō (“I weave”). Cognate to English texture.


## Definition
### Noun
1. A writing consisting of multiple glyphs, characters, symbols or sentences. 
2. A book, tome or other set of writings. 
3. (colloquial) A brief written message transmitted between mobile phones. 
4. (computing) Data which can be interpreted as human-readable text. 
5. A verse or passage of Scripture, especially one chosen as the subject of a sermon, or in proof of a doctrine. 
6. (by extension) Anything chosen as the subject of an argument, literary composition, etc. 
7. (printing) A style of writing in large characters; also, a kind of type used in printing. 

### Verb
1. (transitive) To send a text message to; i.e. to transmit text using the Short Message Service (SMS), or a similar service, between communications devices, particularly mobile phones. 
2. (intransitive) To send and receive text messages. 
3. (dated) To write in large characters, as in text hand. 

## Synonyms
