# sudden

## Etymology
- From Middle English sodeyn, sodain, from Anglo-Norman sodein, from Old French sodain, subdain (“immediate, sudden”), from Vulgar Latin *subitānus (“sudden”), from Latin subitāneus (“sudden”), from subitus (“sudden", literally, "that which has come stealthily”), originally the past participle of subīre (“to come or go stealthily”), from sub (“under”) + īre (“go”). Doublet of subitaneous. Displaced native Old English fǣrlīċ.


## Definition
### Adjective
1. Happening quickly and with little or no warning. 
2. (obsolete) Hastily prepared or employed; quick; rapid. 
3. (obsolete) Hasty; violent; rash; precipitate. 

### Adverb
1. (poetic) Suddenly. 

### Noun
1. (obsolete) An unexpected occurrence; a surprise. 

## Synonyms
[[sharp]] | [[abrupt]] | [[unforeseen]] | [[explosive]] | [[unexpected]]