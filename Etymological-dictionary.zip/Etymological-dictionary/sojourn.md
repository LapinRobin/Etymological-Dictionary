# sojourn

## Etymology
- From Middle English sojourne (noun) and sojournen (verb), from Old French sojor, sojorner (modern séjour, séjourner), from (assumed) Vulgar Latin *subdiurnāre, from Latin sub- (“under, a little over”) + Late Latin diurnus (“lasting for a day”), from Latin dies (“day”).


## Definition
### Noun
1. A short stay somewhere. 
2. A temporary residence. 

### Verb
1. (intransitive) To reside somewhere temporarily, especially as a guest or lodger. 

## Synonyms
