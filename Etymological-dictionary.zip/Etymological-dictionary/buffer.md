# buffer

## Etymology
- buffer (plural buffers)

- Agent noun from obsolete verb buff (“make a dull sound when struck”) (mid-16c.), from Old French buffe (“blow”).

- buffer (plural buffers)


## Definition
### Noun
1. A machine with rotary brushes, passed over a hard floor to clean it. 
2. A machine for polishing shoes and boots. 
3. (chemistry) A solution used to stabilize the pH (acidity) of a liquid. 
4. (computing) A portion of memory set aside to store data, often before it is sent to an external device or as it is received from an external device. 
5. (mechanical) Anything used to maintain slack or isolate different objects. 
6. (telecommunications) A routine or storage medium used to compensate for a difference in rate of flow of data, or time of occurrence of events, when transferring data from one device to another. 
7. (rail transport) A device on trains and carriages designed to cushion the impact between them. 
8. (rail transport) The metal barrier to help prevent trains from running off the end of the track. 
9. An isolating circuit, often an amplifier, used to minimize the influence of a driven circuit on the driving circuit. 
10. (politics, international relations) A buffer zone (such as a demilitarized zone) or a buffer state. 
11. (figuratively) A gap that isolates or separates two things. 
12. (UK, nautical, slang) The chief boatswain's mate. 
13. (colloquial) A good-humoured, slow-witted fellow, usually an elderly man. 

### Verb
1. To use a buffer or buffers; to isolate or minimize the effects of one thing on another. 
2. (computing) To store data in memory temporarily. 
3. (chemistry) To maintain the acidity of a solution near a chosen value by adding an acid or a base. 

## Synonyms
[[pilot]] | [[cushion]] | [[fender]] | [[soften]]