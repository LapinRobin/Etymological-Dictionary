# parrot

## Etymology
- First attested in 1525. From Middle French perrot, either a diminutive of Pierre or a shortened form of perroquet (whence also parakeet). Compare French pierrot and Occitan parrat. A number of origins have been suggested for perroquet, such as Spanish periquito and Italian parrocchetto. The relationship between these various words is disputed. Replaced earlier popinjay.


## Definition
### Noun
1. A kind of bird, many species of which are colourful and able to mimic human speech, of the order Psittaciformes or (narrowly) of the family Psittacidae. 
2. (figuratively) A parroter; a person who repeats the words or ideas of others. 
3. (archaic) A puffin. 
4. (geology, obsolete) Channel coal. 
5. (aviation, slang) A transponder. 
6. A surname transferred from the given name. 

### Verb
1. (transitive) To repeat (exactly what has just been said) without necessarily showing understanding, in the manner of a parrot. 

## Synonyms
