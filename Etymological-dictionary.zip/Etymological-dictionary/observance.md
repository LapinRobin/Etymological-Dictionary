# observance

## Etymology
- From Old French observance, from Latin observantia. Equivalent of observe +‎ -ance.


## Definition
### Noun
1. The practice of complying with a law, custom, command or rule. 
2. The custom of celebrating a holiday or similar occasion. 
3. Observation or the act of watching. 
4. (religion) A rule governing a religious order, especially in the Roman Catholic church. 
5. That which is to be observed. 
6. Reverence; homage. 

## Synonyms
[[notice]] | [[ceremony]] | [[observation]]