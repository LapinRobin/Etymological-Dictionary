# betrothal

## Etymology
- betroth +‎ -al


## Definition
### Noun
1. The act of betrothing. 
2. The fact of being betrothed; a mutual promise, engagement, or contract for a future marriage between two people. 

## Synonyms
[[engagement]] | [[troth]]