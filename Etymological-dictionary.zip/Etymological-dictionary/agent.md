# agent

## Etymology
- From Latin agēns, present active participle of agere (“to drive, lead, conduct, manage, perform, do”).


## Definition
### Noun
1. One who exerts power, or has the power to act 
2. One who acts for, or in the place of, another (the principal), by that person's authority; someone entrusted to do the business of another 
3. A person who looks for work for another person 
4. Someone who works for an intelligence agency 
5. An active power or cause or substance; something (e.g. biological, chemical, thermal, etc.) that has the power to produce an effect 
6. (computing) In the client-server model, the part of the system that performs information preparation and exchange on behalf of a client or server. Especially in the phrase “intelligent agent” it implies some kind of autonomous process which can communicate with other agents to perform some collective task on behalf of one or more humans. 
7. (grammar) The participant of a situation that carries out the action in this situation, e.g. "the boy" in the sentences "The boy kicked the ball" and "The ball was kicked by the boy". 
8. (gambling) A cheat who is assisted by dishonest casino staff. 
9. A surname. 

## Synonyms
[[factor]] | [[broker]]