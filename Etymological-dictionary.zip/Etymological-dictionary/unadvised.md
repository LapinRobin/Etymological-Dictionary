# unadvised

## Etymology
- From Middle English unavised; equivalent to un- +‎ advised.


## Definition
### Adjective
1. Not having received advice. 
2. (dated) Ill-advised; imprudent; rash. 

## Synonyms
