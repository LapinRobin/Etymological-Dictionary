# imminent

## Etymology
- From the present participle of Latin imminēre (“to overhang”), from mineō ("to project, overhang"), related to minae (English menace) and mons (English mount). Compare with eminent.


## Definition
### Adjective
1. about to happen, occur, or take place very soon, especially of something which won't last long. 

## Synonyms
[[close]] | [[impending]] | [[at hand]]