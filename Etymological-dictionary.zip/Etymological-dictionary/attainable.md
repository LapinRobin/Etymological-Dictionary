# attainable

## Etymology
- From attain +‎ -able.


## Definition
### Adjective
1. Able to be accomplished, achieved, or obtained. 

### Noun
1. Something that can be attained. 

## Synonyms
[[possible]]