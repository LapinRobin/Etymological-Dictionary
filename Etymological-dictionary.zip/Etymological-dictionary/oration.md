# oration

## Etymology
- Borrowed from Latin ōrātiō, ōrātiōnem, from ōrō (“I orate”) + -ātiō (“action (nominalizer)”). Cognate with and doublet of orison.


## Definition
### Noun
1. A formal, often ceremonial speech. 
2. (humorous) A lengthy speech or argument in a private setting. 
3. (Catholicism) A specific form of short, solemn prayer said by the president of the liturgical celebration on behalf of the people. 

### Verb
1. To deliver an oration; to speak. 

## Synonyms
