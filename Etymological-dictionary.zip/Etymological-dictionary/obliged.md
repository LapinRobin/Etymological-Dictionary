# obliged

## Definition
### Adjective
1. Under an obligation to do something. 
2. Grateful or indebted because of a favor done. 

## Synonyms
