# instigator

## Etymology
- From Latin īnstīgātor (“stimulator”), from īnstīgāre (present infinitive of īnstīgō (“to incite, set on, stimulate, rouse or urge”), possibly from Proto-Indo-European *(s)teyg- (“to be sharp, to stab; to puncture; to goad”)) + -or (from -ō (“suffix forming masculine agent nouns”), from Proto-Indo-European *-h₃onh₂- (“suffix forming nouns denoting authority or burden”)); cognate with French instigateur.


## Definition
### Noun
1. A person who intentionally instigates, incites, or starts something, especially one that creates trouble. 

## Synonyms
[[firebrand]]