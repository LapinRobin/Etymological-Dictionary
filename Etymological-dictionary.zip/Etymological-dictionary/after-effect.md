# after-effect

## Definition
### Noun
1. An effect; especially, one that is experienced only after a delay, or only in the long term. 

## Synonyms
