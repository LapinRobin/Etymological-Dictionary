# minute

## Etymology
- From Middle English mynute, minute, mynet, from Old French minute, from Medieval Latin minūta (“60th of an hour; note”). Doublet of menu.

- Borrowed from Latin minūtus (“small", "petty”), perfect passive participle of minuō (“make smaller”).


## Definition
### Noun
1. A unit of time equal to sixty seconds (one-sixtieth of an hour). 
2. (informal) A short but unspecified time period. 
3. A unit of angle equal to one-sixtieth of a degree. 
4. (chiefly in the plural, minutes) A (usually formal) written record of a meeting or a part of a meeting. 
5. A unit of purchase on a telephone or other similar network, especially a cell phone network, roughly equivalent in gross form to sixty seconds' use of the network. 
6. A point in time; a moment. 
7. A nautical or a geographic mile. 
8. An old coin, a half farthing. 
9. (obsolete) A very small part of anything, or anything very small; a jot; a whit. 
10. (architecture) A fixed part of a module. 
11. (slang, US, Canada, dialectal) A while or a long unspecified period of time 

### Verb
1. (transitive) Of an event, to write in a memo or the minutes of a meeting. 
2. To set down a short sketch or note of; to jot down; to make a minute or a brief summary of. 

### Adjective
1. Very small. 
2. Very careful and exact, giving small details. 

## Synonyms
[[bit]] | [[hour]] | [[moment]] | [[second]] | [[little]] | [[small]] | [[narrow]] | [[careful]] | [[instant]] | [[infinitesimal]] | [[atomic]]