# hinge

## Etymology
- From Middle English henge, from Old English *henġ (“hinge”), compare Old English henġe- in henġeclif (“overhanging cliff”), Old English henġen (“hanging; that upon which a thing is hung”), from Proto-West Germanic *hangiju. Akin to Scots heenge (“hinge”), Saterland Frisian Hänge (“hinge”), Dutch heng (“door handle”), Low German henge (“a hook, hinge, handle”), Middle Dutch henghe, hanghe (“a hook, hinge, handle”), Scots hingel (“any attachment by which something is hung or fastened”), Dutch hengel (“hook”), geheng (“hinge”), hengsel (“handle”), dialectal German Hängel (“hook, joint”), German Henkel (“handle, hook”), Old English hōn (“to hang”), hangian (“to cause to hang, hang up”). More at hang.


## Definition
### Noun
1. A jointed or flexible device that allows the pivoting of a door etc. 
2. A naturally occurring joint resembling such hardware in form or action, as in the shell of a bivalve. 
3. A stamp hinge, a folded and gummed paper rectangle for affixing postage stamps in an album. 
4. A principle, or a point in time, on which subsequent reasonings or events depend. 
5. (statistics) The median of the upper or lower half of a batch, sample, or probability distribution. 
6. One of the four cardinal points, east, west, north, or south. 
7. A movement that presents itself as rotation when an off-centre fixed point is taken into account. 
8. A surname. 

### Verb
1. (transitive) To attach by, or equip with a hinge. 
2. (intransitive, with on or upon) To depend on something. 
3. (transitive, archaeology) The breaking off of the distal end of a knapped stone flake whose presumed course across the face of the stone core was truncated prematurely, leaving not a feathered distal end but instead the scar of a nearly perpendicular break. 
4. (obsolete) To bend. 
5. To move or already be positioned in such a fashion that it presents itself as rotation when an off-centre fixed point is taken into account. 

## Synonyms
