# scar

## Etymology
- From Middle English scar, scarre, a conflation of Old French escare (“scab”) (from Late Latin eschara, from Ancient Greek ἐσχάρα (eskhára, “scab left from a burn”), and thus a doublet of eschar) and Middle English skar (“incision, cut, fissure”) (from Old Norse skarð (“notch, chink, gap”), from Proto-Germanic *skardaz (“gap, cut, fragment”)). Akin to Old Norse skor (“notch, score”), Old English sċeard (“gap, cut, notch”). More at shard.

- From Middle English scarre, skarr, skerre, sker, a borrowing from Old Norse sker (“an isolated rock in the sea; skerry”). Cognate with Icelandic sker, Norwegian skjær, Swedish skär, Danish skær, German Schäre. Doublet of skerry.

- From Latin scarus (“a kind of fish”), from Ancient Greek σκάρος (skáros, “parrot wrasse, Sparisoma cretense, syn. Scarus cretensis”).


## Definition
### Noun
1. A permanent mark on the skin, sometimes caused by the healing of a wound. 
2. (by extension) A permanent negative effect on someone's mind, caused by a traumatic experience. 
3. Any permanent mark resulting from damage. 
4. A cliff or rock outcrop. 
5. A rock in the sea breaking out from the surface of the water. 
6. A bare rocky place on the side of a hill or mountain. 
7. A marine food fish, the scarus or parrotfish (family Scaridae). 

### Verb
1. (transitive) To mark the skin permanently. 
2. (intransitive) To form a scar. 
3. (transitive, figuratively) To affect deeply in a traumatic manner. 

## Synonyms
[[mark]] | [[pit]] | [[scratch]] | [[scrape]]