# permit

## Etymology
- From Middle English permitten, borrowed from Middle French permettre, from Latin permittō (“give up, allow”), from per (“through”) + mittō (“send”).

- An irregular borrowing from Spanish palometa, probably from a Doric variant of Ancient Greek πηλαμύς (pēlamús, “young tuna”).


## Definition
### Verb
1. (transitive) To allow (something) to happen, to give permission for. 
2. (transitive) To allow (someone) to do something; to give permission to. 
3. (intransitive) To allow for, to make something possible. 
4. (intransitive) To allow, to admit (of). 
5. (transitive, pronounced like noun) To grant formal authorization for (something). 
6. (transitive, pronounced like noun) To attempt to obtain or succeed in obtaining formal authorization for (something). 
7. (now archaic, rare) To hand over, resign (something to someone). 

### Noun
1. An artifact or document rendering something allowed or legal. 
2. A learner's permit. 
3. (obsolete) Formal permission. 
4. A pompano of the species Trachinotus falcatus. 

## Synonyms
[[let]] | [[license]] | [[countenance]] | [[allow]] | [[permission]]