# affirmative

## Etymology
- From Middle English affirmative, affirmatyve, from Old French affirmatif, from Latin affirmativus, from affirmare (“to assert”).


## Definition
### Adjective
1. pertaining to truth; asserting that something is; affirming 
2. pertaining to any assertion or active confirmation that favors a particular result 
3. positive 
4. Confirmative; ratifying. 
5. dogmatic 
6. (logic) Expressing the agreement of the two terms of a proposition. 
7. (algebra) positive; not negative 

### Noun
1. Yes; an answer that shows agreement or acceptance. 
2. (grammar) An answer that shows agreement or acceptance. 
3. (obsolete) An assertion. 

## Synonyms
[[pro]] | [[positive]] | [[optimistic]] | [[favorable]]