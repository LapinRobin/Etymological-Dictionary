# overlap

## Etymology
- over- +‎ lap


## Definition
### Verb
1. To extend over and partly cover something. 
2. To have an area, range, character or function in common. 
3. (mathematics) Of sets: to have some elements in common. 
4. (genetics) To have some similar nucleotide sequences. 

### Noun
1. Something that overlaps or is overlapped 
2. (rugby) a situation in the game where an attacking line has more players in it than the defensive line coming to meet it. The attacking side may exploit the overlap by using their superior numbers to break the opposition's defensive line. If attackers outnumber defenders by more than one player this is often termed a two man overlap or three man overlap, etc. If the attacking side fails to break through usually due to poor execution, they are said to waste an overlap. 
3. (insurance, pensions) The payment of a spouse's or other dependant's annuity benefits concurrently with the member's benefits, on death of the member during the guarantee period. 

## Synonyms
[[lap]] | [[convergence]] | [[intersection]]