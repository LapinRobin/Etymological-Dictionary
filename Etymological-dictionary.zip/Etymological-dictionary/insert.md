# insert

## Etymology
- From Latin insertus, past participle of inserō, from in- +‎ serō (“join, bind together, connect, entwine, interweave”), ultimately from Proto-Indo-European *ser- (“to bind, put together, to line up”).


## Definition
### Verb
1. (transitive) To put in between or into. 

### Noun
1. An image inserted into text. 
2. A promotional or instructive leaflet inserted into a magazine, newspaper, tape or disk package, etc. 
3. A mechanical component inserted into another. 
4. (linguistics) An expression, such as "please" or an interjection, that may occur at various points in an utterance. 
5. (genetics) A sequence of DNA inserted into another DNA molecule. 
6. (television) A pre-recorded segment included as part of a live broadcast. 
7. (film, television) A close-up shot used to draw attention to a particular element of a larger scene. 
8. (audio effects) A plug-in that adds an effect to an audio track. 
9. A key that when pressed switches between the overtype mode and the insert mode of a computer. 

## Synonyms
[[introduce]] | [[enter]] | [[tuck]] | [[enclose]] | [[inset]]