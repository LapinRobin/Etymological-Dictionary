# tilt

## Etymology
- From Middle English tilte, from Old English tyltan (“to be unsteady”), related to the adjective tealt (“unsteady”), from Proto-Germanic *taltaz, ultimately from Proto-Indo-European *del-, *dul- (“to shake, hesitate”), see also Dutch touteren (“to tremble”), North Frisian talt, tolt (“unstable, shaky”).. Cognate with Icelandic tölt (“an ambling place”).

- From Middle English telte, tield, teld, from Old English teld (“tent”), from Proto-West Germanic *teld, from Proto-Germanic *teldą (“tent”). Perhaps influenced by Middle Low German telt, or Danish telt. Cognates include German Zelt (“tent”), Old Norse tjald (“tent”) (whence also archaic Danish tjæld (“tent”)). More at teld.


## Definition
### Verb
1. (transitive) To slope or incline (something); to slant. 
2. (intransitive) To be at an angle. 
3. (intransitive, jousting) To charge (at someone) with a lance. 
4. (transitive) To point or thrust a weapon at. 
5. (transitive) To point or thrust (a weapon). 
6. To forge (something) with a tilt hammer. 
7. (pinball, of a machine) To intentionally let the ball fall down to the drain by disabling flippers and most targets, done as a punishment to the player when the machine is nudged too violently or frequently. 
8. (poker, video games) To play worse than usual (often as a result of previous bad luck or losses). 
9. (transitive) To cover with a tilt, or awning. 

### Noun
1. A slope or inclination. 
2. The inclination of part of the body, such as backbone, pelvis, head, etc. 
3. (photography) The controlled vertical movement of a camera, or a device to achieve this. 
4. A jousting contest. (countable) 
5. An attempt at something, such as a tilt at public office. 
6. A thrust, as with a lance. 
7. A tilt hammer. 
8. A canvas covering for carts, boats, etc. 
9. Any covering overhead; especially, a tent. 

## Synonyms
[[list]] | [[pitch]] | [[rock]] | [[lean]] | [[shift]] | [[angle]] | [[tip]] | [[argument]] | [[sway]] | [[cant]] | [[contention]] | [[controversy]] | [[inclination]] | [[careen]] | [[wobble]] | [[leaning]]