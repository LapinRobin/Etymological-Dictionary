# collocate

## Etymology
- Borrowed from Latin collocatum, supine of collocō. Doublet of couch.


## Definition
### Verb
1. (linguistics, translation studies) (said of certain words) To be often used together, form a collocation; for example strong collocates with tea. 
2. To arrange or occur side by side. 
3. (obsolete, transitive) To set or place; to station. 

### Noun
1. (linguistics) A component word of a collocation; a word that collocates with another. 

### Adjective
1. (obsolete) Set; placed. 

## Synonyms
[[lump]] | [[chunk]]