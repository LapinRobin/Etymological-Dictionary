# fusion

## Etymology
- 1555, from Middle French fusion, from Latin fūsiōnem (the accusative of fūsiō), from fusus, past participle of fundō (“I pour, I melt”) (see also found). Doublet of foison.


## Definition
### Noun
1. (physics) A nuclear reaction in which nuclei combine to form more massive nuclei with the concomitant release of energy. 
2. (music) A style of music that blends disparate genres; especially different types of jazz and reggae. 
3. A style of cooking that combines ingredients and techniques from different countries or cultures 
4. The act of melting or liquefying something by heating it. 
5. (genetics) The result of the hybridation of two genes which originally coded for separate proteins. 
6. (cytology) The process by which two distinct lipid bilayers merge their hydrophobic core, resulting in one interconnected structure. 
7. (fiction) The act of two characters merging into one, typically more powerful, being; or the merged being itself. 

### Verb
1. (nonstandard) to combine; to fuse 

## Synonyms
[[coalition]] | [[merger]]