# morbid

## Etymology
- From Latin morbidus (“diseased”), from morbus (“sickness”), itself from the root of morī (“to die”) or directly from Proto-Indo-European *mer- (“to rub, pound, wear away”).


## Definition
### Adjective
1. (originally) Of, or relating to disease. 
2. (by extension) Taking an interest in unhealthy or unwholesome subjects such as death, decay, disease. 
3. Suggesting the horror of death; macabre or ghoulish. 
4. Grisly or gruesome. 

## Synonyms
[[offensive]] | [[pathological]]