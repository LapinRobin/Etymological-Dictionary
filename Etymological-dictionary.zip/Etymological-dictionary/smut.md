# smut

## Etymology
- From Middle English smutten (“to defile, debase”), related to German Schmutz (“filth, dirt, smut”) and schmutzen (“to make dirty, stain”). This etymology is incomplete. You can help Wiktionary by elaborating on the origins of this term. Doublet of schmutz.


## Definition
### Noun
1. (uncountable) Soot. 
2. (countable) A flake of ash or soot. 
3. (uncountable) Sexually vulgar material; something that is sexual in a dirty way; pornographic material. 
4. (uncountable) Obscene language; ribaldry; obscenity. 
5. Any of a range of fungi, mostly Ustilaginomycetes, that cause plant disease in grasses, including cereal crops; the disease so caused. 
6. (mining) Bad, soft coal containing earthy matter, found in the immediate locality of faults. 

### Verb
1. (transitive, intransitive) To stain (or be stained) with soot or other dirt. 
2. (transitive) To taint (grain, etc.) with the smut fungus. 
3. (intransitive) To become tainted by the smut fungus. 
4. (transitive) To clear of the smut fungus. 

## Synonyms
[[soot]]