# apocalypse

## Etymology
- From Middle English apocalips, from Latin apocalypsis, from Ancient Greek ἀποκάλυψις (apokálupsis, “revelation”), literally meaning "uncovering", from ἀπό (apó, “back, away from”) and καλύπτω (kalúptō, “I cover”). The sense evolution to "catastrophe, end of the world" stems from the depiction of such events in the biblical Book of Revelation, also called the Apocalypse of (i.e. Revelation to) John.


## Definition
### Noun
1. A revelation, especially of supernatural events. 
2. (Christianity) The unveiling of events prophesied in the Revelation; the second coming and the end of life on Earth; global destruction. 
3. (Christianity) The Book of Revelation. 
4. A disaster; a cataclysmic event; destruction or ruin. 
5. (countable, biblical) The written account of a revelation of hidden things given by God to a chosen prophet. 
6. (Christianity) Revelation (last book of the Bible, composed of twenty-two chapters, which narrates the end of times) 

## Synonyms
[[revelation]]