# pipe dream

## Etymology
- From the fantasies experienced when smoking an opium pipe. First attested in the 1800s; surely not a direct reflex of Old English pīpdrēam (“the sound or music of a pipe”).


## Definition
### Noun
1. (idiomatic) A plan, desire, or idea that will not likely work; a near impossibility. 

## Synonyms
