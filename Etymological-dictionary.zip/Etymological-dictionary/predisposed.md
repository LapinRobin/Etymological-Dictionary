# predisposed

## Etymology
- pre- +‎ disposed


## Definition
### Adjective
1. Inclined. 
2. Made susceptible to. 

## Synonyms
[[susceptible]]