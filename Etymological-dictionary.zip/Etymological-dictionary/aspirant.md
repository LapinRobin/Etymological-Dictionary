# aspirant

## Etymology
- Borrowed from French aspirant.


## Definition
### Noun
1. Someone who aspires to high office, etc. 

### Adjective
1. Seeking advancement. 
2. Striving for recognition. 

## Synonyms
[[ambitious]] | [[aspiring]] | [[wannabe]] | [[hopeful]]