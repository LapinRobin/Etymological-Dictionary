# horseplay

## Etymology
- A compound of horse +‎ play, possibly from observation of boisterous horses playing, or from its attributive sense "strong, big or coarse".


## Definition
### Noun
1. Rough or rowdy play that can often result in unintentional physical harm. 

### Verb
1. To engage in horseplay. 

## Synonyms
