# errand

## Etymology
- From Middle English erande, erende, from Old English ǣrende, from Proto-West Germanic *ārundī (“message, errand”).


## Definition
### Noun
1. (literary or archaic) A mission or quest. 
2. A mundane mission of no great consequence, concerning household or business affairs (dropping items by, doing paperwork, going to a friend's house, etc.) 
3. The purpose of such a journey. 
4. An oral message trusted to a person for delivery. 

### Verb
1. (transitive) To send someone on an errand. 
2. (intransitive) To go on an errand. 

## Synonyms
