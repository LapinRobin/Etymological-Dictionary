# dislocation

## Etymology
- Middle English, from Old French, a borrowing from Medieval Latin dislocātiō, delocatio


## Definition
### Noun
1. The act of displacing, or the state of being displaced. 
2. (geology) The displacement of parts of rocks or portions of strata from the situation which they originally occupied. 
3. The act of dislocating, or putting out of joint; also, the condition of being thus displaced. 
4. (materials science) A linear defect in a crystal lattice. Because dislocations can shift within the crystal lattice, they tend to weaken the material, compared to a perfect crystal. 
5. (grammar) A sentence structure in which a constituent that could otherwise be either an argument or an adjunct of a clause occurs outside of and adjacent to the clause boundaries. 

## Synonyms
[[breakdown]] | [[disruption]]