# possible

## Etymology
- From Middle English possible, from Old French possible, from Latin possibilis (“possible”), from posse, possum (“to be able”); see power. Displaced Old English mihtlīċ, which was cognate with Dutch mogelijk (“possible”) and German möglich (“possible”).


## Definition
### Adjective
1. (usually not comparable) Able but not certain to happen; neither inevitable nor impossible. 
2. (comparable) Capable of being done or achieved; feasible. 
3. Being considered, e.g. for a position. 
4. Apparently valid, likely, plausible. 

### Noun
1. A possible one. 
2. (colloquial, rare) A possible choice, notably someone being considered for a position. 
3. (rare) A particular event that may happen. 

## Synonyms
[[contingent]] | [[potential]] | [[feasible]] | [[viable]] | [[latent]] | [[doable]] | [[practicable]] | [[attainable]]