# small

## Etymology
- From Middle English smal, from Old English smæl (“small, narrow, slender”), from Proto-Germanic *smalaz (“small”), from Proto-Indo-European *(s)mal-, *(s)mel- (“small, mean, malicious”). Cognate with Scots smal; sma (“small”); West Frisian smel (“narrow”); Dutch smal (“narrow”); German schmal (“narrow, small”); Danish, Norwegian, Swedish smal (“narrow; thin; slender”); Latin malus (“bad”); Russian ма́лый (mályj, “small”).


## Definition
### Adjective
1. Not large or big; insignificant; few in number. 
2. (figuratively) Young, as a child. 
3. (writing, incomparable) Minuscule or lowercase, referring to written or printed letters. 
4. Humiliated or insignificant. 
5. Evincing little worth or ability; not large-minded; paltry; mean. 
6. Not prolonged in duration; not extended in time; short. 
7. Synonym of little (“of an industry or institution(s) therein: operating on a small scale, unlike larger counterparts”) 
8. (archaic) Slender, gracefully slim. 
9. (especially clothing, food or drink) That is small (the manufactured size). 

### Adverb
1. In a small fashion 
2. In or into small pieces. 
3. (obsolete) To a small extent. 
4. (obsolete) In a low tone; softly. 

### Noun
1. (uncountable, especially clothing, food or drink) One of several common sizes to which an item may be manufactured. 
2. (countable, especially clothing, food or drink) An item labelled or denoted as being that size. 
3. (countable, especially with respect to clothing) One who fits an item of that size. 
4. (countable, rare) Any part of something that is smaller or slimmer than the rest, now usually with anatomical reference to the back. 
5. A surname. 

### Verb
1. (obsolete, transitive) To make little or less. 
2. (intransitive) To become small; to dwindle. 

## Synonyms
[[mean]] | [[humble]] | [[fine]] | [[minute]] | [[low]] | [[tight]] | [[modest]] | [[little]] | [[minor]] | [[soft]] | [[moderate]] | [[petty]] | [[inferior]] | [[narrow]] | [[least]] | [[young]] | [[dwarf]] | [[wee]] | [[diminutive]] | [[stingy]] | [[slender]] | [[limited]] | [[micro]] | [[slim]] | [[tiny]] | [[minuscule]] | [[miniscule]] | [[puny]] | [[elfin]] | [[petite]] | [[lowly]] | [[immature]] | [[miniature]] | [[insignificant]] | [[lesser]] | [[peanut]] | [[infinitesimal]] | [[atomic]] | [[midget]] | [[lilliputian]] | [[bantam]] | [[miserly]]