# inviting

## Definition
### Adjective
1. Alluring; tempting; attractive. 

### Noun
1. invitation 

## Synonyms
[[tantalizing]]