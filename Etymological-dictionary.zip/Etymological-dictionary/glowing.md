# glowing

## Definition
### Noun
1. The action of the verb glow. 

### Adjective
1. That glows or glow. 
2. (figuratively) Full of praise. 

## Synonyms
[[bright]] | [[glow]] | [[enthusiastic]] | [[aglow]] | [[luminous]] | [[lambent]] | [[lucent]] | [[radiance]]