# commence

## Etymology
- From Middle English commencen, comencen (also as contracted comsen, cumsen), from Anglo-Norman comencer, from Vulgar Latin *cominitiāre, formed from Latin com- + initiō (whence English initiate).


## Definition
### Verb
1. (intransitive) To begin, start. 
2. (transitive) To begin to be, or to act as. 
3. (UK, intransitive, dated) To take a degree at a university. 

## Synonyms
[[get]] | [[begin]] | [[start]] | [[set out]]