# accidentally

## Etymology
- accidental +‎ -ly


## Definition
### Adverb
1. In an accidental manner; by chance, unexpectedly. 
2. Unintentionally. 

## Synonyms
[[incidentally]]