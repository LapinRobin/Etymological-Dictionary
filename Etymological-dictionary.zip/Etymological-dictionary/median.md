# median

## Etymology
- Borrowed from Middle French median, from Latin mediānus (“of or pertaining to the middle”, adjective), from medius (“middle”) (see medium), from Proto-Indo-European *médʰyos (“middle”). Doublet of mean and mizzen. Cognate with Old English midde, middel (“middle”). More at middle.


## Definition
### Noun
1. (anatomy, now rare) A central vein or nerve, especially the median vein or median nerve running through the forearm and arm. 
2. (geometry) A line segment joining the vertex of triangle to the midpoint of the opposing side. 
3. (statistics) A number separating the higher half from the lower half of a data sample, population, or probability distribution. The median of a finite list of numbers can be found by arranging all the observations from lowest value to highest value and picking the middle one (e.g., the median of {3, 3, 5, 9, 11} is 5). If there is an even number of observations, then there is no single middle value; the median is then usually defined to be the mean of the two middle values. 
4. (US) The area separating two lanes of opposite-direction traffic; the median strip. 
5. A Mede. 
6. The northwestern Old Iranian language of the Medes, attested only by numerous loanwords in Old Persian, few borrowings in Old Armenian and some glosses in Ancient Greek; nothing is known of its grammar. 

### Adjective
1. (anatomy) Situated in a middle, central, or intermediate part, section, or range of (something). 
2. (anatomy, botany) In the middle of an organ, structure etc.; towards the median plane of an organ or limb. 
3. (statistics) Having the median as its value. 
4. Relating to Media or Medes. 
5. (obsolete) Of laws, rules etc.: unchanging, invariable. 

## Synonyms
[[average]] | [[central]] | [[medial]]