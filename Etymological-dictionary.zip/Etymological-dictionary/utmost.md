# utmost

## Etymology
- From Middle English utmost, utemest , from Old English ūtmest, ūtemest , from ūt, ūte (“out; outdoors, outside”) + -mest (suffix meaning ‘furthest’, used to form superlatives of some adjectives) (and conflated with most). Ūt is derived from Proto-Germanic *ūt (“out, outward”), from Proto-Indo-European *úd (“out, outward”).


## Definition
### Adjective
1. Situated at the most distant limit; farthest, outermost. 
2. The most extreme; greatest, ultimate. 

### Noun
1. The greatest possible capability, extent, or quantity; maximum. 

## Synonyms
[[high]] | [[last]] | [[far]] | [[extreme]] | [[maximum]]