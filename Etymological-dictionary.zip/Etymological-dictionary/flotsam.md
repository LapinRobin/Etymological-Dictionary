# flotsam

## Etymology
- From Anglo-Norman floteson, from Old French flotaison (“a floating”), from floter (“to float”), of Germanic origin (See float.), + -aison, from Latin -atio.


## Definition
### Noun
1. Debris floating in a river or sea, in particular fragments from a shipwreck. 

## Synonyms
[[jetsam]]