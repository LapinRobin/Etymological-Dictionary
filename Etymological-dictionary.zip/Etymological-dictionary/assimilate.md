# assimilate

## Etymology
- Borrowed from Late Latin assimilātus, variant of Latin assimulātus (“made similar, imitated”), perfect passive participle of assimulō, from ad + simulō (“imitate, copy”), from similis (“like, similar”), ultimately from Proto-Indo-European *sem- (“together, one”). Doublet of assemble.


## Definition
### Verb
1. (transitive) To incorporate nutrients into the body, especially after digestion. 
2. (transitive) To incorporate or absorb (knowledge) into the mind. 
3. (transitive) To absorb (a person or people) into a community or culture. 
4. (transitive, rare, used with "to" or "with") To liken, compare to something similar. 
5. (transitive) To bring to a likeness or to conformity; to cause a resemblance between. 
6. (intransitive) To become similar. 
7. (intransitive) To be incorporated or absorbed into something. 

### Noun
1. Something that is or has been assimilated. 

## Synonyms
[[absorb]] | [[imbibe]] | [[ingest]] | [[take in]]