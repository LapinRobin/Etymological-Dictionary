# cliché

## Etymology
- Borrowed from French cliché.


## Definition
### Noun
1. Something, most often a phrase or expression, that is overused or used outside its original context, so that its original impact and meaning are lost. A trite saying; a platitude. 
2. (printing) A stereotype (printing plate). 

### Adjective
1. (proscribed) clichéd; having the characteristics of a cliché 

### Verb
1. (transitive, intransitive) To use a cliché; to make up a word or a name that sounds like a cliché. 

## Synonyms
