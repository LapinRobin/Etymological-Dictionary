# crest

## Etymology
- From Middle English creste, from Old French creste (modern French crête) and perhaps continuing Old English cræsta (“crest, tuft, plume”); both ultimately from Vulgar Latin *cresta, from Latin crista. Doublet of crista.


## Definition
### Noun
1. The summit of a hill or mountain ridge. 
2. A tuft, or other natural ornament, growing on an animal's head, for example the comb of a cockerel, the swelling on the head of a snake, the lengthened feathers of the crown or nape of bird, etc. 
3. The plume of feathers, or other decoration, worn on or displayed on a helmet; the distinctive ornament of a helmet. 
4. (heraldry) A bearing worn, not upon the shield, but usually on a helmet above it, sometimes (as for clerics) separately above the shield or separately as a mark for plate, in letterheads, and the like. 
5. The upper curve of a horse's neck. 
6. The ridge or top of a wave. 
7. The helm or head, as typical of a high spirit; pride; courage. 
8. The ornamental finishing which surmounts the ridge of a roof, canopy, etc. 
9. The top line of a slope or embankment. 
10. (anatomy) A ridge along the surface of a bone. 
11. (informal) A design or logo, especially one of an institution, sports club, association or high-class family. 
12. Any of several birds in the family Regulidae, including the goldcrests and firecrests. 
13. A census-designated place in San Diego County, California, United States. 
14. (military) Acronym of comparisons, reasons, examples, statistics, testimony: the five types of verbal support used to enhance an oral presentation. 

### Verb
1. (intransitive) Particularly with reference to waves, to reach a peak. 
2. (transitive) To reach the crest of (a hill or mountain) 
3. To furnish with, or surmount as, a crest; to serve as a crest for. 
4. To mark with lines or streaks like waving plumes. 

## Synonyms
[[top]] | [[cap]] | [[tip]] | [[peak]] | [[crown]] | [[summit]]