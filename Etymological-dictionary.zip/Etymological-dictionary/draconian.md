# draconian

## Etymology
- From the Athenian lawmaker Draco, from Latin Dracō, from Ancient Greek Δράκων (Drákōn), known for making harsh laws. See δράκων (drákōn, “dragon”).

- From Latin dracō (“dragon”).


## Definition
### Adjective
1. Very severe or strict. 
2. (obsolete, except in fiction) Of or resembling a dragon. 

## Synonyms
