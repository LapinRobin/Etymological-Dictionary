# glad

## Etymology
- From Middle English glad, gled, from Old English glæd (“shining; bright; cheerful; glad”), from Proto-Germanic *gladaz (“shiny; gleaming; radiant; happy; glossy; smooth; flat”), from Proto-Indo-European *gʰladʰ-, from *ǵʰelh₂- (“to shine”).

- glad (plural glads)


## Definition
### Adjective
1. Pleased, happy, gratified. 
2. (obsolete) Having a bright or cheerful appearance; expressing or exciting joy; producing gladness. 

### Verb
1. (archaic, transitive) To make glad. 

### Noun
1. (informal) A gladiolus (plant). 
2. A diminutive of the female given name Gladys 

## Synonyms
[[happy]] | [[grateful]] | [[willing]] | [[cheerful]] | [[pleased]] | [[lief]] | [[thankful]]