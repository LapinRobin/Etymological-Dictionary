# engrossing

## Definition
### Adjective
1. Utterly consuming one's time and attention. 

### Noun
1. The act of one who engrosses, or buys up wholesale. 

## Synonyms
[[interesting]] | [[fascinating]] | [[riveting]]