# ban

## Etymology
- From Middle English bannen (“to summon; to banish; to curse”), partly from Old English bannan (“to summon, command, proclaim, call out”) and partly from Old Norse banna (“to prohibit; to curse”), both from Proto-Germanic *bannaną (“to proclaim, to order; to summon; to ban; to curse, forbid”), from Proto-Indo-European *bʰh₂-new-ti ~ bʰh₂-n̥w-énti, innovative nasal-infixed zero-grade athematic present of *bʰeh₂- (“to say”).

- Borrowed from Romanian ban of uncertain origin, perhaps from Serbo-Croatian bân.

- From Banburismus; coined by Alan Turing.

- From South Slavic (compare Serbo-Croatian bȃn), from Proto-Slavic *banъ; see there for more.


## Definition
### Verb
1. (transitive, obsolete) To summon; to call out. 
2. (transitive) To anathematize; to pronounce an ecclesiastical curse upon; to place under a ban. 
3. (transitive) To curse; to execrate. 
4. (transitive) To prohibit; to interdict; to proscribe; to forbid or block from participation. 
5. (transitive, intransitive) To curse; to utter curses or maledictions. 

### Noun
1. Prohibition. 
2. A public proclamation or edict; a summons by public proclamation. Chiefly, in early use, a summons to arms. 
3. The gathering of the (French) king's vassals for war; the whole body of vassals so assembled, or liable to be summoned; originally, the same as arrière-ban: in the 16th c., French usage created a distinction between ban and arrière-ban, for which see the latter word. 
4. (obsolete) A curse or anathema. 
5. A pecuniary mulct or penalty laid upon a delinquent for offending against a ban, such as a mulct paid to a bishop by one guilty of sacrilege or other crimes. 
6. A subdivision of currency, equal to one hundredth of a Romanian leu. 
7. A subdivision of currency, equal to one hundredth of a Moldovan leu. 
8. A unit measuring information or entropy based on base-ten logarithms, rather than the base-two logarithms that define the bit. 
9. A title used in several states in central and south-eastern Europe between the 7th century and the 20th century. 
10. A surname. 
11. Initialism of British Approved Name. 

## Synonyms
[[shun]] | [[censor]] | [[ostracize]] | [[banish]] | [[prohibition]] | [[blackball]]