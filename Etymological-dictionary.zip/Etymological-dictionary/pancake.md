# pancake

## Etymology
- Inherited from Middle English pancake, panne cake, pankake, ponkake, equivalent to pan +‎ cake.
Perhaps adapted from Middle Low German pankôke, pannekôke, from Old Saxon *pannakōko (suggested by derivatives Old Saxon pannakōkilo and pannakōkilīn), where the compound is much older; compare Old High German phankuohho (8th century), whence Middle High German phankuoche, German Pfannkuchen (“pancake”); further
Saterland Frisian Ponkouke, Ponkuuke (“pancake”), West Frisian pankoek (“pancake”), Dutch pannenkoek (“pancake”), German Low German Pannkook (“pancake”).
The juggling sense is by analogy with a pancake being tossed in a pan.


## Definition
### Noun
1. In England, an often unleavened cake similar to a crepe. 
2. In the US (and e.g. Scotland), a leavened, thicker, fluffier cake. 
3. (theater) A kind of makeup, consisting of a thick layer of a compressed powder. 
4. (juggling) A type of throw, usually with a ring where the prop is thrown in such a way that it rotates round an axis of the diameter of the prop. 
5. Anything very thin and flat. 
6. Composite leather made of scraps, glue and board, by extension of (4), material originally used for insoles, but later used also for heels and even soles. 
7. (film, slang) A box on which an actor stands to make them appear taller. 
8. (volleyball) A defensive play in which the ball bounces off the top of a hand that has been pressed flat against the floor. 
9. A surname. 

### Verb
1. (intransitive) To make a pancake landing. 
2. (construction, demolition) To collapse one floor after another. 
3. (transitive) To flatten violently. 

## Synonyms
