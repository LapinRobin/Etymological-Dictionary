# definition

## Etymology
- From Middle English diffinicioun, from Middle French definition, from Latin dēfīnītiō, from dēfīniō. Equivalent to define +‎ -ition.


## Definition
### Noun
1. (semantics, lexicography) A statement of the meaning of a word or word group or a sign or symbol (dictionary definitions). 
2. (usually with the definite article the) A clear instance conforming to the dictionary or textbook definition. 
3. A statement expressing the essential nature of something; formulation 
4. The action or process of defining. 
5. The act of defining; determination of the limits. 
6. A product of defining. 
7. The action or power of describing, explaining, or making definite and clear. 
8. Clarity of visual presentation, distinctness of outline or detail. 
9. Clarity, especially of musical sound in reproduction. 
10. Sharp demarcation of outlines or limits. 
11. (bodybuilding) The degree to which individual muscles are distinct on the body. 
12. (programming) A statement which provides a previous declaration with a value or body of a subroutine (in the case of function). 
13. (mathematics) A statement that establishes the referent of a term or notation. 

## Synonyms
