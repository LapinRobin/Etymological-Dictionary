# frugal

## Etymology
- From Middle French, from Latin frugalis (“virtuous, thrifty”). Displaced native Old English spærhende (literally “spare-handed”).


## Definition
### Adjective
1. Avoiding unnecessary expenditure either of money or of anything else which is to be used or consumed; avoiding waste. 

## Synonyms
[[scotch]] | [[thrifty]] | [[economical]]