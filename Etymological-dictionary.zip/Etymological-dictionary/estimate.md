# estimate

## Etymology
- Borrowed from Latin aestimatus, past participle of aestimō, older form aestumo (“to value, rate, esteem”); from Old Latin *ais-temos (“one who cuts copper”), meaning one in the Roman Republic who mints money. See also the doublet esteem, as well as aim.


## Definition
### Noun
1. A rough calculation or assessment of the value, size, or cost of something. 
2. (construction and business) A document (or verbal notification) specifying how much a job is likely to cost. 
3. An upper limitation on some positive quantity. 

### Verb
1. To calculate roughly, often from imperfect data. 
2. To judge and form an opinion of the value of, from imperfect data. 

## Synonyms
[[gauge]] | [[figure]] | [[forecast]] | [[idea]] | [[reckon]] | [[judge]] | [[guess]] | [[appraisal]] | [[approximate]] | [[calculate]] | [[estimation]]