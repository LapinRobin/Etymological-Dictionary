# opus

## Etymology
- Borrowed from Latin opus.


## Definition
### Noun
1. (music) A work of music or set of works with a specified rank in an ordering of a composer's complete published works. 
2. A work, especially of art. 

## Synonyms
[[piece]] | [[composition]]