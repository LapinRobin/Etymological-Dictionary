# disparity

## Etymology
- From Middle French disparité.


## Definition
### Noun
1. (uncountable) The state of being unequal; difference. 
2. (countable) Incongruity. 

## Synonyms
