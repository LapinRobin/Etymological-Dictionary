# dated

## Definition
### Adjective
1. Marked with a date. 
2. Outdated. 
3. Anachronistic; being obviously inappropriate for its present context. 
4. No longer fashionable. 
5. (obsolete) Alotted a span of days. 

## Synonyms
