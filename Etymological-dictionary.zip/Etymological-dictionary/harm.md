# harm

## Etymology
- From Middle English harm, herm, from Old English hearm, from Proto-West Germanic *harm, from Proto-Germanic *harmaz (“harm; shame; pain”). Cognate with Dutch harm (“harm”), German Harm (“harm”), Swedish harm (“anger, indignation, harm”), Icelandic harmur (“sorrow, grief”).


## Definition
### Noun
1. physical injury; hurt; damage 
2. emotional or figurative hurt 
3. detriment; misfortune. 
4. That which causes injury, damage, or loss. 

### Verb
1. To cause injury to another; to hurt; to cause damage to something. 

## Synonyms
[[hurt]] | [[damage]] | [[trauma]] | [[injury]] | [[impairment]] | [[scathe]]