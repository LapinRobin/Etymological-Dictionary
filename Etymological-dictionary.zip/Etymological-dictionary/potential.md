# potential

## Etymology
- From Late Latin potentialis, from Latin potentia (“power”), from potens (“powerful”); synchronically analysable as potent +‎ -ial.


## Definition
### Noun
1. Currently unrealized ability (with the most common adposition being to) 
2. (physics) The gravitational potential: the radial (irrotational, static) component of a gravitational field, also known as the Newtonian potential or the gravitoelectric field. 
3. (physics) The work (energy) required to move a reference particle from a reference location to a specified location in the presence of a force field, for example to bring a unit positive electric charge from an infinite distance to a specified point against an electric field. 
4. (grammar) A verbal construction or form stating something is possible or probable. 

### Adjective
1. Existing in possibility, not in actuality. 
2. (archaic) Being potent; endowed with energy adequate to a result 
3. (physics) A potential field is an irrotational (static) field. 
4. (physics) A potential flow is an irrotational flow. 
5. (grammar) Referring to a verbal construction of form stating something is possible or probable. 

## Synonyms
[[prospective]] | [[latent]] | [[likely]] | [[possible]] | [[expected]]