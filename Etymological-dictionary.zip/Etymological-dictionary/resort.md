# resort

## Etymology
- From Middle English resorten, from Old French resortir (“to fall back, return, resort, have recourse, appeal”), back-formation from sortir (“to go out”).

- re- +‎ sort

- From French ressort.


## Definition
### Noun
1. A place where people go for recreation, especially one with facilities such as lodgings, entertainment, and a relaxing environment. 
2. Recourse, refuge (something or someone turned to for safety). 
3. (obsolete) A place where one goes habitually; a haunt. 
4. An act of sorting again. 
5. (obsolete) Active power or movement; spring. 

### Verb
1. (intransitive) To have recourse (to), now especially from necessity or frustration. 
2. (intransitive) To fall back; to revert. 
3. (intransitive) To make one's way, go (to). 
4. (transitive, intransitive) To repeat a sorting process; sort again. 

## Synonyms
[[recourse]] | [[repair]] | [[haunt]] | [[refuge]] | [[recur]]