# nun

## Etymology
- From Middle English nonne, nunne, from Old English nunne (“nun”), from Late Latin nonna (“nun, tutor”), originally (along with masculine form nonnus (“man”)) a term of address for elderly persons, perhaps from children's speech, reminiscent of nana, like papa etc. Doublet of nonna.

- Borrowed from the letter’s name in the respective language. Doublet of nu.

- nun


## Definition
### Noun
1. A member of a Christian religious community of women who live by certain vows and usually wear a habit, (Roman Catholicism, specifically) those living together in a cloister. 
2. (by extension) A member of a similar female community in other confessions. 
3. (archaic, Britain, slang) A prostitute. 
4. A kind of pigeon with the feathers on its head like the hood of a nun. 
5. The fourteenth letter of many Semitic alphabets/abjads (Phoenician, Aramaic, Hebrew, Syriac, Arabic and others). 
6. (very rare) A male given name from Hebrew 
7. The languages of the Bamun people of western Cameroon. 

## Synonyms
