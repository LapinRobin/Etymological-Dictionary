# cape

## Etymology
- Borrowed from Middle French cap, from Occitan cap, from Latin caput (“head”). Doublet of caput, chef, and chief, and distantly with head.

- From French cape, from Old Occitan capa, from Late Latin cappa (“cape”). The second sense ("superhero") is metonymic from the fact that many superheroes wear capes. Likewise, the verb sense "defend, praise" alludes to the stereotypical depiction of superheroes wearing capes when they come to people's defense. (Compare caped crusader and cape (“a superhero”).) Doublet of capa and cappa.

- From Middle English capen (“to stare, gape, look for, seek”), from Old English capian (“to look”), from Proto-West Germanic *kapēn. Cognate with Dutch gapen, German gaffen (“to stare at curiously, rubberneck”), Low German gapen (“to stare”). Related to keep.


## Definition
### Noun
1. (geography) A piece or point of land, extending beyond the adjacent coast into a sea or lake; a promontory; a headland. 
2. A sleeveless garment or part of a garment, hanging from the neck over the back, arms, and shoulders. 
3. (slang) A superhero. 
4. (countable) A surname. 
5. (meteorology) Convective available potential energy 
6. (with the definite article, southern Africa) Ellipsis of Cape of Good Hope.  
7. (with the definite article, South Africa) Ellipsis of Cape Province., South Africa. Cape Province was split into three in 1994. 
8. (with the definite article) Ellipsis of Cape Cod.  
9. (with the definite article, historical, southern Africa) Ellipsis of Cape Colony.  
10. (with the definite article, space flight) Ellipsis of Cape Canaveral., Florida, USA; where the major U.S. spaceflight complex is located.  

### Verb
1. To incite or attract (a bull) to charge a certain direction, by waving a cape. 
2. (nautical) To head or point; to keep a course. 
3. To skin an animal, particularly a deer. 
4. (US, slang, chiefly with "for") To defend or praise, especially that which is unworthy. 
5. (obsolete) To look for, search after. 
6. (rare, dialectal or obsolete) To gaze or stare. 

## Synonyms
[[mantle]] | [[ness]]