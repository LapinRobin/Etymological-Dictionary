# correspondence

## Etymology
- From correspond +‎ -ence.


## Definition
### Noun
1. (uncountable, obsolete) Friendly discussion. 
2. (uncountable) Reciprocal exchange of civilities, especially conversation between persons by means of letters. 
3. (uncountable) Newspaper or news stories. 
4. (countable or uncountable) Postal or other written communications. 
5. (countable) An agreement of situations or objects with an expected outcome. 
6. (set theory, countable) A relation. 
7. (theology, Swedenborgianism) A similarity between physical and spiritual things (e.g. light to wisdom, or warmth to love) 

## Synonyms
[[balance]] | [[map]] | [[agreement]] | [[symmetry]] | [[parallelism]] | [[mapping]]