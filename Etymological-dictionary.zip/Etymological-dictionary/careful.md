# careful

## Etymology
- From Middle English careful, from Old English carful; equivalent to care +‎ -ful.


## Definition
### Adjective
1. Taking care; attentive to potential danger, error or harm; cautious. 
2. Conscientious and painstaking; meticulous. 
3. (obsolete) Full of care or grief; sorrowful, sad. 
4. (obsolete) Full of cares or anxiety; worried, troubled. 

## Synonyms
[[elaborate]] | [[conscientious]] | [[close]] | [[thorough]] | [[minute]] | [[deliberate]] | [[sure]] | [[aware]] | [[certain]] | [[narrow]] | [[mindful]] | [[cautious]] | [[scrupulous]] | [[thrifty]] | [[painstaking]] | [[detailed]] | [[studious]]