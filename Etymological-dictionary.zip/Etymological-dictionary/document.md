# document

## Etymology
- Borrowed from Middle French document, from Latin documentum.


## Definition
### Noun
1. An original or official paper used as the basis, proof, or support of anything else, including any writing, book, or other instrument conveying information pertinent to such proof or support. 
2. Any material substance on which the information is represented by writing. 
3. (computing) A file that contains text. 
4. (information science) An object conveying information by whatever means, capable of being indexed alongside other similar objects. 
5. (obsolete) That which is taught or authoritatively set forth; precept; instruction; dogma. 
6. (obsolete) An example for instruction or warning. 

### Verb
1. To record in documents. 
2. To furnish with documents or papers necessary to establish facts or give information. 

## Synonyms
