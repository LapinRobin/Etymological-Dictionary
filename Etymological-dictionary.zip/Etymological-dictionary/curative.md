# curative

## Etymology
- From Middle French curatif.

- curative (not comparable)


## Definition
### Adjective
1. Possessing the ability to cure, to heal or treat illness. 
2. (figuratively, by extension) Remediative. 
3. (grammar) of a verb, conveying the meaning "the agent makes a patient do something" 

### Noun
1. A substance that acts as a cure. 

## Synonyms
[[remedy]] | [[cure]] | [[healing]] | [[remedial]] | [[therapeutic]]