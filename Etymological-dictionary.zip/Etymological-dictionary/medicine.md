# medicine

## Etymology
- From Middle English medicin, from Middle French medicine, from Old French medecine, from Latin medicīna (“the healing art, medicine, a physician's shop, a remedy, medicine”), feminine of medicīnus (“of or belonging to physic or surgery, or to a physician or surgeon”), from medicus (“a physician, surgeon”).


## Definition
### Noun
1. (uncountable, countable) A substance which specifically promotes healing when ingested or consumed in some way; a pharmaceutical drug. 
2. (broadly, countable) Any treatment or cure. 
3. (uncountable) The study of the cause, diagnosis, prognosis and treatment of disease or illness. 
4. (uncountable) The profession and practice of physicians, including surgeons. 
5. (mainly historical, uncountable) The profession and practice of nonsurgical physicians as sometimes distinguished from that of surgeons. 
6. (uncountable) Ritual magic used, as by a medicine man, to promote a desired outcome in healing, hunting, or warfare; traditional medicine. 
7. Among the Native Americans, any object supposed to give control over natural or magical forces, to act as a protective charm, or to cause healing. 
8. (obsolete) Black magic, superstition. 
9. (obsolete) A philter or love potion. 
10. (obsolete) A physician. 
11. (slang) Recreational drugs, especially alcoholic drinks. 

### Verb
1. (rare, obsolete) To treat with medicine. 

## Synonyms
[[music]] | [[medication]]