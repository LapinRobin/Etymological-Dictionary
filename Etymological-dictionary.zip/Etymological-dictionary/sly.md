# sly

## Etymology
- From Middle English sly, sley, sleigh, sleiȝ, from Old Norse slǿgr (“sly, cunning”, literally “capable of hitting or striking”), from Proto-Germanic *slōgiz (“lively, agile, cunning, sly, striking”), from Proto-Indo-European *slak- (“to hit, throw”). Cognate with Icelandic slægur (“crafty, sly”), Norwegian Nynorsk sløg (“sly”). Related to sleight, slay. In all likelihood, however, unrelated with Saterland Frisian slau (“sly, crafty”), Dutch sluw (“sly, cunning”), Low German slu (“sly, cunning”), German schlau (“clever, crafty”).


## Definition
### Adjective
1. Artfully cunning; secretly mischievous; wily. 
2. (having a positive connotation) Dexterous in performing an action, so as to escape notice 
3. Done with, and marked by, artful and dexterous secrecy; subtle 
4. Light or delicate; slight; thin. 

### Adverb
1. Slyly. 

### Noun
1. A diminutive of the male given name Sylvester. 

## Synonyms
[[cunning]] | [[slick]] | [[dodgy]] | [[crafty]] | [[tricky]] | [[wily]] | [[artful]]