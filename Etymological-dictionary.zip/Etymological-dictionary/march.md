# march

## Etymology
- From Middle English marchen, from Middle French marcher (“to march, walk”), from Old French marchier (“to stride, to march, to trample”), from Frankish *markōn (“to mark, mark out, to press with the foot”), from Proto-Germanic *markōną (“area, region, edge, rim, border”), akin to Persian مرز‎ (marz), from Proto-Indo-European *merǵ- (“edge, boundary”). Akin to Old English mearc, ġemearc (“mark, boundary”). Compare mark, from Old English mearcian.

- From Middle English marche (“tract of land along a country's border”), from Old French marche (“boundary, frontier”), from Frankish *marku, from Proto-Germanic *markō, from Proto-Indo-European *merǵ- (“edge, boundary”).

- From Middle English merche, from Old English merċe, mereċe, from Proto-West Germanic *marik, from Proto-Indo-European *móri (“sea”). Cognate Middle Low German merk, Old High German merc, Old Norse merki (“celery”). Compare also obsolete or regional more (“carrot or parsnip”), from Proto-Indo-European *mork- (“edible herb, tuber”).


## Definition
### Noun
1. A formal, rhythmic way of walking, used especially by soldiers, bands and in ceremonies. 
2. A political rally or parade 
3. Any song in the genre of music written for marching (see Wikipedia's article on this type of music) 
4. Steady forward movement or progression. 
5. (euchre) The feat of taking all the tricks of a hand. 
6. (now archaic, historical) A border region, especially one originally set up to defend a boundary. 
7. (historical) A region at a frontier governed by a marquess. 
8. Any of various territories with similar meanings or etymologies in their native languages. 
9. (obsolete) Smallage. 
10. The third month of the Gregorian calendar, following February and preceding April. Abbreviation: Mar or Mar. 
11. A surname from Middle English for someone born in March, or for someone living near a boundary (marche). 
12. (uncommon) A male given name from English. 
13. A market town and civil parish with a town council in Fenland district, Cambridgeshire, England (OS grid ref TL4196). 

### Verb
1. (intransitive) To walk with long, regular strides, as a soldier does. 
2. (transitive) To cause someone to walk somewhere. 
3. To go to war; to make military advances. 
4. (figuratively) To make steady progress. 
5. (intransitive) To have common borders or frontiers 

## Synonyms
[[process]] | [[stride]] | [[exhibit]] | [[demonstrate]] | [[parade]] | [[mar]]