# impostor

## Etymology
- From Middle French imposteur.


## Definition
### Noun
1. Someone who attempts to deceive by using an assumed name or identity. 
2. (computer graphics) A sprite or animation integrated into a three-dimensional scene, but not based on an actual 3D model. 

## Synonyms
[[fraud]] | [[sham]] | [[fake]] | [[pseudo]] | [[imposter]]