# debris

## Etymology
- Borrowed from French débris, itself from dé- (“de-”) + bris (“broken, crumbled”), or from Middle French debriser (“to break apart”), from Old French debrisier, itself from de- + brisier (“to break apart, shatter, bust”), from Frankish *bristijan, *bristan, *brestan (“to break violently, shatter, bust”), from Proto-Germanic *brestaną (“to break, burst”), from Proto-Indo-European *bʰrest- (“to separate, burst”). Cognate with Old High German bristan (“to break asunder, burst”), Old English berstan (“to break, shatter, burst”), German bersten (“to burst”). More at burst.


## Definition
### Noun
1. Rubble, wreckage, scattered remains of something destroyed. 
2. Litter and discarded refuse. 
3. The ruins of a broken-down structure. 
4. (geology) Large rock fragments left by a melting glacier etc. 

## Synonyms
[[dust]] | [[detritus]] | [[junk]] | [[rubble]]