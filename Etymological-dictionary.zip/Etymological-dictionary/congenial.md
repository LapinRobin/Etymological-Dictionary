# congenial

## Etymology
- con- +‎ genial


## Definition
### Adjective
1. Having the same or very similar nature, personality, tastes, habits or interests. 
2. Friendly or sociable. 
3. Suitable to one’s needs. 

## Synonyms
[[compatible]] | [[sympathetic]] | [[agreeable]] | [[sociable]]