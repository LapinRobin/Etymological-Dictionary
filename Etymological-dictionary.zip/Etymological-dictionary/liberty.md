# liberty

## Etymology
- From Middle English liberte, from Old French liberté, from Latin libertas (“freedom”), from liber (“free”); see liberal.


## Definition
### Noun
1. The condition of being free from control or restrictions. 
2. The condition of being free from imprisonment, slavery or forced labour. 
3. The condition of being free to act, believe or express oneself as one chooses. 
4. Freedom from excessive government control. 
5. A short period when a sailor is allowed ashore. 
6. (often plural) A breach of social convention. 
7. (historical) A local division of government administration in medieval England. 
8. (game of Go) An empty space next to a group of stones of the same color. 
9. A surname from French. 
10. A freed slave surname originating as an occupation. 
11. A female given name from English. 
12. A male given name from English. 
13. A town, the county seat of Union County, Indiana, United States. 
14. A city, the county seat of Casey County, Kentucky, United States. 
15. A town, the county seat of Amite County, Mississippi, United States. 
16. A city, the county seat of Clay County, Missouri, United States. 
17. A city, the county seat of Liberty County, Texas, United States 
18. A number of townships in the United States, listed under Liberty Township. 

## Synonyms
[[autonomy]] | [[impropriety]]