# bless

## Etymology
- From Middle English blessen, from Old English bletsian (“to consecrate (with blood)”), from Proto-West Germanic *blōdisōn (“to sprinkle, mark or hallow with blood”), from Proto-Germanic *blōþą (“blood”), of uncertain origin, possibly from Proto-Indo-European *bʰleh₃- (“to bloom”). Cognate with Old Norse bleza (“to bless”) (whence Icelandic blessa), Old English blēdan (“to bleed”). More at bleed.

- An ellipsis for an expression such as bless your heart.


## Definition
### Verb
1. To make something holy by religious rite, sanctify. 
2. To make the sign of the cross upon, so as to sanctify. 
3. To invoke divine favor upon. 
4. To honor as holy, glorify; to extol for excellence. 
5. To esteem or account happy; to felicitate. 
6. (obsolete) To wave; to brandish. 
7. (Perl programming, transitive, past tense only blessed) To turn (a reference) into an object. 
8. (archaic, with from) To secure, defend, or prevent from. 

### Noun
1. A surname from German. 

## Synonyms
[[sign]] | [[consecrate]] | [[hallow]] | [[sanctify]]