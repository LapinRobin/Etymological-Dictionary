# particle

## Etymology
- From Middle French particule, and its source, Latin particula (“small part, particle”), diminutive of pars (“part, piece”).


## Definition
### Noun
1. A very small piece of matter, a fragment; especially, the smallest possible part of something. 
2. (physics) Any of various physical objects making up the constituent parts of an atom; an elementary particle or subatomic particle. 
3. (linguistics) A part of speech that has no inherent lexical definition but must be associated with another word to impart meaning, often a grammatical category: for example, the English word to in a full infinitive phrase (to eat) or O in a vocative phrase (O Canada), or as a discourse marker (mmm). 
4. (linguistics) A part of speech which cannot be inflected. 
5. (Christianity) In the Roman Catholic church, a crumb of consecrated bread; also the smaller breads used in the communion of the laity. 
6. A little bit. 

## Synonyms
[[atom]] | [[mote]] | [[molecule]] | [[speck]]