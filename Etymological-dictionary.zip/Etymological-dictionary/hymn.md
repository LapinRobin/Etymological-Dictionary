# hymn

## Etymology
- From Middle English ymne, from Old English ymen (reinforced by Old French ymne), from Latin hymnus, borrowed from Ancient Greek ὕμνος (húmnos).


## Definition
### Noun
1. A song of praise or worship, especially a religious one. 

### Verb
1. (transitive, intransitive) To sing a hymn. 
2. (transitive) To praise or extol in hymns. 

## Synonyms
[[anthem]]