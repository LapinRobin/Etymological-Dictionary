# merciless

## Etymology
- From Middle English merciles, mercyles, equivalent to mercy +‎ -less.


## Definition
### Adjective
1. Showing no mercy; cruel and pitiless. 

## Synonyms
[[fierce]] | [[ruthless]]