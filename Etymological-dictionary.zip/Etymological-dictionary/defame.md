# defame

## Etymology
- From Middle English defamen, from Anglo-Norman defamer (verb), defame (noun), and its source, Latin diffāmō, from fāma (“fame; rumour; reputation”).


## Definition
### Verb
1. To disgrace; to bring into disrepute. 
2. (now chiefly historical) To charge; to accuse (someone) of an offence. 
3. To harm or diminish the reputation of; to disparage. 

### Noun
1. (now rare, archaic) Disgrace, dishonour. 
2. (now rare or nonstandard) Defamation; slander, libel. 

## Synonyms
[[slander]] | [[smear]] | [[denigrate]] | [[sully]] | [[besmirch]]