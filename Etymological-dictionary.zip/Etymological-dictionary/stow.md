# stow

## Etymology
- From Middle English stowe, from Old English stōw (“place, location”), from Proto-West Germanic *stōwu, from Proto-Germanic *stōwō (“a place, stowage”), from Proto-Indo-European *steh₂- (“to stand, place, put”). Cognate with Old Frisian stō (“place”), Icelandic stó (“fireplace”), Dutch stouw (“place”). See also -stow.

- From Middle English stowen, stawen, stewen, from Old English stōwian (“to hold back, restrain”), from Proto-Germanic *stōwōną, *stōwijaną (“to stow, dam up”), from Proto-Indo-European *steh₂- (“to stand, place”). Cognate with Dutch stuwen, stouwen (“to stow”), Low German stauen (“to blin, halt, hinder”), German stauen (“to halt, hem in, stow, pack”).


## Definition
### Noun
1. (rare) A place, stead. 
2. A surname. 
3. A village in the Scottish Borders council area, Scotland (OS grid ref NT4544). 
4. A village and civil parish in West Lindsey district, Lincolnshire, England (OS grid ref SK8881). 
5. The alternative spelling of Stowe in Shropshire, England. 
6. A small town in Oxford County, Maine, United States. 
7. A town in Middlesex County, Massachusetts, United States. 
8. A city in Summit County, Ohio, United States. 

### Verb
1. To put something away in a compact and tidy manner, in its proper place, or in a suitable place. 
2. To store or pack something in a space-saving manner and over a long time. 
3. To arrange, pack, or fill something tightly or closely. 
4. To dispose of, lodge, or hide somebody somewhere. 
5. (obsolete, slang, transitive) To cease; to stop doing something. 

## Synonyms
[[store]] | [[load]] | [[garner]]