# surprise

## Etymology
- From Middle English surprise, borrowed from Middle French surprise (“an overtake”), nominal use of the past participle of Old French sorprendre (“to overtake”), from sor- (“over”) + prendre (“to take”), from Latin super- + Latin prendere, contracted from prehendere (“to grasp, seize”). Doublet of suppli.


## Definition
### Noun
1. Something unexpected. 
2. The feeling that something unexpected has happened. 
3. A city in Maricopa County, Arizona, the largest place with this name. 
4. An unincorporated community in Jackson County, Indiana. 
5. A village in Butler County, Nebraska. 
6. A locality in Greene County, New York. 
7. Former name of Surprise Station, California. 

### Verb
1. (transitive) To cause (someone) to feel unusually alarmed or delighted by something unexpected. 
2. (transitive) To do something to (a person) that they are not expecting, as a surprise. 
3. (intransitive) To undergo or witness something unexpected. 
4. (intransitive) To cause surprise. 
5. (transitive) To attack unexpectedly. 
6. (transitive) To take unawares. 

## Synonyms
[[storm]]