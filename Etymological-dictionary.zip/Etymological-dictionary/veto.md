# veto

## Etymology
- From Latin vetō (“I forbid”).


## Definition
### Noun
1. A political right to disapprove of (and thereby stop) the process of a decision, a law etc. 
2. An invocation of that right. 
3. An authoritative prohibition or negative; a forbidding; an interdiction. 

### Verb
1. (transitive) To use a veto against. 

## Synonyms
[[forbid]] | [[negative]] | [[proscribe]] | [[interdict]] | [[prohibit]] | [[blackball]]