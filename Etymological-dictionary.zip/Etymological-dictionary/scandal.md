# scandal

## Etymology
- From Middle French scandale (“indignation caused by misconduct or defamatory speech”), from Ecclesiastical Latin scandalum (“that on which one trips, cause of offense”, literally “stumbling block”), from Ancient Greek σκάνδαλον (skándalon, “a trap laid for an enemy, a cause of moral stumbling”), from Proto-Indo-European *skand- (“to jump”). Cognate with Latin scandō (“to climb”). First attested from Old Northern French escandle, but the modern word is a reborrowing. Doublet, via Old French esclandre, of slander.


## Definition
### Noun
1. An incident or event that disgraces or damages the reputation of the persons or organization involved. 
2. Damage to one's reputation. 
3. Widespread moral outrage, indignation, as over an offence to decency. 
4. (theology) Religious discredit; an act or behaviour which brings a religion into discredit. 
5. (theology) Something which hinders acceptance of religious ideas or behaviour; a stumbling-block or offense. 
6. Defamatory talk; gossip, slander. 

### Verb
1. (obsolete) To treat opprobriously; to defame; to slander. 
2. (obsolete) To scandalize; to offend. 

## Synonyms
[[dirt]] | [[outrage]]