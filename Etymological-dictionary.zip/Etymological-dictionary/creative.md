# creative

## Etymology
- Borrowed from Late Latin creativus, from Latin creō. Equivalent to create +‎ -ive. Displaced native Old English orþanclīċ.


## Definition
### Adjective
1. Tending to create things, or having the ability to create; often, excellently, in a novel fashion, or any or all of these. 
2. (of a created thing) Original, expressive and imaginative. 
3. (set theory) A type of set of natural numbers, related to mathematical logic. 
4. Designed or executed to deceive or mislead. 

### Noun
1. (countable) A person directly involved in a creative marketing process. 
2. (uncountable) Artistic material used in advertising, e.g. photographs, drawings, or video. 

## Synonyms
[[ingenious]] | [[notional]] | [[productive]] | [[constructive]] | [[fanciful]] | [[imaginative]]