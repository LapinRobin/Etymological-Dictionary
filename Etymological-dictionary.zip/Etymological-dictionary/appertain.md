# appertain

## Etymology
- From Middle English apperteinen, apertenen, borrowed from Old French apartenir (French appartenir), from Late Latin appertinēre, from ad (“to”) + Latin pertinēre (“to reach to, belong”). More at pertain.


## Definition
### Verb
1. To belong to or be a part of, whether by right, nature, appointment, or custom; to relate to. 
2. To belong as a part, right, possession, attribute, etc. 

## Synonyms
[[pertain]]