# pestilence

## Etymology
- From Middle English, from Old French, from Latin pestilentia (“plague”), from pestilens (“infected, unwholesome, noxious”); equivalent to pestilent +‎ -ence.


## Definition
### Noun
1. Any epidemic disease that is highly contagious, infectious, virulent and devastating. 
2. (archaic) Anything harmful to morals or public order. 
3. The personification of pestilence, often depicted riding a white horse. 

## Synonyms
[[plague]]