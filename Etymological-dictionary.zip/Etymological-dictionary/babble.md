# babble

## Etymology
- From Middle English babelen, from Old English *bæblian, also wæflian (“to talk foolishly”), from Proto-West Germanic *bablōn, *wablōn, variants of *babalōn, from Proto-Germanic *babalōną (“to chatter”), from Proto-Indo-European *bʰa-bʰa-, perhaps a reduplication of Proto-Indo-European *bʰeh₂- (“to say”), or a variant of Proto-Indo-European *baba- (“to talk vaguely, mumble”), or a merger of the two, possibly ultimately onomatopoeic/mimicry of infantile sounds (compare babe, baby).


## Definition
### Verb
1. (intransitive) To utter words indistinctly or unintelligibly; to utter inarticulate sounds 
2. (intransitive) To talk incoherently; to utter meaningless words. 
3. (intransitive) To talk too much; to chatter; to prattle. 
4. (intransitive) To make a continuous murmuring noise, like shallow water running over stones. 
5. (transitive) To utter in an indistinct or incoherent way; to repeat words or sounds in a childish way without understanding. 
6. (transitive) To reveal; to give away (a secret). 

### Noun
1. Idle talk; senseless prattle 
2. Inarticulate speech; constant or confused murmur. 
3. A sound like that of water gently flowing around obstructions. 

## Synonyms
[[talk]] | [[bubble]] | [[sing]] | [[ripple]] | [[peach]] | [[blather]] | [[tattle]] | [[gurgle]]