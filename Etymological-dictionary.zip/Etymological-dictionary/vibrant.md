# vibrant

## Etymology
- From French vibrant, from Latin vibrans, present participle of vibrare (“to vibrate”). See vibrate.


## Definition
### Adjective
1. Pulsing with energy or activity. 
2. Lively and vigorous. 
3. Vibrating, resonant or resounding. 
4. (of a colour) Bright. 

### Noun
1. (phonetics) Any of a class of consonants including taps and trills. 

## Synonyms
[[vivacious]] | [[spirited]]