# label

## Etymology
- From Middle English label (“narrow band, strip of cloth”), from Old French label, lambel (Modern French lambeau), from Frankish *lappā (“torn piece of cloth”), from Proto-Germanic *lappǭ, *lappô (“cloth stuff, rag, scraps, flap, dewlap, lobe, rabbit ear”), from Proto-Indo-European *leb- (“blade”). Cognate with Old High German lappa (“rag, piece of cloth”), Old English læppa (“skirt, flap of a garment”). More at lap.


## Definition
### Noun
1. A small ticket or sign giving information about something to which it is attached or intended to be attached. 
2. A name given to something or someone to categorise them as part of a particular social group. 
3. (music) A company that sells records. 
4. (computing) A user-defined alias for a numerical designation, the reverse of an enumeration. 
5. (computing) A named place in source code that can be jumped to using a GOTO or equivalent construct. 
6. (heraldry) A charge resembling the strap crossing the horse’s chest from which pendants are hung. 
7. (obsolete) A tassel. 
8. A small strip, especially of paper or parchment (or of some material attached to parchment to carry the seal), but also of iron, brass, land, etc. 
9. A piece of writing added to something, such as a codicil appended to a will. 
10. (historical) A brass rule with sights, formerly used with a circumferentor to take altitudes. 
11. (architecture) The projecting moulding by the sides, and over the tops, of openings in mediaeval architecture. 
12. In mediaeval and later art, a representation of a band or scroll containing an inscription. 
13. (graphical user interface) A non-interactive control or widget displaying text, often used to describe the purpose of another control. 

### Verb
1. (transitive) To put a label (a ticket or sign) on (something). 
2. (ditransitive) To give a label to (someone or something) in order to categorise that person or thing. 
3. (biochemistry) To replace specific atoms by their isotope in order to track the presence or movement of this isotope through a reaction, metabolic pathway or cell. 
4. (biochemistry) To add a detectable substance, either transiently or permanently, to a biological substance in order to track the presence of the label-substance combination either in situ or in vitro 

## Synonyms
[[mark]] | [[tag]] | [[brand]] | [[judge]] | [[pronounce]] | [[marque]] | [[sticker]]