# tone down

## Definition
### Verb
1. (transitive, intransitive, idiomatic) To relax; to make quieter or less obtrusive; to make milder. 
2. To moderate or relax; to diminish or weaken the striking characteristics of; to soften. 
3. To make a television program, piece of writing, etc. less offensive and so more suitable for a family audience. 

## Synonyms
