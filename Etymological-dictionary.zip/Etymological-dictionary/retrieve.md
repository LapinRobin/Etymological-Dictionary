# retrieve

## Etymology
- Recorded in Middle English c. 1410 as retreve (altered to retrive in the 16th century; modern form is from c. 1650), from Middle French retruev-, stem of Old French retrover (“to find again”, modern retrouver), itself from re- (“again”) + trover (“to find”), probably from Vulgar Latin *tropāre (“to compose”).


## Definition
### Verb
1. (transitive) To regain or get back something. 
2. (transitive) To rescue (a creature). 
3. (transitive) To salvage something 
4. (transitive) To remedy or rectify something. 
5. (transitive) To remember or recall something. 
6. (transitive, especially computing) To fetch or carry back something. 
7. (transitive) To fetch and bring in game. 
8. (intransitive) To fetch and bring in game systematically. 
9. (intransitive) To fetch or carry back systematically, notably as a game. 
10. (sports, transitive) To make a difficult but successful return of the ball. 
11. (obsolete) To remedy the evil consequence of, to repair (a loss or damage). 

### Noun
1. A retrieval 
2. (sports) The return of a difficult ball 
3. (obsolete) A seeking again; a discovery. 
4. (obsolete) The recovery of game once sprung. 

## Synonyms
[[find]] | [[think]] | [[recall]] | [[remember]] | [[recover]] | [[remind]]