# heritage

## Etymology
- From Old French eritage, heritage, (French héritage), ultimately derived (through suffixation) from Latin hērēs.


## Definition
### Noun
1. An inheritance; property that may be inherited. 
2. A tradition; a practice or set of values that is passed down from preceding generations through families or through institutional memory. 
3. A birthright; the status acquired by birth, especially of but not exclusive to the firstborn. 
4. (attributive) Having a certain background, such as growing up with a second language. 
5. A surname. 

## Synonyms
[[inheritance]]