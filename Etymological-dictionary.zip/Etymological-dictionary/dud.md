# dud

## Etymology
- From Middle English dudde (“cloak, mantle, kind of cloth; ragged clothing or cloth”), from Old English *dudda (attested only as personal name Dudda, part of modern English Dudley), akin to Old Norse dúði (“swaddling clothes”), Low German dudel. Possibly borrowed from the Old Norse word and related to dyja (“to shake, tremble”). 


## Definition
### Noun
1. (informal) A device or machine that is useless because it does not work properly or has failed to work, such as a bomb, or explosive projectile. 
2. (informal) A loser; an unlucky person. 
3. A lottery ticket that does not give a payout. 
4. (obsolete, informal) Clothes, now always used in plural form duds. 

## Synonyms
[[bomb]] | [[turkey]] | [[flop]] | [[washout]]