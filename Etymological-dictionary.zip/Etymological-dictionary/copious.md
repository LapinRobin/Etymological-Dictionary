# copious

## Etymology
- From Middle English copious, from Latin copiosus, copia (“abundance”), from co- + ops (“wealth”) + -osus (“full of”).


## Definition
### Adjective
1. Vast in quantity or number, profuse, abundant; taking place on a large scale. 
2. Having an abundant supply. 
3. Full of thought, information, or matter; exuberant in words, expression, or style. 

## Synonyms
[[rich]] | [[extensive]] | [[abundant]] | [[ample]] | [[plentiful]]