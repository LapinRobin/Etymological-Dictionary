# slacker

## Etymology
- From slack +‎ -er; compare especially slack off.


## Definition
### Noun
1. One who procrastinates or is lazy. 
2. A person lacking a sense of direction in life; an underachiever. 
3. A member of a certain 1990s subculture associated with Generation X. 
4. (dated, US) A person who seeks to avoid military service. 
5. (rare, slang) A user of the Slackware Linux distribution. 

## Synonyms
