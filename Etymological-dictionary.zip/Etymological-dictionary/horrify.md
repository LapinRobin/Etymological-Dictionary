# horrify

## Etymology
- horror +‎ -ify, or borrowed from Latin horrificare (cf. French horrifier). 1791, in form horrifying.


## Definition
### Verb
1. To cause to feel extreme apprehension or unease; to cause to experience horror. 

## Synonyms
[[dismay]] | [[alarm]] | [[appall]] | [[appal]]