# let up

## Definition
### Verb
1. (intransitive, of something intense) To cease or stop. 
2. (intransitive) To cease or stop (doing something intense). 

## Synonyms
