# boundless

## Etymology
- bound +‎ -less


## Definition
### Adjective
1. Without bounds, unbounded. 

## Synonyms
[[infinite]]