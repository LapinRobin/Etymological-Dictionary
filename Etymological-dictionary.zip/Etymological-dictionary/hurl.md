# hurl

## Etymology
- Inherited from Middle English hurlen, of onomatopoeic origin; compare hurry, hurtle.


## Definition
### Verb
1. (transitive) To throw (something) with force. 
2. (transitive) To utter (harsh or derogatory speech), especially at its target. 
3. (intransitive) To participate in the sport of hurling. 
4. (intransitive, slang) To vomit. 
5. (obsolete, transitive) To twist or turn. 
6. (obsolete) To move rapidly with a noise; to whirl. 
7. (Scotland, transitive, obsolete) To convey in a wheeled vehicle. 

### Noun
1. (countable) A throw, especially a violent throw; a fling. 
2. (slang) The act of vomiting. 
3. (slang, uncountable) Vomit. 
4. (hurling, countable) The act of hitting the sliotar with the hurley. 
5. (Ulster, Scotland, slang, countable) A conveyance in a wheeled vehicle; a ride in a car, etc. 
6. (obsolete) Tumult; riot; hurly-burly. 
7. (obsolete, countable) A table on which fibre is stirred and mixed by beating with a bow spring. 

## Synonyms
[[cast]] | [[throw]] | [[thrust]] | [[lunge]] | [[hurtle]]