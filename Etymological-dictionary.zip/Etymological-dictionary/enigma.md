# enigma

## Etymology
- From Latin aenigma (“riddle”), being derived itself from the Ancient Greek verbal noun αἴνιγμα (aínigma, “dark saying, speaking in riddles”).


## Definition
### Noun
1. Something or someone puzzling, mysterious or inexplicable. 
2. A riddle, or a difficult problem. 
3. (historical) A German device used during World War II to encode strategic messages. 

## Synonyms
[[conundrum]] | [[secret]] | [[mystery]] | [[riddle]]