# eliminate

## Etymology
- From Latin ēlīminātus, past participle of ēlīmināre (“to turn out of doors, banish”), from ē (“out”) + līmen (“a threshold”), akin to līmes (“a boundary”); see English limit and limen.


## Definition
### Verb
1. (transitive) To completely remove, get rid of, put an end to. 
2. (transitive, slang) To kill (a person or animal). 
3. (transitive, intransitive, physiology) To excrete (waste products). 
4. (transitive) To exclude (from investigation or from further competition). 
5. (accounting) To record amounts in a consolidation statement to remove the effects of inter-company transactions. 

## Synonyms
[[pass]] | [[void]] | [[obviate]] | [[eradicate]] | [[empty]] | [[decimate]] | [[reject]] | [[annihilate]] | [[evacuate]] | [[extinguish]]