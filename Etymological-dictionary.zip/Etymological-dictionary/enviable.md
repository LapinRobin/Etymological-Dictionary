# enviable

## Etymology
- From Middle French enviable.


## Definition
### Adjective
1. Arousing or likely to arouse envy. 

## Synonyms
[[desirable]]