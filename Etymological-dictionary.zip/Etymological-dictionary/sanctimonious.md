# sanctimonious

## Etymology
- sanctimony +‎ -ous


## Definition
### Adjective
1. Making a show of being morally better than others, especially hypocritically pious. 
2. (archaic) Holy, devout. 

## Synonyms
[[pious]] | [[self-righteous]]