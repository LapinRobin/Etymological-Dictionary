# get together

## Definition
### Verb
1. Used other than figuratively or idiomatically: see get, together. 
2. to meet, to gather together, to congregate 
3. to accumulate, to gather 
4. to agree 
5. (idiomatic, reciprocal) To start dating; to start being a couple. 

## Synonyms
