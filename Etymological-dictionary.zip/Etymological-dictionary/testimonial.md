# testimonial

## Etymology
- From French testimonial, from Late Latin testimonialis (“of or pertaining to testimony”), from Latin testimonium (“testimony”). See testimony.


## Definition
### Noun
1. A statement, especially one given under oath; testimony 
2. A written recommendation of someone's worth or character 
3. A tribute given in appreciation of someone's service etc. 
4. (soccer) A match played in tribute to a particular player (who sometimes receives a proportion of the gate money). 

### Adjective
1. Serving as testimony. 

## Synonyms
[[tribute]] | [[testimony]] | [[recommendation]]