# afresh

## Etymology
- From Middle English a-fresche, equivalent to a- +‎ fresh. Compare Old English afersċean (“to freshen; become fresh”).


## Definition
### Adverb
1. Anew; again; once more 

## Synonyms
[[anew]]