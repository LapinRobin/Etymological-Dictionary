# well-balanced

## Definition
### Adjective
1. properly balanced; in equilibrium 
2. mentally stable and free from psychological disorder 

## Synonyms
[[balanced]]