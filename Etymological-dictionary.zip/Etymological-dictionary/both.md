# both

## Etymology
- From Middle English bothe, boþe, from Old English bā þā (“both the; both those”) and Old Norse báðir, from Proto-Germanic *bai. Cognate with Saterland Frisian bee (“both”), West Frisian beide (“both”), Dutch beide (“both”), German beide (“both”), Swedish både, båda, Danish både, Norwegian både, Icelandic báðir. Replaced Middle English bō, from Old English bā, a form of Old English bēġen.


## Definition
### Noun
1. A surname. 

## Synonyms
