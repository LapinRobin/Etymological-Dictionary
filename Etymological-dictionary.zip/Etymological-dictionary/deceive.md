# deceive

## Etymology
- From Middle English deceyven, desayven, dissayven, from Old French decever, decevoir, from Latin dēcipiō (“to deceive; beguile; entrap”), from dē- (“from”) + capiō (“to seize”); see captive. Compare conceive, perceive, receive. Displaced native Old English beswīcan.


## Definition
### Verb
1. (transitive) To trick or mislead. 

## Synonyms
[[betray]] | [[delude]] | [[cozen]]