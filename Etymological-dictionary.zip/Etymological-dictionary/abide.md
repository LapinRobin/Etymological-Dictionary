# abide

## Etymology
- From Middle English abyden, from Old English ābīdan (“to abide, wait, remain, delay, remain behind; survive; wait for, await; expect”), from Proto-Germanic *uzbīdaną (“to expect, tolerate”), equivalent to a- +‎ bide. Cognate with Scots abide (“to abide, remain”), Middle High German erbīten (“to await, expect”), Gothic 𐌿𐍃𐌱𐌴𐌹𐌳𐌰𐌽 (usbeidan, “to expect, await, have patience”). The sense of pay for is due to influence from aby.


## Definition
### Verb
1. (transitive) To endure without yielding; to withstand. 
2. (transitive) To bear patiently. 
3. (transitive) To pay for; to stand the consequences of. 
4. Used in a phrasal verb: abide by (“to accept and act in accordance with”). 
5. (intransitive, obsolete) To wait in expectation. 
6. (intransitive, obsolete) To pause; to delay. 
7. (intransitive, archaic, Scotland) To stay; to continue in a place; to remain stable or fixed in some state or condition; to be left. 
8. (intransitive, archaic) To have one's abode. 
9. (intransitive, archaic) To endure; to remain; to last. 
10. (transitive, archaic) To stand ready for; to await for someone; watch for. 
11. (transitive, obsolete) To endure or undergo a hard trial or a task; to stand up under. 
12. (transitive, archaic) To await submissively; accept without question; submit to. 

## Synonyms
[[bear]] | [[stand]] | [[endure]] | [[stay]] | [[suffer]] | [[stomach]] | [[brook]] | [[tolerate]] | [[put up]] | [[bide]]