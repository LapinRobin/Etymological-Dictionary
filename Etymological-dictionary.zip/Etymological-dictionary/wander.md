# wander

## Etymology
- From Middle English wandren, wandrien, from Old English wandrian (“to wander, roam, fly around, hover; change; stray, err”), from Proto-Germanic *wandrōną (“to wander”), from Proto-Indo-European *wendʰ- (“to turn, wind”), equivalent to wend + -er. Cognate with Scots wander (“to wander”), German wandern (“to wander, roam, hike, migrate”), Swedish vandra (“to wander, hike”).


## Definition
### Verb
1. (intransitive) To move without purpose or specified destination; often in search of livelihood. 
2. (intransitive) To stray; stray from one's course; err. 
3. (intransitive) To commit adultery. 
4. (intransitive) To go somewhere indirectly or at varying speeds; to move in a curved path. 
5. (intransitive) Of the mind, to lose focus or clarity of argument or attention. 

### Noun
1. (countable) An act or instance of wandering. 
2. (uncountable) The situation where a value or signal etc. deviates from the correct or normal value. 
3. A surname. 

## Synonyms
[[cast]] | [[range]] | [[drift]] | [[cuckold]] | [[swan]] | [[betray]] | [[stray]] | [[digress]] | [[cheat]] | [[roam]] | [[vagabond]] | [[ramble]] | [[rove]]