# warmonger

## Etymology
- war +‎ monger


## Definition
### Noun
1. (derogatory) Someone who advocates war; a militarist. 

### Verb
1. (derogatory, intransitive) To advocate war. 

## Synonyms
