# au pair

## Etymology
- Borrowed from French être au pair.


## Definition
### Noun
1. A single girl (or, rarely, a boy), usually a foreigner, who helps a host family with childcare, housework, or both while staying as a guest with a host family, and generally receives a small allowance (or pocket money). 

## Synonyms
