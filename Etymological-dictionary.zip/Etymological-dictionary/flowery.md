# flowery

## Etymology
- From Middle English floury, equivalent to flower +‎ -y.


## Definition
### Adjective
1. (not comparable) Pertaining to flowers. 
2. Decorated with or abundant in flowers. 
3. (of a speech or piece of writing) overly complicated or elaborate; with grandiloquent expressions; marked by rhetorical elegance 

## Synonyms
[[rhetorical]] | [[ornate]]