# combustion

## Etymology
- From Old French combustion, from Latin combustio, from comburere (“to burn”), itself from the intensifying prefix com- + the root burere (a faulty sep. of amburere "to burn around", itself from ambi- + urere "to burn, singe"); equivalent to combust +‎ -ion.


## Definition
### Noun
1. (chemistry) The act or process of burning. 
2. A process where two chemicals are combined to produce heat. 
3. A process wherein a fuel is combined with oxygen, usually at high temperature, releasing heat. 
4. (figuratively) Violent agitation, tumult. 

## Synonyms
[[burning]]