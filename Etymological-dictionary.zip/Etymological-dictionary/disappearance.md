# disappearance

## Etymology
- Morphologically disappear +‎ -ance.


## Definition
### Noun
1. The action of disappearing or vanishing. 

## Synonyms
[[fade]]