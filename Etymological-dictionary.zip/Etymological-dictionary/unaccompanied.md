# unaccompanied

## Etymology
- un- +‎ accompanied


## Definition
### Adjective
1. travelling without companions 
2. (music) performed or scored without accompaniment; solo 

## Synonyms
[[alone]] | [[solitary]] | [[stranded]] | [[isolated]]