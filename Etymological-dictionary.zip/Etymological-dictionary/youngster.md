# youngster

## Etymology
- Derived from young +‎ -ster.


## Definition
### Noun
1. A young person. 

## Synonyms
[[child]] | [[minor]] | [[kid]] | [[fry]] | [[tyke]]