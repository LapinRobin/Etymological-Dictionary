# sultry

## Etymology
- From sulter (“verb (obsolete), a variant of swelter”) +‎ -y; compare sweltry.


## Definition
### Adjective
1. (weather) Hot and humid. 
2. (weather) Very hot and dry; torrid. 
3. (figuratively) Sexually enthralling. 

## Synonyms
[[hot]] | [[torrid]] | [[sensual]]