# massacre

## Etymology
- 1580, from Middle French massacre, from Old French macacre, marcacre, macecre, macecle (“slaughterhouse, butchery”), usually thought to be deverbal from Old French macecrer, macecler (“to slaughter”), though the noun seems to be attested somewhat earlier. It is also found in Medieval Latin mazacrium (“massacre, slaughter, killing”, also “the head of a newly killed stag”). Further origin disputed:


## Definition
### Noun
1. The killing of a considerable number (usually limited to people) where little or no resistance can be made, with indiscriminate violence, without necessity, and contrary to civilized norms. 
2. (obsolete) Murder. 
3. (figuratively) Any overwhelming defeat, as in a game or sport. 

### Verb
1. (transitive) To kill in considerable numbers where little or no resistance can be made, with indiscriminate violence, without necessity, and contrary to civilized norms. (Often limited to the killing of human beings.) 
2. (transitive, figuratively) To win against (an opponent) very decisively. 
3. (transitive, figuratively) To perform (a work, such as a musical piece or a play) very poorly. 
4. (transitive, proscribed) To kill with great force or brutality. 

## Synonyms
[[slaughter]]