# balanced

## Definition
### Adjective
1. Containing elements in appropriate proportion; proportionately weighted on all dimensions and therefore unlikely to tip over. 

## Synonyms
[[stable]] | [[poised]] | [[equal]] | [[harmonious]] | [[symmetrical]]