# pushy

## Etymology
- From push +‎ -y.


## Definition
### Adjective
1. Overly assertive, bold or determined; aggressively ambitious. 

## Synonyms
[[aggressive]] | [[ambitious]] | [[enterprising]]