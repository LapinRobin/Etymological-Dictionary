# foreboding

## Etymology
- From Middle English forbodyng, vorboding, equivalent to fore- +‎ boding. Compare German Vorbote (“harbinger, omen”).


## Definition
### Noun
1. A sense of evil to come. 
2. An evil omen. 

### Adjective
1. Of ominous significance; serving as an ill omen; foretelling of harm or difficulty. 

## Synonyms
[[portentous]] | [[premonition]] | [[presentiment]]