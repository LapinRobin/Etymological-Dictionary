# e-mail

## Definition
### Noun
1. Alternative spelling of email.  

### Verb
1. Alternative spelling of email  

## Synonyms
[[email]]