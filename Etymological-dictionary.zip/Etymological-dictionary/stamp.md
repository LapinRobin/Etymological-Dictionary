# stamp

## Etymology
- From Middle English stampen (“to pound, crush”), from assumed Old English *stampian, variant of Old English stempan (“to crush, pound, pound in mortar, stamp”), from Proto-West Germanic *stampōn, *stampijan, from Proto-Germanic *stampōną, *stampijaną (“to trample, beat”), from Proto-Indo-European *stemb- (“to trample down”). Cognate with Dutch stampen (“to stamp, pitch”), German stampfen (“to stamp”), Danish stampe (“to stamp”), Swedish stampa (“to stomp”), Occitan estampar, Polish stąpać (“to step, treat”). See also stomp, step. Marks indicating that postage had been paid were originally made by stamping the item to be mailed; when affixed pieces of paper were introduced for this purpose, the term “stamp” was transferred to cover this new form.


## Definition
### Noun
1. An act of stamping the foot, paw or hoof. 
2. An indentation, imprint, or mark made by stamping. 
3. A device for stamping designs. 
4. A small piece of paper, with a design and a face value, used to prepay postage or other dues such as tax or licence fees. 
5. A small piece of paper bearing a design on one side and adhesive on the other, used to decorate letters or craft work. 
6. (slang, figuratively) A tattoo. 
7. (slang) A single dose of lysergic acid diethylamide. 
8. A kind of heavy pestle, raised by water or steam power, for crushing ores. 
9. Cast; form; character; distinguishing mark or sign; evidence. 
10. A surname. 

### Verb
1. (intransitive) To step quickly and heavily, once or repeatedly. 
2. (transitive) To move (the foot or feet) quickly and heavily, once or repeatedly. 
3. (transitive) To strike, beat, or press forcibly with the bottom of the foot, or by thrusting the foot downward. 
4. (transitive) To mark by pressing quickly and heavily. 
5. (transitive) To give an official marking to, generally by impressing or imprinting a design or symbol. 
6. (transitive) To apply postage stamps to. 
7. (transitive, figuratively) To mark; to impress. 

## Synonyms
[[cast]] | [[seal]] | [[stereotype]] | [[mold]] | [[boss]] | [[impression]] | [[stump]] | [[stomp]] | [[pigeonhole]] | [[emboss]] | [[pestle]]