# gamut

## Etymology
- 1520s, original sense “lowest note of musical scale”, from Medieval Latin gamma ut, from gamma (“Greek letter, corresponding to the musical note G”) + ut (“first solfège syllable, now replaced by do”). In modern terms, “G do” – the first note of the G scale. Meaning later extended to mean all the notes of a scale, and then more generally any complete range.


## Definition
### Noun
1. A (normally) complete range. 
2. (music) All the notes in a musical scale. 
3. All the colours that can be presented by a device such as a monitor or printer. 

## Synonyms
