# inveigh

## Etymology
- Borrowed from Latin invehō (“bring in, carry in”), from in- + vehō (“carry”). Compare vehicle, invective.


## Definition
### Verb
1. (intransitive, with against or occasionally about, formerly also with on, at, upon) To complain loudly, to give voice to one's censure or criticism 
2. (obsolete, transitive) To draw in or away; to entice, inveigle. 

## Synonyms
[[rail]]