# jetty

## Etymology
- From French jetée (“pier, jetty, causeway”), from jeter. Compare jet, jutty.

- jet +‎ -y


## Definition
### Noun
1. A structure of wood or stone extended into the sea to influence the current or tide, or to protect a harbor or beach. 
2. A wharf or dock extending from the shore. 
3. (architecture) A part of a building that jets or projects beyond the rest, and overhangs the wall below. 

### Verb
1. (obsolete, intransitive) To jut out; to project. 

### Adjective
1. (archaic) Made of jet, or like jet in color. 

## Synonyms
[[mole]] | [[bulwark]] | [[groin]] | [[groyne]]