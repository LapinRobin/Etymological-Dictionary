# delighted

## Definition
### Adjective
1. Greatly pleased. 
2. Filled with wonder and delight. 

## Synonyms
[[pleased]] | [[enthralled]] | [[enchanted]] | [[beguiled]]