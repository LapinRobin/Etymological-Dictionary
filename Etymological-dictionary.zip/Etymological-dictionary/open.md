# open

## Etymology
- From Middle English open, from Old English open (“open”), from Proto-West Germanic *opan, from Proto-Germanic *upanaz (“open”), from Proto-Indo-European *upo (“up from under, over”). Cognate with Scots apen (“open”), Saterland Frisian eepen (“open”), West Frisian iepen (“open”), Dutch open (“open”), Low German open, apen (“open”), German offen (“open”), Danish åben (“open”), Swedish öppen (“open”), Norwegian Bokmål åpen (“open”), Norwegian Nynorsk open (“open”), Icelandic opinn (“open”). Compare also Latin supinus (“on one's back, supine”), Albanian hap (“to open”). Related to up.

- From Middle English openen, from Old English openian (“to open”), from Proto-Germanic *upanōną (“to raise; lift; open”), from Proto-Germanic *upanaz (“open”, adjective). Cognate with Saterland Frisian eepenje (“to open”), West Frisian iepenje (“to open”), Dutch openen (“to open”), German öffnen (“to open”), Danish åbne (“to open”), Swedish öppna (“to open”), Norwegian Bokmål åpne (“to open”), Norwegian Nynorsk and Icelandic opna (“to open”). Related to English up.

- From Middle English open (“an aperture or opening”), from the verb (see Etymology 2 above). In the sports sense, however, a shortening of “open competition”.


## Definition
### Adjective
1. Able to be accessed. 
2. Able to have something pass through or along it. 
3. (of a body part) not covered, showing what is inside 
4. Not physically drawn together, closed, folded or contracted; extended. 
5. (not comparable) Actively conducting or prepared to conduct business. 
6. (comparable) Receptive. 
7. (not comparable) Public 
8. (not comparable) Candid, ingenuous, not subtle in character. 
9. (now regional) Mild (of the weather); free from frost or snow. 
10. (mathematics, logic, of a formula) Having a free variable. 
11. (mathematics, topology, of a set) Which is part of a predefined collection of subsets of X, that defines a topological space on X. 
12. (graph theory, of a walk) Whose first and last vertices are different. 
13. (computing, not comparable, of a file, document, etc.) In current use; mapped to part of memory. 
14. (engineering, gas and liquid flow, of valve or damper) To be in a position allowing fluid to flow. 
15. (electricity, of a switch or circuit breaker) To be in a position preventing electricity from flowing. 
16. (business) Not fulfilled. 
17. Not settled or adjusted; not decided or determined; not closed or withdrawn from consideration. 
18. (music, stringed instruments) Of a note, played without pressing the string against the fingerboard. 
19. (music) Of a note, played without closing any finger-hole, key or valve. 
20. Not of a quality to prevent communication, as by closing waterways, blocking roads, etc.; hence, not frosty or inclement; mild; used of the weather or the climate. 
21. (law, of correspondence) Written or sent with the intention that it may made public or referred to at any trial, rather than by way of confidential private negotiation for a settlement. 
22. (phonetics) Uttered with a relatively wide opening of the articulating organs; said of vowels. 
23. (phonetics) Uttered, as a consonant, with the oral passage simply narrowed without closure. 
24. (phonetics, of a syllable) That ends in a vowel; not having a coda. 
25. (computing, education) Made public, usable with a free licence and without proprietary components. 
26. (medicine) Resulting from an incision, puncture or any other process by which the skin no longer protects an internal part of the body. 
27. (computing, used before "code") Source code of a computer program that is not within the text of a macro being generated. 
28. (of a multi-word compound) Having component words separated by spaces, as opposed to being joined together or hyphenated; for example, time slot as opposed to timeslot or time-slot. 

### Verb
1. (transitive) To make something accessible or allow for passage by moving from a shut position. 
2. (transitive) To make (an open space, etc.) by clearing away an obstacle or obstacles, in order to allow for passage, access, or visibility. 
3. (transitive, intransitive, engineering, gas and liquid flow, of valve or damper) To move to a position allowing fluid to flow. 
4. (transitive, intransitive, electricity, of a switch, fuse or circuit breaker) To move to a position preventing electricity from flowing. 
5. (Manglish, Philippines) To turn on; to switch on. 
6. (transitive) To bring up, broach. 
7. (transitive) To enter upon, begin. 
8. (transitive) To spread; to expand into an open or loose position. 
9. (transitive) To make accessible to customers or clients. 
10. (transitive) To start (a campaign). 
11. (intransitive) To become open. 
12. (intransitive) To begin conducting business. 
13. (intransitive, cricket) To begin a side's innings as one of the first two batsmen. 
14. (intransitive, poker) To bet before any other player has in a particular betting round in a game of poker. 
15. (transitive, intransitive, poker) To reveal one's hand. 
16. (computing, transitive, intransitive, of a file, document, etc.) To load into memory for viewing or editing. 
17. (transitive, nursing) To make (a bed) ready for a patient by folding back the bedcovers. 
18. (obsolete) To disclose; to reveal; to interpret; to explain. 

### Noun
1. (with the) Open or unobstructed space; an exposed location. 
2. (with the) Public knowledge or scrutiny; full view. 
3. (electronics) A defect in an electrical circuit preventing current from flowing. 
4. A sports event in which anybody can compete. 
5. The act of something being opened, such as an e-mail message. 

## Synonyms
[[air]] | [[clear]] | [[free]] | [[loose]] | [[spread]] | [[give]] | [[vulnerable]] | [[candid]] | [[afford]] | [[conspicuous]] | [[blatant]] | [[active]] | [[available]] | [[overt]] | [[surface]] | [[obvious]] | [[raw]] | [[public]] | [[coarse]] | [[honest]] | [[empty]] | [[wide]] | [[naked]] | [[ingenuous]] | [[impartial]] | [[bald]] | [[blazing]] | [[visible]] | [[unfold]] | [[honorable]] | [[exposed]] | [[staring]] | [[outdoors]] | [[gaping]]