# accepted

## Etymology
- accept +‎ -ed


## Definition
### Adjective
1. Generally approved, believed, or recognized. 

## Synonyms
[[standard]] | [[conventional]] | [[established]] | [[acceptable]] | [[received]]