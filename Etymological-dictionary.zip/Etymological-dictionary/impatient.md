# impatient

## Etymology
- From Old French impacient (modern French impatient), from Latin impatiēns.


## Definition
### Adjective
1. Restless and intolerant of delays. 
2. Anxious and eager, especially to begin something. 
3. (obsolete) Not to be borne; unendurable. 
4. Prompted by, or exhibiting, impatience. 

## Synonyms
[[short]] | [[restive]]