# disobedient

## Etymology
- From Old French desobedient; morphologically, from dis- +‎ obedient.


## Definition
### Adjective
1. Not obedient. 

### Noun
1. One who disobeys. 

## Synonyms
[[obstinate]] | [[contrary]] | [[recusant]] | [[perverse]] | [[refractory]] | [[fractious]] | [[wayward]] | [[unruly]] | [[willful]] | [[headstrong]] | [[froward]]