# foe

## Etymology
- From Middle English fo (“foe; hostile”), from earlier ifo (“foe”), from Old English ġefāh (“enemy”), from fāh (“hostile”), from Proto-West Germanic *faih, from Proto-Germanic *faihaz (compare Old Frisian fāch (“punishable”), Middle High German gevēch (“feuder”)), from Proto-Indo-European *peyk/ḱ- (“to hate, be hostile”) (compare Middle Irish óech (“enemy, fiend”), Lithuanian pìktas (“evil”)).

- Acronym of  fifty-one ergs, due to equalling 1051 ergs; coined by Gerald Brown of Stony Brook University in his work with Hans Bethe.


## Definition
### Adjective
1. (obsolete) Hostile. 

### Noun
1. An enemy. 
2. A unit of energy equal to 10⁴⁴ joules. 
3. Initialism of Friends of the Earth. 
4. Initialism of Fraternal Order of Eagles. 
5. Initialism of freedom of expression.  
6. Initialism of forces of evil. 

## Synonyms
[[opposition]] | [[enemy]] | [[opponent]]