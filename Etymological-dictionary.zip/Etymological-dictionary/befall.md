# befall

## Etymology
- From Middle English bifallen, from Old English befeallan, from Proto-Germanic *bifallaną; equivalent to be- +‎ fall.


## Definition
### Verb
1. (transitive) To fall upon; fall all over; overtake 
2. (intransitive) To happen. 
3. (transitive) To happen to. 
4. (intransitive, obsolete) To fall. 

### Noun
1. Case; instance; circumstance; event; incident; accident. 

## Synonyms
[[happen]]