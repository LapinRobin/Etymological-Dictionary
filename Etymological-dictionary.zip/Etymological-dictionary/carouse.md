# carouse

## Etymology
- From Middle French carousser (“to quaff, drink, swill”), from German gar aus (literally “quite out”), from gar austrinken (“to drink up entirely, guzzle”). Compare German Garaus.


## Definition
### Verb
1. (intransitive) To engage in a noisy or drunken social gathering. 
2. (intransitive) To drink to excess. 

### Noun
1. A large draught of liquor. 
2. A drinking bout; a carousal. 

## Synonyms
[[riot]]