# vote

## Etymology
- From Latin vōtum, a form of voveō (“I vow”) (cognate with Ancient Greek εὔχομαι (eúkhomai, “to vow”)), from Proto-Indo-European *h₁wegʷʰ-. The word is thus a doublet of vow.


## Definition
### Noun
1. a formalized choice on legally relevant measures such as employment or appointment to office or a proceeding about a legal dispute. 
2. an act or instance of participating in such a choice, e.g., by submitting a ballot 
3. (obsolete) an ardent wish or desire; a vow; a prayer 
4. (obsolete) a formalized petition or request 
5. (obsolete) any judgment of intellect leading to a formal opinion, a point of view 
6. any judgment of intellect leading not only to a formal opinion but also to a particular choice in a legally relevant measure, a point of view as published 
7. A person from Votia or of Votic descent. 

### Verb
1. (intransitive) to cast a vote; to assert a formalized choice in an election 
2. (transitive) to choose or grant by means of a vote, or by general consent 

## Synonyms
[[suffrage]] | [[ballot]]