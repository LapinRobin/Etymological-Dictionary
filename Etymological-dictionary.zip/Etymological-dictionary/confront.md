# confront

## Etymology
- From Middle French confronter, from Old French confronter, from Medieval Latin confrontāre, from con- + frons (“forehead”, “front”).


## Definition
### Verb
1. (transitive) To stand or meet facing, especially in competition, hostility or defiance; to come face to face with 
2. (transitive) To deal with. 
3. (transitive) To bring someone face to face with something. 
4. (transitive) To come up against; to encounter. 
5. (intransitive) To engage in confrontation. 
6. (transitive) To set a thing side by side with; to compare. 
7. (transitive) To put a thing facing to; to set in contrast to. 

## Synonyms
[[face]] | [[present]]