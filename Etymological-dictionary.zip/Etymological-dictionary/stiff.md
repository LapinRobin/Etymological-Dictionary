# stiff

## Etymology
- From Middle English stiff, stiffe, stif, from Old English stīf, from Proto-West Germanic *stīf, from Proto-Germanic *stīfaz, from Proto-Indo-European *steypós.


## Definition
### Adjective
1. (of an object) Rigid; hard to bend; inflexible. 
2. (figuratively, of policies and rules and their application and enforcement) Inflexible; rigid. 
3. (of a person) Formal in behavior; unrelaxed. 
4. (colloquial) Harsh, severe. 
5. (of muscles or parts of the body) Painful as a result of excessive or unaccustomed exercise. 
6. Potent. 
7. (informal) Dead, deceased. 
8. (of the penis) Erect. 
9. Having a dense consistency; thick; (by extension) Difficult to stir. 
10. (cooking, of whipping cream or egg whites) Beaten until so aerated that they stand up straight on their own. 
11. (mathematics) Of an equation: for which certain numerical solving methods are numerically unstable, unless the step size is taken to be extremely small. 
12. (nautical) Keeping upright. 
13. (golf) Of a shot: landing so close to the flagstick that it should be very easy to sink the ball with the next shot. 
14. (professional wrestling, of a strike) Delivered more forcefully than needed, whether intentionally or accidentally, thus causing legitimate pain to the opponent. 

### Noun
1. (slang, chiefly Canada, US) An average person, usually male, of no particular distinction, skill, or education. 
2. (slang) A person who is deceived, as a mark or pigeon in a swindle. 
3. (slang) A cadaver; a dead person. 
4. (slang) A flop; a commercial failure. 
5. (US, slang) A person who leaves (especially a restaurant) without paying the bill. 
6. (US, slang, by extension) A customer who does not leave a tip. 
7. (blackjack) Any hard hand where it is possible to exceed 21 by drawing an additional card. 
8. (finance, slang) Negotiable instruments, possibly forged. 
9. (prison slang) A note or letter surreptitiously sent by an inmate. 
10. A surname. 

### Verb
1. To fail to pay that which one owes (implicitly or explicitly) to another, especially by departing hastily. 
2. To cheat someone 
3. To tip ungenerously. 
4. (slang) To kill. 

### Adverb
1. (nautical) Of the wind, with great force; strongly. 

## Synonyms
[[blind]] | [[hard]] | [[wet]] | [[strong]] | [[tight]] | [[rigid]] | [[clay]] | [[formal]] | [[drunk]] | [[besotted]] | [[corpse]] | [[cadaver]] | [[loaded]] | [[potty]] | [[tipsy]] | [[inebriated]] | [[inflexible]] | [[remains]]