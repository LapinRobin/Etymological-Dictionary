# texture

## Etymology
- Borrowed from Middle French texture, borrowed from Latin textūra (“a weaving, web, texture, structure”), from textus, past participle of texere (“to weave”). See text. Doublet of tessitura.


## Definition
### Noun
1. The feel or shape of a surface or substance; the smoothness, roughness, softness, etc. of something. 
2. (art) The quality given to a work of art by the composition and interaction of its parts. 
3. (computer graphics) An image applied to a polygon to create the appearance of a surface. 
4. (obsolete) The act or art of weaving. 
5. (obsolete) Something woven; a woven fabric; a web. 
6. (biology, obsolete) A tissue. 

### Verb
1. To create or apply a texture. 

## Synonyms
