# coincide

## Etymology
- From French coïncider, from Medieval Latin coincidere, from con- + incidere, from in- (“into, to”) +‎ cadere (“to fall, fall down, drop”).


## Definition
### Verb
1. To occupy exactly the same space. 
2. To occur at the same time. 
3. To correspond, concur, or agree. 

## Synonyms
[[concur]]