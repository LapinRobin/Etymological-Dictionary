# strand

## Etymology
- From Middle English strand, strond, from Old English strand (“strand, sea-shore, shore”), from Proto-West Germanic *strand, from Proto-Germanic *strandō (“edge, rim, shore”), from Proto-Indo-European *(s)trAnt- (“strand, border, field”), from Proto-Indo-European *ster- (“to broaden, spread out”). Cognate with West Frisian strân, Dutch strand, German Strand, Danish strand, Swedish strand, Norwegian Bokmål strand. (street): Perhaps from the similarity of shape.
- Origin uncertain. Cognate with Scots stran, strawn, strand (“strand”). Perhaps the same as strand ("rivulet, stream, gutter"; see Etymology 1 above); or from Middle English *stran, from Old French estran (“a rope, cord”), from Middle High German stren, strene (“skein, strand”), from Old High German streno, from Proto-West Germanic *strenō, from Proto-Germanic *strinô (“strip, strand”), from Proto-Indo-European *strēy-, *ster- (“strip, line, streak, ray, stripe, row”); related to Dutch streen (“skein, hank of thread, strand, string”), German Strähne (“skein, hank of thread, strand of hair”).


## Definition
### Noun
1. The shore or beach of the sea or ocean; shore; beach. 
2. (poetic, archaic or regional) The shore or beach of a lake or river. 
3. A small brook or rivulet. 
4. (Britain dialectal, Northern England, Scotland) A passage for water; gutter. 
5. A street. 
6. Each of the strings which, twisted together, make up a yarn, rope or cord. 
7. A string. 
8. An individual length of any fine, string-like substance. 
9. (electronics) A group of wires, usually twisted or braided. 
10. (broadcasting) A series of programmes on a particular theme or linked subject. 
11. (figuratively) An element in a composite whole; a sequence of linked events or facts; a logical thread. 
12. (genetics) A nucleotide chain. 
13. A surname. 
14. A street in Westminster running from Trafalgar Square to Fleet Street. 
15. An area surrounding the street in central London, England. 
16. A municipality of Rogaland, Norway. 

### Verb
1. (transitive, nautical) To run aground; to beach. 
2. (transitive, figuratively) To leave (someone) in a difficult situation; to abandon or desert. 
3. (transitive, baseball) To cause the third out of an inning to be made, leaving a runner on base. 
4. (transitive) To break a strand of (a rope). 
5. (transitive) To form by uniting strands. 

## Synonyms
[[chain]] | [[string]] | [[maroon]] | [[filament]]