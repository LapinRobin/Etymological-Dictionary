# organized

## Definition
### Adjective
1. (of things or settings) Having been organized; in good order. 
2. (of a person) Characterised by efficient organization. 
3. Unionized. 

## Synonyms
[[union]] | [[corporate]] | [[orderly]] | [[methodical]] | [[incorporated]]