# light out

## Etymology
- Phrasal verb from light (“to get down, drop, come”, verb) +‎ out (“away from”, adverb).


## Definition
### Verb
1. (intransitive, slang, dated) To go away or depart, especially in haste or without notice. 

## Synonyms
