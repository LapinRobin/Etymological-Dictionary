# happen

## Etymology
- From Middle English happenen, hapnen, augmented from Middle English happen (“to come to pass, happen”), perhaps from Old English hæppan (“to move accidentally, slip”) and/or from Old Norse *happa, *heppa, from Proto-Germanic *hampijaną (“to fit in, be fitting”). Equivalent to hap (“a chance, occurrence, byfall”) +‎ -en (verbal suffix).


## Definition
### Verb
1. (intransitive) To occur or take place. 
2. (transitive, archaic) To happen to; to befall. 
3. (intransitive or impersonal, with infinitive) To do or occur by chance or unexpectedly. 
4. (followed by on or upon) To encounter by chance. 

### Adverb
1. (obsolete or dialect) maybe, perhaps. 

## Synonyms
[[pass]] | [[find]] | [[hit]] | [[chance]] | [[encounter]] | [[bump]] | [[occur]] | [[befall]] | [[materialize]] | [[hap]]