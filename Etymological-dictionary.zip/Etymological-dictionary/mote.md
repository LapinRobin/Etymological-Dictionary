# mote

## Etymology
- From Middle English mot, from Old English mot (“grain of sand; mote; atom”), but of uncertain ultimate origin. Sometimes linked to Spanish mota (“speck”) and English mud.

- From Middle English moten, from Old English mōtan (“to be allowed, be able to, have the opportunity to, be compelled to, may, must”), from Proto-Germanic *mōtaną (“to be able to, have to, be delegated”), from Proto-Indo-European *med- (“to acquire, possess, be in charge of”). Cognate with Dutch moeten (“to have to, must”), German müssen (“to have to, must”), Ancient Greek μέδω (médō, “to prevail, dominate, rule over”). Related to empty.

- See moot (“a meeting”).

- From remote, with allusion to the other sense of mote (“a speck of dust”).


## Definition
### Noun
1. A small particle; a speck. 
2. (obsolete) A meeting for discussion. 
3. (obsolete) A body of persons who meet for discussion, especially about the management of affairs. 
4. (obsolete) A place of meeting for discussion. 
5. A tiny computer for remote sensing; a component element of smartdust. 
6. A surname. 

### Verb
1. (archaic) May or might. 
2. (obsolete) Must. 
3. (archaic) Forming subjunctive expressions of wish: may. 

## Synonyms
[[particle]] | [[atom]] | [[molecule]] | [[speck]]