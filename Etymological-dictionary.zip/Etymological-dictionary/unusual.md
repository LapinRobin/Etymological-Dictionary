# unusual

## Etymology
- From un- +‎ usual.


## Definition
### Adjective
1. Not usual, out of the ordinary 

### Noun
1. Something that is unusual; an anomaly. 

## Synonyms
[[unique]] | [[weird]] | [[other]] | [[different]] | [[peculiar]] | [[quaint]] | [[eerie]] | [[curious]] | [[exotic]] | [[crazy]] | [[odd]] | [[queer]] | [[fantastic]] | [[funny]] | [[strange]] | [[grotesque]] | [[singular]] | [[antic]] | [[rum]] | [[gothic]] | [[rummy]] | [[freaky]]