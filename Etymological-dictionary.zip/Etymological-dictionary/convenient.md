# convenient

## Etymology
- From Middle English convenient, from Latin conveniens (“fit, suitable, convenient”), present participle of convenire (“to come together, suit”); see convene and compare covenant.


## Definition
### Adjective
1. Serving to reduce a difficulty, or accessible with minimum difficulty; expedient. 
2. Suspicious due to suiting someone's purposes very well. 
3. (obsolete) Fit; suitable; appropriate. 

## Synonyms
[[accessible]] | [[handy]] | [[favorable]] | [[opportune]] | [[spacious]] | [[commodious]]