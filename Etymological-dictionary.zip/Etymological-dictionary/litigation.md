# litigation

## Etymology
- litigate +‎ -ion.


## Definition
### Noun
1. (law) The conduct of a lawsuit. 

## Synonyms
