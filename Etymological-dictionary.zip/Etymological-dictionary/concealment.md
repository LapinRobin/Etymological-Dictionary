# concealment

## Etymology
- From Old French concelement (“concealment, secrecy”). Synchronically analyzable as conceal +‎ -ment.


## Definition
### Noun
1. The practice of keeping secrets. 
2. The condition of being hidden or concealed. 
3. (military) protection from observation or surveillance. 

## Synonyms
[[cover]] | [[screen]] | [[covert]] | [[privacy]]