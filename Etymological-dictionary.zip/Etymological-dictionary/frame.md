# frame

## Etymology
- From Middle English framen, fremen, fremmen (“to construct, build, strengthen, refresh, perform, execute, profit, avail”), from Old English framian, fremian, fremman (“to profit, avail, advance, perform, promote, execute, commit, do”), from Proto-West Germanic *frammjan, from Proto-Germanic *framjaną (“to perform, promote”), from Proto-Indo-European *promo- (“front, forward”). Cognate with Low German framen (“to commit, effect”), Danish fremme (“to promote, further, perform”), Swedish främja (“to promote, encourage, foster”), Icelandic fremja (“to commit”). More at from.


## Definition
### Verb
1. (transitive) To fit, as for a specific end or purpose; make suitable or comfortable; adapt; adjust. 
2. (transitive) To construct by fitting together or uniting various parts; fabricate by union of constituent parts. 
3. (transitive) To bring or put into form or order; adjust the parts or elements of; compose; contrive; plan; devise. 
4. (transitive) Of a constructed object such as a building, to put together the structural elements. 
5. (transitive) Of a picture such as a painting or photograph, to place inside a decorative border. 
6. (transitive) To position visually within a fixed boundary. 
7. (transitive) To construct in words so as to establish a context for understanding or interpretation. 
8. (transitive, criminology) Conspire to incriminate falsely a presumably innocent person. See frameup. 
9. (intransitive, dialectal, mining) To wash ore with the aid of a frame. 
10. (intransitive, dialectal) To move. 
11. (intransitive, obsolete) To proceed; to go. 
12. (tennis) To hit (the ball) with the frame of the racquet rather than the strings (normally a mishit). 
13. (transitive, obsolete) To strengthen; refresh; support. 
14. (transitive, obsolete) To execute; perform. 
15. (transitive, obsolete) To cause; to bring about; to produce. 
16. (intransitive, obsolete) To profit; avail. 
17. (intransitive, obsolete) To fit; accord. 
18. (intransitive, obsolete) To succeed in doing or trying to do something; manage. 

### Noun
1. The structural elements of a building or other constructed object. 
2. Anything composed of parts fitted and united together; a fabric; a structure. 
3. The structure of a person's body; the human body. 
4. A rigid, generally rectangular mounting for paper, canvas or other flexible material. 
5. A piece of photographic film containing an image. 
6. A context for understanding or interpretation. 
7. (snooker) A complete game of snooker, from break-off until all the balls (or as many as necessary to win) have been potted. 
8. (networking) An independent chunk of data sent over a network. 
9. (bowling) A set of balls whose results are added together for scoring purposes. Usually two balls, but only one ball in the case of a strike, and three balls in the case of a strike or a spare in the last frame of a game. 
10. (bowling) The complete set of pins to be knocked down in their starting configuration. 
11. (horticulture) A movable structure used for the cultivation or the sheltering of plants. 
12. (philately) The outer decorated portion of a stamp's image, often repeated on several issues although the inner picture may change. 
13. (philately) The outer circle of a cancellation mark. 
14. (electronics, film, animation, video games) A division of time on a multimedia timeline, such as 1/30th or 1/60th of a second. 
15. (Internet) An individually scrollable region of a webpage. 
16. (baseball, slang) An inning. 
17. (engineering, dated, chiefly UK) Any of certain machines built upon or within framework. 
18. (dated) Frame of mind; disposition. 
19. (obsolete) Contrivance; the act of devising or scheming. 
20. (dated, video games) A stage or location in a video game. 
21. (genetics, "reading frame") A way of dividing nucleotide sequences into a set of consecutive triplets. 
22. (computing) A form of knowledge representation in artificial intelligence. 
23. (mathematics) A complete lattice in which meets distribute over arbitrary joins. 
24. A surname. 
25. An unincorporated community in Kanawha County, West Virginia, United States. 

## Synonyms
[[cast]] | [[form]] | [[build]] | [[put]] | [[figure]] | [[shape]] | [[redact]] | [[outline]] | [[framework]] | [[couch]] | [[compose]] | [[border]] | [[chassis]] | [[flesh]] | [[anatomy]] | [[set up]] | [[skeleton]] | [[soma]] | [[bod]] | [[physique]] | [[ensnare]]