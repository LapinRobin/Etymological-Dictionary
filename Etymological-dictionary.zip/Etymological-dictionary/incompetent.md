# incompetent

## Etymology
- From French incompétent, from Late Latin incompetentem, from Latin incompetēns.


## Definition
### Adjective
1. Unskilled; lacking the degree of ability that would normally be expected. 
2. Unable to make rational decisions; insane or otherwise cognitively impaired. 
3. (medicine, of the cervix) Opening too early during pregnancy, resulting in miscarriage or premature birth. 
4. (geology) Not resistant to deformation or flow. 

### Noun
1. A person who is incompetent. 

## Synonyms
[[feckless]] | [[bad]] | [[inept]] | [[clumsy]] | [[inadequate]] | [[incapable]]