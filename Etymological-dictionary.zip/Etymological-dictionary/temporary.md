# temporary

## Etymology
- Borrowed from Latin temporarius, from tempus (“time”).


## Definition
### Adjective
1. Not permanent; existing only for a period or periods of time. 
2. Existing only for a short time or short times; transient, ephemeral. 

### Noun
1. One serving for a limited time; short-term employee. 
2. (programming) A temporary variable. 

## Synonyms
[[ephemeral]] | [[interim]] | [[temporal]] | [[transient]] | [[evanescent]] | [[irregular]] | [[makeshift]] | [[passing]] | [[transitory]] | [[episodic]]