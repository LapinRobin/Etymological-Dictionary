# eligible

## Etymology
- From Middle French eligible, from Latin eligibilis, from ēligō (“select, choose”).


## Definition
### Adjective
1. Allowed to and meeting the necessary conditions required to participate in or be chosen for something 
2. Worthy of being chosen (for marriage). 

### Noun
1. One who is eligible. 

## Synonyms
[[entitled]] | [[legal]] | [[suitable]] | [[worthy]] | [[desirable]]