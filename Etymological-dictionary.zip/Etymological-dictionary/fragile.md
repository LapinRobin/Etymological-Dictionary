# fragile

## Etymology
- Borrowed from Middle French fragile, from Latin fragilis, formed on frag-, the root of frangere (“to break”). Cognate  fraction, fracture and doublet of frail.


## Definition
### Adjective
1. Easily broken or destroyed, and thus often of subtle or intricate structure. 
2. (UK) Feeling weak or easily disturbed as a result of illness. 
3. (UK) Thin-skinned or oversensitive. 

### Noun
1. Something that is fragile. 

## Synonyms
[[delicate]] | [[weak]] | [[frail]] | [[flimsy]]