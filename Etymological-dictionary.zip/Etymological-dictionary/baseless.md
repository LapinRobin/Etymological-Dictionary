# baseless

## Etymology
- base +‎ -less


## Definition
### Adjective
1. Of reasoning: based on something that is not true, or not based on solid reasons or facts. 
2. Without a physical base. 

## Synonyms
[[idle]] | [[unwarranted]]