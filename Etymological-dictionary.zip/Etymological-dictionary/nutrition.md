# nutrition

## Etymology
- Borrowed from Middle French nutrition, from Old French nutricion, from Latin nutritio.


## Definition
### Noun
1. (biology) The organic process by which an organism assimilates food and uses it for growth and maintenance. 
2. That which nourishes; nutriment. 

## Synonyms
