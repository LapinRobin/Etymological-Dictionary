# digress

## Etymology
- From Latin digressum, past participle of digredi.


## Definition
### Verb
1. (intransitive) To step or turn aside; to deviate; to swerve; especially, to turn aside from the main subject of attention, or course of argument, in writing or speaking. 
2. (intransitive) To turn aside from the right path; to transgress; to offend. 

## Synonyms
[[wander]] | [[stray]] | [[depart]]