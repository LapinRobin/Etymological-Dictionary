# fitted

## Definition
### Verb
1. simple past tense of fit ("to tailor, to change size") 
2. (regional, sometimes proscribed) simple past tense of fit (other senses) 

### Adjective
1. (of a kitchen, bathroom, etc.) Incorporating all of the fittings into connected units. 

## Synonyms
