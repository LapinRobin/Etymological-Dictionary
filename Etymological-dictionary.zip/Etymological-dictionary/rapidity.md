# rapidity

## Etymology
- rapid +‎ -ity, from French rapidité, from Latin rapiditas.


## Definition
### Noun
1. speed, swiftness; the condition of being rapid 
2. (physics) A measure of velocity relative to the speed of light 
3. (physics) A measure of the velocity of a particle in a beam relative to the beam's axis 

## Synonyms
[[celerity]]