# language

## Etymology
- From Middle English langage, language, from Old French language, from Vulgar Latin *linguāticum, from Latin lingua (“tongue, speech, language”), from Old Latin dingua (“tongue”), from Proto-Indo-European *dn̥ǵʰwéh₂s (“tongue, speech, language”). Displaced native Old English ġeþēode.

- Alteration of languet.


## Definition
### Noun
1. (countable) A body of words, and set of methods of combining them (called a grammar), understood by a community and used as a form of communication. 
2. (uncountable) The ability to communicate using words. 
3. (uncountable) A sublanguage: the slang of a particular community or jargon of a particular specialist field. 
4. (countable, uncountable, figuratively) The expression of thought (the communication of meaning) in a specified way; that which communicates something, as language does. 
5. (countable, uncountable) A body of sounds, signs and/or signals by which animals communicate, and by which plants are sometimes also thought to communicate. 
6. (computing, countable) A computer language; a machine language. 
7. (uncountable) Manner of expression. 
8. (uncountable) The particular words used in a speech or a passage of text. 
9. (uncountable) Profanity. 
10. A languet, a flat plate in or below the flue pipe of an organ. 

### Verb
1. (rare, now nonstandard or technical) To communicate by language; to express in language. 

## Synonyms
[[speech]] | [[words]] | [[nomenclature]] | [[terminology]] | [[lyric]]