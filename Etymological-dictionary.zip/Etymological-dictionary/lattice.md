# lattice

## Etymology
- From Middle English latis, from Middle French lattis (“lathing”), from Old French lattis, from latte (“a lath”), from Frankish *latta (“a lath”), from Proto-Germanic *lattǭ, *lattō, *laþþō (“board; plank; ledge”), from Proto-Indo-European *(s)latn-, *(s)lat- (“beam; log”). Cognate with Old High German latta (“lath”), (German Latte), Old English lætt (“lath”), Middle Low German lāde (“plank, counter, sales counter”), German Laden (“shop”). More at lath.


## Definition
### Noun
1. A flat panel constructed with widely-spaced crossed thin strips of wood or other material, commonly used as a garden trellis. 
2. (heraldry) A bearing with vertical and horizontal bands that cross each other. 
3. (crystallography) A regular spacing or arrangement of geometric points, often decorated with a motif. 
4. (group theory) A discrete subgroup of Rⁿ which is isomorphic to Zⁿ (considered as an additive group) and spans the real vector space Rⁿ. 
5. (music) A model of the tuning relationships of a just intonation system, comprising an array of points in a periodic multidimensional pattern. 
6. (topology, Lie theory) A discrete subgroup L of a given locally compact group G whose quotient space G/L has finite invariant measure. 
7. (algebra, order theory) A partially ordered set in which every pair of elements has a unique supremum and a unique infimum. 

### Verb
1. To make a lattice of. 
2. To close, as an opening, with latticework; to furnish with a lattice. 

## Synonyms
[[wicket]] | [[grille]]