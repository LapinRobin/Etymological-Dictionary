# fabricate

## Etymology
- From Latin fabricātus, perfect passive participle of fabricor, fabricō (“build, forge”), from fabrica (“a fabric, building, etc.”); see fabric and forge. Compare with French fabrique.


## Definition
### Verb
1. (transitive) To form into a whole by uniting its parts; to construct; to build. 
2. (transitive) To form by art and labor; to manufacture; to produce. 
3. (transitive) To invent and form; to forge; to devise falsely. 
4. (transitive, cooking) To cut up an animal as preparation for cooking, particularly used in reference to fowl. 

## Synonyms
[[construct]] | [[manufacture]] | [[make up]] | [[invent]]