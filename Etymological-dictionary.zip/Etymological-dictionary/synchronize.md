# synchronize

## Etymology
- From Ancient Greek συγχρονίζω (sunkhronízō).


## Definition
### Verb
1. (intransitive) To occur at the same time or with coordinated timing. 
2. (transitive) To cause (video and audio) to play in a coordinated way. 
3. (transitive) To set (a clock or watch) to display the same time as another. 
4. (computing, transitive, intransitive) To cause (a set of files, data, or settings) on one computer or device to be (and try to remain) the same as on another. 
5. (intransitive, of inanimate entities) To agree, be coordinated with, or complement well. 
6. (transitive) To coordinate or combine. 

## Synonyms
[[sync]]