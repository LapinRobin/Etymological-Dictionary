# elf

## Etymology
- From Middle English elf, from Old English ielf, ælf, from Proto-West Germanic *albi, from Proto-Germanic *albiz. Ultimately probably derived from Proto-Indo-European *h₂elbʰós (“white”). Doublet of oaf.


## Definition
### Noun
1. (Norse mythology) A luminous spirit presiding over nature and fertility and dwelling in the world of Álfheim (Elfland). Compare angel, nymph, fairy. 
2. Any from a race of mythical, supernatural beings resembling but seen as distinct from human beings. They are usually delicate-featured and skilled in magic or spellcrafting; sometimes depicted as clashing with dwarves, especially in modern fantasy literature. 
3. (fantasy) Any of the magical, typically forest-guarding races bearing some similarities to the Norse álfar (through Tolkien's Eldar). 
4. A very diminutive person; a dwarf. 
5. (South Africa) The bluefish (Pomatomus saltatrix). 
6. (computing) Acronym of Executable and Linking Format (a common object file format for Unix) 
7. (electronics) Initialism of extremely low frequency (band of radio frequencies from 3 to 30 hertz)  
8. (linguistics) Acronym of English as a Lingua Franca (English used by non-native speakers) 
9. Initialism of Earth Liberation Front (a radical environmentalism group) 
10. Initialism of Elvish Linguistic Fellowship (an organization that studies the invented languages of J. R. R. Tolkien) 
11. Initialism of Endangered Language Fund (a non-profit organization) 

### Verb
1. (now rare) To twist into elflocks (of hair); to mat. 

## Synonyms
[[imp]] | [[hob]] | [[pixie]] | [[brownie]]