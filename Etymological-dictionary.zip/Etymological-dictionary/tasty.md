# tasty

## Etymology
- taste +‎ -y
The Philippine sense is due to a genericized trademark from Taystee Bread Company, a defunct American company.


## Definition
### Adjective
1. Having a pleasant or satisfying flavor; delicious. 
2. (obsolete) Having or showing good taste; tasteful. 
3. (slang) Appealing; when applied to persons, sexually appealing. 
4. (UK, informal) Skillful; highly competent. 
5. (UK, informal) Potentially violent. 

### Noun
1. (informal) Something tasty; a delicious article of food. 
2. (Philippines, dated) a loaf of bread 

## Synonyms
[[dainty]] | [[savory]] | [[savoury]]