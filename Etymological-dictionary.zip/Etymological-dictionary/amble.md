# amble

## Etymology
- From Middle English amblen, from Old French ambler (“walk as a horse does”), from Old Occitan amblar, from Latin ambulō (“I walk”). Doublet of ambulate.


## Definition
### Noun
1. An unhurried leisurely walk or stroll. 
2. An easy gait, especially that of a horse. 
3. A town, a harbour and civil parish with a town council in Northumberland, England (OS grid ref NU2604). 
4. A minor river in Cornwall, England, which flows into the River Camel estuary (OS grid ref SW9974). 
5. An unincorporated community in Winfield Township, Montcalm County, Michigan, United States. 

### Verb
1. (intransitive) To stroll or walk slowly and leisurely. 
2. (intransitive) Of a quadruped: to move along by using both legs on one side, and then the other. 

## Synonyms
[[stroll]] | [[promenade]] | [[ramble]] | [[saunter]] | [[mosey]]