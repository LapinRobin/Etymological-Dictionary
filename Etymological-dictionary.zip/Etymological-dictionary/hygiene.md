# hygiene

## Etymology
- From French hygiène, from Ancient Greek ὑγιεινή (τέχνη) (hugieinḗ (tékhnē), literally “art of health”), from ὑγιεινός (hugieinós, “of health, good for the health, wholesome, sound, healthy”), from ὑγιής (hugiḗs, “healthy, sound”).


## Definition
### Noun
1. The science of health, its promotion and preservation. 
2. Those conditions and practices that promote and preserve health. 
3. Cleanliness. 
4. (computing, slang, of a macro) The property of having an expansion that is guaranteed not to cause the accidental capture of identifiers. 

## Synonyms
