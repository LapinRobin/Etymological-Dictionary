# including

## Definition
### Noun
1. One who or that which is eligible to be included. 

### Adjective
1. Alternative form of includible  

## Synonyms
