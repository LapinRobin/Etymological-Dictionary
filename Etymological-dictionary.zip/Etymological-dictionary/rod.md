# rod

## Etymology
- From Middle English rodde, from Old English *rodd or *rodde (attested in dative plural roddum (“rod, pole”)), of uncertain origin, but probably from Proto-Germanic *rudd- (“stick, club”), from Proto-Indo-European *rewdʰ- (“to clear land”). Compare Old Norse rudda (“club”). For the root, compare English rid. Presumably unrelated to Proto-Germanic *rōdō (“rod, pole”).


## Definition
### Noun
1. A straight, round stick, shaft, bar, cane, or staff. 
2. A longitudinal pole used for forming part of a framework such as an awning or tent. 
3. (fishing) A long slender usually tapering pole used for angling; fishing rod. 
4. A stick, pole, or bundle of switches or twigs (such as a birch), used for personal defense or to administer corporal punishment by whipping. 
5. An implement resembling and/or supplanting a rod (particularly a cane) that is used for corporal punishment, and metonymically called the rod, regardless of its actual shape and composition. 
6. A stick used to measure distance, by using its established length or task-specific temporary marks along its length, or by dint of specific graduated marks. 
7. (archaic) A unit of length equal to 1 pole, a perch, ¹⁄₄ chain, 5+¹⁄₂ yards, 16+¹⁄₂ feet, or exactly 5.0292 meters (these being all equivalent). 
8. An implement held vertically and viewed through an optical surveying instrument such as a transit, used to measure distance in land surveying and construction layout; an engineer's rod, surveyor's rod, surveying rod, leveling rod, ranging rod. The modern (US) engineer's or surveyor's rod commonly is eight or ten feet long and often designed to extend higher. In former times a surveyor's rod often was a single wooden pole or composed of multiple sectioned and socketed pieces, and besides serving as a sighting target was used to measure distance on the ground horizontally, hence for convenience was of one rod or pole in length, that is, 5+¹⁄₂ yards. 
9. (archaic) A unit of area equal to a square rod, 30+¹⁄₄ square yards or ¹⁄₁₆₀ acre. 
10. A straight bar that unites moving parts of a machine, for holding parts together as a connecting rod or for transferring power as a driveshaft. 
11. (anatomy) A rod cell: a rod-shaped cell in the eye that is sensitive to light. 
12. (biology) Any of a number of long, slender microorganisms. 
13. (chemistry) A stirring rod: a glass rod, typically about 6 inches to 1 foot long and ¹⁄₈ to ¹⁄₄ inch in diameter that can be used to stir liquids in flasks or beakers. 
14. (slang) A pistol; a gun. 
15. (slang, vulgar) A penis. 
16. (slang) A hot rod, an automobile or other passenger motor vehicle modified to run faster and often with exterior cosmetic alterations, especially one based originally on a pre-1940s model or (currently) denoting any older vehicle thus modified. 
17. (ufology) A rod-shaped object that appears in photographs or videos traveling at high speed, not seen by the person recording the event, often associated with extraterrestrial entities. 
18. (mathematics) A Cuisenaire rod. 
19. (rail transport) A coupling rod or connecting rod, which links the driving wheels of a steam locomotive, and some diesel shunters and early electric locomotives. 
20. A nickname for the male given names Rodney and Roderick. 

### Verb
1. (construction) To reinforce concrete with metal rods. 
2. (transitive) To furnish with rods, especially lightning rods. 
3. (slang, vulgar, transitive) To penetrate sexually. 
4. (slang) To hot rod. 

## Synonyms
[[pole]] | [[perch]] | [[gat]]