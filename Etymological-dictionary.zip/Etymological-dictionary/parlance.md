# parlance

## Etymology
- From Middle English *parlaunce, from Anglo-Norman parlance, parlaunce, from parler (“to talk”) + -ance.


## Definition
### Noun
1. A certain way of speaking, of using words; especially that associated with a particular job or interest. 
2. Of a word, the quality of being lexicalized; especially as jargon or slang. 
3. (archaic, rare) Speech, discussion or debate. 

## Synonyms
[[idiom]]