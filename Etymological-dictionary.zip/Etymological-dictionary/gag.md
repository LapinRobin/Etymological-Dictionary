# gag

## Etymology
- The verb is from 15th-century Middle English gaggen, Early Modern English gagge, possibly imitative or perhaps related to or influenced by Old Norse gag-háls ("with head thrown backwards"; > Norwegian dialectal gaga (“bent backwards”)). The intransitive sense "to retch" is from 1707.


## Definition
### Noun
1. A device to restrain speech, such as a rag in the mouth secured with tape or a rubber ball threaded onto a cord or strap. 
2. (law) An order or rule forbidding discussion of a case or subject. 
3. (figuratively) Any suppression of freedom of speech. 
4. A joke or other mischievous prank. 
5. (film) a device or trick used to create a practical effect; a gimmick 
6. A convulsion of the upper digestive tract. 
7. (archaic) A mouthful that makes one retch or choke. 
8. Mycteroperca microlepis, a species of grouper. 
9. Abbreviation of group-specific antigen. 

### Verb
1. (intransitive) To experience the vomiting reflex. 
2. (transitive) To cause to heave with nausea. 
3. (transitive) To restrain someone's speech by blocking his or her mouth. 
4. (transitive) To pry or hold open by means of a gag. 
5. (transitive, figuratively) To restrain someone's speech without using physical means. 
6. (transitive, intransitive) To choke; to retch. 
7. (transitive, intransitive, obsolete, slang) To deceive (someone); to con. 

## Synonyms
[[fret]] | [[choke]] | [[laugh]] | [[heave]] | [[joke]] | [[quip]] | [[jest]] | [[muzzle]] | [[yak]] | [[jape]] | [[wheeze]]