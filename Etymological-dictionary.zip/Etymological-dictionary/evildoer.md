# evildoer

## Etymology
- From Middle English yvel doer; equivalent to evil +‎ doer.


## Definition
### Noun
1. A person who performs evil acts. 

## Synonyms
