# strategic

## Etymology
- From Ancient Greek στρατηγικός (stratēgikós, “of or for a general", also "a treatise on strategy”), from στρατηγός (stratēgós, “the leader or commander of an army, a general”), from στρατός (stratós, “army”) + ἄγω (ágō, “I lead, I conduct”).


## Definition
### Adjective
1. Of or pertaining to strategy. 
2. Of or relating to military operations that are more large-scale or long-range than local or tactical ones. 

## Synonyms
[[important]]