# disobliging

## Definition
### Adjective
1. Not obliging; not making an effort to respect the needs and wishes of others; unaccommodating. 

## Synonyms
