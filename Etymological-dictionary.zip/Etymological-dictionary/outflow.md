# outflow

## Etymology
- From Middle English outflowen, from late Old English ūtflōwan (attested in the past tense as ūt flēow), equivalent to out- +‎ flow. The noun is derived from the verb.


## Definition
### Noun
1. The process of flowing out. 
2. A fluid that flows out. 
3. Any outward movement. 
4. (astronomy) A stream of gaseous material emanating from an active galactic nucleus. 
5. The part of a system that allows material to flow out. 
6. (sewage) Something that flows out of a sewage treatment plant. 

### Verb
1. (intransitive) To flow outward. 

## Synonyms
[[spring]] | [[escape]] | [[leak]] | [[fountain]]