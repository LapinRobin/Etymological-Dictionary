# refugee

## Etymology
- From French réfugié, past participle of réfugier (“to take refuge”), describing early French Protestants seeking refuge after the Edict of Fontainebleau in 1685. Analyzable as refuge +‎ -ee. Displaced native Old English flīema.


## Definition
### Noun
1. A person seeking refuge in a foreign country out of fear of political persecution or the prospect of such persecution in their home country, i.e., a person seeking political asylum. 
2. A person seeking refuge due to a natural disaster, war, etc. 
3. A person formally granted political or economic asylum by a country other than their home country. 
4. (by extension) A person who flees one place or institution for another. 

### Verb
1. (transitive, US, historical) To convey (slaves) away from the advance of the federal forces. 

## Synonyms
