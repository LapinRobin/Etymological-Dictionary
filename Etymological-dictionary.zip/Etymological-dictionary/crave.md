# crave

## Etymology
- From Middle English craven, from Old English crafian (“to crave, ask, implore, demand, summon”), from Proto-Germanic *krafjaną (“to demand”). Cognate with Danish kræve (“to demand, require”), Swedish kräva (“to crave, demand”), Icelandic krefja (“to demand”), Norwegian kreve (“to demand”).


## Definition
### Verb
1. (transitive, intransitive) To desire strongly, so as to satisfy an appetite; to long or yearn for. 
2. (transitive) To ask for earnestly; to beg; to claim. 
3. (transitive, obsolete) To call for; to require as a course of action. 

### Noun
1. (law, Scotland) A formal application to a court to make a particular order. 

## Synonyms
[[lust]] | [[hunger]] | [[starve]]