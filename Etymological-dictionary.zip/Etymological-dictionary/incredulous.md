# incredulous

## Etymology
- Borrowed from Latin incrēdulus (“unbelieving”).


## Definition
### Adjective
1. Skeptical, disbelieving, or unable to believe. 
2. Expressing or indicative of incredulity. 
3. (largely obsolete, now only nonstandard) Difficult to believe; incredible. 

## Synonyms
[[skeptical]] | [[sceptical]]