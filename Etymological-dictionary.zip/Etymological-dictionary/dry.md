# dry

## Etymology
- Adjective and noun from Middle English drye, dryge, drüȝe, from Old English drȳġe (“dry; parched, withered”), from Proto-Germanic *drūgiz, *draugiz (“dry, hard”), from Proto-Indo-European *dʰerǵʰ- (“to strengthen; become hard”), from *dʰer- (“to hold, support”).


## Definition
### Adjective
1. Free from or lacking moisture. 
2. Unable to produce a liquid, as water, (petrochemistry) oil, or (farming) milk. 
3. (masonry) Built without or lacking mortar. 
4. (chemistry) Anhydrous: free from or lacking water in any state, regardless of the presence of other liquids. 
5. (figuratively) Athirst, eager. 
6. Free from or lacking alcohol or alcoholic beverages. 
7. (law) Describing an area where sales of alcoholic or strong alcoholic beverages are banned. 
8. (wine and other alcoholic beverages, ginger ale) Low in sugar; lacking sugar; unsweetened. 
9. (humor) Amusing without showing amusement. 
10. Lacking interest, boring. 
11. (fine arts) Exhibiting precise execution lacking delicate contours or soft transitions of color. 
12. (aviation) Not using afterburners or water injection for increased thrust. 
13. (sciences, somewhat derogatory) Involving computations rather than work with biological or chemical matter. 
14. (of a sound recording) Free from applied audio effects (especially reverb). 
15. Without a usual complement or consummation; impotent. 
16. Of a bite from an animal: not containing the usual venom. 
17. (Christianity) Of a mass, service, or rite: involving neither consecration nor communion. 
18. (software engineering) Of code, having the quality of adhering to the principle of DRY; containing as little repetition as possible. 

### Noun
1. The process by which something is dried. 
2. (US) A prohibitionist (of alcoholic beverages). 
3. An area with little or no rain, or sheltered from it. 
4. (chiefly Australia, with "the") The dry season. 
5. (Australia) An area of waterless country. 
6. Unsweetened ginger ale; dry ginger. 
7. (Britain, UK politics) A radical or hard-line Conservative; especially, one who supported the policies of British Prime Minister Margaret Thatcher in the 1980s. 
8. A surname. 

### Verb
1. (intransitive) To lose moisture. 
2. (transitive) To remove moisture from. 
3. (transitive, figuratively) To exhaust; to cause to run dry. 
4. (intransitive, informal) For an actor to forget his or her lines while performing. 
5. (software engineering) To cause code to become DRY; to remove repetition from code. 

## Synonyms
[[plain]] | [[solid]] | [[wry]] | [[ironic]] | [[sober]] | [[arid]] | [[sear]] | [[sere]] | [[humorous]] | [[sec]] | [[brut]] | [[parched]] | [[thirsty]] | [[withered]]