# insanely

## Etymology
- From insane +‎ -ly.


## Definition
### Adverb
1. In an insane manner; not sanely. 
2. To a great degree; very much. 

## Synonyms
[[deadly]]