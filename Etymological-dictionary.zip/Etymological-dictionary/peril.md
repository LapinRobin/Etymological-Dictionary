# peril

## Etymology
- From Middle English peril, from Old French peril, from Latin perīculum. Doublet of periculum.


## Definition
### Noun
1. A situation of serious and immediate danger. 
2. Something that causes, contains, or presents danger. 
3. (insurance) An event which causes a loss, or the risk of a specific such event. 

### Verb
1. (transitive) To cause to be in danger; to imperil; to risk. 

## Synonyms
[[risk]] | [[expose]] | [[queer]] | [[hazard]] | [[menace]] | [[jeopardy]] | [[threaten]] | [[jeopardize]] | [[danger]] | [[scupper]] | [[endanger]]