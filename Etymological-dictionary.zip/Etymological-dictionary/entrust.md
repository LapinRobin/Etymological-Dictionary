# entrust

## Etymology
- en- +‎ trust


## Definition
### Verb
1. (transitive) To trust to the care of. 

## Synonyms
[[leave]] | [[trust]] | [[commit]] | [[confide]]