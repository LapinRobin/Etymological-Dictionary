# archetype

## Etymology
- From Old French architipe (modern French archétype), from Latin archetypum (“original”), from Ancient Greek ἀρχέτυπον (arkhétupon, “model, pattern”), the neuter form of ἀρχέτυπος (arkhétupos, “first-moulded”), from ἀρχή (arkhḗ, “beginning, origin”) (from ἄρχω (árkhō, “to begin; to lead, rule”), from Proto-Indo-European *h₂ergʰ- (“to begin; to command, rule”)) + τῠ́πος (túpos, “blow, pressing; sort, type”) (from τύπτω (túptō, “to beat, strike”), from Proto-Indo-European *(s)tewp- (“to push; to stick”)).


## Definition
### Noun
1. An original model of which all other similar concepts, objects, or persons are merely copied, derivative, emulated, or patterned; a prototype. 
2. An ideal example of something; a quintessence. 
3. (literature) A character, object, or story that is based on a known character, object, or story. 
4. (psychology) According to Swiss psychologist Carl Jung: a universal pattern of thought, present in an individual's unconscious, inherited from the past collective experience of humanity. 
5. (textual criticism) A protograph (“original manuscript of a text from which all further copies derive”). 

### Verb
1. To depict as, model using, or otherwise associate an object or subject with an archetype. 

## Synonyms
[[pilot]] | [[original]]