# prehistoric

## Etymology
- From pre- (“before”) +‎ historic, q.v., similar to slightly earlier ante-historic.


## Definition
### Adjective
1. (properly) Of or relating to the epoch before written record. 
2. (inexact or humorous) Ancient; very old, outdated, etc. 

## Synonyms
[[past]]