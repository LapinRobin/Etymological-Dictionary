# concentrated

## Definition
### Adjective
1. Not dilute; having a high concentration. 
2. Intense; directed towards a specific location. 

## Synonyms
[[exclusive]] | [[intent]] | [[intense]] | [[dense]] | [[compact]] | [[thick]] | [[focused]] | [[fixed]] | [[saturated]] | [[congregate]]