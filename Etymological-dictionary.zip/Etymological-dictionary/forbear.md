# forbear

## Etymology
- From Middle English forberen, from Old English forberan (“to forbear, abstain from, refrain; suffer, endure, tolerate, humor; restrain; do without”), from Proto-Germanic *fraberaną (“to hold back, endure”); equivalent to for- +‎ bear. Cognate with Old Frisian forbera (“to forfeit”), Middle High German verbërn (“to have not; abstain; refrain from; avoid”) (Cimbrian forbèeran), Gothic 𐍆𐍂𐌰𐌱𐌰𐌹𐍂𐌰𐌽 (frabairan, “to endure”).

- (UK) IPA(key): /ˈfɔː.bɛə/ (US) IPA(key): /ˈfɔɹ.bɛɚ/

## Definition
### Verb
1. (transitive) To keep away from; to avoid; to abstain from. 
2. (intransitive) To refrain from proceeding; to pause; to delay. 
3. (intransitive) To refuse; to decline; to withsay; to unheed. 
4. (intransitive) To control oneself when provoked. 

### Noun
1. Alternative spelling of forebear  

## Synonyms
[[refrain]] | [[forebear]]