# percentage

## Etymology
- From Latin per centum (“for every hundred”),  +‎ -age.


## Definition
### Noun
1. The amount, number or rate of something, regarded as part of a total of 100; a part of a whole. 
2. A share of the sales, profits, gross margin or similar. 
3. (informal) Benefit or advantage. 

## Synonyms
[[part]] | [[share]] | [[portion]] | [[percent]]