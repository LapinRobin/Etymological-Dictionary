# set back

## Definition
### Verb
1. (transitive) To delay or obstruct. 
2. (transitive) To remove from or allow distance. 
3. (transitive) To install or position behind a boundary or surface, or in a recess. 
4. (transitive, idiomatic) To cost money. 
5. To reverse, go backwards. 

## Synonyms
