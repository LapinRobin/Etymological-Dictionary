# double standard

## Definition
### Noun
1. The situation where two groups or individuals are the same in pertinent ways, but one is condemned for it while the other is excused. 
2. A pair of monetary values, i.e. a gold standard and a silver standard, both of which are legal tender. 

## Synonyms
