# mien

## Etymology
- From French mine (“appearance”) (whence also Danish mine and German Miene), perhaps from Breton min (“face of an animal”), or from Latin minio (“to redden”).


## Definition
### Noun
1. (countable, uncountable) Demeanor; facial expression or attitude, especially one which is intended by its bearer. 
2. (countable) A specific facial expression. 
3. A group of related languages spoken by the Yao people. 

## Synonyms
[[bearing]] | [[presence]] | [[comportment]]