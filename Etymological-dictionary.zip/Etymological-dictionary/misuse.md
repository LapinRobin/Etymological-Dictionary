# misuse

## Etymology
- mis- +‎ use (noun)

- mis- +‎ use (verb)


## Definition
### Noun
1. An incorrect, improper or unlawful use of something. 

### Verb
1. (transitive) To use (something) incorrectly. 
2. (transitive) To abuse or mistreat (something or someone). 
3. (transitive) To rape (a woman); later more generally, to sexually abuse (someone). 
4. (obsolete, transitive) To abuse verbally, to insult. 

## Synonyms
[[abuse]] | [[pervert]]