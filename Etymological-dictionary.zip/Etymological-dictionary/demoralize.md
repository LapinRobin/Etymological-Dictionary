# demoralize

## Etymology
- From French démoraliser.


## Definition
### Verb
1. To destroy the morale of; to dishearten. 
2. (dated) To erode the moral adherence of; to corrupt. 

## Synonyms
[[dismay]] | [[corrupt]] | [[profane]] | [[vitiate]] | [[pervert]] | [[debase]] | [[depress]]