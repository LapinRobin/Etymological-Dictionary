# reinstate

## Etymology
- re- +‎ instate


## Definition
### Verb
1. (transitive) To restore to a former position or rank. 
2. (transitive) To bring back into use or existence; resurrect. 

## Synonyms
[[restore]] | [[reestablish]]