# defer

## Etymology
- Originally a variant of (and hence a doublet of) differ; from Middle English differren (“to postpone”), from Old French differer, from Latin differō.

- From late Middle English differren (“to refer for judgement”), from Middle French déférer, from Latin dēferō.


## Definition
### Verb
1. (transitive) To delay or postpone 
2. (especially more common, historically) to postpone induction into military service. 
3. (American football) After winning the opening coin toss, to postpone until the start of the second half a team's choice of whether to kick off or receive (and to allow the opposing team to make this choice at the start of the first half). 
4. (intransitive) To delay, to wait. 
5. (transitive, intransitive) To submit to the opinion or desire of others in respect to their judgment or authority. 
6. To render, to offer. 

## Synonyms
[[table]] | [[bow]] | [[remit]] | [[submit]] | [[accede]] | [[postpone]] | [[put off]] | [[shelve]]