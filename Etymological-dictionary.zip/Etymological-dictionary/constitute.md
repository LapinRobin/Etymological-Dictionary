# constitute

## Etymology
- From Middle English constituten, from Latin cōnstitūtum, neuter of cōnstitūtus, past participle of Latin cōnstituō (“to put in place, set up, establish”).


## Definition
### Verb
1. (transitive) To set up; to establish; to enact. 
2. (transitive) To make up; to compose; to form. 
3. (transitive) To appoint, depute, or elect to an office; to make and empower. 

### Noun
1. (obsolete) An established law. 

## Synonyms
[[be]] | [[plant]] | [[name]] | [[form]] | [[make]] | [[comprise]] | [[establish]] | [[represent]] | [[institute]] | [[found]] | [[make up]] | [[appoint]] | [[nominate]]