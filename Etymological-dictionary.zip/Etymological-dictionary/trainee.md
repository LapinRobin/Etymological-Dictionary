# trainee

## Etymology
- train +‎ -ee


## Definition
### Noun
1. Someone who is still in the process of being formally trained in a workplace. 
2. A juvenile inmate being trained and (re)educated in a reformatory school. 

## Synonyms
