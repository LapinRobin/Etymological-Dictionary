# climactic

## Etymology
- climax +‎ -ic


## Definition
### Adjective
1. Of, pertaining to, or constituting a climax; reaching a decisive moment or point of greatest excitement. 

## Synonyms
[[high]] | [[peak]]