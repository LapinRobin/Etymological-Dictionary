# dusk

## Etymology
- (adjective): From Middle English dosk, duske (“dusky”, adj.), from Old English dox (“dark, swarthy”), from Proto-Germanic *duskaz (“dark, smoky”), from Proto-Indo-European *dʰuh₂s- (compare Old Irish donn (“dark”), Latin fuscus (“dark, dusky”), Sanskrit धूसर (dhūsara, “dust-colored”)), from Proto-Indo-European *dʰewh₂- (“smoke, mist, haze”). More at dye. Related to dust. (verb): From Middle English dusken, from Old English doxian.

## Definition
### Noun
1. A period of time at the end of day when the sun is below the horizon but before the full onset of night, especially the darker part of twilight. 
2. A darkish colour. 
3. The condition of being dusky; duskiness 

### Verb
1. (intransitive) To begin to lose light or whiteness; to grow dusk. 
2. (transitive) To make dusk. 

### Adjective
1. Tending to darkness or blackness; moderately dark or black; dusky. 

## Synonyms
[[fall]] | [[twilight]] | [[gloaming]] | [[nightfall]]