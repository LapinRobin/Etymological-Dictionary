# deliberation

## Etymology
- From Old French deliberation, from Latin deliberatio
Morphologically deliberate +‎ -ion


## Definition
### Noun
1. The act of deliberating, or of weighing and examining the reasons for and against a choice or measure; careful consideration; mature reflection. 
2. Careful discussion and examination of the reasons for and against a measure 

## Synonyms
