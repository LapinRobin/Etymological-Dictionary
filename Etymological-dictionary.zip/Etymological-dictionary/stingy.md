# stingy

## Etymology
- Uncertain, possibly from stinge, a dialectal variation of sting (verb).

- sting +‎ -y


## Definition
### Adjective
1. Unwilling to spend, give, or share; ungenerous; mean 
2. Small, scant, meager, insufficient 
3. (informal) Stinging; able or inclined to sting. 

## Synonyms
[[mean]] | [[close]] | [[tight]] | [[little]] | [[small]] | [[near]] | [[meager]] | [[cheap]] | [[parsimonious]] | [[selfish]] | [[penurious]] | [[chintzy]] | [[miserly]]