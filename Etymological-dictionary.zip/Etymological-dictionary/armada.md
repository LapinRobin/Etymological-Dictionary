# armada

## Etymology
- Borrowed from Spanish armada (“fleet, navy”), from Medieval Latin armāta, from the feminine past participle of Latin armō, from arma. Doublet of army.


## Definition
### Noun
1. A fleet of warships, especially with reference to the Spanish Armada. 
2. Any large army or fleet of military vessels. 
3. A large flock of anything. 
4. The Spanish Armada which sailed against England in 1588. 
5. A village in Michigan. 

## Synonyms
