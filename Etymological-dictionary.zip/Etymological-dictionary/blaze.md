# blaze

## Etymology
- From Middle English blase, from Old English blæse, blase (“firebrand, torch, lamp, flame”), from Proto-West Germanic *blasā, from Proto-Germanic *blasǭ (“torch”), from Proto-Indo-European *bʰel- (“to shine, be white”). 

- From Middle English blasen, from Middle English blase (“torch”). See above.

- From Middle English blasen (“to blow”), from Old English *blǣsan, from Proto-West Germanic *blāsan, from Proto-Germanic *blēsaną (“to blow”). Related to English blast.


## Definition
### Noun
1. A fire, especially a fast-burning fire producing a lot of flames and light. 
2. Intense, direct light accompanied with heat. 
3. The white or lighter-coloured markings on a horse's face. 
4. (color) A high-visibility orange colour, typically used in warning signs and hunters' clothing. 
5. A bursting out, or active display of any quality. 
6. A spot made on trees by chipping off a piece of the bark, usually as a surveyor's mark. 
7. (poker) A hand consisting of five face cards. 
8. Publication; the act of spreading widely by report 
9. A male given name from Latin. 
10. A surname originating as a patronymic. 

### Verb
1. (intransitive) To be on fire, especially producing bright flames. 
2. (intransitive) To send forth or reflect a bright light; shine like a flame. 
3. (intransitive, poetic) To be conspicuous; shine brightly a brilliancy (of talents, deeds, etc.). 
4. (transitive, rare) To set in a blaze; burn. 
5. (transitive) To cause to shine forth; exhibit vividly; be resplendent with. 
6. (transitive, only in the past participle) To mark with a white spot on the face (as a horse). 
7. (transitive) To set a mark on (as a tree, usually by cutting off a piece of its bark). 
8. (transitive) To indicate or mark out (a trail, especially through vegetation) by a series of blazes. 
9. (transitive, figuratively) To set a precedent for the taking-on of a challenge; lead by example. 
10. (figuratively) To be furiously angry; to speak or write in a rage. 
11. (slang) To smoke marijuana. 
12. (transitive) To blow, as from a trumpet 
13. (transitive) To publish; announce publicly 
14. (transitive) To disclose; bewray; defame 
15. (transitive, heraldry) To blazon 

## Synonyms
[[hell]] | [[glare]] | [[blazing]] | [[brilliance]]