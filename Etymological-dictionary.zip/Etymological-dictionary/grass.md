# grass

## Etymology
- From Middle English gras, from Old English græs, from Proto-Germanic *grasą (“grass”), from Proto-Indo-European *gʰreh₁- (“to grow”).


## Definition
### Noun
1. (countable, uncountable) Any plant of the family Poaceae, characterized by leaves that arise from nodes in the stem and leaf bases that wrap around the stem, especially those grown as ground cover rather than for grain. 
2. (countable) Various plants not in family Poaceae that resemble grasses. 
3. (uncountable) A lawn. 
4. (uncountable, slang) Marijuana. 
5. (countable, Britain, slang) An informer, police informer; one who betrays a group (of criminals, etc) to the authorities. 
6. (uncountable, physics) Sharp, closely spaced discontinuities in the trace of a cathode-ray tube, produced by random interference. 
7. (uncountable, slang) Noise on an A-scope or similar type of radar display. 
8. The season of fresh grass; spring or summer. 
9. (obsolete, figuratively) That which is transitory. 
10. (countable, folk etymology) Asparagus; "sparrowgrass". 
11. (mining) The surface of a mine. 
12. A group of languages spoken in Papua New Guinea. 
13. A surname. 

### Verb
1. (transitive) To lay out on the grass; to knock down (an opponent etc.). 
2. (transitive or intransitive, slang) To act as a grass or informer, to betray; to report on (criminals etc) to the authorities. 
3. (transitive) To cover with grass or with turf. 
4. (transitive) To feed with grass. 
5. (transitive) To expose, as flax, on the grass for bleaching, etc. 
6. (transitive) To bring to the grass or ground; to land. 

## Synonyms
[[shop]] | [[rat]] | [[pot]] | [[weed]] | [[dope]] | [[gage]] | [[denounce]] | [[smoke]] | [[forage]] | [[betray]] | [[stag]] | [[skunk]] | [[peach]] | [[snitch]] | [[pasture]] | [[cannabis]] | [[marijuana]] | [[ganja]]