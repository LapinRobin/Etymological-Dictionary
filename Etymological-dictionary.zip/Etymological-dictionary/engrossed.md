# engrossed

## Definition
### Adjective
1. Preoccupied with something to the exclusion of everything else. 
2. (of a document) Finalized, written in large letters. 

## Synonyms
[[intent]] | [[attentive]] | [[rapt]] | [[written]]