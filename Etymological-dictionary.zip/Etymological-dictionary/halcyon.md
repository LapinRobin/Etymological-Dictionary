# halcyon

## Etymology
- Inherited from Middle English Alceoun, from Latin halcyōn, alcyōn (“kingfisher”), from Ancient Greek ἀλκυών (alkuṓn).


## Definition
### Noun
1. (poetic) A kingfisher said in classical mythology to nest on the sea, thereby calming the waters. 
2. The dead body of such a bird, said in Tudor times to act as a weather vane when hung from a beam. 
3. A tropical kingfisher of the genus Halcyon, such as the sacred kingfisher (Halcyon sancta) of Australia. 

### Adjective
1. Pertaining to the halcyon or kingfisher. 
2. (figuratively) Calm, undisturbed, peaceful, serene. 

## Synonyms
[[happy]] | [[prosperous]] | [[golden]] | [[peaceful]]