# insure

## Etymology
- Recorded since about 1440, as a variant of Middle English ensuren (from Anglo-Norman enseurer, itself from en- (“make”) + seür (“sure”), probably influenced by Old French asseürer (“to assure”)); took on its particular sense of "make safe against loss by payment of premiums" in 1635, replacing assure.


## Definition
### Verb
1. (transitive) To provide for compensation if some specified risk occurs. Often agreed by policy (contract) to offer financial compensation in case of an accident, theft or other undesirable event. 
2. (intransitive) To deal in such contracts; subscribe to a policy of insurance 
3. (chiefly US, transitive, dated) Alternative spelling of ensure; to make sure or certain of; guarantee.  

## Synonyms
[[check]] | [[see]] | [[control]] | [[ensure]] | [[cover]] | [[guarantee]] | [[ascertain]] | [[secure]] | [[assure]] | [[underwrite]]