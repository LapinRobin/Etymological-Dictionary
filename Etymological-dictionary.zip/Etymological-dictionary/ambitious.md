# ambitious

## Etymology
- From Middle English ambitious, from Middle French ambitieus, from Latin ambitiosus, from ambitio; see ambition. Compare with French ambitieux.


## Definition
### Adjective
1. (of a person or their character) Having or showing ambition; wanting a lot of power, honor, respect, superiority, or other distinction. 
2. (followed by "of" or the infinitive) Very desirous 
3. Resulting from, characterized by, or indicating, ambition 
4. Hard to achieve. 

## Synonyms
[[aggressive]] | [[hard]] | [[determined]] | [[difficult]] | [[driven]] | [[challenging]] | [[manque]] | [[compulsive]] | [[pushy]] | [[aspirant]] | [[enterprising]]