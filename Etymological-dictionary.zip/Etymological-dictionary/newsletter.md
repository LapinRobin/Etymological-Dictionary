# newsletter

## Etymology
- news +‎ letter


## Definition
### Noun
1. A periodically sent publication containing current events or the like, generally on a particular topic or geared toward a limited audience. 

## Synonyms
