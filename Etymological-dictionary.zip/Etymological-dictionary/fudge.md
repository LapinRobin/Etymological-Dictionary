# fudge

## Etymology
- Probably a variant of fadge (“to fit”), the confectionery sense having evolved from the meaning of “merging together” or “turning out as expected”.


## Definition
### Noun
1. (chiefly uncountable) A type of very sweet candy or confection, usually made from sugar, butter, and milk or cream. 
2. (US) Chocolate fudge. 
3. (uncountable) Light or frothy nonsense. 
4. (countable) A deliberately misleading or vague answer. 
5. (uncountable, dated) A made-up story. 
6. (countable) A less than perfect decision or solution; an attempt to fix an incorrect solution after the fact. 
7. (euphemistic, slang) Fecal matter; feces. 
8. A surname. 

### Verb
1. (intransitive) To try to avoid giving a direct answer. 
2. (transitive) To alter something from its true state, as to hide a flaw or uncertainty, deliberately but not necessarily dishonestly or immorally. 
3. (dated, transitive, intransitive) To botch or bungle something. 
4. To cheat, especially in the game of marbles. 

## Synonyms
[[duck]] | [[hedge]] | [[manipulate]] | [[circumvent]] | [[elude]] | [[cook]] | [[fake]] | [[dodge]] | [[skirt]] | [[evade]] | [[parry]] | [[put off]] | [[sidestep]] | [[falsify]]