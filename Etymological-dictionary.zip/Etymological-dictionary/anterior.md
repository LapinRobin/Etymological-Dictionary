# anterior

## Etymology
- Borrowed from Latin anterior (“that is before, foremost”).


## Definition
### Adjective
1. (botany) (of a part of a flower or leaf) Situated further away from the mainstem. 
2. (phonetics) Pronounced with an obstruction located in front of the palato-alveolar region of the mouth, e.g. b, p, d, t. 
3. (formal) Coming before or earlier in time or development, prior to, preceding. 

## Synonyms
[[antecedent]] | [[prior]] | [[preceding]]