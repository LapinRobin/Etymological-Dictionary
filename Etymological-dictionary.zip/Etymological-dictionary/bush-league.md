# bush-league

## Definition
### Adjective
1. (US) Minor-league; second-rate. 

## Synonyms
