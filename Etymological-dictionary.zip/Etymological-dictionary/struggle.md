# struggle

## Etymology
- From Middle English struglen, stroglen, strogelen, of obscure origin. Cognate with Scots strugil (“to struggle, grapple, contend”). Perhaps from a variant of *strokelen, *stroukelen (> English stroll), from Middle Dutch struyckelen ("to stumble, trip, falter"; > Modern Dutch struikelen), the frequentative form of Old Dutch *strūkon (“to stumble”), from Proto-Germanic *strūkōną, *strūkēną (“to be stiff”), from Proto-Indo-European *strug-, *ster- (“to be stiff; to bristle, strut, stumble, fall”), related to Middle Low German strûkelen ("to stumble"; > Low German strükeln), Old High German strūhhēn, strūhhōn ("to stumble, trip, tumble, go astray"; > German strauchen, straucheln).


## Definition
### Noun
1. A contortion of the body in an attempt to escape or to perform a difficult task. 
2. (figuratively) Strife, contention, great effort. 

### Verb
1. To strive, to labour in difficulty, to fight (for or against), to contend. 
2. To strive, or to make efforts, with a twisting, or with contortions of the body. 

## Synonyms
[[fight]] | [[conflict]] | [[skin]] | [[scramble]] | [[battle]] | [[shin]] | [[sputter]] | [[clamber]]