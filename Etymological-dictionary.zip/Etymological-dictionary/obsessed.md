# obsessed

## Definition
### Adjective
1. Intensely preoccupied with or by a given topic or emotion; driven by a specified obsession. 
2. Influenced or controlled by evil spirits, but less than possessed in that the spirits do not actually reside in the victim. 

## Synonyms
[[concerned]] | [[haunted]] | [[preoccupied]] | [[possessed]]