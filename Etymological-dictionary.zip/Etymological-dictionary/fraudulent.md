# fraudulent

## Etymology
- From Middle English fraudulent, from Old French fraudulent, from Latin fraudulentus, from fraus.


## Definition
### Adjective
1. Dishonest; based on fraud or deception. 
2. False, phony. 

## Synonyms
[[fallacious]] | [[deceitful]] | [[dishonest]]