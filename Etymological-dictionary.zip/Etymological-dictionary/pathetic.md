# pathetic

## Etymology
- From Middle French pathétique, from Latin patheticus, from Ancient Greek παθητικός (pathētikós, “subject to feeling, capable of feeling, impassioned”), from παθητός (pathētós, “one who has suffered, subject to suffering”), from πάσχω (páskhō, “to suffer”).


## Definition
### Adjective
1. Arousing pity, sympathy, or compassion; exciting pathos. 
2. Arousing scorn or contempt, often due to miserable inadequacy. 
3. (obsolete) Expressing or showing anger; passionate. 
4. (anatomy) Trochlear. 

## Synonyms
[[poor]] | [[ridiculous]] | [[wretched]] | [[silly]] | [[hapless]] | [[miserable]] | [[pitiful]] | [[contemptible]] | [[piteous]] | [[unfortunate]]