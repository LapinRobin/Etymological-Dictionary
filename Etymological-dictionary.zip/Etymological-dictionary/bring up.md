# bring up

## Etymology
- From Middle English bring up, dissimilated from Middle English upbringen (“to bring up, raise”). Doublet of upbring.


## Definition
### Verb
1. Used other than figuratively or idiomatically: see bring, up: To bring from a lower to a higher position. 
2. To mention. 
3. To raise or rear (children). 
4. To uncover, to bring from obscurity; to resurface (e.g. a memory) 
5. To turn on power or start, as of a machine. 
6. To vomit. 
7. To stop or interrupt a flow or steady motion. 
8. (cricket) To reach a particular score, especially a milestone. 

## Synonyms
