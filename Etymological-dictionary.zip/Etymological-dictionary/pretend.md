# pretend

## Etymology
- From Anglo-Norman pretendre, Middle French pretendre (French prétendre (“to claim, demand”)), from Latin praetendere, present active infinitive of praetendō (“put forward, hold out, pretend”), from prae- (“pre-”) + tendō (“stretch”); see tend.


## Definition
### Verb
1. To claim, to allege, especially when falsely or as a form of deliberate deception. 
2. To feign, affect (a state, quality, etc.). 
3. To lay claim to (an ability, status, advantage, etc.). (originally used without to) 
4. To make oneself appear to do or be doing something; to engage in make-believe. 
5. (transitive, obsolete) To hold before, or put forward, as a cloak or disguise for something else; to exhibit as a veil for something hidden. 
6. (transitive, obsolete) To intend; to design, to plot; to attempt. 
7. (transitive, obsolete) To hold before one; to extend. 

### Adjective
1. Not really what it is represented as being; imaginary, feigned. 

### Noun
1. (childish, informal) the act of engaging in pretend play. 

## Synonyms
[[affect]] | [[play]] | [[act]] | [[feign]] | [[sham]] | [[dissemble]]