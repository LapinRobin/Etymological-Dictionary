# wan

## Etymology
- From Middle English wan, wanne (“grey, leaden; pale grey, ashen; blue-black (like a bruise); dim, faint; dark, gloomy”), from Old English ƿann (“dark, dusky”), from Proto-Germanic *wannaz (“dark, swart”), of uncertain origin. Cognate with Old Frisian wann, wonn (“dark”).

- Eye dialect spelling of one. Sense 2 (“girl or woman”) possibly as a result of the phrase your wan as a counterpart to your man.

- An inflected form.


## Definition
### Adjective
1. Pale, sickly-looking. 
2. Dim, faint. 
3. Bland, uninterested. 

### Noun
1. The quality of being wan; wanness. 
2. (Ireland) A girl or woman. 
3. A surname. 
4. Pronunciation spelling of one, representing Ireland English.  
5. (networking) Acronym of wide area network.  

### Verb
1. (obsolete) simple past tense of win. 

## Synonyms
[[pale]] | [[weak]] | [[pallid]]