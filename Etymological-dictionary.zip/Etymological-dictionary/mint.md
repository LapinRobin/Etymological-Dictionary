# mint

## Etymology
- From Middle English mynt, münet (“money, coin”), from Old English mynet (“coin”), from late Proto-West Germanic *munit, from Latin monēta (“place for making coins, coined money”), from the temple of Juno Moneta (named for Monēta mother of the Muses), where coins were made. Doublet of money and manat.

- From Middle English mynte, from Old English minte (“mint plant”), from Proto-West Germanic *mintā (“mint”), from Latin menta, probably from a lost Mediterranean language either through Ancient Greek μίνθη (mínthē), μίνθα (míntha) or directly. Akin to Old Norse minta (“mint”).

- From Middle English minten, from Old English myntan (“to mean, intend, purpose, determine, resolve”), from Proto-West Germanic *muntijan (“to think, consider”), from Proto-Indo-European *men-, *mnā- (“to think”). Cognate with Saterland Frisian mintsje, muntsje (“to aim, target”), Dutch munten (“to aim at, target”), German Low German münten (“to aim at”), German münzen (“to aim at”), Dutch monter (“cheerful, gladsome, spry”), Gothic 𐌼𐌿𐌽𐍃 (muns, “thought, opinion”), Old English munan (“to be mindful of, consider, intend”). More at mind.


## Definition
### Noun
1. A building or institution where money (originally, only coins) is produced under government licence. 
2. (informal) A vast sum of money; (by extension) a large amount of something. 
3. (figuratively) Any place regarded as a source of unlimited supply; the supply itself. 
4. Any plant in the genus Mentha in the family Lamiaceae, typically aromatic with square stems. 
5. The flavouring of the plant, either a sweet, a jelly or sauce. 
6. Any plant in the mint family, Lamiaceae. 
7. A green colour, like that of mint. 
8. A mint-flavored candy, often eaten to sweeten the smell of the breath. 
9. (provincial, Northern England, Scotland) Intent, purpose; an attempt, try; effort, endeavor. 
10. (economics) Acronym of Mexico, Indonesia, Nigeria, Turkey.  

### Verb
1. (transitive) To reproduce (coins), usually en masse, under licence. 
2. To invent; to forge; to fabricate; to fashion. 
3. (transitive, cryptocurrencies) To create a crypto token. 
4. (intransitive, provincial, Northern England, Scotland) To try, attempt; take aim. 
5. (transitive, provincial, Northern England, Scotland) To try, attempt, endeavor; to take aim at; to try to hit; to purpose. 
6. (intransitive, chiefly Scotland) To hint; suggest; insinuate. 

### Adjective
1. (with condition) Like new. 
2. (numismatics) In near-perfect condition; uncirculated. 
3. (philately) Unused with original gum; as issued originally. 
4. (Northern England, especially Manchester, Tyneside) Very good. 
5. (UK, slang) Attractive; beautiful; handsome. 
6. Of a green colour, like that of the mint plant. 

## Synonyms
[[lot]] | [[strike]] | [[deal]] | [[mass]] | [[pot]] | [[sight]] | [[stack]] | [[slew]] | [[flock]] | [[mess]] | [[pile]] | [[spate]] | [[heap]] | [[coin]] | [[raft]] | [[batch]] | [[plenty]] | [[peck]] | [[wad]]