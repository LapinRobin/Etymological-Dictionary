# bowl

## Etymology
- From Middle English bolle, from Old English bolla, bolle (“bowl, cup, pot, beaker, measure”), from Proto-West Germanic *bollā, from Proto-Germanic *bullǭ (“ball, round vessel, bowl”).

- From Middle English bowle, boule, from Old French boule (“ball”), from Latin bulla (“bubble, stud, round object”). Doublet of poll.


## Definition
### Noun
1. A roughly hemispherical container used to hold, mix or present food, such as salad, fruit or soup, or other items. 
2. As much as is held by a bowl. 
3. (cooking) A dish comprising a mix of different foods, not all of which need be cooked, served in a bowl. 
4. A haircut in which straight hair is cut at an even height around the edges, forming a bowl shape. 
5. The part of a spoon that holds content, as opposed to the handle. 
6. A part of a pipe or bong packed with marijuana for smoking 
7. (typography) A rounded portion of a glyph that encloses empty space, as in the letters d and o. 
8. (geography) A round crater (or similar) in the ground. 
9. (sports, theater) An elliptical-shaped stadium or amphitheater resembling a bowl. 
10. (American football) A postseason football competition, a bowl game (i.e. Rose Bowl, Super Bowl) 
11. The ball rolled by players in the game of lawn bowls. 
12. The action of bowling a ball. 
13. (in the plural, but used with a singular verb) The game of bowls. 

### Verb
1. (transitive) To roll or throw (a ball) in the correct manner in cricket and similar games and sports. 
2. (intransitive) To throw the ball (in cricket and similar games and sports). 
3. (intransitive) To play bowling or a similar game. 
4. To roll or carry smoothly on, or as on, wheels. 
5. To pelt or strike with anything rolled. 

## Synonyms
[[trough]] | [[basin]] | [[arena]] | [[stadium]]