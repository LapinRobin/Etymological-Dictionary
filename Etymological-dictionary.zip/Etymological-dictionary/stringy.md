# stringy

## Etymology
- From string +‎ -y.


## Definition
### Adjective
1. Composed of, or resembling, string or strings. 
2. (of food) Tough to the bite, as containing too much sinew or string tissue. 
3. (of a person) Wiry, lean, scrawny. 
4. (programming, informal) Resembling or involving text strings. 
5. (birdwatching) Of a sighting, unlikely to be accurate; probably based on a misidentification, whether innocent or deliberate. 

## Synonyms
[[lean]] | [[tough]] | [[thin]] | [[thick]] | [[wiry]]