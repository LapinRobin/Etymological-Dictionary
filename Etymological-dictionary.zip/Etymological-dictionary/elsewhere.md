# elsewhere

## Etymology
- From Middle English elswher, from Old English elles hwǣr and elles hwerġen (“elsewhere”); corresponding with else +‎ where.


## Definition
### Adverb
1. Synonym of somewhere else: in, at, or to some other place. 

### Noun
1. Synonym of somewhere else: a place other than here. 

## Synonyms
