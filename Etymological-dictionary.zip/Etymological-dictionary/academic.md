# academic

## Etymology
- From both the Medieval Latin acadēmicus and the French académique, from Latin academia, from Ancient Greek ἀκαδημικός (akadēmikós), from Ἀκαδημία (Akadēmía) or Ἀκαδήμεια (Akadḗmeia), the name of the place where Plato taught; compare academy.


## Definition
### Adjective
1. Belonging to the school or philosophy of Plato 
2. Belonging to an academy or other higher institution of learning, or a scholarly society or organization. 
3. In particular: relating to literary, classical, or artistic studies like the humanities, rather than to technical or vocational studies like engineering or welding. 
4. Having little practical use or value, as by being overly detailed and unengaging, or by being theoretical and speculative with no practical importance. 
5. Having a love of or aptitude for learning. 
6. (art) Conforming to set rules and traditions; conventional; formalistic. 
7. Subscribing to the architectural standards of Vitruvius. 
8. So scholarly as to be unaware of the outside world; lacking in worldliness; inexperienced in practical matters. 

### Noun
1. (usually capitalized) A follower of Plato, a Platonist. 
2. A senior member of an academy, college, or university; a person who attends an academy; a person engaged in scholarly pursuits; one who is academic in practice. 
3. A member of the Academy; an academician. 
4. (archaic) A student in a college. 
5. (plural only) Academic dress; academicals. 
6. (plural only) Academic studies. 

## Synonyms
[[pedantic]] | [[theoretical]] | [[scholarly]]