# gravitate

## Etymology
- Back-formation from gravitation. Or borrowed from New Latin gravito, gravitatus.


## Definition
### Verb
1. (intransitive, astrophysics) To move under the force of gravity. 
2. (intransitive, figuratively) To tend or drift towards someone or something, as though being pulled by gravity. 

## Synonyms
