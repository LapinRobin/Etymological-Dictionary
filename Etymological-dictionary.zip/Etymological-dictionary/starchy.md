# starchy

## Etymology
- From starch +‎ -y.


## Definition
### Adjective
1. Of or pertaining to starch. 
2. Containing starch. 
3. Having the quality of fabric starch as applied to fabric; stiff, hard; starched. 
4. Having a starched personality; stiffly formal. 

## Synonyms
[[stiff]] | [[formal]]