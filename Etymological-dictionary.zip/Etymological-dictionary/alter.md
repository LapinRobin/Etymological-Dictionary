# alter

## Etymology
- From Old French alterer (French altérer), from Medieval Latin alterare (“to make other”), from Latin alter (“the other”), from al- (seen in alius (“other”), alienus (“of another”), etc.; see alias, alien, etc.) + compar. suffix -ter.

- Probably from alter ego.

- alter


## Definition
### Verb
1. (transitive) To change the form or structure of. 
2. (intransitive) To become different. 
3. (transitive) To tailor clothes to make them fit. 
4. (transitive) To castrate, neuter or spay (a dog or other animal). 
5. (transitive) To affect mentally, as by psychotropic drugs or illness. 

### Noun
1. (especially in the plural) An identity or headmate of a person with dissociative identity disorder (previously known as multiple personality disorder). A member of a system. 
2. Misspelling of altar.  

## Synonyms
[[change]] | [[vary]] | [[interpolate]] | [[neuter]] | [[falsify]] | [[spay]]