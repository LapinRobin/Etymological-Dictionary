# witty

## Etymology
- From Middle English witty, witti, from Old English wittiġ, witiġ, ġewittiġ (“clever, wise”), from Proto-West Germanic *witīg, *witag, from Proto-Germanic *witagaz, *wītagaz (“knowing, wise, clever”), equivalent to wit +‎ -y. Cognate with Middle Low German wittich, gewittich (“knowing, clever, wise, understanding”), German witzig (“funny, witty”), Norwegian Bokmål vettig, Norwegian Nynorsk vittig (“witty”).


## Definition
### Adjective
1. (obsolete) Wise, having good judgement. 
2. (archaic) Possessing a strong intellect or intellectual capacity; intelligent, skilful, ingenious. 
3. Clever; amusingly ingenious. 
4. Full of wit. 
5. Quick of mind; insightful; in possession of wits. 

### Noun
1. A surname. 

## Synonyms
[[humorous]]