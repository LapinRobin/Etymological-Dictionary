# naysayer

## Etymology
- Origin: 1715–1725, from nay +‎ say +‎ -er, equivalent to naysay +‎ -er. First recorded use: 1721.


## Definition
### Noun
1. One who consistently denies, criticizes, or doubts; a detractor. 

## Synonyms
