# capitalism

## Etymology
- Borrowed from French capitalisme (“the condition of one who is rich”); equivalent to capital +‎ -ism. First used in English by novelist William Thackeray in 1854.


## Definition
### Noun
1. (politics) A socio-economic system based on private ownership of resources or capital. 
2. (economics) An economic system based on private ownership of the means of production and their operation for profit. 
3. (politics, economic liberalism) A socio-economic system based on private property rights, including the private ownership of resources or capital, with economic decisions made largely through the operation of a market unregulated by the state. 
4. (economics, economic liberalism) An economic system based on the abstraction of resources into the form of privately owned capital, with economic decisions made largely through the operation of a market unregulated by the state. 

## Synonyms
