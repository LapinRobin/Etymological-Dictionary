# idiom

## Etymology
- From Middle French idiome, and its source, Late Latin idioma, from Ancient Greek ἰδίωμα (idíōma, “a peculiarity, property, a peculiar phraseology, idiom”), from ἰδιοῦσθαι (idioûsthai, “to make one's own, appropriate to oneself”), from ἴδιος (ídios, “one's own, pertaining to oneself, private, personal, peculiar, separate”).


## Definition
### Noun
1. A manner of speaking, a mode of expression peculiar to a language, language family, or group of people. 
2. (programming) A programming construct or phraseology that is characteristic of the language. 
3. A language or language variety; specifically, a restricted dialect used in a given historical period, context etc. 
4. An established phrasal expression whose meaning may not be deducible from the literal meanings of its component words. 
5. An artistic style (for example, in art, architecture, or music); an instance of such a style. 

## Synonyms
[[accent]] | [[phrase]] | [[parlance]] | [[dialect]]