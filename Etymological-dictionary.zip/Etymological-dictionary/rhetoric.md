# rhetoric

## Etymology
- From Middle English rethorik, from Latin rēthoricus, rhētoricus, from Ancient Greek ῥητορῐκός (rhētorikós).

- From Middle English rethorik, rhetoric, from Old French rhetorique, from Latin rhētorica, from Ancient Greek ῥητορική (rhētorikḗ), ellipsis of ῥητορικὴ τέχνη (rhētorikḕ tékhnē), from ῥητορικός (rhētorikós, “concerning public speech”), from ῥήτωρ (rhḗtōr, “public speaker”).


## Definition
### Adjective
1. Synonym of rhetorical. 

### Noun
1. The art of using language, especially public speaking, as a means to persuade. 
2. Meaningless language with an exaggerated style intended to impress. 

## Synonyms
[[palaver]]