# maniac

## Etymology
- From mania +‎ -ac. Borrowed from French maniaque, from Late Latin maniacus, from Ancient Greek μανιακός (maniakós), adjectival form of μανία (manía, “madness”).  Doublet of manic.


## Definition
### Noun
1. An insane person, especially one who suffers from a mania. 
2. A fanatic, a person with an obsession. 

## Synonyms
[[lunatic]] | [[maniacal]]