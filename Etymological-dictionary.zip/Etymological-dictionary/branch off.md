# branch off

## Definition
### Verb
1. (idiomatic, intransitive, of a path or route) To diverge into two or more separate paths. 
2. To separate from a main path or route. 
3. (of a conversation) To divert from the main topic of conversation. 

## Synonyms
