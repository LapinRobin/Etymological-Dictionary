# constitutional

## Etymology
- From constitution +‎ -al (suffix meaning ‘of or pertaining to’ forming adjectives). Constitution is derived from Middle English constitucioun, constitucion (“edict, law, ordinance, regulation, rule, statute; body of laws or rules, or customs; body of fundamental principles; principle or rule (of science); creation”) from Old French constitucion (modern French constitution), a learned borrowing from Latin cōnstitūtiō, cōnstitūtiōnem (“character, constitution, disposition, nature; definition; point in dispute; order, regulation; arrangement, system”), from cōnstituō (“to establish, set up; to confirm; to decide, resolve”) (from con- (prefix indicating a being or bringing together of several objects) + statuō (“to set up, station; to establish; to determine, fix”) (ultimately from Proto-Indo-European *steh₂- (“to stand (up)”))) + -tiō (suffix forming nouns relating to actions or the results of actions), -tiōnem (accusative singular of -tiō).


## Definition
### Adjective
1. Belonging to, or inherent in, the constitution or structure of one's body or mind. 
2. For the benefit of one's constitution or health. 
3. Relating to the constitution or composition of something; essential, fundamental. 
4. Relating to a legal or political constitution (“the basic law of a nation or institution; the formal or informal system of primary principles and laws that regulates a government or other institution”). 
5. In compliance with or valid under a legal or political constitution. 
6. (also politics) Of a monarch: having a purely ceremonial role, or possessing powers limited by a constitution rather than plenary or unlimited powers. 

### Noun
1. A walk that is taken regularly for good health and wellbeing. 
2. (euphemistic) An act of defecation. 

## Synonyms
[[intrinsic]] | [[inherent]] | [[integral]] | [[essential]] | [[organic]] | [[constituent]]