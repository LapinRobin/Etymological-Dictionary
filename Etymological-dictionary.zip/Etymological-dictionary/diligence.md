# diligence

## Etymology
- Borrowed from French diligence.


## Definition
### Noun
1. Steady application; industry; careful work involving long-term effort. 
2. The qualities of a hard worker, including conscientiousness, determination, and perseverance. 
3. Carefulness. 
4. (historical, 19th century) A public stage-coach. 
5. (law, Scotland) The process by which persons, lands, or effects are seized for debt; process for enforcing the attendance of witnesses or the production of writings. 

## Synonyms
[[industry]] | [[application]]