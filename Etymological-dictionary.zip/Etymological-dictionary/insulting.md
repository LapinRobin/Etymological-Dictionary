# insulting

## Definition
### Adjective
1. Containing insult, or having the intention of insulting. 

### Noun
1. The act of giving insult. 

## Synonyms
[[offensive]] | [[scurrilous]] | [[contemptuous]] | [[disdainful]] | [[scornful]] | [[abusive]]