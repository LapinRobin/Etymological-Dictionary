# sobriety

## Etymology
- From Old French sobriete, from Latin sobrietas.


## Definition
### Noun
1. The quality or state of not being intoxicated. 
2. The quality or state of being grave or earnestly thoughtful. 
3. The state or quality of being unhurried; a state of calm. 
4. A state of moderation or seriousness. 
5. Modesty in color or style. 
6. Soundness of judgement. 

## Synonyms
[[gravity]] | [[temperance]]