# avert

## Etymology
- From Middle English averten, adverten, from Old French avertir (“turn, direct, avert; turn the attention, make aware”), from Latin āvertere, present active infinitive of āvertō, from ab + vertō (“to turn”).


## Definition
### Verb
1. (transitive) To turn aside or away. 
2. (transitive) To ward off, or prevent, the occurrence or effects of. 
3. (intransitive, archaic) To turn away. 

## Synonyms
[[obviate]] | [[avoid]] | [[deflect]] | [[debar]]