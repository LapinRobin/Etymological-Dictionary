# fort

## Etymology
- From Middle English fort, from Middle French fort (“strong”) (adjective use is from Old French). Doublet of fortis and forte.


## Definition
### Noun
1. A fortified defensive structure stationed with troops. 
2. Any permanent army post. 
3. (historical) An outlying trading-station, as in British North America. 
4. A structure improvised from furniture, bedding, etc., for playing games. 
5. A surname. 

### Verb
1. To create a fort, fortifications, a strong point, or a redoubt. 

## Synonyms
[[garrison]] | [[fortify]] | [[fortress]]