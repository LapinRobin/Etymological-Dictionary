# plead

## Etymology
- From Middle English pleden, plaiden, from Old French plaider (“to plead, offer a plea”), from plait, from Medieval Latin placitum (“a decree, sentence, suit, plea, etc.", in Classical Latin, "an opinion, determination, prescription, order; literally, that which is pleasing, pleasure”), neuter of placitus, past participle of placeō (“to please”). Cognate with Spanish pleitear (“to litigate, take to court”).


## Definition
### Verb
1. (transitive, intransitive, copulative) To present (an argument or a plea), especially in a legal case. 
2. (intransitive) To beg, beseech, or implore. 
3. (transitive) To offer by way of excuse. 
4. (transitive) To discuss by arguments. 

## Synonyms
