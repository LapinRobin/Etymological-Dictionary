# caper

## Etymology
- Clipping of capriole.

- From Dutch kaper.

- From Latin capparis, from Ancient Greek κάππαρις (kápparis).

- Shortening of capercaillie.


## Definition
### Noun
1. A playful leap or jump. 
2. A jump while dancing. 
3. A prank or practical joke. 
4. (usually in the plural) Playful behaviour. 
5. (figuratively) A crime, especially an elaborate heist, or a narrative about such a crime. 
6. A vessel formerly used by the Dutch; privateer. 
7. The pungent grayish green flower bud of the European and Oriental caper (Capparis spinosa), which is pickled and eaten. 
8. A plant of the genus Capparis. 
9. (Scotland) The capercaillie. 

### Verb
1. To leap or jump about in a sprightly or playful manner. 
2. To jump as part of a dance. 
3. To engage in playful behaviour. 

## Synonyms
[[play]] | [[job]] | [[trick]] | [[joke]] | [[prank]] | [[frolic]] | [[gambol]] | [[antic]] | [[romp]]