# desk jockey

## Etymology
- Blend of desk +‎ disk jockey


## Definition
### Noun
1. (idiomatic) One who spends his or her time seated at a desk; especially one who is more concerned with procedure, paperwork, or administration than with its ultimate goal or practical consequence. 

## Synonyms
