# gate

## Etymology
- From Middle English gate, gat, ȝate, ȝeat, from Old English ġeat (“gate”), from Proto-West Germanic *gat, from Proto-Germanic *gatą (“hole, opening”).

- Borrowed from Old Norse gata, from Proto-Germanic *gatwǭ. Cognate with Danish gade, Swedish gata, German Gasse (“lane”). Doublet of gait.


## Definition
### Noun
1. A doorlike structure outside a house. 
2. Doorway, opening, or passage in a fence or wall. 
3. Movable barrier. 
4. Passageway (as in an air terminal) where passengers can embark or disembark. 
5. A location which serves as a conduit for transport, migration, or trade. 
6. The amount of money made by selling tickets to a concert or a sports event. 
7. (computing) A logical pathway made up of switches which turn on or off. Examples are and, or, nand, etc. 
8. (electronics) The controlling terminal of a field effect transistor (FET). 
9. In a lock tumbler, the opening for the stump of the bolt to pass through or into. 
10. (metalworking) The channel or opening through which metal is poured into the mould; the ingate. 
11. The waste piece of metal cast in the opening; a sprue or sullage piece. Also written geat and git. 
12. (cricket) The gap between a batsman's bat and pad. 
13. (cinematography) A mechanism, in a film camera and projector, that holds each frame momentarily stationary behind the aperture. 
14. (flow cytometry) A line that separates particle type-clusters on two-dimensional dot plots. 
15. A tally mark consisting of four vertical bars crossed by a diagonal, representing a count of five. 
16. (now Scotland, Northern England) A way, path. 
17. (obsolete) A journey. 
18. (Scotland, Northern England) A street; now used especially as a combining form to make the name of a street e.g. "Briggate" (a common street name in the north of England meaning "Bridge Street") or Kirkgate meaning "Church Street". 
19. (Britain, Scotland, dialect, archaic) Manner; gait. 
20. A ghost town in Scott County, Arkansas, United States. 
21. A tiny town in Beaver County, Oklahoma, United States. 
22. An unincorporated community in Thurston County, Washington, United States. 
23. (education, initialism) gifted and talented education 

### Verb
1. (transitive) To keep something inside by means of a closed gate. 
2. (transitive) To punish, especially a child or teenager, by not allowing them to go out. 
3. (transitive, biochemistry) To open a closed ion channel. 
4. (transitive) To furnish with a gate. 
5. (transitive) To turn (an image intensifier) on and off selectively as needed, or to avoid damage from excessive light exposure. See autogating. 

## Synonyms
