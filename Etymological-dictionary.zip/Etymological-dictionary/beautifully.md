# beautifully

## Etymology
- beautiful +‎ -ly, circa 17th century


## Definition
### Adverb
1. In a beautiful manner. 

## Synonyms
