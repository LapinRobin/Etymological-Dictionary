# repel

## Etymology
- From Middle English repellen, a borrowing from Old French *repeller, from Latin repellere (“to drive back”), from re- (“back”) + pellere (“to drive”).  Doublet of repeal.


## Definition
### Verb
1. (transitive, now rare) To turn (someone) away from a privilege, right, job, etc. 
2. (transitive) To reject, put off (a request, demand etc.). 
3. (transitive) To ward off (a malignant influence, attack etc.). 
4. (transitive) To drive back (an assailant, advancing force etc.). 
5. (transitive, physics) To force away by means of a repulsive force. 
6. (transitive) To cause repulsion or dislike in; to disgust. 
7. (transitive, sports) To save (a shot). 

## Synonyms
[[drive]] | [[snub]] | [[rebuff]] | [[revolt]] | [[disgust]] | [[repulse]]