# unwary

## Etymology
- From un- +‎ wary. Compare Old English unwær (“unaware, unwary”) and unwærlīċ (“unwary, heedless”).


## Definition
### Adjective
1. Lacking caution as a result of naïveté or inexperience 
2. Unprepared; not watchful 

## Synonyms
[[gullible]]