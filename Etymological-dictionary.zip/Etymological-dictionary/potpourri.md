# potpourri

## Etymology
- From French pot-pourri (“stew, potpourri”), a Calque of Spanish olla podrida (“stew”, literally “rotten pot”). Doublet of olla podrida.


## Definition
### Noun
1. A collection of various things; an assortment, mixed bag or motley. 
2. An anthology of miscellaneous prose. 
3. (music) A medley of songs or music. 
4. A mixture of dried fragrant plant material, often in a decorative bowl, used to scent a room. 
5. A ragout or stew of meat and vegetables. 

## Synonyms
[[variety]] | [[pastiche]] | [[motley]] | [[medley]] | [[mixture]] | [[assortment]]