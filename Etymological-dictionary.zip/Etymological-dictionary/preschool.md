# preschool

## Etymology
- pre- +‎ school


## Definition
### Adjective
1. Of or relating to the years of early childhood before attendance at primary school. 

### Noun
1. A nursery school. 

### Verb
1. (transitive) To provide nursery school education for. 
2. (intransitive) To undergo nursery school education. 

## Synonyms
