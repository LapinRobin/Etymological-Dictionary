# sweet

## Etymology
- From Middle English swete, from Old English swēte (“sweet”), from Proto-West Germanic *swōtī, from Proto-Germanic *swōtuz (“sweet”), from Proto-Indo-European *swéh₂dus (“sweet”).


## Definition
### Adjective
1. Having a pleasant taste, especially one relating to the basic taste sensation induced by sugar. 
2. Having a taste of sugar. 
3. (wine) Retaining a portion of sugar. 
4. Not having a salty taste. 
5. Having a pleasant smell. 
6. Not decaying, fermented, rancid, sour, spoiled, or stale. 
7. Having a pleasant sound. 
8. Having a pleasing disposition. 
9. Having a helpful disposition. 
10. (mineralogy) Free from excessive unwanted substances like acid or sulphur. 
11. (informal) Very pleasing; agreeable. 
12. (slang) Doing well; in a good or happy position. 
13. (informal, followed by on) Romantically fixated; enamored with; fond of. 
14. Fresh; not salt or brackish. 
15. (of soil, UK, dated) Alkaline. 
16. Pleasing to the eye; beautiful; mild and attractive; fair. 
17. An intensifier. 

### Adverb
1. In a sweet manner. 

### Noun
1. (uncountable) The basic taste sensation induced by sugar. 
2. (countable, Britain) A confection made from sugar, or high in sugar content; a candy. 
3. (countable, Britain) A food eaten for dessert. 
4. Synonym of sweetheart, a term of affection. 
5. (obsolete) That which is sweet or pleasant in odour; a perfume. 
6. (obsolete) Sweetness, delight; something pleasant to the mind or senses. 
7. A surname. 
8. A female given name. 
9. An unincorporated community in Gem County, Idaho, United States. 

### Verb
1. (obsolete or poetic) To sweeten. 

## Synonyms
[[dessert]] | [[fresh]] | [[mellifluous]] | [[confectionery]] | [[cloying]] | [[confection]] | [[dulcet]] | [[musical]] | [[angelic]] | [[saccharine]] | [[fragrant]]