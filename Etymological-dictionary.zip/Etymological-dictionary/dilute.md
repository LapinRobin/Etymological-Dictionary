# dilute

## Etymology
- From Latin dīlūtus, from dīluere (“to wash away, dissolve, cause to melt, dilute”), from dī-, dis- (“away, apart”) + luere (“to wash”). See lave, and compare deluge.


## Definition
### Verb
1. (transitive) To make thinner by adding solvent to a solution, especially by adding water. 
2. (transitive) To weaken, especially by adding a foreign substance. 
3. (transitive, stock market) To cause the value of individual shares or the stake of a shareholder to decrease by increasing the total number of shares. 
4. (intransitive) To become attenuated, thin, or weak. 

### Adjective
1. Having a low concentration. 
2. Weak; reduced in strength by dilution; diluted. 
3. Of an animal: having a lighter-coloured coat than is usual. 

### Noun
1. An animal having a lighter-coloured coat than is usual. 

## Synonyms
[[cut]] | [[white]] | [[stretch]] | [[reduce]] | [[thin]] | [[weak]] | [[debase]] | [[adulterate]]