# rider

## Etymology
- From Middle English ryder, ridere, from Late Old English rīdere (“rider, knight”); equivalent to ride +‎ -er. Compare Dutch rijder, German Reiter.


## Definition
### Noun
1. (now archaic or historical) A knight, or other mounted warrior. 
2. An old Dutch gold coin with the figure of a man on horseback stamped upon it. 
3. (generally) Someone who rides a horse or (later) a bicycle, motorcycle etc. 
4. (now historical or archaic) A mounted robber; a bandit, especially in the Scottish borders. 
5. (obsolete) Someone who breaks in or manages a horse; a riding master. 
6. (now rare, historical) An agent who goes out with samples of goods to obtain orders; a commercial traveller or travelling salesman. 
7. (now chiefly US) Someone riding in a vehicle; a passenger on public transport. 
8. (politics) A supplementary clause added to a document after drafting, especially to a bill under the consideration of a legislature. 
9. An amendment or addition to an entertainer's performance contract, often covering a performer's equipment or food, drinks, and general comfort requirements. 
10. An additional matter or question arising in corollary; a qualification. 
11. A supplementary question, now especially in mathematics. 
12. (shipbuilding) An interior rib occasionally fixed in a ship's hold, reaching from the keelson to the beams of the lower deck, to strengthen the frame. 
13. (mining, now rare) Rock material in a vein of ore, dividing it. 
14. (nautical, in the plural) The second tier of casks in a vessel's hold. 
15. A small, sliding piece of thin metal on a balance, used to determine small weights. 
16. (cartomancy) The first Lenormand card, also known as either the horseman or the cavalier. 
17. (chess) A piece, such as the rook or bishop, which moves any distance in one direction, as long as no other piece is in the way. 
18. A surname originating as an occupation. More often spelled Ryder. 

## Synonyms
[[passenger]]