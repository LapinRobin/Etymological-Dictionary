# probe

## Etymology
- For verb: borrowed from Latin probare (“to test, examine, prove”), from probus (“good”).


## Definition
### Noun
1. (surgery) Any of various medical instruments used to explore wounds, organs, etc. 
2. (figuratively) Something which penetrates something else, as though to explore; something which obtains information. 
3. An act of probing; a prod, a poke. 
4. (figuratively) An investigation or inquiry. 
5. (aeronautics) A tube attached to an aircraft which can be fitted into the drogue from a tanker aircraft to allow for aerial refuelling. 
6. (sciences) A small device, especially an electrode, used to explore, investigate or measure something by penetrating or being placed in it. 
7. (astronautics) A small, usually unmanned, spacecraft used to acquire information or measurements about its surroundings. 
8. (game of Go) a move with multiple answers seeking to make the opponent choose and commit to a strategy 
9. (biochemistry) Any group of atoms or molecules radioactively labeled in order to study a given molecule or other structure 
10. A model of Ford automobile. 

### Verb
1. (transitive, intransitive) To explore, investigate, or question 
2. (transitive) To insert a probe into. 

## Synonyms
[[examine]] | [[investigation]]