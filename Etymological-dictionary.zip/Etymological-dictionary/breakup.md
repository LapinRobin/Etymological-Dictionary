# breakup

## Etymology
- break +‎ up


## Definition
### Noun
1. The act of breaking up; disintegration or division. 
2. The termination of a friendship or a romantic relationship. 
3. A loss of emotional control; a breakdown. 
4. (Alaska and northern Canada) The time of year during which winter ice covering bodies of water disintegrates; more generally, spring. 

## Synonyms
[[dissolution]] | [[detachment]] | [[separation]]