# crude

## Etymology
- From Middle English crude, borrowed from Latin crūdus (“raw, bloody, uncooked, undigested, crude”), probably from Proto-Indo-European *krewh₂- (“raw meat, fresh blood”). Cognate with Old English hrēaw (“raw, uncooked”). More at raw.


## Definition
### Adjective
1. In a natural, untreated state. 
2. Characterized by simplicity, especially something not carefully or expertly made. 
3. Lacking concealing elements. 
4. Lacking tact or taste. 
5. (archaic) Immature or unripe. 
6. (obsolete) Uncooked, raw. 
7. (grammar) Pertaining to the uninflected stem of a word. 

### Noun
1. Any substance in its natural state. 
2. Crude oil. 

## Synonyms
[[blunt]] | [[gross]] | [[rough]] | [[stark]] | [[rude]] | [[raw]] | [[coarse]] | [[vulgar]] | [[primitive]] | [[early]] | [[indecent]] | [[earthy]]