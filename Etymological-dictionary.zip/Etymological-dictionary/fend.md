# fend

## Etymology
- From Middle English fenden (“defend, fight, prevent”), shortening of defenden (“defend”), from Old French deffendre (Modern French défendre), from Latin dēfendō (“to ward off”), from dē- +‎ *fendō (“hit, thrust”), from Proto-Italic *fendō, from Proto-Indo-European *gʷʰen- (“strike, kill”).

- From Middle English fēnd, feond, from Old English fēond (“adversary, foe, enemy, fiend, devil, Satan”), from Proto-Germanic *fijandz, present participle of *fijaną, from Proto-Indo-European *peh₁- (“to hate”). More at fiend.


## Definition
### Verb
1. (intransitive) To take care of oneself; to take responsibility for one's own well-being. 
2. (rare, except as "fend for oneself") To defend, to take care of (typically construed with for); to block or push away (typically construed with off). 

### Noun
1. (obsolete) Self-support; taking care of one's own well-being. 
2. (UK dialectal) An enemy; fiend; the Devil. 

## Synonyms
