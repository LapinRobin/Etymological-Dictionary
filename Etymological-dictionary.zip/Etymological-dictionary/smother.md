# smother

## Etymology
- From Middle English smothren, smortheren, alteration (due to smother, smorther (“a suffocating vapour, dense smoke”, noun)) of Middle English smoren (“to smother”), from Old English smorian (“to smother, suffocate, choke”), from Proto-Germanic *smurōną (“to suffocate, strangle”), probably related to *smallijan (“to burn”) or Old English smoca (“smoke”).

- From Middle English smother, smorther (“a suffocating vapour, dense smoke”), from Old English smorþor (“smoke”, literally “that which suffocates”), from smorian (“to suffocate, choke”) + -þor (instrumental suffix).


## Definition
### Verb
1. (transitive) To suffocate; stifle; obstruct, more or less completely, the respiration of something or someone. 
2. (transitive) To extinguish or deaden, as fire, by covering, overlaying, or otherwise excluding the air. 
3. (transitive) To reduce to a low degree of vigor or activity; suppress or do away with; extinguish 
4. (transitive, cooking) To cook in a close dish. 
5. (transitive) To daub or smear. 
6. (intransitive) To be suffocated. 
7. (intransitive) To breathe with great difficulty by reason of smoke, dust, close covering or wrapping, or the like. 
8. (intransitive, of a fire) to burn very slowly for want of air; smolder. 
9. (intransitive, figuratively) to perish, grow feeble, or decline, by suppression or concealment; be stifled; be suppressed or concealed. 
10. (soccer) To get in the way of a kick of the ball. 
11. (Australian rules football) To get in the way of a kick of the ball, preventing it going very far. When a player is kicking the ball, an opponent who is close enough will reach out with his hands and arms to get over the top of it, so the ball hits his hands after leaving the kicker's boot, dribbling away. 
12. (boxing) To prevent the development of an opponent's attack by one's arm positioning. 

### Noun
1. Smoldering; slow combustion. 
2. Cookware used in such cooking. 
3. (dated) The state of being stifled; suppression. 
4. (dated) Stifling smoke; thick dust. 
5. (Australian rules football) The act of smothering a kick (see verb section). 

## Synonyms
[[stifle]] | [[clutter]] | [[muddle]] | [[surround]] | [[jumble]] | [[welter]] | [[muffle]] | [[put out]]