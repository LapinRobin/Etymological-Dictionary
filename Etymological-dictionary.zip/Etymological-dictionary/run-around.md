# run-around

## Definition
### Noun
1. A small car for making short trips. 
2. Alternative form of runaround  

## Synonyms
