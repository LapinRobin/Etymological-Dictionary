# presently

## Etymology
- From Middle English presently; equivalent to present +‎ -ly.


## Definition
### Adverb
1. (now Britain, rare) Immediately, at once; quickly. 
2. Before long; soon. 
3. (rarely proscribed) At present; now; currently. 
4. (obsolete) With actual presence; in actuality. 

## Synonyms
[[soon]] | [[currently]] | [[shortly]]