# trivia

## Etymology
- From Latin trivia, plural of trivium (“place where three roads meet”). The term came to be used for any public place, and then for anything commonplace. Furthermore, because the beginners' course at university was called trivium, the word came to be used only for anything basic, simple and trivial.

- trivia


## Definition
### Noun
1. Insignificant trifles of little importance, especially items of unimportant information. 
2. A quiz game that involves obscure facts. 
3. (Roman mythology) An aspect of the Roman goddess Diana, pertaining to her role as guardian of trivia (crossroads or forks where three roads meet); used as an epithet. 

## Synonyms
[[trifle]]