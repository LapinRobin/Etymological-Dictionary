# swindler

## Etymology
- Borrowed from German Schwindler, 1774.


## Definition
### Noun
1. A person who swindles, cheats or defrauds. 
2. A surname. 

## Synonyms
