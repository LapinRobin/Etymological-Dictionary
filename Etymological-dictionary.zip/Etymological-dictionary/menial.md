# menial

## Etymology
- From Middle English meyneal, from Anglo-Norman mesnal, from maisnee (“household”), from Vulgar Latin mansionata, from Latin mānsiō (“house”).


## Definition
### Adjective
1. Of or relating to work normally performed by a servant. 
2. Of or relating to unskilled work. 
3. Servile; low; mean. 

### Noun
1. A servant, especially a domestic servant. 
2. A person who has a subservient nature. 

## Synonyms
[[humble]] | [[lowly]]