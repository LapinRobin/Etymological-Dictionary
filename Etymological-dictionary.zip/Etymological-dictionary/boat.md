# boat

## Etymology
- From Middle English bot, boot, boet, boyt (“boat”), from Old English bāt (“boat”), from Proto-Germanic *baitaz, *baitą (“boat, small ship”), from Proto-Indo-European *bʰeyd- (“to break, split”). Cognate with Old Norse beit (“boat”), Middle Dutch beitel (“little boat”).


## Definition
### Noun
1. A craft used for transportation of goods, fishing, racing, recreational cruising, or military use on or in the water, propelled by oars or outboard motor or inboard motor or by wind. 
2. (poker slang) A full house. 
3. A vehicle, utensil, or dish somewhat resembling a boat in shape. 
4. (chemistry) One of two possible conformations of cyclohexane rings (the other being chair), shaped roughly like a boat. 
5. (Australia, politics, informal) The refugee boats arriving in Australian waters, and by extension, refugees generally. 
6. (Internet slang) Acronym of best of all time. 
7. Acronym of brightest of all time. 

### Verb
1. (intransitive) To travel by boat. 
2. (transitive) To transport in a boat. 
3. (transitive) To place in a boat. 

## Synonyms
