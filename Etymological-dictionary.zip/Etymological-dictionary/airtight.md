# airtight

## Etymology
- air +‎ tight


## Definition
### Adjective
1. Impermeable to air or other gases. 
2. (figuratively) Having no weak points or flaws. 
3. (figuratively, of a person) Highly reserved in some matter, particularly tight-lipped or tight-fisted. 

## Synonyms
[[tight]]