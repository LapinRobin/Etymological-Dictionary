# transform

## Etymology
- From Middle English transformen, from Old French transformer, from Latin transformo, transformare, from trans (“across”, preposition) + forma (“form”).


## Definition
### Verb
1. (transitive) To change greatly the appearance or form of. 
2. (transitive) To change the nature, condition or function of; to change in nature, disposition, heart, character, etc.; to convert. 
3. (transitive, mathematics) To subject to a transformation; to change into another form without altering the value. 
4. (transitive, electricity) To subject to the action of a transformer. 
5. (transitive, genetics) To subject (a cell) to transformation. 
6. (intransitive) To undergo a transformation; to change in appearance or character. 

### Noun
1. (mathematical analysis) An operation (often an integration) that converts one function into another. 
2. (by extension) A function so produced. 
3. (geology, seismology) A transform fault. 

## Synonyms
[[translate]] | [[transmute]]