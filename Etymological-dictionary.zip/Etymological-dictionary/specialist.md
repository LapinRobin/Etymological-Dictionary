# specialist

## Etymology
- Borrowed from French spécialiste.


## Definition
### Adjective
1. (Britain) Specialised, involving detailed knowledge of a restricted topic. 

### Noun
1. Someone who is an expert in, or devoted to, some specific branch of study or research. 
2. (medicine) A physician whose practice is limited to a particular branch of medicine or surgery. 
3. (US, military) Any of several non-commissioned ranks corresponding to that of corporal. 
4. An organism that is specialized for a particular environment. 
5. A stenotopic species. 

## Synonyms
