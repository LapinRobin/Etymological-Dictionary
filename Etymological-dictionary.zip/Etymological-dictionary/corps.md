# corps

## Etymology
- From French corps d'armée (literally “army body”), from Latin corpus (“body”). Doublet of corpse and corpus. See also English riff.

- Clipping.


## Definition
### Noun
1. (military) A battlefield formation composed of two or more divisions. 
2. An organized group of people united by a common purpose. 

## Synonyms
