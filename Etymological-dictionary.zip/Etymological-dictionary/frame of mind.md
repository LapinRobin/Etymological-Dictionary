# frame of mind

## Definition
### Noun
1. Alternative form of state of mind  

## Synonyms
