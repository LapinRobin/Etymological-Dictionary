# immobile

## Etymology
- From Old French immobile, from Latin immōbilis.


## Definition
### Adjective
1. not mobile, not movable 
2. fixed, unable to be moved 

## Synonyms
[[fast]] | [[firm]] | [[stiff]] | [[fixed]]