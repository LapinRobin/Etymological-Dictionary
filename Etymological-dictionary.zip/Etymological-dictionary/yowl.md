# yowl

## Etymology
- From Middle English yollen, past participle of yellen (“to yell”). More at yell, yollen.


## Definition
### Noun
1. A prolonged, loud cry, like the sound of an animal; a wail; a howl. 

### Verb
1. (intransitive) Utter a yowl. 
2. (transitive) Express by yowling; utter with a yowl. 

## Synonyms
[[holler]] | [[roar]] | [[bellow]] | [[howl]] | [[yammer]] | [[caterwaul]]