# automobile

## Etymology
- From French automobile, from Ancient Greek αὐτός (autós, “self”) + French mobile (“moving”), from Latin mōbilis (“movable”).


## Definition
### Noun
1. (US, Canada) A type of vehicle designed to move on the ground under its own stored power and intended to carry a driver, a small number of additional passengers, and a very limited amount of other load. A car or motorcar. 

### Verb
1. (intransitive, dated) To travel by automobile. 

### Adjective
1. Self-moving; self-propelled. 

## Synonyms
[[car]] | [[machine]] | [[auto]]