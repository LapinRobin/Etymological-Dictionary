# washed-out

## Definition
### Adjective
1. Alternative form of washed out  

## Synonyms
[[exhausted]] | [[tired]] | [[spent]]