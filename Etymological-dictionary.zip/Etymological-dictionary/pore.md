# pore

## Etymology
- From Middle English pore, from Old French pore, from Latin porus, from Ancient Greek πόρος (póros, “passage”). Displaced native English sweat hole from Middle English swet hole, which might have been a reformation of Old English swātþȳrel (literally “sweat hole”), which competed with līcþēote (literally “body pipe”).

- From Middle English poren, pouren, puren (“to gaze intently, look closely”), from Old English *purian, suggested by Old English spyrian (“to investigate, examine”). Akin to Middle Dutch poren (“to pore, look”), Dutch porren (“to poke, prod, stir, encourage, endeavour, attempt”), Low German purren (“to poke, stir”), Danish purre (“to poke, stir, rouse”), dialectal Swedish pora, pura, påra (“to work slowly and gradually, work deliberately”), Old English spor (“track, trace, vestige”). Compare also Middle English puren, piren (“to look, peer”). See peer.


## Definition
### Noun
1. A tiny opening in the skin. 
2. By extension any small opening or interstice, especially one of many, or one allowing the passage of a fluid. 

### Verb
1. to study meticulously; to go over again and again. 
2. to meditate or reflect in a steady way. 

## Synonyms
[[center]] | [[focus]] | [[centre]] | [[rivet]] | [[concentrate]] | [[stoma]]