# tailor-made

## Definition
### Adjective
1. Made by a tailor, especially if made to order; bespoke 
2. Perfectly appropriate to some specific occasion or purpose; made to one's specific requirements 

### Noun
1. A suit made by a tailor. 
2. (prison slang) Synonym of civvy (“manufactured cigarette”) 

## Synonyms
[[bespoke]] | [[custom]] | [[tailored]]