# overjoyed

## Definition
### Adjective
1. Very happy. 
2. (obsolete) Overly happy. 

## Synonyms
[[joyful]]