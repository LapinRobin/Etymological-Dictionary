# gutless

## Etymology
- gut +‎ -less


## Definition
### Adjective
1. (informal) Cowardly; lacking courage or morals. 

## Synonyms
