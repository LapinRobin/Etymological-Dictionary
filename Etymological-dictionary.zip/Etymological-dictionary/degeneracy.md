# degeneracy

## Definition
### Noun
1. The state of being degenerate (in all senses). 
2. (neuroscience) The ability of one part of the brain to take over another's function without being overexerted. 

## Synonyms
[[corruption]] | [[depravity]] | [[degeneration]]