# unconscious

## Etymology
- un- +‎ conscious


## Definition
### Adjective
1. Not awake; having no awareness. 
2. (psychology) Without directed thought or awareness. 
3. (sports) engaged in skilled performance without conscious control. 

### Noun
1. (psychology) That part of mind that is not consciously perceived. 

## Synonyms
[[cold]] | [[ignorant]] | [[innocent]] | [[stunned]] | [[subconscious]] | [[comatose]] | [[involuntary]]