# hyperbole

## Etymology
- From Latin hyperbolē, from Ancient Greek ὑπερβολή (huperbolḗ, “excess, exaggeration”), from ὑπέρ (hupér, “above”) + βάλλω (bállō, “I throw”). Doublet of hyperbola.


## Definition
### Noun
1. (uncountable, rhetoric, literature) Deliberate or unintentional overstatement, particularly extreme overstatement. 
2. (countable) An instance or example of such overstatement. 
3. (countable, obsolete) A hyperbola. 

## Synonyms
[[exaggeration]]