# imperturbable

## Etymology
- From Middle English imperturbable, from Middle French imperturbable and directly from Late Latin imperturbābilis, from im- + perturbō + -bilis. Surface analysis im- + perturbable.


## Definition
### Adjective
1. Not easily perturbed, upset or excited. 
2. Calm and collected, even under pressure. 

## Synonyms
[[composed]]