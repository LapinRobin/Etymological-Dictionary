# interchange

## Etymology
- From Old French entrechange.


## Definition
### Verb
1. (transitive) to switch (each of two things) 
2. (transitive) to mutually give and receive (something); to exchange 
3. (intransitive) to swap or change places 
4. (transitive) to alternate; to intermingle or vary 
5. (transport) To act as or carry out an interchange (noun, senses 2, 3). 

### Noun
1. An act of interchanging. 
2. A highway junction in which traffic may change from one road to another without crossing a stream of traffic. 
3. (rail transport) A connection between two or more lines, services or modes of transport; a station at which such a connection can be made. 

## Synonyms
[[change]] | [[exchange]] | [[switch]] | [[flip]] | [[alternate]] | [[transpose]] | [[flip-flop]]