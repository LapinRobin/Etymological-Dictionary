# further

## Etymology
- From Middle English further, forther, from Old English forþor, furþor (“further”, adverb), from Proto-West Germanic *furþer, from Proto-Indo-European *per- (a common preposition), equivalent to fore + -ther (a vestigial comparative ending still present in such words as other, either, whether, and, in altered form, in after); or as sometimes stated, as forth +‎ -er. Cognate with Scots forder, furder, Saterland Frisian foarder, West Frisian fierder, Dutch verder, German fürder.


## Definition
### Verb
1. (transitive) To help forward; to assist. 
2. (transitive) To encourage growth; to support progress or growth of something; to promote. 

### Adjective
1. (comparative form of far) More distant; relatively distant. 
2. More, additional. 

### Adverb
1. (comparative form of far) To, at or over a greater distance in space, time or other extent. 
2. (comparative form of far) To a greater extent or degree. 
3. Beyond what is already stated or is already the case. 
4. (conjunctive) Also; in addition; furthermore; moreover. 
5. (in the phrase 'further to') Following on (from). 

## Synonyms
[[foster]] | [[more]] | [[advance]] | [[promote]] | [[boost]] | [[encourage]] | [[far]] | [[farther]] | [[additional]]