# go under

## Definition
### Verb
1. To descend into a body of water; to founder. 
2. (idiomatic) To collapse or fail, e.g. by going bankrupt. 
3. (idiomatic) To be named; to call oneself. 
4. To enter a trance, state of hypnosis, etc. 

## Synonyms
