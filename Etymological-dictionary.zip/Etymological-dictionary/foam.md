# foam

## Etymology
- From Middle English fom, foom, from Old English fām, from Proto-West Germanic *faim, from Proto-Germanic *faimaz, from Proto-Indo-European *(s)poHy-m-os, from *(s)poH(y)- (“foam”). Cognate with German Feim (“foam”), Latin spūma (“foam”), Latin pūmex (“pumice”), Sanskrit फेन (phéna, “foam”), possibly Northern Kurdish fê (“epilepsy”).


## Definition
### Noun
1. A collection of small bubbles created when the surface of a body of water is moved by tides, wind, etc. 
2. A collection of small bubbles formed from bodily fluids such as saliva or sweat. 
3. A collection of small bubbles on the surface of a liquid that is heated, fermented or carbonated. 
4. A collection of small bubbles created by mixing soap with water. 
5. (firefighting) A collection of small bubbles formed by mixing an extinguishing agent with water, used to cover and extinguish fires. 
6. A material formed by trapping pockets of gas in a liquid or solid. 
7. (figuratively, poetic) The sea. 
8. Fury. 

### Verb
1. (intransitive) To form or emit foam. 
2. (intransitive) To spew saliva as foam; to foam at the mouth. 
3. (firefighting) To coat or cover with foam. 

## Synonyms
[[sparkle]] | [[froth]] | [[seethe]] | [[fizz]] | [[spume]]