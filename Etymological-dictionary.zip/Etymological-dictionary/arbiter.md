# arbiter

## Etymology
- From Middle English arbiter, arbytour, arbitre, from Old French arbitre, from Latin arbiter (“a witness, judge, literally one who goes to see”).


## Definition
### Noun
1. A person appointed, or chosen, by parties to determine a controversy between them; an arbitrator. 
2. (with of) A person or object having the power of judging and determining, or ordaining, without control; one whose power of deciding and governing is not limited. 
3. (electronics) A component in circuitry that allocates scarce resources. 

### Verb
1. (transitive) To act as arbiter. 

## Synonyms
