# aroma

## Etymology
- From Late Latin arōmata (“spices”) (or arōma (“spice”)), from Ancient Greek ἄρωμα (árōma, “seasoning, spicy and/or fragrant smell”).


## Definition
### Noun
1. A smell; especially a pleasant spicy or fragrant one. 

## Synonyms
[[smell]] | [[scent]] | [[odor]] | [[fragrance]] | [[odour]] | [[perfume]]