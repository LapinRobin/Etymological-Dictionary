# diploma

## Etymology
- From Latin diplōma, from Ancient Greek δίπλωμα (díplōma, “folded paper, license”), from διπλόω (diplóō, “I double, fold over”), from διπλόος (diplóos, “double”).


## Definition
### Noun
1. A document issued by an educational institution testifying that the recipient has earned a degree or has successfully completed a particular course of study. 

## Synonyms
