# blame

## Etymology
- From Middle English blame, borrowed from Old French blame, blasme, produced from the verb blasmer, which in turn is derived from Vulgar Latin *blastēmāre, present active infinitive of *blastēmō, from Ecclesiastical Latin, Late Latin blasphēmō, ultimately from Ancient Greek βλασφημέω (blasphēméō). Doublet of blaspheme. Displaced native Old English tǣling (“blame”) and tǣlan (“to blame”).

- From Middle English blamen, borrowed from Old French blasmer, from Ecclesiastical Latin blasphēmō (“to reproach, to revile”), from Ancient Greek βλασφημέω (blasphēméō). Compare blaspheme, a doublet. Overtook common use from the native wite (“to blame, accuse, reproach, suspect”) (from Middle English wīten, from Old English wītan).


## Definition
### Noun
1. Censure. 
2. Culpability for something negative or undesirable. 
3. Responsibility for something meriting censure. 
4. (computing) A source control feature that can show which user was responsible for a particular portion of the source code. 

### Verb
1. To censure (someone or something); to criticize. 
2. (obsolete) To bring into disrepute. 
3. (transitive, usually followed by "for") To assert or consider that someone is the cause of something negative; to place blame, to attribute responsibility (for something negative or for doing something negative). 

## Synonyms
[[charge]] | [[fault]] | [[pick]] | [[rap]] | [[damn]] | [[blessed]] | [[everlasting]] | [[infernal]] | [[blasted]] | [[damned]] | [[cursed]]