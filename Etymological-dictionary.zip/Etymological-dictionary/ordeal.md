# ordeal

## Etymology
- From Middle English ordel, ordal, from Medieval Latin ordālium or inherited from its source Old English ordēl, ordāl (“ordeal, judgement”), from Proto-West Germanic *uʀdailī (“judgement”, literally “an out-dealing”), from *uʀdailijan (“to deal out; dispense”), equivalent to or- +‎ deal.


## Definition
### Noun
1. A painful or trying experience. 
2. A trial in which the accused was subjected to a dangerous test (such as ducking in water), divine authority deciding the guilt of the accused. 
3. The poisonous ordeal bean or Calabar bean 

## Synonyms
