# dues

## Definition
### Noun
1. Membership fees. 

## Synonyms
