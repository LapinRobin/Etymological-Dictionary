# verse

## Etymology
- From Middle English vers, from a mixture of Old English fers and Old French vers; both from Latin versus (“a line in writing, and in poetry a verse; (originally) row, furrow”), from vertō (“to turn around”).

- Back-formation from versus, misconstrued as a third-person singular verb verses.


## Definition
### Noun
1. A poetic form with regular meter and a fixed rhyme scheme. 
2. Poetic form in general. 
3. One of several similar units of a song, consisting of several lines, generally rhymed. 
4. A small section of a holy book (Bible, Quran etc.) 
5. (music) A portion of an anthem to be performed by a single voice to each part. 

### Verb
1. (obsolete) To compose verses. 
2. (transitive) To tell in verse, or poetry. 
3. (transitive, figuratively) to educate about, to teach about. 
4. (colloquial, sometimes proscribed) To oppose, to compete against, especially in a video game. 

## Synonyms
[[rhyme]] | [[poetry]]