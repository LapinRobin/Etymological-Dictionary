# vertigo

## Etymology
- Borrowed from Latin vertīgō.


## Definition
### Noun
1. A sensation of whirling and loss of balance, caused by looking down from a great height or by disease affecting the inner ear. 
2. A disordered or imbalanced state of mind or things analogous to physical vertigo; mental giddiness or dizziness. 
3. The act of whirling round and round; rapid rotation. 

## Synonyms
