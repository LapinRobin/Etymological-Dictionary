# acme

## Etymology
- Directly borrowed from Ancient Greek ἀκμή (akmḗ, “point, high point”).


## Definition
### Noun
1. A high point: the highest point of any range, the most developed stage of any process, or the culmination of any field or historical period. 
2. A paragon: a person or thing representing such a high point. 
3. (rare) Full bloom or reproductive maturity. 
4. (medicine) Synonym of crisis, the decisive moment in the course of an illness. 
5. (fiction) A generic or monopoly company. 
6. A village in Alberta, Canada. 
7. An unincorporated community in Hamilton Township, Jackson County, Indiana, United States. 
8. An unincorporated community in Dickinson County, Kansas, United States. 
9. An unincorporated community in Concordia Parish, Louisiana, United States. 
10. An unincorporated community in Columbus County, North Carolina, United States. 
11. An unincorporated community in Westmoreland County and Fayette County, Pennsylvania, United States. 
12. A ghost town in Oklahoma, United States. 
13. A ghost town in Texas, United States. 
14. A census-designated place in Washington, United States. 
15. An unincorporated community in Kanawha County, West Virginia, United States. 
16. A 29° trapezoidal threading used for various fittings and adapters. 
17. Alternative letter-case form of Acme, particularly as a threading format.  
18. Alternative letter-case form of Acme, particularly as a generic company name.  

## Synonyms
[[top]] | [[peak]] | [[apex]] | [[pinnacle]] | [[summit]] | [[height]] | [[superlative]] | [[vertex]] | [[elevation]]