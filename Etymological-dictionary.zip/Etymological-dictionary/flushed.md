# flushed

## Definition
### Adjective
1. Red in the face because of embarrassment, exertion, etc. 

## Synonyms
[[red]] | [[healthy]] | [[crimson]] | [[rosy]] | [[colorful]] | [[colored]]