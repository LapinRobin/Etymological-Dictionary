# wedlock

## Etymology
- From Middle English wedlok, wedlocke (“wedlock, marriage, matrimony”), from Old English wedlāc (“marriage vow, pledge, plighted troth, wedlock”); synchronically analyzable as wed +‎ -lock.


## Definition
### Noun
1. The state of being married. 
2. (obsolete) A wife; a married woman. 

## Synonyms
[[marriage]] | [[union]]