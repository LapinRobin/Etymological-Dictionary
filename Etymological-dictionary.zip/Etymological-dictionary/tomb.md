# tomb

## Etymology
- From Middle English tombe, toumbe, borrowed from Old French tombe, from Latin tumba from Ancient Greek τύμβος (túmbos, “a sepulchral mound, tomb, grave”), probably from Proto-Indo-European *tewh₂- (“to swell”).


## Definition
### Noun
1. A small building (or "vault") for the remains of the dead, with walls, a roof, and (if it is to be used for more than one corpse) a door. It may be partly or wholly in the ground (except for its entrance) in a cemetery, or it may be inside a church proper or in its crypt. Single tombs may be permanently sealed; those for families (or other groups) have doors for access whenever needed. 
2. A pit in which the dead body of a human being is deposited; a grave. 
3. One who keeps secrets. 
4. A surname transferred from the given name. 

### Verb
1. (transitive) To bury. 

## Synonyms
[[grave]]