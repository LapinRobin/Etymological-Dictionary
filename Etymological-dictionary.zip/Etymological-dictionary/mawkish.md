# mawkish

## Etymology
- From mawk +‎ -ish.


## Definition
### Adjective
1. Excessively or falsely sentimental; showing a sickly excess of sentiment. 
2. (archaic or dialectal) Feeling sick, queasy. 
3. (archaic) Sickening or insipid in taste or smell. 

## Synonyms
[[maudlin]] | [[sentimental]] | [[emotional]] | [[mushy]]