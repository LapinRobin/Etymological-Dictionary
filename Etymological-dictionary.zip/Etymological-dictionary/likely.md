# likely

## Etymology
- From Middle English likely, likly, lykly, likliche, from Old English ġelīclīċ (“likely”) and Old Norse líkligr (“likely”), both from Proto-Germanic *līkalīkaz, equivalent to like +‎ -ly.

- From Middle English likely, likly, lykly, likliche, from Old English ġelīclīċe (“equally”) and Old Norse líkliga, glíkliga (“likely”), both from Proto-Germanic *līkalīka, equivalent to like +‎ -ly.


## Definition
### Adjective
1. probable; having a greater-than-even chance of occurring 
2. (as predicate, followed by to and infinitive) Reasonably to be expected; apparently destined, probable 
3. appropriate, suitable; believable; having a good potential 
4. plausible; within the realm of credibility 
5. promising; apt to achieve success or yield a desired outcome 
6. attractive; pleasant 
7. (obsolete) Similar; like; alike. 

### Noun
1. Something or somebody considered likely. 
2. A surname. 
3. A census-designated place in Modoc County, California, United States. 

### Adverb
1. (obsolete) Similarly. 
2. Probably. 

## Synonyms
[[potential]] | [[prospective]] | [[plausible]] | [[credible]] | [[probably]] | [[presumptive]] | [[probable]] | [[promising]] | [[expected]]