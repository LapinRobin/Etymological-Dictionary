# slaughter

## Etymology
- From Middle English slaughter, from Old Norse *slahtr, later sláttr, from Proto-Germanic *slahtrą, from Proto-Germanic *slahaną. Equivalent to slay +‎ -ter (as in laughter). Eventually derived from Proto-Indo-European *slak- (“to hit, strike, throw”). Related with Dutch slachten, German schlachten (both “to slaughter”).


## Definition
### Noun
1. (uncountable) The killing of animals, generally for food. 
2. A massacre; the killing of a large number of people. 
3. (rare) A mass destruction of non-living things. 
4. A rout or decisive defeat. 
5. A group of iguanas. 
6. A surname. 
7. A town in Louisiana. 

### Verb
1. (transitive) To butcher animals, generally for food. 
2. (transitive, intransitive) To massacre people in large numbers. 
3. (transitive) To kill someone or something, especially in a particularly brutal manner. 

## Synonyms
[[debacle]] | [[carnage]] | [[massacre]] | [[butcher]]