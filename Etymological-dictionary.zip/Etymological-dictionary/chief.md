# chief

## Etymology
- From Middle English cheef, chef, from Old French chef, chief (“leader”), from Vulgar Latin capus (from which also captain, chieftain), from Latin caput (“head”) (English cap (“head covering”)), from Proto-Indo-European *kauput- (English head). Doublet of chef.


## Definition
### Noun
1. A leader or head of a group of people, organisation, etc. 
2. (heraldry) The top part of a shield or escutcheon; more specifically, an ordinary consisting of the upper part of the field cut off by a horizontal line, generally occupying the top third. 
3. The principal part or top of anything. 
4. (sometimes ironic) An informal term of address. 
5. (US, Canada, offensive) An informal term of address for a Native American or First Nations man. 

### Adjective
1. Primary; principal. 
2. (Scotland) Intimate, friendly. 

### Verb
1. (US, slang) To smoke cannabis. 

## Synonyms
[[head]] | [[top]] | [[principal]] | [[arch]] | [[boss]] | [[main]] | [[primary]] | [[gaffer]] | [[foreman]] | [[honcho]]