# ruddy

## Etymology
- From Middle English ruddy, rody, rudi, from Old English rudiġ (“reddish; ruddy”), from rudu (“redness”), equivalent to rud (“redness”) +‎ -y. Compare Icelandic roði (“redness”).


## Definition
### Adjective
1. Reddish in color, especially of the face, fire, or sky. 
2. (Britain, Australia, slang, not comparable) A mild intensifier, expressing irritation. 

### Adverb
1. (Britain, slang) A mild intensifier, expressing irritation. 

### Noun
1. (informal) A ruddy duck. 
2. (informal) A ruddy ground dove. 
3. A surname. 

### Verb
1. (transitive) To make reddish in colour. 

## Synonyms
[[red]] | [[cherry]] | [[sanguine]] | [[healthy]] | [[ruby]] | [[crimson]] | [[scarlet]] | [[cerise]] | [[carmine]] | [[colored]]