# relax

## Etymology
- From Middle English relaxen, from Old French relaxer, from Latin relaxāre (“relax, loosen, open”), from re- (“back”) + laxāre (“loosen”), from laxus (“loose, free”).


## Definition
### Verb
1. (transitive) To calm down. 
2. (transitive) To make something loose. 
3. (intransitive) To become loose. 
4. (transitive) To make something less severe or tense. 
5. (intransitive) To become less severe or tense. 
6. (transitive) To make something (such as codes and regulations) more lenient. 
7. (intransitive, of codes and regulations) To become more lenient. 
8. (transitive) To relieve (something) from stress. 
9. (transitive, dated) To relieve from constipation; to loosen; to open. 

## Synonyms
[[loose]] | [[unwind]] | [[unbend]] | [[loosen]]