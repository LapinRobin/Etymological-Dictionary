# backpack

## Etymology
- From back +‎ pack.


## Definition
### Noun
1. A knapsack, sometimes mounted on a light frame, but always supported by straps, worn on a person’s back for the purpose of carrying things, especially when hiking, or on a student's back when carrying books. 
2. A similarly placed item containing a parachute or other life-support equipment. 

### Verb
1. (intransitive) To hike and camp overnight in backcountry with one's gear carried in a backpack. 
2. (intransitive) To engage in low-cost, generally urban, travel with minimal luggage and frugal accommodation. 
3. (transitive, rare) To place or carry (an item or items) in a backpack. 

## Synonyms
[[pack]]