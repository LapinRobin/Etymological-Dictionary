# dandle

## Etymology
- Compare Scots dandill (“to dander; go about idly; move uncertainly; trifle”), English dialectal dander (“to wander about; talk incoherently; rave”), Middle Dutch dantinnen (“to trifle”) (from French dandiner (“to swing; waddle”)), German dändeln, tändeln (“to trifle, dandle”), Middle Dutch and Provincial German danten (“to do foolish things; trifle”), German Tand (“trifle, prattle”).


## Definition
### Verb
1. (transitive) To move up and down on one's knee or in one's arms, in affectionate play, usually said of a child. 
2. (transitive) To treat with fondness or affection, as if a child; to pet. 
3. (transitive, obsolete) To play with; to wheedle. 

## Synonyms
