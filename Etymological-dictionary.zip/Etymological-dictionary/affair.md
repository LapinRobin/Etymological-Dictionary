# affair

## Etymology
- From Middle English afere, affere, from Old French afaire, from a- + faire (“to do”), from Latin ad- + facere (“to do”). See fact, and compare ado.


## Definition
### Noun
1. (often in the plural) Something which is done or is to be done; business of any kind, commercial, professional, or public. 
2. Any proceeding or action which it is wished to refer to or characterize vaguely. 
3. (military) An action or engagement not of sufficient magnitude to be called a battle. 
4. A material object (vaguely designated). 
5. An adulterous relationship (from affaire de cœur, affair of the heart). 
6. A romantic relationship with someone who is not one's regular partner (boyfriend, girlfriend). 
7. A person with whom someone has an adulterous relationship. 
8. A party or social gathering, especially of a formal nature. 
9. (slang, now rare) The (male or female) genitals. 

## Synonyms
[[matter]] | [[liaison]] | [[occasion]] | [[thing]] | [[intimacy]] | [[amour]] | [[involvement]]