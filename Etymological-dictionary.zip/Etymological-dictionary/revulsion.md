# revulsion

## Etymology
- French révulsion, Latin revulsio.


## Definition
### Noun
1. Abhorrence, a sense of loathing, intense aversion, repugnance, repulsion, horror. 
2. A sudden violent feeling of disgust. 
3. (medicine) The treatment of one diseased area by acting elsewhere; counterirritation. 
4. (obsolete) A strong pulling or drawing back; withdrawal. 
5. (obsolete) A sudden reaction; a sudden and complete change of the feelings. 

## Synonyms
[[horror]]