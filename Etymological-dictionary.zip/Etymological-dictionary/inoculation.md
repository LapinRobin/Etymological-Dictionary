# inoculation

## Etymology
- From Latin inoculātio. Equivalent to inoculate +‎ -ion.


## Definition
### Noun
1. (immunology) The introduction of an antigenic substance or vaccine into the body to produce immunity to a specific disease. 
2. (microbiology) The introduction of a microorganism into a culture medium. 
3. The insertion of the buds of one plant into another; grafting. 
4. An inoculum; that which is inoculated. 

## Synonyms
