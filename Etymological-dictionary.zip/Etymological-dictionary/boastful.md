# boastful

## Etymology
- From Middle English bostful, equivalent to boast +‎ -ful.


## Definition
### Adjective
1. Tending to boast or brag. 

## Synonyms
[[big]] | [[proud]] | [[braggart]]