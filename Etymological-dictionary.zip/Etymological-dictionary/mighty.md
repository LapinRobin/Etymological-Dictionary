# mighty

## Etymology
- From Middle English mighty, mightie, mighti, myghty, miȝty, maȝty, from Old English mihtiġ, mehtiġ, meahtiġ, mæhtiġ (“mighty”), from Proto-West Germanic *mahtīg (“mighty”), from Proto-Germanic *mahtīgaz (“mighty”), equivalent to might +‎ -y.


## Definition
### Noun
1. (obsolete, rare) A warrior of great strength and courage. 

### Adjective
1. Very strong; possessing might. 
2. Very heavy and powerful. 
3. (colloquial) Very large; hefty. 
4. Accomplished by might; hence, extraordinary; wonderful. 
5. (informal) Excellent, extremely good. 

### Adverb
1. (colloquial, dialect) Very; to a high degree. 

## Synonyms
[[right]] | [[powerful]]