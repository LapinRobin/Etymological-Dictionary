# oppression

## Etymology
- From Middle English oppression, from Old French oppression, from Latin oppressiō (“a pressing down, violence, oppression”), from opprimō; see oppress.


## Definition
### Noun
1. The exercise of authority or power in a burdensome, cruel, or unjust manner. 
2. The act of oppressing, or the state of being oppressed. 
3. A feeling of being oppressed. 

## Synonyms
[[subjugation]]