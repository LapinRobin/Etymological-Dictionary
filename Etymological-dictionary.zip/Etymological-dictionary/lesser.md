# lesser

## Etymology
- less +‎ -er


## Definition
### Adjective
1. Of two (or, rarely, more than two) things: the smaller in size (littler), in value, in importance etc. 

### Noun
1. a thing that is of smaller size, value, importance etc. 
2. A surname. 

## Synonyms
[[little]] | [[small]]