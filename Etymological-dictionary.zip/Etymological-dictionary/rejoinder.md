# rejoinder

## Etymology
- From Middle French rejoindre, with infinitive used as noun frequent in Law French.


## Definition
### Noun
1. (law) The defendant's answer to the replication. 
2. A response that answers another response. 
3. A quick response that involves disagreement or is witty, especially an answer to a question. 
4. (US patent law) Re-insertion, typically after allowance of a patent application, of patent claims that had been withdrawn from examination under a restriction requirement. 

### Verb
1. (intransitive) To issue a rejoinder. 
2. (transitive) To say as a rejoinder. 

## Synonyms
[[return]] | [[retort]] | [[riposte]] | [[comeback]]