# point out

## Etymology
- From point and out. Instead of pointing to a particular thing, the term implies pointing to one particular thing out of several similar things, or to a thing in a scene where it might not be readily seen.


## Definition
### Verb
1. (transitive, idiomatic) To identify among a group of similar subjects, or in a scene where the subject might not be readily seen or noticed, with a gesture of the body. 
2. (figuratively, idiomatic) To tell, remind, indicate. 

## Synonyms
