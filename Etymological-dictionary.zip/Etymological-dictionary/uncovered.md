# uncovered

## Etymology
- uncovered

- un- +‎ covered


## Definition
### Adjective
1. Not covered or protected from the weather, etc. 
2. Lacking insurance or security. 
3. Bareheaded. 

## Synonyms
[[bare]] | [[bald]] | [[exposed]]