# significance

## Etymology
- Inherited from Middle English significaunce, from Middle French significance, from Old French significance, from Latin significantia. Doublet of signifiance.


## Definition
### Noun
1. The extent to which something matters; importance 
2. Meaning. 

## Synonyms
[[implication]] | [[meaning]] | [[import]]