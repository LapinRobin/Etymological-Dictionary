# illegitimate

## Etymology
- Based on Latin illegitimus; equivalent to il- +‎ legitimate.


## Definition
### Adjective
1. Not conforming to known principles, or established or accepted rules or standards. 
2. Not in accordance with the law. 
3. Born to unmarried parents. 
4. (dated) Having a child or children with a person to whom one is not married. 
5. Not correctly deduced. 
6. Not authorized by good usage; not genuine. 
7. (botany) Involving the fertilization of pistils by stamens not of their own length, in heterogonously dimorphic and trimorphic flowers. 

### Noun
1. A person born to unmarried parents. 

### Verb
1. (transitive) To make illegitimate. 

## Synonyms
[[base]] | [[spurious]] | [[illicit]] | [[outlaw]] | [[illegal]]