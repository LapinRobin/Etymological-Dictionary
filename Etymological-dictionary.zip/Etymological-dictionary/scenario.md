# scenario

## Etymology
- From Italian scenario (a derivation of scena (“scene”)), from Latin scaena. See scene, scenary.


## Definition
### Noun
1. An outline of the plot of a dramatic or literary work. 
2. A screenplay itself, or an outline or a treatment of it. 
3. An outline or model of an expected or supposed sequence of events. 

## Synonyms
