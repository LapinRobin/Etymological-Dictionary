# squawk

## Etymology
- First attested in the from 1821. Unknown, but probably of imitative origin (compare dialectal Italian squacco (“small-crested heron”)).


## Definition
### Noun
1. A shrill noise, especially made by a voice or bird; a yell, scream, or call. 
2. (aviation) A four-digit transponder code used by aircraft for identification or transmission of emergency signals. 
3. (informal) A complaint or objection. 
4. (aviation) An issue or complaint related to aircraft maintenance. 
5. The American night heron. 
6. (programming, informal) A warning message indicating a possible error. 

### Verb
1. To make a squawking noise; to yell, scream, or call out shrilly. 
2. (slang, intransitive) To speak out; to protest. 
3. (slang, intransitive) To report an infraction; to rat on or tattle; to disclose a secret. 
4. (programming, intransitive, informal) To produce a warning message, indicating a possible error. 
5. (aviation) To set or transmit a four-digit transponder code. (Normally followed by the specific code in question.) 
6. (US, slang, dated) To back out in a mean way. 

## Synonyms
[[kick]] | [[beef]] | [[grouse]] | [[holler]] | [[gripe]] | [[screech]]