# zone

## Etymology
- From Latin zōna, from Ancient Greek ζώνη (zṓnē, “girdle, belt”).


## Definition
### Noun
1. (geography, now rare) Each of the five regions of the earth's surface into which it was divided by climatic differences, namely the torrid zone (between the tropics), two temperate zones (between the tropics and the polar circles), and two frigid zones (within the polar circles). 
2. Any given region or area of the world. 
3. A given area distinguished on the basis of a particular characteristic, use, restriction, etc. 
4. A band or area of growth encircling anything. 
5. A band or stripe extending around a body. 
6. (crystallography) A series of planes having mutually parallel intersections. 
7. (baseball, informal) The strike zone. 
8. (ice hockey) Every of the three parts of an ice rink, divided by two blue lines. 
9. (handball) A semicircular area in front of each goal. 
10. (chiefly sports) A high-performance phase or period. 
11. (basketball, American football) A defensive scheme where defenders guard a particular area of the court or field, as opposed to a particular opposing player. 
12. (networking) That collection of a domain's DNS resource records, the domain and its subdomains, that are not delegated to another authority. 
13. (networking, dated) A logical group of network devices on AppleTalk (an obsolete networking protocol). 
14. (now literary) A belt or girdle. 
15. (geometry) The curved surface of a frustum of a sphere, the portion of surface of a sphere delimited by parallel planes. 
16. (geometry, loosely, perhaps by meronymy) A frustum of a sphere. 
17. A circuit; a circumference. 

### Verb
1. (transitive) To divide into or assign to sections or areas. 
2. (transitive) To define the property use classification of (an area). 
3. (intransitive, slang) To enter a daydream state temporarily, for instance as a result of boredom, fatigue, or intoxication; to doze off. 
4. (transitive, archaic, poetic) To girdle or encircle. 

## Synonyms
[[district]] | [[partition]]