# farmer

## Etymology
- From Middle English fermour (“a steward, bailliff, collector of taxes”),  from Old French fermier (“a farmer, a lessee, husbandman, bailliff”), from Medieval Latin firmarius (“one to whom land is rented, a collector of taxes, deputy”), from firma; equivalent to farm +‎ -er. Compare Old English feormere (“a purveyor of a guild, a supplier of food, a grocer, farmer”). More at farm.


## Definition
### Noun
1. A person who works the land and/or who keeps livestock, especially on a farm. 
2. (historical) One who takes taxes, customs, excise, or other duties, to collect for a certain rate per cent. 
3. (historical, mining) The lord of the field, or one who farms the lot and cope of the crown. 
4. A surname. 
5. (NATO code name) the Soviet MiG 19 aircraft. 
6. An unincorporated community in North Carolina, United States. 
7. A town in South Dakota, United States. 

## Synonyms
