# basket

## Etymology
- From Middle English basket, from Anglo-Norman bascat, of obscure origin. 


## Definition
### Noun
1. A lightweight container, generally round, open at the top, and tapering toward the bottom. 
2. A wire or plastic container similar in shape to a basket, used for carrying articles for purchase in a shop. 
3. (Internet) In an online shop, a listing of a customer's chosen items before they are ordered. 
4. (figuratively) A set or collection of intangible things. 
5. (basketball) A circular hoop, from which a net is suspended, which is the goal through which the players try to throw the ball. 
6. (basketball) The act of putting the ball through the basket, thereby scoring points. 
7. (uncountable) The game of basketball. 
8. A dance movement in some line dances, where men put their arms round the women's lower backs, and the women put their arms over the men's shoulders, and the group (usually of four, any more is difficult) spins round, which should result in the women's feet leaving the ground. 
9. (LGBT, slang) The male genitalia and region surrounding it. 
10. (slang) The bulge of the male genitals seen through clothing. 
11. (obsolete) In a stage-coach, two outside seats facing each other. 
12. (archaic) A protection for the hand on a sword or a singlestick; a guard of a bladed weapon. 
13. A singlestick with a basket hilt. 
14. (ballooning) The gondola or wicker basket suspended from the balloon, in which the pilot and passengers travel. 
15. (architecture) The bell or vase of the Corinthian capital. 
16. (informal, euphemistic) Bastard. 
17. (military, aircraft) A drogue (or para-drogue) in the probe-and-drogue refueling method 

### Verb
1. (transitive) To place in a basket or baskets. 
2. (transitive, publishing) To cross-collateralize the royalty advances for multiple works so that the creator is not paid until all of those works have achieved a certain level of success. 

## Synonyms
[[hoop]]