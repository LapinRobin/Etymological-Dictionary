# coming

## Etymology
- From Middle English cominge, comynge, comande, from Old English cumende, from Proto-Germanic *kwemandz, present participle of Proto-Germanic *kwemaną (“to come”), equivalent to come +‎ -ing (present participle ending). Cognate with Dutch komend (“coming”), German kommend (“coming”), Swedish kommande (“coming”), Icelandic komandi (“coming”).

- From Middle English coming, commyng, cumming, equivalent to come +‎ -ing (gerundive ending).


## Definition
### Noun
1. The act of arriving; an arrival. 

### Adjective
1. Approaching; of the future, especially the near future; the next. 
2. Newly in fashion; advancing into maturity or achievement. 
3. (obsolete) Ready to come; complaisant; fond. 

## Synonyms
[[approach]] | [[advent]] | [[forthcoming]] | [[climax]] | [[upcoming]] | [[orgasm]]