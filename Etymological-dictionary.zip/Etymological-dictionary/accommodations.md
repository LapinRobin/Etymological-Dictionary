# accommodations

## Definition
### Noun
1. (chiefly Britain, usually a mass noun) Lodging in a dwelling or similar living quarters afforded to travellers in hotels or on cruise ships, or prisoners, etc. 
2. (countable, uncountable, followed by to) The act of fitting or adapting, or the state of being fitted or adapted; adaptation; adjustment. 
3. (countable, uncountable) A convenience, a fitting, something satisfying a need. 
4. (countable, physiology, biology) The adaptation or adjustment of an organism, organ, or part. 
5. (countable, medicine) The adjustment of the eye to a change of the distance from an observed object. 
6. (countable, uncountable) Willingness to accommodate; obligingness. 
7. (countable, uncountable) Adjustment of differences; state of agreement; reconciliation; settlement; compromise. 
8. (countable) The application of a writer's language, on the ground of analogy, to something not originally referred to or intended. 
9. (countable, commerce) A loan of money. 
10. (countable, commerce) An accommodation bill or note. 
11. (countable, law) An offer of substitute goods to fulfill a contract, which will bind the purchaser if accepted. 
12. (theology) An adaptation or method of interpretation which explains the special form in which the revelation is presented as unessential to its contents, or rather as often adopted by way of compromise with human ignorance or weakness. 
13. (countable, geology) The place where sediments can make, or have made, a sedimentation. 
14. (linguistics, sociolinguistics) Modification(s) to make one's way of communicating similar to others involved in a conversation or discourse. 

## Synonyms
