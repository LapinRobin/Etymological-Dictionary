# puke

## Etymology
- Probably imitative; or, alternatively from Proto-Germanic *pukaną (“to spit, puff”), from Proto-Indo-European *bew- (“to blow, swell”). If so, then cognate with German pfauchen, fauchen (“to hiss, spit”). Compare also Dutch spugen (“to spit, spit up”), German spucken (“to spit, puke, throw up”), Old English spīwan (“to vomit, spit”). More at spew.

- This etymology is incomplete. You can help Wiktionary by elaborating on the origins of this term.


## Definition
### Noun
1. (colloquial, uncountable) vomit. 
2. (colloquial, countable) A drug that induces vomiting. 
3. (colloquial, countable) A worthless, despicable person. 
4. (US, slang, derogatory, countable) A person from Missouri. 
5. A fine grade of woolen cloth. 
6. A very dark, dull, brownish-red color. 

### Verb
1. (colloquial, transitive, intransitive) To vomit; to throw up; to eject from the stomach. 
2. (intransitive, finance, slang) To sell securities or investments at a loss, often under duress or pressure, in order to satisfy liquidity or margin requirements, or out of a desire to exit a deteriorating market. 

## Synonyms
[[cat]] | [[cast]] | [[rat]] | [[sick]] | [[bum]] | [[chuck]] | [[skunk]] | [[spew]] | [[crumb]] | [[regurgitate]] | [[vomit]] | [[retch]] | [[honk]] | [[barf]] | [[lowlife]]