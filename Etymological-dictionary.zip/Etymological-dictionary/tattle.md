# tattle

## Etymology
- From Middle Dutch tatelen, tateren (“to babble, chatter”) (modern Dutch tatelen, tateren (“to talk, chatter”)), originally imitative. The word is cognate with Saterland Frisian tätelje (“to talk nonsense, babble”), Middle Low German tāteren, tadderen (“to babble, chatter”) (whence modern German Low German tatern (“to chatter”)), Low German tateln, täteln (“to cackle, gabble”). Compare also Middle English dadel, dadull (“tattling, gossip”), and its alteration twaddle.


## Definition
### Verb
1. (intransitive) To chatter; to gossip. 
2. (intransitive, Canada, US, derogatory) Often said of children: to report incriminating information about another person, or a person's wrongdoing; to tell on somebody. 
3. (intransitive, obsolete) To speak like a baby or young child; to babble, to prattle; to speak haltingly; to stutter. 

### Noun
1. (countable) A tattletale. 
2. (countable, Canada, US, derogatory) Often said of children: a piece of incriminating information or an account of wrongdoing that is said about another person. 
3. (uncountable) Idle talk; gossip; (countable) an instance of such talk or gossip. 

## Synonyms
[[talk]] | [[sing]] | [[palaver]] | [[babble]] | [[peach]] | [[chatter]] | [[telling]] | [[prattle]] | [[prate]] | [[twaddle]] | [[clack]]