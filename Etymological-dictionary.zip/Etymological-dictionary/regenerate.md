# regenerate

## Etymology
- From Latin regenerātus, perfect passive participle of regenerō, from re- +‎ generō, from genus, generis (“descent, origin, birth”) +‎ -ō.


## Definition
### Verb
1. (transitive) To construct or create anew, especially in an improved manner. 
2. (transitive) To revitalize. 
3. (transitive, biology) To replace lost or damaged tissue. 
4. (intransitive) To become reconstructed. 
5. (intransitive) To undergo a spiritual rebirth. 
6. (intransitive) Of a water softener: to flush out the minerals extracted from the water supply. 

### Adjective
1. Spiritually reborn. 
2. (obsolete) Reproduced. 

### Noun
1. One who is spiritually reborn. 

## Synonyms
[[restore]] | [[reform]] | [[renew]]