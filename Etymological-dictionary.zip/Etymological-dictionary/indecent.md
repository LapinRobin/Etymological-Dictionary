# indecent

## Etymology
- in- +‎ decent


## Definition
### Adjective
1. offensive to good taste 
2. not in keeping with conventional moral values; improper, immodest or unseemly 
3. (criminal law) Generally unacceptable for public broadcasting but not legally obscene. 

## Synonyms
[[gross]] | [[crude]] | [[coarse]] | [[obscene]] | [[vulgar]] | [[untoward]] | [[improper]] | [[earthy]] | [[unseemly]] | [[unbecoming]]