# decoy

## Etymology
- From Dutch de +‎ kooi, literally "the cage". Possibly related to verb coy (which itself may have been influenced by decoy).


## Definition
### Noun
1. A person or object meant to lure somebody into danger. 
2. A real or fake animal used by hunters to lure game. 
3. Deceptive military device used to draw enemy attention or fire away from a more important target. 

### Verb
1. (transitive) To lead into danger by artifice; to lure into a net or snare; to entrap. 
2. (intransitive) To act as, or use, a decoy. 

## Synonyms
[[lure]] | [[bait]]