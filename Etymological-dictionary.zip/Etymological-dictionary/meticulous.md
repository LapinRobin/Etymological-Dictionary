# meticulous

## Etymology
- Learned borrowing from Latin meticulōsus (“full of fear, timid, fearful, terrible, frightful”), from metus (“fear”) and -culōsus, extracted from perīculōsus (“perilous”). Sense of “characterized by very precise, conscientious attention to details” is a semantic loan from French méticuleux.


## Definition
### Adjective
1. Characterized by very precise, conscientious attention to details. 
2. (archaic) Timid, fearful, overly cautious. 

## Synonyms
[[precise]] | [[fastidious]] | [[punctilious]]