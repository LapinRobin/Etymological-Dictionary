# localize

## Etymology
- From local +‎ -ize. Compare French localiser.


## Definition
### Verb
1. (transitive) To make local; to fix in, or assign to, a definite place. 
2. (software engineering, marketing) To adapt a product for use in a particular country or region, typically by translating text into the language of that country and modifying currencies, date formats, etc. 
3. (translation studies, chiefly software, marketing) To adapt translated text to fit a local culture; to domesticate. 
4. To determine where something takes place or is to be found. 

## Synonyms
[[set]] | [[place]]