# exponent

## Etymology
- From Latin expōnēns, present participle of expōnō (“to expose; to exhibit, display, set out; to explain”), from ex- (“out, away”) + pōnō (“to lay, place, put”).


## Definition
### Noun
1. One who expounds, represents or advocates. 
2. (mathematics) The number by which a value (called the base) is said to be raised to a power in exponentiation: for example, the 3 in 2³=8. 
3. (mathematics, obsolete) The degree to which the root of a radicand is found, for example, the 2 in ^(2])√=b. 
4. (linguistics) A manifestation of a morphosyntactic property. 
5. (computing) The part of a floating-point number that represents its exponent value. 

## Synonyms
[[power]] | [[advocate]] | [[index]] | [[proponent]]