# mourning

## Definition
### Noun
1. The act of expressing or feeling sorrow or regret; lamentation. 
2. Feeling or expressing sorrow over someone's death. 
3. The traditional clothes worn by those who mourn (in Western societies, typically coloured black). 
4. Drapes or coverings associated with mourning. 
5. A surname. 

## Synonyms
[[bereft]] | [[bereavement]]