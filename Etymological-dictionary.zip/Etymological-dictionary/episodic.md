# episodic

## Etymology
- episode +‎ -ic. Compare French épisodique.


## Definition
### Adjective
1. relating to an episode 
2. sporadic, happening infrequently and irregularly 
3. (literature) made up a sequence of seemingly unconnected episodes 

## Synonyms
[[temporary]] | [[unpredictable]] | [[occasional]]