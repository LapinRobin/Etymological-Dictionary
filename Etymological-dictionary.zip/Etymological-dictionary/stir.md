# stir

## Etymology
- From Middle English stiren, sturien, from Old English styrian (“to be in motion, move, agitate, stir, disturb, trouble”), from Proto-Germanic *sturiz (“turmoil, noise, confusion”), related to Proto-West Germanic *staurijan (“to destroy, disturb”). Cognate with Old Norse styrr (“turmoil, noise, confusion”), German stören (“to disturb”), Dutch storen (“to disturb”).

- From Romani stariben (“prison”), nominalisation of (a)star (“seize”), causative of ast (“remain”), probably from Sanskrit आतिष्ठति (ātiṣṭhati, “stand or remain by”), from तिष्ठति (tiṣṭhati, “stand”).


## Definition
### Verb
1. (transitive) To disturb the relative position of the particles of (a liquid or similar) by passing an object through it. 
2. (transitive) To disturb the content of (a container) by passing an object through it. 
3. (transitive) To incite to action. 
4. (transitive) To bring into debate; to agitate. 
5. (transitive, obsolete) To disturb, to disrupt. 
6. (transitive, dated) To change the place of in any manner; to move. 
7. (intransitive) To begin to move, especially gently, from a still or unmoving position. 
8. (intransitive) Of a feeling or emotion: to rise, begin to be felt. 
9. (intransitive) To be in motion; to be active or bustling; to exert or busy oneself. 
10. (intransitive) To rise from sleep or unconsciousness. 

### Noun
1. The act or result of stirring (moving around the particles of a liquid etc.) 
2. agitation; tumult; bustle; noise or various movements. 
3. Public disturbance or commotion; tumultuous disorder; seditious uproar. 
4. Agitation of thoughts; conflicting passions. 
5. (slang) Jail; prison. 
6. (finance) Acronym of short-term interest rate, often referring to a short-term interest rate future or option. 

## Synonyms
[[shift]] | [[raise]] | [[touch]] | [[invoke]] | [[shake]] | [[hustle]] | [[turmoil]] | [[fuss]] | [[conjure]] | [[toss]] | [[commotion]] | [[agitate]] | [[ado]] | [[arouse]] | [[bustle]] | [[flurry]] | [[stimulate]] | [[disruption]] | [[budge]] | [[excite]] | [[disturbance]] | [[bring up]] | [[put forward]]