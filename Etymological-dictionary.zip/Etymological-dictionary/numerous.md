# numerous

## Etymology
- From Middle English numerous from Latin numerōsus (“numerous, abundant; harmonious”), from numerus (“number”). Doublet of numerose. Analyzeable as numero- +‎ -ous.


## Definition
### Adjective
1. Indefinitely large numerically, many. 

## Synonyms
[[many]]