# cage

## Etymology
- From Middle English cage, from Old French cage, from Latin cavea. Doublet of cadge and related to jail.


## Definition
### Noun
1. An enclosure made of bars, normally to hold animals. 
2. The passenger compartment of a lift. 
3. (field hockey or ice hockey, water polo) The goal. 
4. (US, derogatory, slang) An automobile. 
5. (figuratively) Something that hinders freedom. 
6. (athletics) The area from which competitors throw a discus or hammer. 
7. An outer framework of timber, enclosing something within it. 
8. (engineering) A skeleton frame to limit the motion of a loose piece, such as a ball valve. 
9. A wirework strainer, used in connection with pumps and pipes. 
10. (mining) The drum on which the rope is wound in a hoisting whim. 
11. (baseball) The catcher's wire mask. 
12. (graph theory) A regular graph that has as few vertices as possible for its girth. 
13. In killer sudoku puzzles, an irregularly-shaped group of cells that must contain a set of unique digits adding up to a certain total, in addition to the usual constraints of sudoku. 
14. A surname from French. 

### Verb
1. To confine in a cage; to put into and keep in a cage. 
2. (figuratively) To restrict someone's movement or creativity. 
3. (aviation) To immobilize an artificial horizon. 
4. To track individual responses to direct mail, either (advertising) to maintain and develop mailing lists or (politics) to identify people who are not eligible to vote because they do not reside at the registered addresses. 

## Synonyms
[[coop]]