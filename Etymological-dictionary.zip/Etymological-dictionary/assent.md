# assent

## Etymology
- From Middle English assent (noun) and assenten (verb), from Old French assent (noun) and assentir (verb).


## Definition
### Verb
1. (intransitive) To agree to a proposal. 

### Noun
1. agreement; act of agreeing 

## Synonyms
[[consent]] | [[acquiesce]] | [[comply]] | [[accede]] | [[acquiescence]]