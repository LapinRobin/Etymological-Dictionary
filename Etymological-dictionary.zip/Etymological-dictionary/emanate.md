# emanate

## Etymology
- From Latin ēmānāre (“to flow out, spring out of, arise, proceed from”), from e (“out”) + mānāre (“to flow”).


## Definition
### Verb
1. (intransitive) To come from a source; issue from. 
2. (transitive, rare) To send or give out; manifest. 

## Synonyms
[[exhale]]