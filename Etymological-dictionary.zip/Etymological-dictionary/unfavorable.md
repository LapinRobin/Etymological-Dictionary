# unfavorable

## Definition
### Adjective
1. (American spelling) Alternative spelling of unfavourable  

## Synonyms
[[bad]] | [[adverse]] | [[hostile]] | [[contrary]] | [[invidious]] | [[untoward]] | [[harmful]]