# impose

## Etymology
- Borrowed from Middle French imposer (“to lay on, impose”), taking the place of Latin imponere (“to lay on, impose”), from in (“on, upon”) +‎ ponere (“to put, place”).


## Definition
### Verb
1. (transitive) To establish or apply by authority. 
2. (intransitive) to be an inconvenience (on or upon) 
3. to enforce: compel to behave in a certain way 
4. To practice a trick or deception (on or upon). 
5. To lay on, as the hands, in the religious rites of confirmation and ordination. 
6. To arrange in proper order on a table of stone or metal and lock up in a chase for printing; said of columns or pages of type, forms, etc. 

## Synonyms
[[levy]] | [[visit]] | [[enforce]] | [[inflict]]