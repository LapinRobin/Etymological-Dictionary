# interchangeable

## Etymology
- From interchange +‎ -able.


## Definition
### Adjective
1. Freely substitutable; that may be swapped at will. 
2. Following each other in alternate succession; alternating. 

### Noun
1. Anything that can be interchanged; a substitute. 

## Synonyms
[[complementary]] | [[similar]] | [[reciprocal]] | [[symmetrical]]