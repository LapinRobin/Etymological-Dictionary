# off-guard

## Definition
### Adjective
1. Alternative spelling of off guard 

## Synonyms
