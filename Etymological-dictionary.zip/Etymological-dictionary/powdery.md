# powdery

## Etymology
- powder +‎ -y


## Definition
### Adjective
1. Of or pertaining to powder. 

## Synonyms
[[light]] | [[fine]]