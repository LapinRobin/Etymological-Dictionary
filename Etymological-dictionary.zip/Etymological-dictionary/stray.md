# stray

## Etymology
- From Middle English stray, strey, from Anglo-Norman estray, stray, Old French estrai, from the verb (see below).

- From Middle English strayen, partly from Old French estraier, from Vulgar Latin via strata, and partly from Middle English strien, streyen, streyȝen (“to spread, scatter”), from Old English strēġan (“to strew”).

- From Middle English stray, from the noun (see above).


## Definition
### Noun
1. Any domestic animal that has no enclosure nor proper place and company, but that instead wanders at large or is lost; an estray. 
2. One who is lost, literally or figuratively. 
3. An act of wandering off or going astray. 
4. (historical) An area of common land for use by domestic animals generally. 
5. (radio) An instance of atmospheric interference. 

### Verb
1. (intransitive) To wander, as from a direct course; to deviate, or go out of the way. 
2. (intransitive) To wander from company or outside proper limits; to rove or roam at large; to go astray. 
3. (intransitive) To wander from the path of duty or rectitude; to err. 
4. (transitive) To cause to stray; lead astray. 

### Adjective
1. Having gone astray; strayed; wandering 
2. In the wrong place; misplaced. 

## Synonyms
[[cast]] | [[range]] | [[drift]] | [[wander]] | [[sporadic]] | [[swan]] | [[err]] | [[digress]] | [[roam]] | [[vagabond]] | [[ramble]] | [[depart]] | [[isolated]] | [[rove]] | [[scattered]]