# raid

## Etymology
- From Scots raid, from Northern Middle English rade, from Old English rād (“a riding, an expedition on horseback, road”), whence also the inherited English road (“way, street”). The earlier senses of “a riding, expedition, raid” fell into disuse in Early Modern English, but were revived in the northern form raid by Walter Scott in the early 19th century. The use for a swift police operation appears in the later 19th century and may perhaps have been influenced by French razzia (similar in both original meaning and sound).


## Definition
### Noun
1. (military) A quick hostile or predatory incursion or invasion in a battle. 
2. An attack or invasion for the purpose of making arrests, seizing property, or plundering. 
3. (sports) An attacking movement. 
4. (Internet) An activity initiated at or towards the end of a live broadcast by the broadcaster that sends its viewers to a different broadcast, primarily intended to boost the viewership of the receiving broadcaster. This is frequently accompanied by a message in the form of a hashtag that is posted in the broadcast's chat by the viewers. 
5. (online gaming) A large group in a massively multiplayer online game, consisting of multiple parties who team up to defeat a powerful enemy. 
6. (computing) Acronym of Redundant Array of Inexpensive (or Independent) Disks. 

### Verb
1. (transitive) To engage in a raid against. 
2. (transitive) To lure from another; to entice away from. 
3. (transitive) To indulge oneself by taking from. 

## Synonyms
[[bust]] | [[foray]]