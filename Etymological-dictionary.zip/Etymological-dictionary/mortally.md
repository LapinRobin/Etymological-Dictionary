# mortally

## Etymology
- From Middle English mortally, equivalent to mortal +‎ -ly.


## Definition
### Adverb
1. Fatally; in such a way as to cause death. 
2. (obsolete) As a mortal. 

## Synonyms
