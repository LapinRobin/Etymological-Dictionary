# swish

## Definition
### Adjective
1. (Britain, colloquial) sophisticated; fashionable; smooth. 
2. Attractive, stylish 
3. Effeminate. 

### Noun
1. A short rustling, hissing or whistling sound, often made by friction. 
2. A hissing, sweeping movement through the air, as of an animal's tail. 
3. A sound of liquid flowing inside a container. 
4. A twig or bundle of twigs, used for administering beatings; a switch 
5. (basketball) A successful basketball shot that does not touch the rim or backboard. 
6. (slang) An effeminate male homosexual. 
7. (uncountable, Canada, prison slang) An improvised alcoholic drink made by fermenting whatever ingredients are available. 

### Verb
1. To make a rustling sound while moving. 
2. (transitive) To flourish with a swishing sound. 
3. (transitive, slang, dated) To flog; to lash. 
4. (basketball) To make a successful basketball shot that does not touch the rim or backboard. 
5. (gay slang) To mince or otherwise to behave in an effeminate manner. 
6. (transitive) To cause a liquid to move around in a container, or in one's mouth. 

## Synonyms
[[lap]] | [[posh]] | [[classy]] | [[fashionable]] | [[stylish]]