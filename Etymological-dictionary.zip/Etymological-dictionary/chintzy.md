# chintzy

## Etymology
- From chintz +‎ -y.

- From earlier chinchy, from Middle English chynchy (“miserly, stingy”), from Middle English chinche (“stingy, miserly; miser”)  +‎ -y.


## Definition
### Adjective
1. Of or decorated with chintz. 
2. (figuratively) Tastelessly showy; cheap, gaudy, or tacky. 
3. (figuratively) Excessively reluctant to spend; miserly, stingy. 

## Synonyms
[[bum]] | [[inferior]] | [[cheap]] | [[cheesy]] | [[stingy]] | [[punk]] | [[sleazy]] | [[crummy]]