# damnation

## Etymology
- From Middle English dampnacioun, from Old French dampnacion, from Latin damnatio.


## Definition
### Noun
1. The state of being damned; condemnation; openly expressed disapprobation. 
2. (religion) Condemnation to everlasting punishment in the future state, or the punishment itself. 

## Synonyms
