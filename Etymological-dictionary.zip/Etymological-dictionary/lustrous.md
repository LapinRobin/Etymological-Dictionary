# lustrous

## Etymology
- lustre +‎ -ous


## Definition
### Adjective
1. Having a glow or lustre. 
2. As if shining with a brilliant light; radiant. 

## Synonyms
[[bright]] | [[glorious]] | [[shiny]] | [[glossy]] | [[shining]] | [[polished]]