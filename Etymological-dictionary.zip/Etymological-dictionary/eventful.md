# eventful

## Etymology
- From event +‎ -ful.


## Definition
### Adjective
1. Of or pertaining to high levels of activity; having many memorable events. 

## Synonyms
[[important]] | [[lively]] | [[consequential]]