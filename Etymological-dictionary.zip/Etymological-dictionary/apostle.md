# apostle

## Etymology
- From Middle English apostle, from Old French apostle, from Late Latin apostolus, from Ancient Greek ἀπόστολος (apóstolos, “one sent forth, apostle”). Merged with Old English apostol, borrowing from the same Latin source.

- See apostil.


## Definition
### Noun
1. A missionary, or leader of a religious mission, especially one in the early Christian Church (but see Apostle). 
2. A pioneer or early advocate of a particular cause, prophet of a belief. 
3. A top-ranking ecclesiastical official in the twelve seat administrative council of The Church of Jesus Christ of Latter-day Saints. 
4. (obsolete, Cambridge slang) A person who is plucked, that is, refused an academic degree. 
5. (law) A letter dismissory. 
6. (law) A note sent to an appeals court presenting the appeal in summary. 
7. (law) The trial court record sent to an appeal court concerning an appeal. 
8. (Christianity) Any of the group of twelve disciples chosen by Jesus to preach and spread the Gospel. 
9. A top-ranking ecclesiastical official in the twelve-seat Mormon administrative council. 
10. A transliteration of the Greek male given name Απόστολος (Apóstolos). A rare transcription; usually transliterated as Apostolos. 

## Synonyms
