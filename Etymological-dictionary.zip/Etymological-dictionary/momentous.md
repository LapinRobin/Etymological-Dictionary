# momentous

## Etymology
- From moment +‎ -ous.


## Definition
### Adjective
1. Outstanding in importance, of great consequence. 

## Synonyms
[[big]] | [[important]] | [[significant]]