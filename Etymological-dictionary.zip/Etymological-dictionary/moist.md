# moist

## Etymology
- The adjective is derived from Middle English moist, moiste (“damp, humid, moist, wet; well-irrigated, well-watered; made up of water or other fluids, fluid; of ale: fresh; (figuratively) carnal, lascivious; undisciplined, weak; (alchemy, medicine, physics) dominated by water as an element”) , from Anglo-Norman moist, moiste, moste, Middle French moiste, and Old French moiste, muste (“damp, moist, wet”) (modern French moite); further etymology uncertain, perhaps a blend of a Late Latin variant of Latin mūcidus (“mouldy, musty”) + a Late Latin derivative of Latin mustum (“unfermented or partially fermented grape juice or wine, must”).

- From Middle English moisten, moist, moiste (“to make moist or wet; to soak in liquid; to become moist or wet; to provide with moisture or water; to satisfy thirst with liquor or water, slake”) , and then either:


## Definition
### Adjective
1. Characterized by the presence of moisture; not dry; slightly wet; damp. 
2. Of eyes: wet with tears; tearful; also (obsolete), watery due to some illness or to old age. 
3. Of a climate, the weather, etc.: damp, humid, rainy. 
4. (informal) Of the vagina: sexually lubricated due to sexual arousal; of a woman: sexually aroused, turned on. 
5. Characterized by the presence of some fluid such as mucus, pus, etc. 
6. Of sounds of internal organs (especially as heard through a stethoscope): characterized by the sound of air bubbling through a fluid. 
7. (sciences, historical) Pertaining to one of the four essential qualities formerly believed to be present in all things, characterized by wetness; also, having a significant amount of this quality. 
8. Fluid, liquid, watery. 
9. (also poetic) Bringing moisture or rain. 

### Noun
1. (obsolete except US, regional) Moistness; also, moisture. 
2. A surname. 

### Verb
1. (obsolete except Britain, regional and US) To make (something) moist or wet; to moisten. 
2. (obsolete, figuratively) To inspire, to refresh (someone); also, to soften (one's heart). 
3. (US) To rain lightly; to drizzle. 
4. (obsolete) To have an effect of moistening or wetting. 

## Synonyms
[[wet]] | [[damp]]