# lavatory

## Etymology
- From Middle English lavatorie, from Late Latin lavātōrium, from Latin lavāre (“to wash”) + -ium (forming places related to an activity). Doublet of lavatorium. As a place to pan gold, via Spanish lavadero. See also lave.


## Definition
### Noun
1. A laver: a washbasin. 
2. (archaic) A bathtub. 
3. (Christianity) A piscina: the basin used for washing communion vessels. 
4. (Christianity) A lavabo: the basin used for washing one's hands before handling the Eucharist. 
5. (Christianity, usually figuratively) A baptismal font: the basin used for baptism, used figuratively for the washing away of sins. 
6. (construction, interior design) A plumbing fixture used for washing: a sink. 
7. (Christianity) The lavabo: the ritual washing of hands before handling the eucharist. 
8. (Christianity) The ritual washing of hands after using the piscina to clean the communion vessels. 
9. (obsolete) A liquid used in washing; a lotion; a wash; a rinse. 
10. (dated) A washroom: a room used for washing the face and hands. 
11. (euphemistic) A room containing a toilet: a bathroom (US) or WC (UK). 
12. (UK, New England) A plumbing fixture for urination and defecation: a toilet. 
13. (dated) A place to wash clothes: a laundry. 
14. (obsolete) A place where gold is panned. 
15. (obsolete) A paved room in a mortuary where corpses are kept under a shower of disinfecting fluid. 

### Adjective
1. (dated) Washing, or cleansing by washing. 

## Synonyms
[[can]] | [[facility]] | [[john]] | [[privy]] | [[toilet]] | [[bathroom]]