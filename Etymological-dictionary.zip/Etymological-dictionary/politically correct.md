# politically correct

## Etymology
- The earliest known attestation is in late 18th century United States, in response to a toast made to “the United States” instead of to “the people of the United States”.


## Definition
### Adjective
1. (politics) Possessing or conforming to the correct political positions; following the official policies of the government or a political party. 
2. (idiomatic) Respectful of marginalized ethnic groups, genders, etc. 
3. (idiomatic, derogatory) Overly sensitive to giving offense on the grounds of race, sex, etc. 
4. (idiomatic, politics, derogatory) Stereotypically left-wing; possessing or conforming to stereotypical left-wing social views. 

### Verb
1. (transitive) To modify in a way that is more respectful to minorities. 
2. (transitive) To modify in a way that conforms more to the official position of a government or political party. 

## Synonyms
