# crisp

## Etymology
- From Middle English crisp (“curly”), from Old English crisp (“curly”), from Latin crispus (“curly”). Doublet of crêpe.


## Definition
### Adjective
1. (of something seen or heard) Sharp, clearly defined. 
2. Brittle; friable; in a condition to break with a short, sharp fracture. 
3. Possessing a certain degree of firmness and freshness. 
4. (of weather, air etc.) Dry and cold. 
5. (of movement, action etc.) Quick and accurate. 
6. (of talk, text, etc.) Brief and to the point. 
7. (of wine) having a refreshing amount of acidity; having less acidity than green wine, but more than a flabby one. 
8. (obsolete) Lively; sparking; effervescing. 
9. (dated) Curling in stiff curls or ringlets. 
10. (obsolete) Curled by the ripple of water. 
11. (computing theory) Not using fuzzy logic; based on a binary distinction between true and false. 

### Noun
1. (Britain) A thin slice of fried potato eaten as a snack. 
2. A baked dessert made with fruit and crumb topping 
3. (food) Anything baked or fried in thin slices and eaten as a snack. 
4. A surname. 

### Verb
1. (transitive) To make crisp. 
2. (intransitive) To become crisp. 
3. (transitive, dated) To cause to curl or wrinkle (of the leaves or petals of plants, for example); to form into ringlets or tight curls (of hair). 
4. (intransitive, dated) To become curled. 
5. (transitive, dated) To cause to undulate irregularly (of water); to cause to ripple. 
6. (intransitive, dated) To undulate or ripple. 
7. (transitive, dated) To wrinkle, contort or tense (a part of one's body). 
8. (intransitive, dated) To become contorted or tensed (of a part of the body). 
9. (transitive, intransitive, rare) To interweave (of the branches of trees). 
10. (intransitive, dated) To make a sharp or harsh sound. 
11. (transitive, dated) To colour (something with highlights); to add small amounts of colour to (something). 

## Synonyms
[[tender]] | [[cold]] | [[concise]] | [[firm]] | [[sharp]] | [[chip]] | [[fresh]] | [[laconic]] | [[distinct]] | [[terse]] | [[toast]] | [[curt]] | [[crease]] | [[kinky]] | [[wrinkle]] | [[nappy]] | [[snappy]] | [[crispy]] | [[frosty]] | [[scrunch]]