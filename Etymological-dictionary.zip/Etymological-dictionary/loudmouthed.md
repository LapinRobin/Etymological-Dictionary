# loudmouthed

## Etymology
- loud +‎ mouthed


## Definition
### Adjective
1. Tending to loud, indiscreet, especially bragging, speech. 

## Synonyms
