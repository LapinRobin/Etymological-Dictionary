# exhibit

## Etymology
- From Latin exhibitus, perfect passive participle of exhibeō (“I hold forth, present, show, display”), from ex (“out of, from”) + habeō (“I have, hold”); see habit.


## Definition
### Verb
1. (transitive) To display or show (something) for others to see, especially at an exhibition or contest. 
2. (transitive) To demonstrate. 
3. (transitive, law) To submit (a physical object) to a court as evidence. 
4. (intransitive) To put on a public display. 
5. (medicine) To administer as a remedy. 

### Noun
1. An instance of exhibiting. 
2. That which is exhibited. 
3. A public showing; an exhibition. 
4. (law) An article formally introduced as evidence in a court. 

## Synonyms
[[show]] | [[present]] | [[display]] | [[expose]] | [[demonstrate]] | [[march]] | [[parade]] | [[demo]]