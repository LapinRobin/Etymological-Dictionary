# subpoena

## Etymology
- First attested with this spelling in 1623 C.E., from earlier subpena, from Middle English sub pena, from  Medieval Latin: sub (“under”) and poena (“penalty”), the beginning of the original subpoena used in the Court of Chancery.


## Definition
### Noun
1. (law, historical) A writ requiring a defendant to appear in court to answer a plaintiff's claim. 
2. (law) A writ requiring someone to appear in court to give testimony. 

### Verb
1. (transitive) To summon with a subpoena. 

## Synonyms
