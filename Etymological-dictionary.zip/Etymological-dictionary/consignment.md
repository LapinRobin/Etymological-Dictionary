# consignment

## Etymology
- consign +‎ -ment


## Definition
### Noun
1. A collection of goods to be sent, in transit or having been sent. 
2. The act of consigning. 
3. The sale of one's own goods (clothing, furniture, etc.) through a third-party vendor, in exchange for a portion of the sale price, and with the consigner retaining ownership of the goods until they are sold or abandoned. 

## Synonyms
[[commitment]] | [[load]] | [[freight]] | [[payload]] | [[cargo]] | [[shipment]] | [[lading]]