# compromise

## Etymology
- From Middle French compromis, from Medieval Latin, Late Latin compromissum (“a compromise, originally a mutual promise to refer to arbitration”), prop. neuter of Latin compromissus, past participle of compromittere (“to make a mutual promise to abide by the decision of an arbiter”), from com- (“together”) + promittere (“to promise”); see promise.


## Definition
### Noun
1. The settlement of differences by arbitration or by consent reached by mutual concessions. 
2. A committal to something derogatory or objectionable; a prejudicial concession; a surrender. 
3. (computer security) A breach of a computer or network's rules such that an unauthorized disclosure or loss of sensitive information may have occurred, or the unauthorized disclosure or loss itself. 

### Verb
1. (transitive, intransitive) To bind by mutual agreement. 
2. To adjust and settle by mutual concessions; to compound. 
3. (intransitive) To find a way between extremes. 
4. To pledge by some act or declaration; to endanger the life, reputation, etc., of, by some act which can not be recalled; to expose to suspicion. 
5. (transitive) To cause impairment of. 
6. (transitive) To breach (a security system). 

## Synonyms
