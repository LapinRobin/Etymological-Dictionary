# stooge

## Etymology
- Perhaps an abbreviation of Russian студе́нт (studént) ; the original meaning was “stage assistant, actor who assists a comedian”. It may have been a Yiddish vaudeville term.


## Definition
### Noun
1. One who knowingly allows himself or herself to be used for another's profit; a dupe. 
2. (magic) A magician's assistant who pretends to be a member of the audience. 
3. (comedy) A straight man. 
4. A secret informant for police. 
5. (psychology) A confederate; a person who is secretly working for the researcher, unknown to the study participant. 

### Verb
1. (intransitive) To act as a straight man. 

## Synonyms
[[butt]] | [[goat]] | [[dweeb]] | [[flunky]]