# lay into

## Definition
### Verb
1. (colloquial) To beat up or launch an attack against. 
2. (colloquial) To berate; to scold. 

## Synonyms
