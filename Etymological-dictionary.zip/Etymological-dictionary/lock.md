# lock

## Etymology
- From Middle English lok, from Old English loc, from Proto-West Germanic *lok, from Proto-Germanic *luką from Proto-Indo-European *lewg- (“to bend; turn”). The verb is from Middle English locken, lokken, louken, from Old English lūcan, Proto-West Germanic *lūkan, from Proto-Germanic *lūkaną. Related to luxe via Latin.

- From Middle English lok, lokke, from Old English locc (“hair of the head, hair, lock of hair, curl, ringlet”), from Proto-West Germanic *lokk, from Proto-Germanic *lukkaz, from Proto-Indo-European *lugnó-, from Proto-Indo-European *lewg- (“to bend”).


## Definition
### Noun
1. Something used for fastening, which can only be opened with a key or combination. 
2. (computing, by extension) A mutex or other token restricting access to a resource. 
3. A segment of a canal or other waterway enclosed by gates, used for raising and lowering boats between levels. 
4. (firearms) The firing mechanism. 
5. Complete control over a situation. 
6. Something sure to be a success. 
7. (rugby) A player in the scrum behind the front row, usually the tallest members of the team. 
8. A fastening together or interlacing; a closing of one thing upon another; a state of being fixed or immovable. 
9. A place impossible to get out of, as by a lock. 
10. A device for keeping a wheel from turning. 
11. A grapple in wrestling. 
12. A tuft or length of hair, wool, etc. 
13. A small quantity of straw etc. 
14. (Scotland, law, historical) A quantity of meal, the perquisite of a mill-servant. 
15. A surname. 

### Verb
1. (intransitive) To become fastened in place. 
2. (transitive) To fasten with a lock. 
3. (intransitive) To be capable of becoming fastened in place. 
4. (transitive) To intertwine or dovetail. 
5. (intransitive, break dancing) To freeze one's body or a part thereof in place. 
6. To furnish (a canal) with locks. 
7. To raise or lower (a boat) in a lock. 
8. To seize (e.g. the sword arm of an antagonist) by turning one's left arm around it, to disarm them. 
9. (Internet, transitive) To modify (a thread) so that users cannot make new posts in it. 
10. (Internet, transitive, Wikimedia jargon) To prevent a page from being edited by other users. 
11. (intransitive, rugby) To play in the position of lock. 

## Synonyms
[[engage]] | [[mesh]] | [[operate]] | [[curl]] | [[whorl]] | [[interlock]]