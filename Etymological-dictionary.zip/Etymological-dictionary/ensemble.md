# ensemble

## Etymology
- Borrowed from French ensemble.


## Definition
### Noun
1. A group of separate things that contribute to a coordinated whole. 
2. (fashion) A coordinated costume or outfit; a suit. 
3. (collective) A group of musicians, dancers, actors, etc who perform together; e.g. the chorus of a ballet company. 
4. (music) A piece for several instrumentalists or vocalists. 
5. (mathematics, physics) A probability distribution for the state of the system. 
6. (machine learning) A supervised learning algorithm combining multiple hypotheses. 

### Verb
1. To put together in a coordinated whole. 
2. (music) To perform in a musical ensemble. 

## Synonyms
