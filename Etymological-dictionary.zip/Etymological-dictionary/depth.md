# depth

## Etymology
- From Middle English depthe, from Old English *dīepþ (“depth”), from Proto-Germanic *diupiþō (“depth”), equivalent to deep +‎ -th. Cognate with Scots deepth (“depth”), Saterland Frisian Djüpte (“depth”), West Frisian djipte (“depth”), Dutch diepte (“depth”), Low German Deepde (“depth”), Danish dybde (“depth”), Icelandic dýpt (“depth”), Gothic 𐌳𐌹𐌿𐍀𐌹𐌸𐌰 (diupiþa, “depth”).


## Definition
### Noun
1. the vertical distance below a surface; the degree to which something is deep 
2. the distance between the front and the back, as the depth of a drawer or closet 
3. (figuratively) the intensity, complexity, strength, seriousness or importance of an emotion, situation, etc. 
4. lowness 
5. (computing, colors) the total palette of available colors 
6. (art, photography) the property of appearing three-dimensional 
7. (literary, usually in the plural) the deepest part (usually of a body of water) 
8. (literary, usually in the plural) a very remote part. 
9. the most severe part 
10. (logic) the number of simple elements which an abstract conception or notion includes; the comprehension or content 
11. (horology) a pair of toothed wheels which work together 
12. (aeronautics) the perpendicular distance from the chord to the farthest point of an arched surface 
13. (statistics) the lower of the two ranks of a value in an ordered set of values 

## Synonyms
[[profundity]]