# monster

## Etymology
- From Middle English monstre, borrowed from Old French monstre, mostre, moustre, from Latin mōnstrum.


## Definition
### Noun
1. A terrifying and dangerous creature. 
2. A bizarre or whimsical creature. 
3. A cruel, heartless, or antisocial person, especially a criminal. 
4. (medicine, archaic) A severely deformed person. 
5. (figuratively) A badly behaved child, a brat. 
6. (informal) Something unusually large. 
7. (informal) A prodigy; someone very talented in a specific domain. 
8. (gaming) A non-player character that player(s) fight against in role-playing games. 

### Adjective
1. (informal) Very large; worthy of a monster. 
2. (informal) Great; very good; excellent. 

### Verb
1. (transitive) To make into a monster; to categorise as a monster; to demonise. 
2. (intransitive) To behave as a monster to; to terrorise. 
3. (chiefly Australia) To harass. 
4. (UK, live action role-playing games) To play (often a series of) non-player characters as directed, almost always as part of a team, and usually without having an organisational role in running the game; not limited to playing literal monsters or hostile combatants. 

## Synonyms
[[devil]] | [[freak]] | [[behemoth]] | [[fiend]] | [[giant]] | [[demon]] | [[ogre]] | [[colossus]] | [[goliath]]