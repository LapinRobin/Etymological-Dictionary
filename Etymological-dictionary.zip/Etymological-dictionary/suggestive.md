# suggestive

## Definition
### Adjective
1. Tending to suggest or imply. 
2. Suggesting romance, sex, etc.; risqué. 
3. Relating to hypnotic suggestion. 

## Synonyms
[[indicative]] | [[meaningful]]