# concept

## Etymology
- Borrowed from Middle French concept, from Latin conceptus (“a thought, purpose, also a conceiving, etc.”), from concipiō (“to take in, conceive”). Doublet of conceit. See conceive.


## Definition
### Noun
1. An abstract and general idea; an abstraction. 
2. Understanding retained in the mind, from experience, reasoning and imagination; a generalization (generic, basic form), or abstraction (mental impression), of a particular set of instances or occurrences (specific, though different, recorded manifestations of the concept). 
3. (generic programming) A description of supported operations on a type, including their syntax and semantics. 

### Verb
1. to conceive; to dream up 

## Synonyms
[[construct]] | [[conception]]