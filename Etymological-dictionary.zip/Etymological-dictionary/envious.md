# envious

## Etymology
- From Middle English envious, from Anglo-Norman envious, from Old French envieus, envious (modern French envieux), from Latin invidiōsus; more at envy. Doublet of invidious, borrowed directly from Latin. Displaced native Old English æfestiġ.


## Definition
### Adjective
1. Feeling or exhibiting envy; jealously desiring the excellence or good fortune of another; maliciously grudging 
2. Excessively careful; cautious. 
3. (obsolete) Malignant; mischievous; spiteful. 
4. (obsolete, poetic) Inspiring envy. 

## Synonyms
[[jealous]] | [[selfish]] | [[covetous]]