# spawn

## Etymology
- Recorded since 1413; from Middle English spawnen, from Anglo-Norman espaundre, from Old French espandre, from Latin expandere (“stretch out; spread out”, verb). Doublet of expand. Compare also Middle English spalden, spolden, spawden (“to cut open (a fish)”).

- From Middle English spawne, from the verb (see above).


## Definition
### Verb
1. (transitive) To produce or deposit (eggs) in water. 
2. (transitive) To generate, bring into being, especially non-mammalian beings in very large numbers. 
3. (transitive) To bring forth in general. 
4. (transitive) To induce (aquatic organisms) to spawn. 
5. (transitive) To plant with fungal spawn. 
6. (intransitive) To deposit (numerous) eggs in water. 
7. (intransitive) To reproduce, especially in large numbers. 
8. (ergative, video games, of a character or object) (To cause) to appear spontaneously in a game at a certain point and time. 

### Noun
1. The numerous eggs of an aquatic organism. 
2. Mushroom mycelium prepared for (aided) propagation. 
3. (by extension, sometimes derogatory) Any germ or seed, even a figurative source; offspring. 
4. (horticulture) The buds or branches produced from underground stems. 
5. (video games) The location in a game where characters or objects spontaneously appear. 
6. A surname. 

## Synonyms
[[breed]] | [[engender]]