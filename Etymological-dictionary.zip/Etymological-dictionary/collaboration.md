# collaboration

## Etymology
- Originated 1855–60 from French collaboration, from Late Latin collaboratus + -ion, from Latin con- (“with”) + labōrō (“work”).
Morphologically collaborate +‎ -ion


## Definition
### Noun
1. (uncountable) The act of collaborating. 
2. (countable) A production or creation made by collaborating. 
3. (uncountable) Treasonous cooperation. 

## Synonyms
