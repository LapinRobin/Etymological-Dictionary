# helper

## Etymology
- From Middle English helpere, from Old English *helpere, from Proto-West Germanic *helpārī (“helper”), equivalent to help +‎ -er. Cognate with Saterland Frisian Hälper (“helper”), West Frisian helper (“helper”), Dutch helper (“helper”), German Low German Helper (“helper”), German Helfer (“helper”), Danish hjælper (“helper”), Swedish hjälpare (“helper”), Icelandic hjálpar (“helper”).


## Definition
### Noun
1. One who helps; an aide; assistant; auxiliary. 
2. That which helps; anything serving to assist. 
3. (Singapore) A person who does cleaning and cooking in a family home, or in a market; domestic employee. 
4. (rail transport, US) A locomotive that assists a train, usually on steep gradients. 
5. A city in Carbon County, Utah, United States, which got its name from the practice of the Denver & Rio Grande Railroad of attaching helper engines to trains there. 
6. A surname; variant of Halpern or Helfer. 

## Synonyms
[[help]] | [[assistant]] | [[benefactor]]