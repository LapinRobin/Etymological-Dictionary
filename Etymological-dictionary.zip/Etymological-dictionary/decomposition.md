# decomposition

## Etymology
- de- +‎ composition


## Definition
### Noun
1. A biological process through which organic material is reduced to e.g. compost. 
2. The act of taking something apart, e.g. for analysis. 
3. The splitting (of e.g. a matrix, an atom, or a compound) into constituent parts. 

## Synonyms
[[rot]] | [[decay]]