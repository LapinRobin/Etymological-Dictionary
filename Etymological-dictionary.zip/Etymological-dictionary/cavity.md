# cavity

## Etymology
- Mid 16th century borrowing from Middle French cavité or Late Latin cavitās, from cavus (“hollow, excavated, concave”) +‎ -tās (“-ity”, nominal suffix).


## Definition
### Noun
1. A hole or hollow depression in a solid object. 
2. (anatomy) A hollow area within the body. 
3. (dentistry) A small or large hole in a tooth caused by caries; often also a soft area adjacent to the hole also affected by caries. 

## Synonyms
[[pit]] | [[caries]]