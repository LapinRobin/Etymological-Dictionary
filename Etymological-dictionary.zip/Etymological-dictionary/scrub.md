# scrub

## Etymology
- Variant of shrub, possibly under Norse influence.
This etymology is incomplete. You can help Wiktionary by elaborating on the origins of this term.

- From Middle English scrobben (“groom a horse with a currycomb”); from Middle Dutch schrobben (“clean by scrubbing”).


## Definition
### Adjective
1. Mean; dirty; contemptible; scrubby. 

### Noun
1. One who labors hard and lives meanly; a mean fellow. 
2. One who is incompetent or unable to complete easy tasks. 
3. A thicket or jungle, often specified by the name of the prevailing plant 
4. (US, stock breeding) One of the common livestock of a region of no particular breed or not of pure breed, especially when inferior in size, etc. Often used to refer to male animals unsuited for breeding. 
5. Vegetation of inferior quality, though sometimes thick and impenetrable, growing in poor soil or in sand; also, brush. 
6. One not on the first team of players; a substitute. 
7. (obsolete, slang) Informal attire or dress code; morning dress 
8. An instance of scrubbing. 
9. A cancellation. 
10. A worn-out brush. 
11. One who scrubs. 
12. (medicine, in the plural) Clothing worn while performing surgery. 
13. (by extension, in the plural) Any medical uniform consisting of a short-sleeved shirt and pants (trousers). 
14. An exfoliant for the body. 

### Verb
1. (transitive) To rub hard; to wash with rubbing; usually, to rub with a wet brush, or with something coarse or rough, for the purpose of cleaning or brightening 
2. (intransitive) To rub anything hard, especially with a wet brush; to scour 
3. (intransitive, figuratively) To be diligent and penurious 
4. (transitive) To call off a scheduled event; to cancel. 
5. (databases, transitive) To eliminate or to correct data from a set of records to bring it inline with other similar datasets 
6. (audio) To move a recording tape back and forth with a scrubbing motion to produce a scratching sound, or to do so by a similar use of a control on an editing system. 
7. (audio, video) To maneuver the play position on a media editing system by using a scroll bar or touch-based interface. 

## Synonyms
[[bush]] | [[scour]] | [[cur]] | [[mongrel]] | [[chaparral]]