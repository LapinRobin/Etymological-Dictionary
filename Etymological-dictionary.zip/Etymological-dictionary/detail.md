# detail

## Etymology
- Borrowed from Middle French détail, from Old French detail, from detaillier, from de- + taillier (“to cut”).


## Definition
### Noun
1. (countable) A part small enough to escape casual notice. 
2. (uncountable) A profusion of details. 
3. (uncountable) The small parts that can escape casual notice. 
4. A part considered trivial enough to ignore. 
5. (countable) A person's name, address and other personal information. 
6. (military, law enforcement) A temporary unit or assignment. 
7. An individual feature, fact, or other item, considered separately from the whole of which it is a part. 
8. A narrative which relates minute points; an account which dwells on particulars. 
9. (paintings) A selected portion of a painting. 

### Verb
1. (transitive) To explain in detail. 
2. (transitive) To clean carefully (particularly of road vehicles) (always pronounced. /ˈdiːteɪl/) 
3. (transitive, military, law enforcement) To assign to a particular task. 

## Synonyms
[[point]] | [[contingent]] | [[particular]] | [[item]]