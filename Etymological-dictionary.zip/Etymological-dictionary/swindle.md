# swindle

## Etymology
- Back-formation from swindler, from German Schwindler, from German schwindeln, from Middle High German swindeln, swindelen, from Old High German swintiln, frequentative of the verb swintan, from Proto-West Germanic *swindan (“to diminish”).


## Definition
### Verb
1. (transitive) To defraud. 
2. (transitive, intransitive) To obtain (money or property) by fraudulent or deceitful methods. 
3. (chess) for a player in a losing position to play a clever move that provokes an error from the opponent, thus achieving a win or a draw 

### Noun
1. An instance of swindling. 
2. Anything that is deceptively not what it appears to be. 
3. (chess) when a player in a losing position plays a clever move that provokes an error from the opponent, thus achieving a win or a draw 
4. A surname. 

## Synonyms
[[con]] | [[cheat]] | [[rook]] | [[gyp]] | [[defraud]] | [[diddle]]