# block out

## Definition
### Verb
1. (transitive) to prevent from entering or penetrating. 
2. (idiomatic, transitive) to prevent (a thought) from entering one's mind. 
3. (transitive) to cover something, so as to make it impossible to see. 
4. (transitive) to begin to reduce to shape; to mark out roughly; to lay out. 

## Synonyms
