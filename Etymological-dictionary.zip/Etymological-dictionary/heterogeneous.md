# heterogeneous

## Etymology
- From Medieval Latin heterogeneus, from Ancient Greek ἑτερογενής (heterogenḗs, “of different kinds”), from ἕτερος (héteros, “other, another, different”) + γένος (génos, “kind”). Compare hetero- and -ous.


## Definition
### Adjective
1. Diverse in kind or nature; composed of diverse parts. 
2. (mathematics) Incommensurable because of different kinds. 
3. (physics, chemistry) Having more than one phase (solid, liquid, gas) present in a system or process. 
4. (chemistry) Visibly consisting of different components. 
5. (computing) Of a network comprising different types of computers, potentially with vastly differing memory sizes, processing power and even basic underlying architecture; alternatively, of a data resource with multiple types of formats. 

## Synonyms
[[disparate]] | [[miscellaneous]] | [[motley]]