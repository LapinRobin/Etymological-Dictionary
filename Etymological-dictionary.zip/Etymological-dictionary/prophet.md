# prophet

## Etymology
- From Middle English prophete, from Anglo-Norman prophete, from Latin prophēta, from Ancient Greek προφήτης (prophḗtēs, “one who speaks for a god”), from πρό (pró, “before”) + φημί (phēmí, “I tell”). Displaced native Old English wītga.


## Definition
### Noun
1. Someone who speaks by divine inspiration. 
2. Someone who predicts the future; a soothsayer. 
3. (Christianity, Judaism) Any of the prophets mentioned in the Bible, especially an author of one of the Prophets. 
4. (Christianity, with "the") Jesus. 
5. (Islam, with "the") Muhammad. 
6. A surname 

## Synonyms
[[oracle]]