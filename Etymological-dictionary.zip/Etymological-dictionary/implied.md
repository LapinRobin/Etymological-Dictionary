# implied

## Definition
### Adjective
1. Suggested without being stated directly; implicated or hinted at. 

## Synonyms
[[tacit]] | [[implicit]] | [[silent]]