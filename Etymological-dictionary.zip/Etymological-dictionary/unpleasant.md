# unpleasant

## Etymology
- From Middle English unplesaunt, equivalent to un- +‎ pleasant.


## Definition
### Adjective
1. Not pleasant. 

## Synonyms
[[acid]] | [[hot]] | [[sharp]] | [[rough]] | [[sore]] | [[obnoxious]] | [[grim]] | [[awful]] | [[harsh]] | [[bitter]] | [[dour]] | [[acerbic]] | [[tart]] | [[nasty]] | [[offensive]] | [[caustic]] | [[dreadful]] | [[acrid]] | [[embarrassing]] | [[virulent]] | [[vitriolic]] | [[repellent]] | [[painful]] | [[blistering]] | [[venomous]]