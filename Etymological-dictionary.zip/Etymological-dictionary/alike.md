# alike

## Etymology
- From Middle English alike, alyke, alyche, aleche, and earlier ilike, ilik, ylike, yliche, ylich, elik, ȝelic, from Old English ġelīċ (“like; alike; similar; equal”) and Old English onlīċ, anlīċ ("like; similar; equal"; > Middle English anlike, onlich (compare German ähnlich), reinforced by Old Norse álíkr, from Proto-West Germanic *galīk, from Proto-Germanic *galīkaz (“alike, similar”).


## Definition
### Adjective
1. Having resemblance or similitude; similar; without difference. 

### Adverb
1. In the same manner, form, or degree; in common; equally. 

## Synonyms
[[like]] | [[similar]] | [[likewise]]