# width

## Etymology
- From wide +‎ -th, possibly by analogy with Old Norse vídd (“width”), though this is unlikely, as the word is not attested before the end of the 16th century and was historically unknown in Scots and the traditional dialect of Northern England, where one would expect Old Norse influence to be the strongest (these varieties traditionally employed wideness instead). Replaced Middle English wide, wyde (“width”).


## Definition
### Noun
1. The state of being wide. 
2. The measurement of the extent of something from side to side. 
3. A piece of material measured along its smaller dimension, especially fabric. 
4. (cricket) The horizontal distance between a batsman and the ball as it passes him. 
5. (sports) The use of all the width of the pitch, from one side to the other. 

## Synonyms
[[breadth]]