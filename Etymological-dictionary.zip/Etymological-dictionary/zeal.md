# zeal

## Etymology
- From Middle English zele, from Old French zel, from Late Latin zēlus, from Ancient Greek ζῆλος (zêlos, “zeal, jealousy”), from Proto-Indo-European *yeh₂- (“to search”). Related to jealous.


## Definition
### Noun
1. The fervour or tireless devotion for a person, cause, or ideal and determination in its furtherance; diligent enthusiasm; powerful interest. 
2. (obsolete) A person who exhibits such fervour or tireless devotion. 
3. The collective noun for a group of zebras. 

## Synonyms
[[ardor]] | [[elan]] | [[ardour]]