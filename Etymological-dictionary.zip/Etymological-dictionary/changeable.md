# changeable

## Etymology
- From Old French changeable.


## Definition
### Adjective
1. Capable of being changed. 
2. Subject to sudden or frequent changes. 
3. (of a species) Capable of camouflaging itself by changing colour. 

## Synonyms
[[shot]] | [[volatile]] | [[mobile]] | [[fickle]] | [[variable]] | [[fluid]] | [[mercurial]] | [[erratic]] | [[iridescent]] | [[uncertain]] | [[mutable]] | [[colorful]] | [[unstable]]