# worn

## Etymology
- By analogy to past participles like torn from tear and sworn from swear.


## Definition
### Adjective
1. Damaged and shabby as a result of much use. 
2. Worn out; exhausted. 

## Synonyms
[[decrepit]] | [[tired]] | [[haggard]] | [[shabby]] | [[drawn]] | [[ragged]] | [[seedy]] | [[aged]] | [[scruffy]] | [[frayed]] | [[tattered]]