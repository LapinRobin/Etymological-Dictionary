# employment

## Etymology
- From employ (itself from Middle French employer, from Middle French empleier, from Latin implicō (“enfold, involve, be connected with”), itself from in- + plicō (“fold”))  +‎ -ment.


## Definition
### Noun
1. The work or occupation for which one is used, and often paid 
2. The act of employing 
3. A use, purpose 
4. The state of being employed 
5. An activity to which one devotes time 
6. (economics) The number or percentage of people at work 

## Synonyms
[[work]] | [[employ]] | [[job]] | [[use]] | [[exercise]] | [[engagement]] | [[usage]] | [[hire]]