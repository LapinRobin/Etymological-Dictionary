# brazen

## Etymology
- From Middle English brasen, from Old English bræsen (“brazen, of brass”); equivalent to brass +‎ -en (compare golden).


## Definition
### Adjective
1. (archaic) Pertaining to, made of, or resembling brass (in color or strength). 
2. Sounding harsh and loud, like brass cymbals or brass instruments. 
3. (archaic) Extremely strong; impenetrable; resolute. 
4. Shamelessly shocking and offensive; audacious; impudent; barefaced; immodest, unblushing. 

### Verb
1. (intransitive) To turn a brass color. 
2. (transitive) Generally followed by out or through: to carry through in a brazen manner; to act boldly despite embarrassment, risk, etc. 

## Synonyms
[[audacious]] | [[insolent]] | [[bodacious]]