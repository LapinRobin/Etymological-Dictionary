# early

## Etymology
- 
From Middle English erly, erlich, earlich, from Old English ǣrlīċ (“early”, adjective), equivalent to ere +‎ -ly.

- 
From Middle English erly, orely, arely, erliche, arliche, from Old English ǣrlīċe, ārlīċe (“early; early in the morning”, adverb), equivalent to ere +‎ -ly. Cognate with Old Norse árliga, árla ( > Danish årle, Swedish arla, Norwegian årle, Faroese árla).


## Definition
### Adjective
1. At a time in advance of the usual or expected event. 
2. Arriving a time before expected; sooner than on time. 
3. Near the start or beginning. 
4. Near the start of the day. 
5. Having begun to occur; in its early stages. 
6. (astronomy) Of a star or class of stars, hotter than the sun. 

### Noun
1. (informal) A shift (scheduled work period) that takes place early in the day. 
2. A surname. 

### Adverb
1. At a time before expected; sooner than usual. 
2. Soon; in good time; seasonably. 

## Synonyms
[[new]] | [[other]] | [[baby]] | [[inchoate]] | [[old]] | [[future]] | [[incipient]] | [[precocious]] | [[crude]] | [[rude]] | [[archaic]] | [[former]] | [[young]] | [[primitive]] | [[primal]] | [[wee]] | [[primordial]] | [[primeval]] | [[aboriginal]] | [[immature]] | [[premature]] | [[earlier]]