# incense

## Etymology
- From Middle English encens, from Old French encens (“sweet-smelling substance”) from Late Latin incensum (“burnt incense”, literally “something burnt”), neuter past participle of incendō (“I set on fire”). Compare incendiary. Cognate with Spanish encender and incienso.


## Definition
### Noun
1. A perfume used in the rites of various religions. 
2. (figuratively) Homage; adulation. 

### Verb
1. (transitive) To anger or infuriate. 
2. (archaic) To incite, stimulate. 
3. (transitive) To offer incense to. 
4. (transitive) To perfume with, or as with, incense. 
5. (obsolete) To set on fire; to inflame; to kindle; to burn. 

## Synonyms
[[exasperate]] | [[outrage]]