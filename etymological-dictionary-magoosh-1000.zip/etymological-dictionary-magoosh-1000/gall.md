# gall

## Etymology
- From Middle English galle, from Old English galla, ġealla, from Proto-West Germanic *gallā, from Proto-Germanic *gallǭ.

- Borrowed from French galle, from Latin galla (“oak-apple”).


## Definition
### Noun
1. (anatomy) The gall bladder. 
2. (uncountable) A feeling of exasperation. 
3. (uncountable) Impudence or brazenness; temerity, chutzpah. 
4. (countable) A sore on a horse caused by an ill-fitted or ill-adjusted saddle; a saddle sore. 
5. (countable) A pit on a surface being cut caused by the friction between the two surfaces exceeding the bond of the material at a point. 
6. (anatomy, obsolete, uncountable) Bile, especially that of an animal; the greenish, profoundly bitter-tasting fluid found in bile ducts and gall bladders, structures associated with the liver. 
7. (uncountable, obsolete) Great misery or physical suffering, likened to the bitterest-tasting of substances. 
8. (medicine, obsolete, countable) A sore or open wound caused by chafing, which may become infected, as with a blister. 
9. (countable, phytopathology) A blister or tumor-like growth found on the surface of plants, caused by burrowing of insect larvae into the living tissues, especially that of the common oak gall wasp Cynips quercusfolii. 
10. (countable) A bump-like imperfection resembling a gall. 
11. A surname. 

### Verb
1. (transitive) To bother or trouble. 
2. To harass, to harry, often with the intent to cause injury. 
3. To chafe, to rub or subject to friction; to create a sore on the skin. 
4. To exasperate. 
5. To cause pitting on a surface being cut from the friction between the two surfaces exceeding the bond of the material at a point. 
6. To scoff; to jeer. 
7. To impregnate with a decoction of gallnuts in dyeing. 

## Synonyms
[[fret]] | [[resentment]] | [[chafe]] | [[rancor]] | [[crust]] | [[irk]] | [[insolence]] | [[impudence]] | [[rancour]] | [[bitterness]]