# steadfast

## Etymology
- From Middle English stedefast, from Old English stedefæst, from Proto-Germanic *stadifastuz, equivalent to stead (“place; spot; position”) +‎ fast (“firm; fixed”). Cognate with Middle Dutch stedevast (“steadfast”), Icelandic staðfastur (“steadfast”), Danish stedfast (“firmly attached, secured”), Danish stadfæste (“to confirm; ratify”), Norwegian Bokmål stadfeste (“confirm, ratify; establish”), Swedish stadfästa (“to confirm; establish”).


## Definition
### Adjective
1. Fixed or unchanging; steady. 
2. Firmly loyal or constant; unswerving. 

## Synonyms
[[constant]] | [[firm]] | [[steady]] | [[staunch]] | [[resolute]] | [[unwavering]]