# ethereal

## Etymology
- From Latin aetherius (“of or pertaining to the ether, the sky, or the air or upper air”), from Ancient Greek αἰθέριος (aithérios, “of or pertaining to the upper air”). By surface analysis, ether +‎ -ial.


## Definition
### Adjective
1. Pertaining to the (real or hypothetical) upper, purer air, or to the higher regions beyond the earth or beyond the atmosphere. 
2. Pertaining to the immaterial realm, as symbolically represented by, or (in earlier epochs) conflated with, such atmospheric and extra-atmospheric concepts. 
3. Consisting of ether; hence, exceedingly light or airy; tenuous; spiritlike; characterized by extreme delicacy, as form, manner, thought, etc. 
4. (organic chemistry) To do with diethyl ether. 

## Synonyms
[[aerial]] | [[delicate]] | [[celestial]] | [[gossamer]] | [[airy]] | [[supernal]]