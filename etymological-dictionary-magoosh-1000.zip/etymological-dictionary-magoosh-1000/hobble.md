# hobble

## Etymology
- From Middle English hobblen, hobelen, akin to Middle Dutch hoblen, hobbelen (Modern Dutch hobbelen).


## Definition
### Noun
1. (chiefly in the plural) One of the short straps tied between the legs of unfenced horses, allowing them to wander short distances but preventing them from running off. 
2. An unsteady, off-balance step. 
3. (archaic, informal) A difficult situation; a scrape. 
4. (dialect, UK and Newfoundland) An odd job; a piece of casual work. 

### Verb
1. To fetter by tying the legs; to restrict (a horse) with hobbles. 
2. To walk lame, or unevenly. 
3. (figuratively) To move roughly or irregularly. 
4. To perplex; to embarrass. 

## Synonyms
[[hitch]] | [[limp]] | [[fetter]]