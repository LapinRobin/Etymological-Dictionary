# commensurate

## Etymology
- From Latin com- (“together, with”) + mēnsūrō.


## Definition
### Adjective
1. Of a proportionate or similar measurable standard. 
2. (physics) Describing a crystal in which every atom or molecule is placed in the same relative position 

### Verb
1. To reduce to a common measure. 
2. To proportionate; to adjust. 

## Synonyms
[[corresponding]] | [[coterminous]]