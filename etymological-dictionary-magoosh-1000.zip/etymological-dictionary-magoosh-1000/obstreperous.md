# obstreperous

## Etymology
- Borrowed from Latin obstreperus, first attested circa 17th c.. Compare obstropulous.


## Definition
### Adjective
1. Attended by, or making, a loud and tumultuous noise; boisterous. 
2. Stubbornly defiant; disobedient; resistant to authority or control, whether in a noisy manner or not. 

## Synonyms
[[aggressive]] | [[defiant]]