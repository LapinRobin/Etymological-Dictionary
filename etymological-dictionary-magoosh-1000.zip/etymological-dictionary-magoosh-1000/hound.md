# hound

## Etymology
- From Middle English hound, from Old English hund, from Proto-West Germanic *hund, from Proto-Germanic *hundaz. Cognate with West Frisian hûn, Dutch hond, Luxembourgish Hond, German Hund, German Low German Hund, Danish hund, Faroese hundur, Icelandic hundur, Norwegian Bokmål hund, Norwegian Nynorsk hund, and Swedish hund, from pre-Germanic *ḱuntós (compare Latvian sùnt-ene (“big dog”), enlargement of Proto-Indo-European *ḱwṓ (“dog”) (compare Old Irish cú (“dog”), Tocharian B ku, Lithuanian šuõ, Armenian շուն (šun), Russian сука (suka)). Doublet of canine.

- From Middle English hounden, from the noun (see above).

- From Middle English hownde, hount, houn, probably from Old Norse húnn, from Proto-Germanic *hūnaz.


## Definition
### Noun
1. A dog, particularly a breed with a good sense of smell developed for hunting other animals. 
2. Any canine animal. 
3. (by extension) Someone who seeks something. 
4. (by extension) A male who constantly seeks the company of desirable women. 
5. A despicable person. 
6. A houndfish. 
7. (nautical, in the plural) Projections at the masthead or foremast, serving as a support for the trestletrees and top to rest on; foretop 
8. A side bar used to strengthen portions of the running gear of a vehicle. 
9. A small village and civil parish in Eastleigh borough, Hampshire, England (OS grid ref SU4708). 

### Verb
1. (transitive) To persistently harass. 
2. (transitive) To urge on against; to set (dogs) upon in hunting. 

## Synonyms
[[dog]] | [[trace]] | [[heel]] | [[hunt]] | [[cad]] | [[bounder]] | [[blackguard]]