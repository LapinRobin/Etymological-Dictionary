# fecund

## Etymology
- From Middle French fécond, from Latin fēcundus (“fertile”), which is related to fētus and fēmina (“woman”).


## Definition
### Adjective
1. (formal) Highly fertile; able to produce offspring. 
2. (figuratively) Leading to new ideas or innovation. 

## Synonyms
[[prolific]] | [[productive]] | [[fertile]]