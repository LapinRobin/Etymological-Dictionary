# pittance

## Etymology
- From Middle English pitaunce, from Old French pitance, pitence, from Medieval Latin *pietāntia, from Latin pietās (“piety”).


## Definition
### Noun
1. A small allowance of food and drink; a scanty meal. 
2. A meagre allowance of money or wages. 
3. A small amount. 

## Synonyms
