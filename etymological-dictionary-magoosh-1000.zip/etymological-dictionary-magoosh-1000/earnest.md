# earnest

## Etymology
- From Middle English ernest, eornest, from Old English eornest, eornost, eornust (“earnestness, zeal, seriousness, battle”), from Proto-Germanic *ernustuz (“earnest, strength, solidity, struggle, fight”), a derivative of Proto-Germanic *arniz (“efficient, capable, diligent, sure”), from Proto-Indo-European *er- (“to cause to move, arouse, increase”). Cognate with West Frisian earnst (“earnest, seriousness”), Dutch ernst (“seriousness, gravity, earnest”), German Ernst (“seriousness, earnestness, zeal, vigour”), Icelandic ern (“brisk, vigorous”), Gothic 𐌰𐍂𐌽𐌹𐌱𐌰 (arniba, “secure, certain, sure”).

- Uncertain; apparently related to erres. Compare also arles.

- earn +‎ -est


## Definition
### Noun
1. Gravity; serious purpose; earnestness. 
2. Seriousness; reality; actuality (as opposed to joking or pretence) 
3. A sum of money paid in advance as a deposit; hence, a pledge, a guarantee, an indication of something to come. 
4. A male given name from the Germanic languages, of occasional usage, variant of Ernest. 

### Verb
1. (transitive) To be serious with; use in earnest. 

### Adjective
1. (said of an action or an utterance) Serious or honest. 
2. (with a positive sense) Focused in the pursuit of an objective; eager to obtain or do. 
3. Intent; focused; showing a lot of concentration. 
4. (said of a person or a person's character) Possessing or characterised by seriousness. 
5. Strenuous; diligent. 
6. Serious; weighty; of a serious, weighty, or important nature; important. 

## Synonyms
[[solemn]] | [[serious]] | [[dear]] | [[sincere]] | [[heartfelt]] | [[devout]]