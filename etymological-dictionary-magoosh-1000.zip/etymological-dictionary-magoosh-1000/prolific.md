# prolific

## Etymology
- 1640–1650: from French prolifique, from Latin proles (“offspring”) and facere (“to make”).


## Definition
### Adjective
1. Fertile; producing offspring or fruit in abundance — applied to plants producing fruit, animals producing young, etc. 
2. Similarly producing results or performing deeds in abundance 
3. (botany) Of a flower: from which another flower is produced. 

## Synonyms
[[fecund]] | [[productive]] | [[fertile]] | [[fruitful]]