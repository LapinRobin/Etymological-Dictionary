# foible

## Etymology
- 1640–50, from Early Modern Middle French foible (“feeble”) (contemporary French faible). Doublet of feeble.


## Definition
### Noun
1. (chiefly in the plural) A quirk, idiosyncrasy, or mannerism; an unusual habit that is slightly strange or silly. 
2. A weakness or failing of character. 
3. (fencing) Part of a sword between the middle and the point, weaker than the forte. 

### Adjective
1. (obsolete) Weak; feeble. 

## Synonyms
[[idiosyncrasy]] | [[mannerism]]