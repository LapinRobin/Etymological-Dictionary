# whimsical

## Etymology
- From whimsy +‎ -ical.


## Definition
### Adjective
1. Given to whimsy. 

## Synonyms
[[arbitrary]] | [[capricious]] | [[impulsive]]