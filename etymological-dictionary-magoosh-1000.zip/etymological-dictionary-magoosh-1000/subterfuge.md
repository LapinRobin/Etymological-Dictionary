# subterfuge

## Etymology
- Borrowed from Middle French subterfuge, from Medieval Latin subterfugium, from Latin subterfugiō (“I flee secretly”), from subter (“under”) and fugiō (“I flee”).


## Definition
### Noun
1. (countable) An indirect or deceptive device or stratagem; a blind. Refers especially to war and diplomatics. 
2. (uncountable) Deception; misrepresentation of the true nature of an activity. 

## Synonyms
[[blind]]