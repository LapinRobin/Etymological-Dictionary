# begrudge

## Etymology
- From Middle English bigrucchen (“to grumble at”), equivalent to be- (“at, about, over”) +‎ grudge. Compare also English begrouch.


## Definition
### Verb
1. To grudge about or over; be envious or covetous. 
2. To be reluctant. 
3. To give reluctantly. 

## Synonyms
[[envy]] | [[resent]]