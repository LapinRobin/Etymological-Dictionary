# solecism

## Etymology
- Borrowed from French solécisme, from Latin soloecismus, from Ancient Greek σολοικισμός (soloikismós), from σόλοικος (sóloikos, “speaking incorrectly”), from Σόλοι (Sóloi), an ancient Athenian colony in Cilicia whose inhabitants spoke a dialect regarded by Athenians as a corrupted and barbarous form of Attic Greek. Compare Atticism.


## Definition
### Noun
1. An erroneous or improper usage. 
2. (grammar) Error in the use of language. 
3. (by extension) A faux pas or breach of etiquette; a transgression against the norms of expected behavior. 

## Synonyms
[[slip]] | [[faux pas]] | [[gaffe]]