# wax

## Etymology
- 
From Middle English wax, from Old English weax, from Proto-Germanic *wahsą, possibly from Proto-Indo-European *woḱ-so-. Cognate with Saterland Frisian Woaks (“wax”), West Frisian waaks (“wax”), Dutch was (“wax”), German Wachs (“wax”), Norwegian voks (“wax”); and with Lithuanian vaškas (“wax”), Proto-Slavic *voskъ (“wax”).

- 
From Middle English waxen, from the noun (see above).

- 
From Middle English waxen, from Old English weaxan (“to wax, grow, be fruitful, increase, become powerful, flourish”), from Proto-West Germanic *wahsan, from Proto-Germanic *wahsijaną (“to grow”), from Proto-Indo-European *h₂weg- (“to grow, increase”). 

- Uncertain; probably from phrases like to wax angry, wax wode, and similar (see Etymology 2, above).


## Definition
### Noun
1. Beeswax. 
2. Earwax. 
3. Any oily, water-resistant, solid or semisolid substance; normally long-chain hydrocarbons, alcohols or esters. 
4. Any preparation containing wax, used as a polish. 
5. (uncountable, music, informal) The phonograph record format for music. 
6. (US, dialect) A thick syrup made by boiling down the sap of the sugar maple and then cooling it. 
7. (US, slang) A type of drugs with as main ingredients weed oil and butane; hash oil. 
8. (rare) The process of growing. 
9. (dated, colloquial) An outburst of anger, a loss of temper, a fit of rage. 
10. A surname. 

### Adjective
1. Made of wax. 

### Verb
1. (transitive) To apply wax to (something, such as a shoe, a floor, a car, or an apple), usually to make it shiny. 
2. (transitive) To remove hair at the roots from (a part of the body) by coating the skin with a film of wax that is then pulled away sharply. 
3. (transitive, informal) To defeat utterly. 
4. (transitive, slang) To kill, especially to murder a person. 
5. (transitive, archaic, usually of a musical or oral performance) To record. 
6. (intransitive, copulative, literary) To increasingly assume the specified characteristic. 
7. (intransitive, literary) To grow. 
8. (intransitive, of the moon) To appear larger each night as a progression from a new moon to a full moon. 
9. (intransitive, of the tide) To move from low tide to high tide. 

## Synonyms
[[rise]] | [[mount]] | [[full]] | [[climb]]