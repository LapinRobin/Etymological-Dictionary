# amuck

## Definition
### Adverb
1. Alternative form of amok  

### Noun
1. Alternative form of amok  

## Synonyms
[[insane]] | [[berserk]] | [[amok]] | [[possessed]]