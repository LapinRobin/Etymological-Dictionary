# hamper

## Etymology
- From Middle English hamper, contracted from hanaper, hanypere, from Anglo-Norman hanaper, Old French hanapier, hanepier (“case for holding a large goblet or cup”), from hanap (“goblet, drinking cup”), from Frankish *hnapp (“cup, bowl, basin”), from Proto-Germanic *hnappaz (“cup, bowl”).

- From Middle English hamperen, hampren (“to hamper, oppress”), probably of the same origin as English hamble (“to limp”), Scots hamp (“to halt in walking, stutter”), Dutch haperen (“to falter, hesitate”), German hemmen (“to stop, hinder, check”). More at hamble.


## Definition
### Noun
1. A large basket, usually with a cover, used for the packing and carrying of articles or small animals 
2. (uncommon outside New England) A wicker or plastic basket specifically for holding laundry (from clothes hamper), as opposed to a covered wicker basket which is a true hamper 
3. (UK) A gift basket. 
4. A shackle; a fetter; anything which impedes. 
5. (nautical) Articles ordinarily indispensable, but in the way at certain times. 

### Verb
1. (transitive) To put into a hamper. 
2. (transitive) To put a hamper or fetter on; to shackle 
3. To impede in motion or progress. 

## Synonyms
[[bond]] | [[hinder]] | [[cramp]] | [[shackle]] | [[trammel]] | [[handicap]] | [[halter]] | [[disadvantage]]