# tractable

## Etymology
- From Middle English tractable, tractabel, from Latin tractābilis (“that may be touched, handled, or managed”), from tractō (“take in hand, handle, manage”), frequentative of trahō (“draw”).


## Definition
### Adjective
1. (of people) Capable of being easily led, taught, or managed. 
2. (of a problem) Easy to deal with or manage 
3. Capable of being shaped; malleable. 
4. (obsolete) Capable of being handled or touched. 
5. (mathematics) Sufficiently operationalizable or useful to allow a mathematical calculation to proceed toward a solution. 
6. (computer science, of a decision problem) Algorithmically solvable fast enough to be practically relevant, typically in polynomial time. 

## Synonyms
[[amenable]] | [[docile]] | [[malleable]] | [[responsive]] | [[ductile]]