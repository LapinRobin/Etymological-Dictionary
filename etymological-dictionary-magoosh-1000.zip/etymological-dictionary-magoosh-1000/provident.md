# provident

## Etymology
- Borrowed from Latin prōvidēns, prōvidentis, present participle of prōvideō (“I foresee; I am cautious; I provide”): compare French provident. See provide. Doublet of prudent.


## Definition
### Adjective
1. Possessing, exercising, or demonstrating great care and consideration for the future. 
2. Showing care in the use of something (especially money or provisions), so as to avoid wasting it. 
3. Providing (for someone’s needs). 

## Synonyms
[[prudent]] | [[long]] | [[careful]] | [[thrifty]]