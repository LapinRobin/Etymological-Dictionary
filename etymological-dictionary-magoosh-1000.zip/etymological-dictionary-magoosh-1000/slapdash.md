# slapdash

## Etymology
- slap +‎ dash. First attested in the late 17th century, meaning "careless".


## Definition
### Adjective
1. Produced or carried out hastily; haphazard; careless. 

### Adverb
1. In a hasty or careless manner. 
2. Directly, right there; slap-bang. 
3. With a slap; all at once; slap. 

### Verb
1. (colloquial) To apply, or apply something to, in a hasty, careless, or rough manner; to roughcast. 

## Synonyms
[[bolt]] | [[bang]] | [[smack]] | [[haphazard]] | [[sloppy]] | [[slap]] | [[careless]] | [[slipshod]]