# puissant

## Etymology
- From Middle English puissaunt, from Middle French puissant, poissant, Anglo-Norman puissant, Old French pussant, et al., present participle of pooir (“to be able”), ultimately from Latin posse (“be able”).


## Definition
### Adjective
1. (archaic or literary) Powerful, mighty, having authority. 

## Synonyms
[[powerful]]