# expunge

## Etymology
- Learned borrowing from Latin expungere.


## Definition
### Verb
1. (transitive) To erase or strike out. 
2. (transitive) To eliminate completely; to annihilate. 
3. (transitive, computing) To delete permanently (e-mail etc.) that was previously marked for deletion but still stored. 

## Synonyms
[[strike]] | [[excise]]