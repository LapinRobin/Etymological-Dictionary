# furtive

## Etymology
- From Middle English *furtyve (implied in furtyvely (adverb)), from Middle French furtif, furtive (“furtive, stealthy”) (modern French furtif), from Latin fūrtīvus (“clandestine, furtive, secret; concealed, hidden; stolen”), from fūrtum (“theft; robbery”) (from fūr (“thief”), ultimately from Proto-Indo-European *bʰer- (“to bear, carry”)) + -īvus (suffix forming adjectives).


## Definition
### Adjective
1. Stealthy. 
2. Exhibiting guilty or evasive secrecy. 

## Synonyms
[[sneak]] | [[covert]] | [[surreptitious]] | [[sneaky]] | [[stealthy]] | [[lurking]] | [[concealed]]