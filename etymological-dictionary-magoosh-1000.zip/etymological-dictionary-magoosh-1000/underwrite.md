# underwrite

## Etymology
- From Middle English underwriten, from Old English underwrītan (“to write at the foot of, write under, subscribe”), equivalent to under- +‎ write. Compare Dutch onderschrijven (“to endorse”), German unterschreiben (“to sign; endorse”), Danish underskrive (“to sign; endorse”).


## Definition
### Verb
1. (transitive) To write below or under; subscribe. 
2. (transitive, intransitive, obsolete) To subscribe (a document, policy etc.) with one's name. 
3. (transitive) To sign; to put one's name to. 
4. (transitive) To agree to pay by signing one's name; subscribe. 
5. (transitive) Specifically, to assume financial responsibility for something, and guarantee it against failure. 
6. (intransitive, insurance) To act as an underwriter. 
7. (transitive) To support, lend support to, guarantee the basis of. 
8. (obsolete, transitive) To submit to; put up with. 

## Synonyms
[[cover]] | [[insure]]