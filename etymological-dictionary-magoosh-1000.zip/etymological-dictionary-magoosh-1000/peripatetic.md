# peripatetic

## Etymology
- From French péripatétique, from Latin peripatēticus, from Ancient Greek περιπατητικός (peripatētikós, “given to walking around”), from περιπατέω (peripatéō, “I walk around”), from περί (perí, “around”) (English peri-)+ πατέω (patéō, “I walk”).


## Definition
### Adjective
1. Tending to walk about. 
2. Constantly travelling. 
3. Of or pertaining to the philosophy or methods of Aristotle, or to his followers. 
4. (philosophy, usually capitalized) Alternative letter-case form of Peripatetic  

### Noun
1. One who walks about; a pedestrian; an itinerant. 
2. (historical) A disciple of Aristotle. 
3. (philosophy, usually capitalized) Alternative letter-case form of Peripatetic (“Aristotelian”)  

## Synonyms
[[itinerant]]