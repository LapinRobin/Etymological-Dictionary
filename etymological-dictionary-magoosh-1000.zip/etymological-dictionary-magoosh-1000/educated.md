# educated

## Etymology
- educate +‎ -ed


## Definition
### Adjective
1. Having attained a level of higher education, such as a college degree. 
2. Based on relevant information. 

## Synonyms
[[knowledgeable]] | [[taught]] | [[learned]] | [[literate]] | [[informed]] | [[enlightened]] | [[knowing]]