# veneer

## Etymology
- From German Furnier, from furnieren (“to inlay, cover with a veneer”), from French fournir (“to furnish, accomplish”), from Middle French fornir, from Old French fornir, furnir (“to furnish”), from Old Frankish frumjan (“to provide”), from Proto-Germanic *frumjaną (“to further, promote”). Cognate with Old High German frumjan, frummen (“to accomplish, execute, provide”), Old English fremian (“to promote, perform”). More at furnish.


## Definition
### Noun
1. A thin decorative covering of fine material (usually wood) applied to coarser wood or other material. 
2. An attractive appearance that covers or disguises one's true nature or feelings. 

### Verb
1. (transitive, woodworking) To apply veneer to. 
2. (transitive, figuratively) To disguise with apparent goodness. 

## Synonyms
