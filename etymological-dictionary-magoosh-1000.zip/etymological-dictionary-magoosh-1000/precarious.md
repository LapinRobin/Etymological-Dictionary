# precarious

## Etymology
- From Latin precārius (“begged for, obtained by entreaty”), from prex, precis (“prayer”). Compare French précaire, Portuguese precário, and Spanish and Italian precario.

- pre- +‎ carious


## Definition
### Adjective
1. (comparable) Dangerously insecure or unstable; perilous. 
2. (law) Depending on the intention of another. 
3. (dentistry) Relating to incipient caries. 

## Synonyms
[[perilous]] | [[dangerous]] | [[insecure]] | [[parlous]] | [[shaky]] | [[uneasy]] | [[unstable]]