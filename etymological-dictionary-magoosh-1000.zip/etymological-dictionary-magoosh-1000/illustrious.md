# illustrious

## Etymology
- From Latin illūstris (“bright, shining; distinguished, prominent, illustrious”)  +‎ -ous (“suffix forming adjectives from nouns, to denote possession or presence of a quality in any degree”). Illūstris is derived from illūstrō (“to brighten, illuminate; to make famous or illustrious”), from in- (“prefix meaning ‘in, inside’”) + lustrō (“to purify by making a sacrifice; to brighten, illuminate”) (from lustrō (“purificatory sacrifice”), possibly ultimately from Proto-Indo-European *lewk- (“bright; to shine”) or *lewh₃- (“to wash”)).


## Definition
### Adjective
1. Admired, distinguished, respected, or well-known, especially due to past achievements or noble qualities. 

## Synonyms
[[proud]] | [[renowned]] | [[known]] | [[famous]] | [[notable]] | [[glorious]] | [[noted]] | [[redoubtable]]