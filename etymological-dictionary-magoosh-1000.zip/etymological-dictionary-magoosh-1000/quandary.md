# quandary

## Etymology
- 16th century. Origin unknown; perhaps a dialectal corruption (simulating a word of Latin origin with suffix -ary) of wandreth (“evil, plight, peril, adversity, difficulty”), from Middle English wandreth, from Old Norse vandræði (“difficulty, trouble”), from vándr (“difficult, requiring pains and care”).


## Definition
### Noun
1. A state of not knowing what to decide; a state of difficulty or perplexity; a state of uncertainty, hesitation or puzzlement. 
2. A dilemma, a difficult decision or choice. 

## Synonyms
[[dilemma]] | [[predicament]] | [[plight]]