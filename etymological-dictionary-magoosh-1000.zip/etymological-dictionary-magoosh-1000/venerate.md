# venerate

## Etymology
- From Latin venerātus, perfect passive participle of veneror (“worship, reverence”).


## Definition
### Verb
1. (transitive) To treat with great respect and deference. 
2. (transitive) To revere or hold in awe. 

## Synonyms
[[fear]] | [[reverence]] | [[revere]]