# incontrovertible

## Etymology
- in- +‎ controvertible


## Definition
### Adjective
1. Not capable of being denied, challenged, or disputed; closed to questioning. 

## Synonyms
[[positive]] | [[irrefutable]]