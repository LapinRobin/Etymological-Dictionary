# dictatorial

## Etymology
- dictator +‎ -ial.


## Definition
### Adjective
1. of or pertaining to a dictator 
2. in the manner of a dictator, usually with callous disregard for others. 

## Synonyms
[[autocratic]] | [[overbearing]] | [[authoritarian]] | [[despotic]]