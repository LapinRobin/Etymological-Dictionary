# easygoing

## Etymology
- easy +‎ going


## Definition
### Adjective
1. (of a person) calm, relaxed, casual and informal 
2. (of a journey or pace) unhurried 

## Synonyms
[[easy]] | [[mellow]] | [[placid]] | [[tolerant]] | [[laid-back]] | [[relaxed]]