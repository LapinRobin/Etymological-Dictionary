# conciliate

## Etymology
- Borrowed from Latin conciliātus, perfect passive participle of conciliō (“I unite”), from concilium (“council, meeting”).


## Definition
### Verb
1. (transitive, obsolete) To acquire, to procure. 
2. (transitive, now rare) To reconcile (discordant theories, demands etc.); to make compatible, bring together. 
3. (transitive) To make calm and content, or regain the goodwill of; to placate. 
4. (intransitive) To mediate in a dispute. 

## Synonyms
[[accommodate]] | [[assuage]] | [[reconcile]] | [[settle]] | [[placate]] | [[appease]] | [[gentle]] | [[make up]] | [[mollify]] | [[pacify]]