# insipid

## Etymology
- From French insipide, from Latin īnsipidus (“tasteless”), from in- (“not”) + sapidus (“savory”). In some senses, perhaps influenced by insipient (“unwise, foolish, stupid”).


## Definition
### Adjective
1. Unappetizingly flavorless. 
2. Flat; lacking character or definition. 

## Synonyms
[[flat]] | [[vapid]] | [[innocuous]] | [[bland]] | [[jejune]]