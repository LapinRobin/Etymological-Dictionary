# rustic

## Etymology
- From Latin rūsticus. Doublet of roister.


## Definition
### Adjective
1. Country-styled or pastoral; rural. 
2. Unfinished or roughly finished. 
3. Crude, rough. 
4. Simple; artless; unaffected. 

### Noun
1. A (sometimes unsophisticated) person from a rural area. 
2. A noctuoid moth. 
3. Any of various nymphalid butterflies having brown and orange wings, especially Cupha erymanthis. 

## Synonyms
[[bucolic]] | [[pastoral]] | [[rural]] | [[provincial]]