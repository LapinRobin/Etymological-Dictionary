# ravenous

## Etymology
- From Middle English ravenous, ravynous, from Old French ravineus.


## Definition
### Adjective
1. Very hungry. 
2. Grasping; characterized by strong desires. 

## Synonyms
[[rapacious]] | [[voracious]] | [[esurient]] | [[hungry]] | [[famished]]