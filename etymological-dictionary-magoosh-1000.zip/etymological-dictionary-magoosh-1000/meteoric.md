# meteoric

## Etymology
- meteor +‎ -ic


## Definition
### Adjective
1. Of, pertaining to, or originating from a meteor. 
2. (by extension) Like a meteor in speed, brilliance, or ephemeralness. 
3. (geology, of water) Originating in the atmosphere. 
4. Influenced by the weather. 

## Synonyms
[[fast]]