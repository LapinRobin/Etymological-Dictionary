# chastise

## Etymology
- From Middle English chastisen, from Old French chastier, from Latin castīgō. See also the doublets chasten and castigate and cf. also chaste.


## Definition
### Verb
1. To punish (someone), especially by corporal punishment. 
2. To castigate; to severely scold or censure (someone). 
3. To lightly criticize or correct (someone). 

## Synonyms
[[correct]] | [[castigate]] | [[chasten]]