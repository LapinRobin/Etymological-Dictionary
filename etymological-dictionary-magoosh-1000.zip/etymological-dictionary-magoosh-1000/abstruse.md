# abstruse

## Etymology
- Learned borrowing from Latin abstrūsus (“concealed, hidden; having been concealed”), an adjective use of the perfect passive participle of abstrūdō (“to conceal, hide; to push or thrust away”), from abs- (from ab- (prefix meaning ‘away; from; away from’)) + trūdō (“to push, shove; to thrust”) (ultimately from Proto-Indo-European *trewd- (“to push; to thrust”)).


## Definition
### Adjective
1. Difficult to comprehend or understand; obscure. 
2. (obsolete) Concealed or hidden; secret. 

## Synonyms
[[esoteric]] | [[deep]] | [[recondite]]