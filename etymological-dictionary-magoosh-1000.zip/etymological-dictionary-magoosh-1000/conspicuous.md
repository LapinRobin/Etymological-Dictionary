# conspicuous

## Etymology
- From Latin conspicuus (“visible, striking”), from cōnspicere (“to notice”), from con- (“with, together”) + specere (“to look at”).


## Definition
### Adjective
1. Obvious or easy to notice. 
2. Noticeable or attracting attention, especially if unattractive. 

## Synonyms
[[egregious]] | [[salient]] | [[open]] | [[pretentious]] | [[big]] | [[prominent]] | [[large]] | [[bold]] | [[gross]] | [[rank]] | [[ostentatious]] | [[outstanding]] | [[blatant]] | [[obvious]] | [[spectacular]] | [[flagrant]] | [[striking]] | [[obtrusive]] | [[blazing]] | [[visible]] | [[marked]] | [[noticeable]] | [[glaring]]