# reconcile

## Etymology
- Borrowed from Latin reconciliō.


## Definition
### Verb
1. To restore a friendly relationship; to bring back to harmony. 
2. To make things compatible or consistent. 
3. To make the net difference in credits and debits of a financial account agree with the balance. 

## Synonyms
[[accommodate]] | [[settle]] | [[submit]] | [[resign]] | [[make up]] | [[conciliate]]