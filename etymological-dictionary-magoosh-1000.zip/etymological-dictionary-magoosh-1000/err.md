# err

## Etymology
- From Middle English erren, from Old French errer (“to wander, err, mistake”), from Latin errō (“wander, stray, err, mistake”, verb), from Proto-Indo-European *h₁ers- (“to be angry, lose one's temper”). Cognate with Old English eorre, ierre (“anger, wrath, ire”), Old English iersian (“to be angry with, rage, irritate, provoke”), Old English ierre (“wandering, gone astray, confused”).

- err


## Definition
### Verb
1. (intransitive, formal) To make a mistake. 
2. (intransitive) To sin. 
3. (archaic) to stray. 

## Synonyms
[[slip]] | [[drift]] | [[mistake]] | [[stray]]