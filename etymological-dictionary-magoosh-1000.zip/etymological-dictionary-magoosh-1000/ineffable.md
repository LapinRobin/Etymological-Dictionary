# ineffable

## Etymology
- From Middle French ineffable (modern French ineffable), from Latin ineffābilis, from in- (“not”) +‎ effor (“utter”) +‎ -bilis (“-able”).


## Definition
### Adjective
1. Beyond expression in words; unspeakable. 
2. Forbidden to be uttered; taboo. 

## Synonyms
[[sacred]]