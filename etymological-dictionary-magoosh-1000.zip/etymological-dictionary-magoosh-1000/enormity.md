# enormity

## Etymology
- From Late Middle English ēnorme (“monstrous or unnatural act; enormity”), from Old French énormité (“enormity”), from Latin ēnormitās (“irregularity; enormity”), from ēnōrmis (“irregular, unusual; enormous, immense”) + -itās (suffix forming nouns indicating states of being). Ēnōrmis is derived from e- (a variant of ex- (prefix meaning ‘out; away’) + nōrma (“norm, standard”) + -is (Latin suffix forming adjectives from nouns).


## Definition
### Noun
1. (obsolete) Deviation from what is normal or standard; irregularity, abnormality. 
2. (uncountable) Deviation from moral normality; extreme wickedness, nefariousness, or cruelty. 
3. (countable) A breach of law or morality; a transgression, an act of evil or wickedness. 
4. (uncountable, sometimes proscribed) Great size; enormousness, hugeness, immenseness. 

## Synonyms
