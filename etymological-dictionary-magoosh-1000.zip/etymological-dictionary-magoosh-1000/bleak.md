# bleak

## Etymology
- From Middle English bleke (also bleche, whence the English doublet bleach (“pale, bleak”)), and bleike (due to Old Norse), and earlier Middle English blak, blac (“pale, wan”), from Old English blǣc, blǣċ, blāc (“bleak, pale, pallid”) and Old Norse bleikr (“pale, whitish”), all from Proto-Germanic *blaikaz (“pale, shining”). 

- From Middle English bleke (“small river fish, bleak, blay”), perhaps an alteration (due to English blǣc (“bright”) or Old Norse bleikja) of Old English blǣġe (“bleak, blay, gudgeon”); or perhaps from a diminutive of Middle English *bleye (“blay”), equivalent to blay +‎ -ock or blay +‎ -kin. See blay.


## Definition
### Adjective
1. Without color; pale; pallid. 
2. Desolate and exposed; swept by cold winds. 
3. Unhappy; cheerless; miserable; emotionally desolate. 

### Noun
1. A small European river fish (Alburnus alburnus), of the family Cyprinidae. 

## Synonyms
[[black]] | [[cold]] | [[bare]] | [[stark]] | [[desolate]] | [[barren]] | [[raw]] | [[dim]] | [[cutting]] | [[hopeless]]