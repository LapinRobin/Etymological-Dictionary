# impermeable

## Etymology
- From French imperméable, from Latin impermeābilis, from im- + permeābilis (“permeable”).


## Definition
### Adjective
1. Impossible to permeate. 
2. Not allowing passage, especially of liquids; waterproof. 

## Synonyms
[[rubber]]