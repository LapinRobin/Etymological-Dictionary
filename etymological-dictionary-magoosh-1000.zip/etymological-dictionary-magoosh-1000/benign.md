# benign

## Etymology
- From Middle English benigne, benygne, from Old French benigne, from Latin benignus (“kind, good”), from bene (“well”) + genus (“origin, kind”). Compare malign.


## Definition
### Adjective
1. Kind; gentle; mild. 
2. (of a climate or environment) mild and favorable 
3. (in combination) Not harmful to the environment. 
4. (medicine) Not posing any serious threat to health; not particularly aggressive or recurrent. 

## Synonyms
[[kind]] | [[genial]] | [[kindly]]