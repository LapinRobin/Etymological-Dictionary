# arriviste

## Etymology
- Borrowed from French arriviste.


## Definition
### Noun
1. (derogatory) An upstart or newcomer; nouveau riche; parvenu; an ambitious, brash or arrogant person who has yet to integrate with his or her new social group. 

## Synonyms
