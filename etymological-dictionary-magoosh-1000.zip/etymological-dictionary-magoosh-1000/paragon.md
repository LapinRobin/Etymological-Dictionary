# paragon

## Etymology
- From Anglo-Norman paragone, peragone, Middle French paragon, from Italian paragone (“comparison”) or Spanish parangón, from paragonare, from Ancient Greek παρακονάω (parakonáō, “I sharpen, whet”), from παρά (pará) +‎ ἀκόνη (akónē, “whetstone”) (from Proto-Indo-European *h₂eḱ- (“sharp”)).


## Definition
### Noun
1. A person of preeminent qualities, who acts as a pattern or model for others. 
2. (obsolete) A companion; a match; an equal. 
3. (obsolete) Comparison; competition. 
4. (typography, printing, dated) The size of type between great primer and double pica, standardized as 20-point. 
5. A flawless diamond of at least 100 carats. 

### Verb
1. To compare; to parallel; to put in rivalry or emulation with. 
2. To compare with; to equal; to rival. 
3. To serve as a model for; to surpass. 
4. To be equal; to hold comparison. 

## Synonyms
[[ideal]] | [[apotheosis]] | [[idol]] | [[nonpareil]] | [[saint]] | [[perfection]]