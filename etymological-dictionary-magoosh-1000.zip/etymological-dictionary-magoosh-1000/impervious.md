# impervious

## Etymology
- From Latin impervius (“that cannot be passed through”), from in- (“not”) + pervius (“letting things through”).


## Definition
### Adjective
1. Unaffected or unable to be affected by something. 
2. Preventive of any penetration; impenetrable, impermeable, particularly of water. 
3. Immune to damage or effect. 

## Synonyms
[[resistant]]