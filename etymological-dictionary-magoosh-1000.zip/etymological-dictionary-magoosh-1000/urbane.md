# urbane

## Etymology
- A variant of urban  +‎ -ane (a variant of -an (suffix meaning ‘of or pertaining to’ forming adjectives)). Urban is borrowed from Middle French urbain (“belonging to a city, urban; courteous, refined, urbane”) (modern French urbain), or from its etymon Latin urbānus (“of or belonging to a city, urban; of manners or style: like those of city dwellers: cultivated, polished, refined, sophisticated”), from urbs (“city; walled town; Rome”) (further etymology uncertain, possibly from Proto-Indo-European *gʰerdʰ- (“to encircle, enclose; a belt; an enclosure, fence”) or *werbʰ- (“to enclose”)) + -ānus (suffix meaning ‘of or pertaining to’ forming adjectives).


## Definition
### Adjective
1. (of a person, usually a man) Courteous, polite, refined, and suave. 

## Synonyms
[[sophisticated]] | [[gracious]] | [[cosmopolitan]] | [[svelte]] | [[refined]] | [[polished]]