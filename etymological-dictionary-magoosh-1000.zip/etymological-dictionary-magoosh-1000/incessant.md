# incessant

## Etymology
- From Late Middle English incessaunte, from Late Latin incessāns, incessantem, from Latin in- +‎ cessāns.


## Definition
### Adjective
1. Without pause or stop; not ending, especially to the point of annoyance. 

## Synonyms
[[perpetual]] | [[constant]] | [[continuous]] | [[endless]] | [[continual]]