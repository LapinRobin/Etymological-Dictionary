# mesmerize

## Etymology
- Back-formation from mesmerism, thus mesmerism +‎ -ize; first attested in 1829.


## Definition
### Verb
1. To exercise mesmerism on; to affect another person, such as to heal or soothe, through the use of animal magnetism. 
2. To spellbind; to enthrall. 

## Synonyms
