# aberrant

## Etymology
- From Latin aberrāns, present active participle of aberrō (“go astray; err”), from ab (“from”) + errō (“to wander”). See aberr.


## Definition
### Adjective
1. Differing from the norm. 
2. (sometimes figuratively) Straying from the right way; deviating from morality or truth. 
3. (botany, zoology) Deviating from the ordinary or natural type; exceptional; abnormal. 

### Noun
1. A person or object that deviates from the rest of a group. 
2. (biology) A group, individual, or structure that deviates from the usual or natural type, especially with an atypical chromosome number. 

## Synonyms
[[deviant]] | [[abnormal]]