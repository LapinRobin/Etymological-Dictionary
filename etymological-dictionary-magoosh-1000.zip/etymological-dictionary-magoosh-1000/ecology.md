# ecology

## Etymology
- Calque of German Ökologie (coined by Ernst Haeckel), from Ancient Greek οἶκος (oîkos, “house”) + -λογία (-logía, “study of”). By surface analysis, eco- +‎ -logy.


## Definition
### Noun
1. (biology) The branch of biology dealing with the relationships of organisms with their environment and with each other. 

## Synonyms
