# chary

## Etymology
- From Middle English chari, charre, charri, chary, Early Middle English cearig, chariȝ (“concerned with, diligent; sad, sorrowful; of a person: cherished, loved”), from Old English ċeariġ (“careful; pensive; chary, wary; anxious, sad, sorrowful; dire, grievous”), from Proto-West Germanic *karag (“anxious; sad”), from Proto-Germanic *karō + *-gaz, ultimately from Proto-Indo-European *ǵeh₂r- (“exclamation; voice”) + *-kos (suffix forming adjectives with the meaning ‘pertaining to; typical of’)); analysable as care +‎ -y.


## Definition
### Adjective
1. Careful, cautious, shy, wary. 
2. Excessively particular or fussy about details; fastidious. 
3. Not disposed to give freely; not lavish; frugal, sparing. 
4. (obsolete) Cared for, regarded as precious; cherished. 

### Adverb
1. Synonym of charily: carefully, cautiously, warily. 

## Synonyms
[[cautious]] | [[cagey]]