# corollary

## Etymology
- From Middle English, from Late Latin corōllārium (“money paid for a garland; gift, gratuity, corollary; consequence, deduction”), from corōlla (“small garland”), diminutive of corōna (“crown”).


## Definition
### Noun
1. A gift beyond what is actually due; an addition or superfluity. 
2. An a fortiori occurrence, as a result of another effort without significant additional effort. 
3. (mathematics, logic) A proposition which follows easily from the proof of another proposition. 

### Adjective
1. Occurring as a natural consequence or result; attendant; consequential. 
2. (rare) Forming a proposition that follows from one already proved. 

## Synonyms
