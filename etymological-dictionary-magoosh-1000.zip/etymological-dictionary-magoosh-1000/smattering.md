# smattering

## Etymology
- From smatter +‎ -ing.

- From Middle English smateringe, smattrynge, equivalent to smatter +‎ -ing.


## Definition
### Noun
1. A superficial or shallow knowledge of a subject. 
2. A small number or amount of something. 

## Synonyms
[[handful]]