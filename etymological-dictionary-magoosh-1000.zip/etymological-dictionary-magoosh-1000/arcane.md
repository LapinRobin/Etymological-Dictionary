# arcane

## Etymology
- Borrowed from Latin arcānus (“hidden, secret”), from arceō (“to shut up, enclose”); cognate with Latin arca (“a chest”).


## Definition
### Adjective
1. Understood by only a few. 
2. (by extension) Obscure, mysterious. 
3. Requiring secret or mysterious knowledge to understand. 
4. Extremely old (e.g. interpretation or knowledge), and possibly irrelevant. 

## Synonyms
[[esoteric]]