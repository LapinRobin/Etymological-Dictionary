# doughty

## Etymology
- The adjective is derived from Middle English doughty (“brave, bold, valiant”), from Old English dohtiġ, dyhtiġ (“competent, good, strong, valiant”), from Proto-West Germanic *duhtīg.


## Definition
### Adjective
1. (dated or archaic) Bold; brave, courageous. 

### Noun
1. (archaic, rare) A person who is bold or brave. 
2. A surname transferred from the nickname. 

## Synonyms
[[hardy]] | [[fearless]]