# inveterate

## Etymology
- From Latin inveteratus (“of long standing, chronic”), form of inveterare, from in- (“in, into”) + veterare (“to age”), from vetus, form of veteris (“old”); latter ancestor to veteran.


## Definition
### Adjective
1. firmly established from having been around for a long time; of long standing 
2. (of a person) Having had a habit for a long time 
3. Malignant; virulent; spiteful. 

### Verb
1. (obsolete) To fix and settle after a long time; to entrench. 

## Synonyms
[[chronic]] | [[habitual]]