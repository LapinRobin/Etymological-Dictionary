# precipitous

## Etymology
- From obsolete French précipiteux, from Vulgar Latin *praecipitosus. Equivalent to precipice (“steep”) +‎ -ous.


## Definition
### Adjective
1. Steep, like a precipice 
2. Headlong 
3. Hasty; rash; quick; sudden 

## Synonyms
[[sharp]] | [[steep]] | [[abrupt]]