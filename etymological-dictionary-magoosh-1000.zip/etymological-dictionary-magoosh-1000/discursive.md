# discursive

## Etymology
- Borrowed from Middle French discursif, formed from the stem of Latin discursus and the suffix -if, and in part borrowed from Medieval Latin discursivus.


## Definition
### Adjective
1. (of speech or writing) Tending to digress from the main point; rambling. 
2. (philosophy) Using reason and argument rather than intuition. 

## Synonyms
[[logical]] | [[rambling]] | [[indirect]]