# effeminate

## Etymology
- From Middle English effeminat, effemynat, from Latin effēminātus, past participle of effēminō, from fēmina (“woman”).


## Definition
### Adjective
1. (often derogatory, of a man or boy) Exhibiting behaviour or mannerisms considered typical of a female; unmasculine. 
2. (obsolete) Womanly; tender, affectionate, caring. 

### Verb
1. (transitive, archaic or nonstandard) To make womanly; to unman. 
2. (intransitive) To become womanly. 

### Noun
1. An effeminate person. 

## Synonyms
[[soft]] | [[weak]] | [[epicene]] | [[emasculate]] | [[sissy]]