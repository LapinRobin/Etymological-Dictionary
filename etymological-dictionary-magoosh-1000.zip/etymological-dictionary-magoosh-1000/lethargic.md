# lethargic

## Etymology
- From Ancient Greek ληθαργικός (lēthargikós), from λήθαργος (lḗthargos, “forgetful, lethargic”), from λήθη (lḗthē, “a forgetting, forgetfulness”) (from which Lethe (“river in Hades”)) + ἀργός (argós, “not working”).


## Definition
### Adjective
1. sluggish, slow 
2. indifferent, apathetic 

## Synonyms
[[languid]] | [[lackadaisical]] | [[listless]] | [[groggy]] | [[dazed]] | [[foggy]] | [[logy]]