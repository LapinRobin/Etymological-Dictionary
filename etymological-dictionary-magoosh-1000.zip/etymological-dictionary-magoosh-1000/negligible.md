# negligible

## Etymology
- From negligence/negligent +‎ -ible, as if from New Latin *negligibilis, from Latin neglegō (“I neglect”) + -ibilis (“-ible”).


## Definition
### Adjective
1. Able to be neglected, ignored or excluded from consideration; too small or unimportant to be of concern. 

## Synonyms
[[paltry]] | [[minimum]] | [[minimal]] | [[trifling]]