# miser

## Etymology
- From Late Latin miser (“wretched, unfortunate, unhappy, miserable, sick, ill, bad, worthless, etc.”).


## Definition
### Noun
1. (derogatory) A person who hoards money rather than spending it; one who is cheap or extremely parsimonious. 
2. A kind of earth auger, typically large-bored and often hand-operated. 
3. A surname. 

## Synonyms
