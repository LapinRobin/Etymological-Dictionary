# noisome

## Etymology
- From Middle English noysom; equivalent to noy +‎ -some (short for annoy, from an(n)oien, enoien from Anglo-Norman anuier, from Old French enuier (French ennuyer), from Late Latin inodiare (“to make hateful”), from in- (intensive prefix) + odium (“hate”)).


## Definition
### Adjective
1. (literary) Morally hurtful or noxious. 
2. (literary) Hurtful or noxious to health; unwholesome, insalubrious. 
3. (literary) Offensive to the senses; disgusting, unpleasant, nauseous, especially having an undesirable smell. 

## Synonyms
[[foul]] | [[vile]] | [[offensive]] | [[funky]] | [[nauseous]] | [[fetid]] | [[putrid]] | [[loathsome]]