# flush

## Etymology
- From Middle English flusshen, fluschen, of uncertain origin. Perhaps related to Middle English flasshen, flasschen, flaschen, see flash; or a Middle English blend of flowen (“to flow”) +‎ guschen (“to gush”).  Compare with German flutschen.

- Same as Etymology 3, according to the American Heritage Dictionary.

- Probably from Etymology 1 according to the American Heritage Dictionary.

- Probably from Middle French flus (“flow”), cognate with flux.


## Definition
### Noun
1. A group of birds that have suddenly started up from undergrowth, trees, etc. 
2. A sudden flowing; a rush which fills or overflows, as of water for cleansing purposes. 
3. Particularly, such a cleansing of a toilet. 
4. (computing) The process of clearing the contents of a buffer or cache. 
5. A suffusion of the face with blood, as from fear, shame, modesty, or intensity of feeling of any kind; a blush; a glow. 
6. Any tinge of red colour like that produced on the cheeks by a sudden rush of blood. 
7. A sudden flood or rush of feeling; a thrill of excitement, animation, etc. 
8. (poker) A hand consisting of all cards with the same suit. 

### Verb
1. (transitive) To cause to take flight from concealment. 
2. (intransitive) To take suddenly to flight, especially from cover. 
3. (transitive) To cleanse by flooding with generous quantities of a fluid. 
4. (transitive) Particularly, to cleanse a toilet by introducing a large amount of water. 
5. (intransitive) To become suffused with reddish color due to embarrassment, excitement, overheating, or other systemic disturbance, to blush. 
6. (transitive) To cause to blush. 
7. To cause to be full; to flood; to overflow; to overwhelm with water. 
8. (transitive) To excite, inflame. 
9. (intransitive, of a toilet) To be cleansed by being flooded with generous quantities of water. 
10. (transitive, computing) To clear (a buffer or cache) of its contents. 
11. (transitive, computing, of data held in a buffer or cache) To write (the data) to primary storage, clearing it from the buffer or cache. 
12. To flow and spread suddenly; to rush. 
13. To show red; to shine suddenly; to glow. 
14. (masonry) To fill in (joints); to point the level; to make them flush. 
15. (mining, intransitive) To operate a placer mine, where the continuous supply of water is insufficient, by holding back the water, and releasing it periodically in a flood. 
16. (mining) To fill underground spaces, especially in coal mines, with material carried by water, which, after drainage, constitutes a compact mass. 
17. (intransitive, transitive) To dispose or be disposed of by flushing down a toilet 

### Adjective
1. Smooth, even, aligned; not sticking out. 
2. Wealthy or well off. 
3. Full of vigour; fresh; glowing; bright. 
4. Affluent; abounding; well furnished or suppled; hence, liberal; prodigal. 
5. (typography) Short for flush left and right: a body of text aligned with both its left and right margins.  

### Adverb
1. Suddenly and completely. 

## Synonyms
[[charge]] | [[flower]] | [[prime]] | [[peak]] | [[buff]] | [[rush]] | [[kick]] | [[rich]] | [[bloom]] | [[bang]] | [[affluent]] | [[scour]] | [[blossom]] | [[thrill]] | [[gush]] | [[sluice]] | [[blush]] | [[inflammation]] | [[heyday]] | [[burnish]] | [[crimson]] | [[wealthy]] | [[efflorescence]] | [[loaded]]