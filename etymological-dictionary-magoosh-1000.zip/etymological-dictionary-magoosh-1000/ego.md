# ego

## Etymology
- From Latin ego (“I”). Chosen by Freud’s translator as a translation of his use of German Ich as a noun for this concept from the pronoun ich (“I”). Doublet of I and Ich.


## Definition
### Noun
1. The self, especially with a sense of self-importance. 
2. (psychology, Freudian) The most central part of the mind, which mediates with one's surroundings. 

## Synonyms
[[self]]