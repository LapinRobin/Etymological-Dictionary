# incorrigible

## Etymology
- From Middle English incorrigible, from Middle French incorrigible (1334), or directly from Latin incorrigibilis (“not to be corrected”), from in- (“not”) +‎ corrigere (“to correct”) +‎ -ibilis (“-able”). Recorded since 1340.


## Definition
### Adjective
1. Defective and impossible to materially correct or set aright. 
2. Incurably depraved; not reformable. 
3. Impervious to correction by punishment or pain. 
4. Unmanageable. 
5. Determined, unalterable, hence impossible to improve upon. 
6. (archaic) Incurable. 

### Noun
1. An incorrigibly bad individual. 

## Synonyms
[[delinquent]] | [[depraved]]