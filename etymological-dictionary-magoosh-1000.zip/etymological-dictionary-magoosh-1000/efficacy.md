# efficacy

## Etymology
- From Old French efficace, from Late Latin efficācia (“efficacy”), from efficāx (“efficacious”); see efficacious.


## Definition
### Noun
1. Ability to produce a desired effect under ideal testing conditions. 
2. Degree of ability to produce a desired effect; effectiveness. 

## Synonyms
