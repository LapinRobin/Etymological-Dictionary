# jargon

## Etymology
- From Middle English jargoun, jargon, from Old French jargon, a variant of gargon, gargun (“chatter; talk; language”).

- jargon (countable and uncountable, plural jargons)


## Definition
### Noun
1. (uncountable) A technical terminology unique to a particular subject. 
2. (countable) A language characteristic of a particular group. 
3. (uncountable) Speech or language that is incomprehensible or unintelligible; gibberish. 
4. Alternative form of jargoon (“A variety of zircon”)  

### Verb
1. To utter jargon; to emit confused or unintelligible sounds. 

## Synonyms
[[vernacular]] | [[cant]] | [[slang]] | [[argot]] | [[patois]] | [[lingo]]