# effectual

## Etymology
- From Middle English effectual, effectuel, from Old French effectuel, from Late Latin effectualis.


## Definition
### Adjective
1. Producing the intended result; entirely adequate. 

## Synonyms
[[effective]] | [[strong]] | [[trenchant]] | [[impressive]] | [[potent]] | [[efficacious]] | [[telling]]