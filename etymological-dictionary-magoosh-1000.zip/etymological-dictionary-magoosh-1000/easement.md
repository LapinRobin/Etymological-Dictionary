# easement

## Etymology
- From Anglo-Norman aisement, easement, eisement, esament, esement, and Middle French aisement (“comfort, convenience, ease, facility, opportunity; a benefit, relief; a right to use land, a thing, etc.; a privy”), from aisier (“to put at ease; to facilitate”) + -ment (“-ment, suffix forming nouns, usually the action or state resulting from verbs”).


## Definition
### Noun
1. (law) An interest in land which grants the legal right to use another person's real property (real estate), generally in order to cross a part of the property or to gain access to something on the property (right of way). 
2. (architecture) An element such as a baseboard, handrail, etc., that is curved instead of abruptly changing direction. 
3. (archaic) Easing; relief; assistance; support. 
4. (archaic, euphemistic) The act of relieving oneself: defecating or urinating. 
5. (model railroading) Transition spiral curve track between a straight or tangent track and a circular curved track of a certain radius or selected radius. 
6. Gratification. 

## Synonyms
