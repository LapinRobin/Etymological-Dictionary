# preempt

## Etymology
- Back-formation from preemption.


## Definition
### Verb
1. (transitive) To appropriate first. 
2. (transitive) To displace or take the place of (by having higher precedence, etc). 
3. (transitive) To prevent or beat to the punch, to forestall an expected occurrence by acting first. 
4. (transitive) To secure (land, etc.) by the right of preemption (purchasing before others, e.g. land because one already occupies it). 
5. (bridge, intransitive) To make a preemptive bid at bridge. 

### Noun
1. (bridge) A preemptive bid. 

## Synonyms
