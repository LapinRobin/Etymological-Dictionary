# modicum

## Etymology
- From Late Middle English modicum, borrowed from Latin modicum (“a little, a small amount”), a noun use of the neuter form of modicus (“moderate; restrained, temperate; reasonable”) + -cum (suffix forming neuter nouns). Modicus is derived from modus (“a measure; a bound, limit”) (ultimately from Proto-Indo-European *med- (“to measure”)) + -icus (suffix meaning ‘of or pertaining to’ forming adjectives).


## Definition
### Noun
1. A modest, small, or trifling amount. 

## Synonyms
