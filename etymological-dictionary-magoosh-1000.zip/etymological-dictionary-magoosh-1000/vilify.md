# vilify

## Etymology
- From Late Latin vīlificāre, present active infinitive of vīlificō (“vilify”).


## Definition
### Verb
1. (transitive) To say defamatory things about someone or something; to speak ill of. 
2. (transitive) To belittle through speech; to put down. 

## Synonyms
[[rail]] | [[revile]] | [[vituperate]]