# maverick

## Etymology
- From the surname of Texas lawyer and politician Samuel Maverick (1803–1870), who refused to brand his cattle.  See Maverick.


## Definition
### Adjective
1. (of cattle) Unbranded. 
2. Showing independence in thoughts or actions. 

### Noun
1. An unbranded range animal. 
2. (by extension) Anything dishonestly obtained. 
3. (by extension) One who is unconventional or does not abide by rules. 
4. (by extension) One who creates or uses controversial or unconventional ideas or practices. 
5. (military) A person in the military who became an officer by going to college while on active duty as an enlisted person. 
6. (poker slang) A queen and a jack as a starting hand in Texas hold 'em. 
7. A surname. 
8. A male given name. 
9. Any of several individual secondary school and sports team mascots, most of which are in the United States. 
10. A member of one of the sports teams with a mascot called Maverick. 
11. Someone who attends, or has attended in the past, one of these schools, especially one involved in the sports teams. 

### Verb
1. (US) To take an unbranded range animal. 
2. (by extension) To seize without a legal claim. 

## Synonyms
[[rebel]] | [[irregular]] | [[unorthodox]] | [[unconventional]]