# vehement

## Etymology
- Borrowed from Middle French vehement (modern French véhément; compare Italian veemente, Portuguese veemente, Spanish vehemente); or from Latin vehemēns (“vehement; very eager; ardent, furious, impetuous; emphatic”), probably from vē- (“prefix meaning ‘lacking, too little’”) + mēns (“mind; intellect; judgment, reasoning”).


## Definition
### Adjective
1. Showing strong feelings; passionate; forceful or intense. 

## Synonyms
[[strong]] | [[intense]] | [[fierce]] | [[violent]]