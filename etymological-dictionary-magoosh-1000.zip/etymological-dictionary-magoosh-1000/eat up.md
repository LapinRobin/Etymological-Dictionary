# eat up

## Definition
### Verb
1. (transitive, intransitive) To consume completely. 
2. (transitive, figuratively) To cover (a distance or an amount). 
3. (transitive, figuratively, informal) To accept or believe entirely, immediately, and without questioning. 
4. (US, informal) to find something to be very cute (typically only used for children or pets) 

## Synonyms
