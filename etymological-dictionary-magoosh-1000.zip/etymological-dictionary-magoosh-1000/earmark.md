# earmark

## Etymology
- ear +‎ mark


## Definition
### Verb
1. (transitive) To mark (sheep or other animals) by slitting the ear. 
2. (transitive, by extension) To specify or set aside for a particular purpose, to allocate. 
3. (transitive, finance, UK) To designate part of a pension to be payable to the holder's former spouse or partner at its time of payment. 

### Noun
1. A mark or deformation of the ear of an animal, intended to indicate ownership. 
2. (US, politics) The designation of specific projects in appropriations of funding for general programs. 
3. A mark for identification; a distinguishing mark. 

## Synonyms
[[appropriate]] | [[reserve]] | [[allow]] | [[hallmark]] | [[trademark]]