# bastardization

## Etymology
- bastard +‎ -ization


## Definition
### Noun
1. The making of a bastard or bastards; Having children out of wedlock or destroying the legitimacy of children's paternity. 
2. The creation of offspring from two different species; cross-breeding. 
3. (by extension) The combining of separate races in marriage or breeding; miscegenation. 
4. Any change or neologism in language that is viewed as a degradation. 
5. (more generally) The creation of an inferior copy or version; corruption, degradation, or debasement. 
6. Activities involving harassment, abuse or humiliation used as a way of initiating a person into a group. 

## Synonyms
