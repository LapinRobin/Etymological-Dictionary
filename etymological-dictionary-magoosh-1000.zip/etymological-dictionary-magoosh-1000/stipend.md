# stipend

## Etymology
- The noun is derived from Late Middle English stipend, stipende (“salary, wage”) , from Old French stipende, stipendie, from Latin stīpendium (“contribution; dues; impost, tax; tribute; military pay or stipend; military service”), from *stipipendium, *stippendium, from stips (“alms; contribution, donation, gift”) (ultimately from Proto-Indo-European *steyp- (“erect; stiff”)) + pendere (the present active infinitive of pendō (“to cause to hang down or suspend; to weigh, weigh out; (hence) to pay”), ultimately from Proto-Indo-European *(s)pend- (“to pull; to spin; to stretch”)) + -ium (suffix forming abstract nouns).


## Definition
### Noun
1. (archaic) A regular fixed payment made to someone (especially a clergyman, judge, soldier, or teacher) for services provided by them; a salary.  
2. Some other form of fixed (and generally small) payment occurring at regular intervals, such as an allowance, a pension, or (obsolete) a tax.  
3. (education) A scholarship granted to a student.  
4. Money which is earned; an income. 
5. A one-off payment for a service provided. 

### Verb
1. (transitive, obsolete or historical) To provide (someone) with a stipend (an allowance, a pension, a salary, etc.).  

## Synonyms
