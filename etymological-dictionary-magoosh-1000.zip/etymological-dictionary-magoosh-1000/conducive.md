# conducive

## Etymology
- conduce +‎ -ive, 1640s, from Latin condūcere, patterned after forms like conductive.


## Definition
### Adjective
1. Tending to contribute to, encourage, or bring about some result. 

## Synonyms
