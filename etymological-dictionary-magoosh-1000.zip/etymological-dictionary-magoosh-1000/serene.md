# serene

## Etymology
- From Middle English, borrowed from Latin serēnus (“clear, cloudless, untroubled”).

- Borrowed from Middle French serein, from Old French serein (“evening”), from Vulgar Latin *serānum, from substantive use of sērum, neuter of sērus (“late”) + -ānus suffix.


## Definition
### Adjective
1. Calm, peaceful, unruffled. 
2. Without worry or anxiety; unaffected by disturbance. 
3. (archaic) Fair and unclouded (as of the sky); clear; unobscured. 
4. Used as part of certain titles, originally to indicate sovereignty or independence. 

### Verb
1. (transitive) To make serene. 

### Noun
1. (poetic) Serenity; clearness; calmness. 
2. A fine rain from a cloudless sky after sunset. 
3. A female given name from English. A rare variant of Serena. 

## Synonyms
[[clear]] | [[calm]] | [[tranquil]] | [[peaceful]]