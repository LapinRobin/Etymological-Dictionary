# buttress

## Etymology
- From Old French ars bouterez (noun, literally “supporting arcs”), from bouterez (adj), oblique plural of bouteret (rare in the singular), from Frankish *botan, from Proto-Germanic *bautaną (“to push”). Ultimately cognate with beat.


## Definition
### Noun
1. (architecture) A brick or stone structure built against another structure to support it. 
2. (by extension) Anything that serves to support something; a prop. 
3. (botany) A buttress-root. 
4. (climbing) A feature jutting prominently out from a mountain or rock. 
5. (figuratively) Anything that supports or strengthens. 

### Verb
1. To support something physically with, or as if with, a prop or buttress. 
2. (figuratively, by extension) To support something or someone by supplying evidence. 

## Synonyms
