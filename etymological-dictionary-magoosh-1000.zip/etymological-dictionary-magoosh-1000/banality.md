# banality

## Etymology
- From French banalité, from banal.


## Definition
### Noun
1. (uncountable) The quality of being banal. 
2. (countable) Something which is banal. 
3. (rare, historical) A feudal right or obligation, especially the obligation for a peasant to grind grain at the lord's mill, or the profits accruing from such rights. 

## Synonyms
[[platitude]] | [[cliche]] | [[bromide]] | [[commonplace]]