# gossamer

## Etymology
- From Middle English gossomer, gosesomer, gossummer (attested since around 1300, and only in reference to webs or other light things), usually thought to derive from gos (“goose”) + somer (“summer”) and to have initially referred to a period of warm weather in late autumn when geese were eaten — compare Middle Scots goesomer, goe-summer (“summery weather in late autumn; St Martin's summer”) and dialectal English go-harvest, both later connected in folk-etymology to go) — and to have been transferred to cobwebs because they were frequent then or because they were likened to goose-down. Skeat says that in Craven the webs were called summer-goose, and compares Scots and dialectal English use of summer-colt in reference to "exhalations seen rising from the ground in hot weather". Weekley notes that both the webs and the weather have fantastical names in most European languages: compare German Altweibersommer (“Indian summer; cobwebs, gossamer”, literally “old wives' summer”) and other terms listed there.


## Definition
### Noun
1. A fine film or strand as of cobwebs, floating in the air or caught on bushes, etc. 
2. A soft, sheer fabric. 
3. Anything delicate, light and flimsy. 

### Adjective
1. Tenuous, light, filmy or delicate. 

## Synonyms
[[sheer]] | [[ethereal]] | [[transparent]] | [[delicate]] | [[thin]] | [[diaphanous]] | [[cobweb]]