# delineate

## Etymology
- From Latin dēlīneātus, past participle of dēlīneo (“to sketch out, to delineate”), from de- + līnea (“line”).


## Definition
### Verb
1. To sketch out, draw or trace an outline. 
2. To depict, represent with pictures. 
3. To describe or depict with words or gestures. 
4. To outline or mark out. 

## Synonyms
[[line]] | [[draw]] | [[trace]] | [[outline]] | [[define]] | [[describe]] | [[specify]] | [[limn]] | [[drawn]] | [[delimit]] | [[depicted]]