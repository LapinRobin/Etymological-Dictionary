# contrite

## Etymology
- From Middle English contrit, from Old French contrit, from Latin contrītus (literally “ground to pieces”), perfect passive participle of conterō (“grind, bruise”), from con- + terō (“rub, wear away”).


## Definition
### Adjective
1. Sincerely penitent or feeling regret or sorrow, especially for one’s own actions. 
2. (obsolete) Thoroughly bruised or broken. 

### Noun
1. A contrite person; a penitent. 

## Synonyms
[[sorry]] | [[penitent]] | [[rueful]] | [[apologetic]]