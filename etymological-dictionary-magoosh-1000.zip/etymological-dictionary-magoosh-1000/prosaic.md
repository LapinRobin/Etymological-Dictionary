# prosaic

## Etymology
- From Middle French prosaïque, from Medieval Latin prosaicus (“in prose”), from Latin prosa (“prose”), from prorsus (“straightforward, in prose”), from Old Latin provorsus (“straight ahead”), from pro- (“forward”) + vorsus (“turned”), from vertō (“to turn”), from Proto-Indo-European *wer- (“to turn, to bend”).


## Definition
### Adjective
1. Pertaining to or having the characteristics of prose. 
2. (of writing or speaking) Straightforward; matter-of-fact; lacking the feeling or elegance of poetry. 
3. (main usage, usually of writing or speaking but also figurative) Overly plain, simple or commonplace, to the point of being boring. 

## Synonyms
[[pedestrian]] | [[commonplace]] | [[humdrum]]