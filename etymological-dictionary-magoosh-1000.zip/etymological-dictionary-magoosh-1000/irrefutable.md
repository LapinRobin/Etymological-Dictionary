# irrefutable

## Etymology
- From Late Latin irrefūtābilis, from ir- (“not”) +‎ refūtābilis (“refutable”), from refūtō (“to refute”) +‎ -bilis (“-able”).


## Definition
### Adjective
1. undeniable; unable to be disproved or refuted 

## Synonyms
[[positive]] | [[incontrovertible]]