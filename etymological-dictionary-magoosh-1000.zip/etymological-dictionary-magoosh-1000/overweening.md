# overweening

## Etymology
- From Middle English overweninge, equivalent to overween +‎ -ing. Cognate with obsolete Dutch overwanig, overwaand (“presumptuous; cocky; conceited”).

- From Middle English overweninge, equivalent to overween +‎ -ing.

- See the etymology of the corresponding lemma form.


## Definition
### Adjective
1. Unduly confident; arrogant 
2. Exaggerated, excessive. 

### Noun
1. (now rare) An excessively high opinion of oneself or one’s abilities; presumption, arrogance. 

## Synonyms
[[exuberant]] | [[extravagant]] | [[excessive]] | [[uppity]]