# respite

## Etymology
- From Anglo-Norman and Old French respit (“rest”), from Latin respectus. Doublet of respect.


## Definition
### Noun
1. A brief interval of rest or relief. 
2. (law) A reprieve, especially from a sentence of death. 
3. (law) The delay of appearance at court granted to a jury beyond the proper term. 
4. (musical theatre) A short period of spoken dialogue in an otherwise sung-through musical. 

### Verb
1. (transitive) To delay or postpone (an event). 
2. (transitive) To allow (a person) extra time to fulfil some obligation. 

## Synonyms
[[break]] | [[relief]] | [[rest]] | [[recess]] | [[hiatus]] | [[reprieve]] | [[abatement]] | [[suspension]]