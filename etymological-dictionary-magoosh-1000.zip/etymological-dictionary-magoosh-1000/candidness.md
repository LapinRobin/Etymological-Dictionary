# candidness

## Etymology
- candid +‎ -ness


## Definition
### Noun
1. The quality of being candid. 

## Synonyms
[[candor]] | [[candour]]