# vacillate

## Etymology
- From Latin vacillātum, supine form of vacillō (“sway, waver”).


## Definition
### Verb
1. (intransitive) To sway unsteadily from one side to the other; oscillate. 
2. (intransitive) To swing indecisively from one course of action or opinion to another. 

## Synonyms
[[hover]] | [[waver]] | [[fluctuate]]