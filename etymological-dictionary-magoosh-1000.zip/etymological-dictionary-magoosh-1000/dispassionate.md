# dispassionate

## Etymology
- dis- +‎ passionate


## Definition
### Adjective
1. not showing, and not affected by, emotion, bias, or prejudice 

## Synonyms
[[fair]] | [[impartial]]