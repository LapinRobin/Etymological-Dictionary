# atavism

## Etymology
- From French atavisme < Latin atavus (ancestor).


## Definition
### Noun
1. The reappearance of an ancestral characteristic in an organism after several generations of absence; a throwback. 
2. The recurrence or reversion to a past behaviour, method, characteristic or style after a long period of absence. 
3. (sociology) Reversion to past primitive behavior, especially violence. 

## Synonyms
[[throwback]]