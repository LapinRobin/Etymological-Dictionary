# reticent

## Etymology
- Latin reticēns, present participle of reticeō (“to keep silence”).


## Definition
### Adjective
1. Keeping one's thoughts and opinions to oneself; reserved or restrained. 
2. (proscribed) Hesitant or not wanting to take some action; reluctant (usually followed by a verb in the infinitive). 

## Synonyms
[[taciturn]] | [[reserved]]