# involved

## Etymology
- involve +‎ -ed


## Definition
### Adjective
1. Complicated. 
2. Associated with others, be a participant or make someone be a participant (in a crime, process, etc.) 
3. Having an affair with someone. 

## Synonyms
[[complex]] | [[active]] | [[intricate]] | [[convoluted]] | [[committed]] | [[byzantine]] | [[concerned]] | [[engaged]] | [[interested]] | [[attached]] | [[tortuous]] | [[enclosed]] | [[mired]] | [[knotty]] | [[encumbered]]