# inchoate

## Etymology
- From Latin incohātus (“begun, unfinished”), perfect passive participle of incohō (“begin”). Cognate with Spanish incoar (“to initiate, commence, begin”).


## Definition
### Adjective
1. Recently started but not fully formed yet; just begun; only elementary or immature. 
2. Chaotic, disordered, confused; also, incoherent, rambling. 
3. (law) Of a crime, imposing criminal liability for an incompleted act. 

### Noun
1. (rare) A beginning, an immature start. 

### Verb
1. (transitive) To begin or start (something). 
2. (transitive) To cause or bring about. 
3. (intransitive) To make a start. 

## Synonyms
[[incipient]] | [[early]]