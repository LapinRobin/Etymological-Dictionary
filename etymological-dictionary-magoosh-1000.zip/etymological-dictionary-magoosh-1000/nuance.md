# nuance

## Etymology
- Borrowed from French nuance (“nuance, shade, hue”).


## Definition
### Noun
1. A minor distinction. 
2. Subtlety or fine detail. 

### Verb
1. (transitive) To apply a nuance to; to change or redefine in a subtle way. 

## Synonyms
[[shade]] | [[subtlety]] | [[refinement]]