# browbeat

## Etymology
- brow +‎ beat


## Definition
### Verb
1. (transitive) To bully in an intimidating, bossy, or supercilious way. 

## Synonyms
[[bully]] | [[swagger]] | [[hector]]