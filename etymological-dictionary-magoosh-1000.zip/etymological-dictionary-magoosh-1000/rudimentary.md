# rudimentary

## Etymology
- rudiment +‎ -ary


## Definition
### Adjective
1. Of or relating to one or more rudiments. 
2. Basic; minimal; with less than, or only the minimum, necessary. 

### Noun
1. (zoology, usually in the plural) One of the rudimentary mammae of boars. 

## Synonyms
[[fundamental]] | [[basic]] | [[underlying]] | [[vestigial]]