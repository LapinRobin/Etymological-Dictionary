# parochial

## Etymology
- From Anglo-Norman parochial and its source Late Latin parochialis, an alteration of paroecialis (“of a church province”), from paroecia, from Hellenistic Greek παροικία (paroikía, “stay in a foreign land”), later “community, diocese”, from Ancient Greek πάροικος (pároikos, “neighbouring, neighbour”), from παρα- (para-) + οἶκος (oîkos, “house”).


## Definition
### Adjective
1. Pertaining to a parish. 
2. Characterized by an unsophisticated focus on local concerns to the exclusion of wider contexts; elementary in scope or outlook. 

## Synonyms
[[insular]] | [[provincial]]