# epigram

## Etymology
- From Middle French epigramme, from Latin epigramma, from Ancient Greek ἐπίγραμμα (epígramma, “inscription”).


## Definition
### Noun
1. (obsolete) An inscription in stone. 
2. A brief but witty saying. 
3. A short, witty or pithy poem. 

## Synonyms
[[quip]]