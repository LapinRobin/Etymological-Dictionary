# perfunctory

## Etymology
- From Late Latin perfunctōrius (“careless, negligent”), from the past participial stem of perfungor, perfunct- (“perform, carry through”), from per- + fungor.


## Definition
### Adjective
1. Done only or merely to conform to a minimal standard or to fulfill a protocol or presumptive duty. 
2. Performed in a careless or indifferent manner as a thing of rote. 

## Synonyms
[[casual]] | [[cursory]] | [[formal]] | [[careless]] | [[passing]]