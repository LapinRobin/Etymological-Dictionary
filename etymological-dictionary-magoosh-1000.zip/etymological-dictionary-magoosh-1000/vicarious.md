# vicarious

## Etymology
- Borrowed from Latin vicārius (“vicarious, substituted”), 17th century.


## Definition
### Adjective
1. Delegated. 
2. Experienced or gained by taking in another person’s experience, rather than through first-hand experience, such as through watching or reading. 
3. On behalf of others. 

## Synonyms
[[secondary]]