# disenfranchise

## Etymology
- dis- +‎ enfranchise


## Definition
### Verb
1. (transitive) To deprive someone of a franchise, generally of the right to vote. 

## Synonyms
