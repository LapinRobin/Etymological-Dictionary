# embroiled

## Definition
### Adjective
1. deeply involved especially in something complicated

## Synonyms
[[involved]]