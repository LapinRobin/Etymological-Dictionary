# tawdry

## Etymology
- Shortened from tawdry lace; originally a corruption of Saint Audrey lace (from Old English Æðelþryð). The lace necklaces sold to pilgrims to Saint Audrey fell out of fashion in the 17th century, and so tawdry was reinterpreted as meaning “cheap” or “vulgar”.


## Definition
### Noun
1. (obsolete) Tawdry lace. 
2. (obsolete) Anything gaudy and cheap; pretentious finery. 

### Adjective
1. (of clothing, appearance, etc.) Cheap and gaudy; showy. 
2. (of character, behavior, situations, etc.) Unseemly, base, shameful. 

## Synonyms
[[flash]] | [[inferior]] | [[meretricious]] | [[loud]] | [[cheap]] | [[gaudy]] | [[garish]] | [[tacky]] | [[shoddy]] | [[gimcrack]]