# boorish

## Etymology
- boor +‎ -ish


## Definition
### Adjective
1. Behaving as a boor; rough in manners. 

## Synonyms
[[neanderthal]]