# constituent

## Etymology
- From Latin cōnstituēns, present participle of cōnstituō (“I establish”), from com- (“together”) + statuo (“I set, place, establish”); see statute or statue, and compare institute and restitute.


## Definition
### Adjective
1. being a part, or component of a whole 
2. authorized to make a constitution 

### Noun
1. A part, or component of a whole 
2. A person or thing which constitutes, determines, or constructs 
3. A resident of an area represented by an elected official, particularly in relation to that official. 
4. A voter who supports a (political) candidate; a supporter of a cause. 
5. (law) One who appoints another to act for him as attorney in fact 
6. (grammar) A functional element of a phrase or clause 

## Synonyms
[[factor]] | [[element]] | [[organic]] | [[component]] | [[ingredient]] | [[constitutional]]