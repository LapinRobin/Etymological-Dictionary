# coterminous

## Etymology
- From Latin conterminus, from con- (“with”) + terminus (“border, end”). The spelling with co- instead of con- is probably influenced by the related prefix co-.


## Definition
### Adjective
1. Meeting end to end or at the ends. 
2. (geography) Having matching boundaries; or, adjoining and sharing a boundary. 
3. Having the same scope, range of meaning, or extent in time. 
4. (law) Said of linked or related property leases that expire together. 

## Synonyms
[[commensurate]]