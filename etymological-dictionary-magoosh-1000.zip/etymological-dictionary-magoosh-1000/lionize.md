# lionize

## Etymology
- From lion +‎ -ize.


## Definition
### Verb
1. (transitive) To treat (a person) as if they were important, or a celebrity. 
2. (transitive) To visit (a famous place) in order to revere it. 

## Synonyms
[[celebrate]]