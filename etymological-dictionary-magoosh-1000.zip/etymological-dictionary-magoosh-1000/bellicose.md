# bellicose

## Etymology
- From Middle English bellicose, from Latin bellicosus.


## Definition
### Adjective
1. Warlike in nature; aggressive; hostile. 
2. Showing or having the impulse to be combative. 

## Synonyms
[[aggressive]] | [[contentious]] | [[combative]]