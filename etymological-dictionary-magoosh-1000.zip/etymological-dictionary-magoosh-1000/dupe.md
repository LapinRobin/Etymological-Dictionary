# dupe

## Etymology
- From French duper, from Middle French duppe, alteration of huppe (“hoopoe”), from Latin, onomatopoeic.

- Clipping of duplicate.


## Definition
### Noun
1. A person who has been deceived. 
2. (photography) A duplicate of a photographic image. 
3. (restaurant industry) A duplicate of an order receipt printed for kitchen staff. 
4. (informal) A duplicate. 
5. (informal, TikTok) A counterfeit; a fake. 

### Verb
1. To swindle, deceive, or trick. 
2. (transitive) To duplicate. 

## Synonyms
[[fool]] | [[slang]] | [[cod]] | [[gull]] | [[victim]] | [[take in]]