# peruse

## Etymology
- From either Medieval Latin perūtor, perūsitō (“wear out”)) or Anglo-Norman peruser (“use up”)), originally leading to two concurrent meanings, but only those derived from "to examine" survive today. By surface analysis, per- +‎ use.


## Definition
### Verb
1. (transitive) To examine or consider with care. 
2. (transitive) To read completely. 
3. (transitive, informal) To look over casually; to skim. 
4. (intransitive, regional) To go from place to place; to wander. 

### Noun
1. An examination or perusal; an instance of perusing. 

## Synonyms
