# macabre

## Etymology
- Borrowed from French macabre, whose etymology is uncertain. Possibly from the term danse macabre, most commonly believed to be from corruption of the biblical name Maccabees; compare Latin Chorea Machabaeorum.


## Definition
### Adjective
1. Representing or personifying death. 
2. Obsessed with death or the gruesome. 
3. Ghastly, shocking, terrifying. 

## Synonyms
[[grim]] | [[gruesome]] | [[ghastly]] | [[grisly]]