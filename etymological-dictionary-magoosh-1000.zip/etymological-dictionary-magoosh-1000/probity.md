# probity

## Etymology
- From Middle French probité, from Latin probitās (“uprightness, honesty”), from probus (“good, excellent, honest”); see probe, prove.


## Definition
### Noun
1. Integrity, especially of the quality of having strong moral principles; decency and honesty. 

## Synonyms
