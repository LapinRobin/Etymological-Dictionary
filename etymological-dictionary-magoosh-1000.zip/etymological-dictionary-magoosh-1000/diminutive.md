# diminutive

## Etymology
- From Middle French diminutif (1398), from Latin diminutivum, from dēminuō (“diminish”).


## Definition
### Adjective
1. Very small. 
2. (obsolete) Serving to diminish. 
3. (grammar) Of or pertaining to, or creating a word form expressing smallness, youth, unimportance, or endearment. 

### Noun
1. (grammar) A word form expressing smallness, youth, unimportance, or endearment. 

## Synonyms
[[little]] | [[small]] | [[tiny]] | [[petite]] | [[midget]] | [[lilliputian]] | [[bantam]]