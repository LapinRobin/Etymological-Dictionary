# zenith

## Etymology
- From Middle English cenyth, from Medieval Latin cenit, from Arabic سَمْت‎ (samt, “direction, path”), from the fuller form سَمْت اَلرَّأْس‎ (samt ar-raʔs, “direction of the head”). The -ni- for -m- is sometimes thought to be due to a misreading of the three strokes, which is plausible, though it could be a mere phonetic approximation.


## Definition
### Noun
1. (astronomy) The point in the sky vertically above a given position or observer; the point in the celestial sphere opposite the nadir. 
2. (astronomy) The highest point in the sky reached by a celestial body. 
3. (by extension) Highest point or state; peak. 

## Synonyms
