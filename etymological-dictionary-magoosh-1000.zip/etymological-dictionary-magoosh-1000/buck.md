# buck

## Etymology
- From Middle English bukke, bucke, buc, from Old English buc, bucc, bucca (“he-goat, stag”), from Proto-West Germanic *bukk, *bukkō, from Proto-Germanic *bukkaz, *bukkô (“buck”), from Proto-Indo-European *bʰuǵ- (“ram”). Doublet of puck (billy goat).

- From Middle Low German bucken (“to bend”) or Middle Dutch bucken, bocken (“to bend”), intensive forms of Old Saxon būgan and Old Dutch *būgan (“to bend, bow”), both from Proto-West Germanic *beugan, from Proto-Germanic *būganą (“to bend”), from Proto-Indo-European *bʰūgʰ- (“to bend”). Influenced in some senses by buck “male goat” (see above).

- See beech.

- From Middle English bouken (“steep in lye”), ultimately related to the root of beech. Cognate with Middle High German büchen, Swedish byka, Danish byge and Low German būken.

- From Middle English bouk (“belly, trunk, body, hull of a ship, fishtrap, container”), from Old English būc (“belly, container”), from Proto-West Germanic *būk, from Proto-Germanic *būkaz. Doublet of bucket.


## Definition
### Noun
1. A male deer, antelope, sheep, goat, rabbit, hare, and sometimes the male of other animals such as the hamster, ferret and shad. 
2. (US) An uncastrated sheep, a ram. 
3. A young buck; an adventurous, impetuous, dashing, or high-spirited young man. 
4. (Britain, obsolete) A fop or dandy. 
5. (US, dated, derogatory) A black or Native American man. 
6. (US, Australia, New Zealand, Canada, informal) A dollar (one hundred cents). 
7. (South Africa, informal) A rand (currency unit). 
8. (UK, slang, obsolete) A sixpence. 
9. (informal, rare) A euro. 
10. (by extension, Australia, South Africa, US, informal) Money. 
11. (finance) One million dollars. 
12. (US, slang) One hundred. 
13. (UK, dialect) The body of a post mill, particularly in East Anglia. See Wikipedia:Windmill machinery. 
14. A frame on which firewood is sawed; a sawhorse; a sawbuck. 
15. A leather-covered frame used for gymnastic vaulting. 
16. A wood or metal frame used by automotive customizers and restorers to assist in the shaping of sheet metal bodywork. 
17. (dated) An object of various types, placed on a table to indicate turn or status; such as a brass object, placed in rotation on a US Navy wardroom dining table to indicate which officer is to be served first, or an item passed around a poker table indicating the dealer or placed in the pot to remind the winner of some privilege or obligation when his or her turn to deal next comes. 
18. (African-American Vernacular, dated, dance) Synonym of buck dance. 
19. Synonym of mule (“type of cocktail with ginger ale etc.”) 
20. (dated, slang) A kind of large marble in children's games. 
21. (Scotland) The beech tree. 
22. Lye or suds in which cloth is soaked in the operation of bleaching, or in which clothes are washed. 
23. The cloth or clothes soaked or washed. 
24. An English surname transferred from the nickname. 
25. A male given name from Old English. 
26. A German surname, a variant of Buch. 
27. An unincorporated community in Lancaster County, Pennsylvania, United States. 
28. A township in Luzerne County, Pennsylvania. 
29. A township in Hardin County, Ohio, United States. 
30. Clipping of buckshot. ] 

### Verb
1. (intransitive) To copulate, as bucks and does. 
2. (intransitive) To bend; buckle. 
3. (intransitive, of a horse or similar saddle or pack animal) To leap upward arching its back, coming down with head low and forelegs stiff, forcefully kicking its hind legs upward, often in an attempt to dislodge or throw a rider or pack. 
4. (transitive, of a horse or similar saddle or pack animal) To throw (a rider or pack) by bucking. 
5. (transitive, military) To subject to a mode of punishment which consists of tying the wrists together, passing the arms over the bent knees, and putting a stick across the arms and in the angle formed by the knees. 
6. (intransitive, by extension) To resist obstinately; oppose or object strongly. 
7. (intransitive, by extension) To move or operate in a sharp, jerking, or uneven manner. 
8. (transitive, by extension) To overcome or shed (e.g., an impediment or expectation), in pursuit of a goal; to force a way through despite (an obstacle); to resist or proceed against. 
9. (riveting) To press a reinforcing device (bucking bar) against (the force of a rivet) in order to absorb vibration and increase expansion. See Wikipedia: Rivet:Installation. 
10. (forestry) To saw a felled tree into shorter lengths, as for firewood. 
11. (electronics) To output a voltage that is lower than the input voltage. See Wikipedia: Buck converter 
12. (chiefly Irish, humorous or euphemistic) To fuck 
13. To soak, steep or boil in lye or suds, as part of the bleaching process. 
14. To wash (clothes) in lye or suds, or, in later usage, by beating them on stones in running water. 
15. (mining) To break up or pulverize, as ores. 

## Synonyms
[[charge]] | [[horse]] | [[tear]] | [[shoot]] | [[jerk]] | [[hitch]] | [[subordinate]] | [[clam]] | [[dollar]]