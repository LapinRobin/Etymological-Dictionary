# veracious

## Etymology
- From Latin verac- +‎ -ious, stem of vērāx (“truthful”), from vērus (“true”).


## Definition
### Adjective
1. True. 
2. Truthful; speaking the truth. 

## Synonyms
[[true]] | [[accurate]] | [[honest]]