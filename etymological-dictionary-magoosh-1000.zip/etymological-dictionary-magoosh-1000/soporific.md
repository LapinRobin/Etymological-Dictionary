# soporific

## Etymology
- From French soporifique, from Latin sopor (“deep sleep”), from Proto-Indo-European *swepōr, from *swep-. Unrelated to stupor (distinct in Proto-Indo-European).


## Definition
### Noun
1. (pharmacology) Something inducing sleep, especially a drug. 
2. (figuratively) Something boring or dull. 

### Adjective
1. (pharmacology) Tending to induce sleep. 
2. (figuratively) Boring, dull. 

## Synonyms
[[narcotic]]