# inure

## Etymology
- From Middle English inuren, equivalent to in- +‎ ure (“practise, exercise”).


## Definition
### Verb
1. (transitive) To cause someone to become accustomed to something that requires prolonged or repeated tolerance of one or more unpleasantries. 
2. (intransitive, chiefly law) To take effect, to be operative. 
3. (transitive, obsolete) To commit. 

## Synonyms
