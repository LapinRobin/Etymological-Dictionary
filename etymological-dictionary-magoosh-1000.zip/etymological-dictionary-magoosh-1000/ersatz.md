# ersatz

## Etymology
- Borrowed from German Ersatz (“replacement”); and from the German ersetzen (“to replace”, verb).


## Definition
### Adjective
1. made in imitation; artificial, especially of a poor quality 

### Noun
1. something made in imitation; an effigy or substitute 

## Synonyms
[[substitute]] | [[artificial]] | [[imitation]]