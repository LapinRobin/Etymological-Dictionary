# trite

## Etymology
- From Latin trītus "worn out," a form of the verb terō (“I wear away, wear out”).

- This etymology is incomplete. You can help Wiktionary by elaborating on the origins of this term.


## Definition
### Adjective
1. Often in reference to a word or phrase: used so many times that it is commonplace, or no longer interesting or effective; worn out, hackneyed. 
2. (law) So well established as to be beyond debate: trite law. 

### Noun
1. A denomination of coinage in ancient Greece equivalent to one third of a stater. 
2. Trite, a genus of spiders, found in Australia, New Zealand and Oceania, of the family Salticidae. 

## Synonyms
[[stock]] | [[banal]] | [[tired]] | [[hackneyed]] | [[commonplace]]