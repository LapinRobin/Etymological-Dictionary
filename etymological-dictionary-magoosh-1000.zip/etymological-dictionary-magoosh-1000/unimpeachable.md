# unimpeachable

## Etymology
- un- +‎ impeachable


## Definition
### Adjective
1. Not able to be impeached or reproached. 
2. Blameless. 
3. Beyond doubt. 

## Synonyms
[[innocent]] | [[acceptable]]