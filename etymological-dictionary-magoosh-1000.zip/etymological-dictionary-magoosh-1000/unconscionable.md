# unconscionable

## Etymology
- un- +‎ conscionable


## Definition
### Adjective
1. Not conscionable; unscrupulous and lacking principles or conscience. 
2. Excessive, imprudent or unreasonable. 

## Synonyms
[[steep]] | [[outrageous]] | [[exorbitant]]