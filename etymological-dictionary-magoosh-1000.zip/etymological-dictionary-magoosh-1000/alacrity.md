# alacrity

## Etymology
- Coined between 1500 and 1510 from Latin alacritās, from alacer (“brisk”) + -itas (“-ity”).


## Definition
### Noun
1. Eagerness; liveliness; enthusiasm. 
2. Promptness; speed. 

## Synonyms
