# echo

## Etymology
- From Middle English eccho, ecco, ekko, from Medieval Latin ecco, from Latin echo, from Ancient Greek ἠχώ (ēkhṓ), from ἠχή (ēkhḗ, “sound”). Possibly from the same Proto-Indo-European root as sough.


## Definition
### Noun
1. A reflected sound that is heard again by its initial observer. 
2. An utterance repeating what has just been said. 
3. (poetry) A device in verse in which a line ends with a word which recalls the sound of the last word of the preceding line. 
4. (figuratively) Sympathetic recognition; response; answer. 
5. (computing) The displaying on the command line of the command that has just been executed. 
6. (computing) An individual discussion forum using the echomail system. 
7. (whist, bridge) A signal, played in the same manner as a trump signal, made by a player who holds four or more trumps (or, as played by some, exactly three trumps) and whose partner has led trumps or signalled for trumps. 
8. (whist, bridge) A signal showing the number held of a plain suit when a high card in that suit is led by one's partner. 
9. An antisemitic punctuation symbol or marking, ((( ))), placed around a name or phrase to indicate the person is Jewish or the entity is controlled by Jewish people. 
10. (Greek mythology) An oread, punished by Hera by losing her own voice and only being able to mimic that of others. 
11. (astronomy) 60 Echo, a main belt asteroid. 
12. (international standards) Alternative letter-case form of Echo from the NATO/ICAO Phonetic Alphabet. 
13. (medicine, colloquial, uncountable) Clipping of echocardiography.  
14. (medicine, colloquial, countable) Clipping of echocardiogram.  

### Verb
1. (of a sound or sound waves, intransitive) To reflect off a surface and return. 
2. (transitive) To reflect back (a sound). 
3. (by extension, transitive) To repeat (another's speech, opinion, etc.). 
4. (computing, transitive) To repeat its input as input to some other device or system. 
5. (intransitive, whist, bridge) To give the echo signal, informing one's partner about cards one holds. 

## Synonyms
[[ring]] | [[recall]] | [[repeat]] | [[reverberate]]