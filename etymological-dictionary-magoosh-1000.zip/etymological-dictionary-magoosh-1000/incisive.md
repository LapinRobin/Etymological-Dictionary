# incisive

## Etymology
- Late Middle English (in the sense “cutting, penetrating”), borrowed from Medieval Latin incīsīvus, from incīdō (“to cut in, cut through”) +‎ -īvus (“-ive”, adjectival suffix). Compare Middle French incisif.


## Definition
### Adjective
1. (of a person or mental process) Intelligently analytical and concise. 
2. (of an account) Accurate and sharply focused. 
3. (of an action) Quickly proceeding to judgment and forceful in expression. 
4. Having the quality of incising, cutting, or penetrating, as with a sharp instrument. 
5. (anatomy, relational) Of or relating to the incisors. 

## Synonyms
[[keen]] | [[acute]] | [[sharp]] | [[intelligent]] | [[perceptive]] | [[piercing]]