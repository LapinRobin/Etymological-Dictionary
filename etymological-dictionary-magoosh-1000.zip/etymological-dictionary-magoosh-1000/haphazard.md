# haphazard

## Etymology
- From archaic hap (“chance, luck”) +‎ hazard.


## Definition
### Adjective
1. Random; chaotic; incomplete; not thorough, constant, or consistent. 

### Noun
1. Simple chance, a random accident, luck. 

## Synonyms
[[random]] | [[sloppy]] | [[careless]] | [[slipshod]] | [[slapdash]]