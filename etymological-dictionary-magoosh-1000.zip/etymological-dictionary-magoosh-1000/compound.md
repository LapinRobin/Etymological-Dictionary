# compound

## Etymology
- Possibly from Malay kampong, kampung (“group of buildings, village”), via Dutch or Portuguese, altered under the influence of Etymology 2. Doublet of kampung.

- From Middle English compounen, from Middle French componre, compondre (“to put together”), from Latin componō, from Latin com- (“together”) + ponō (“to put”).


## Definition
### Noun
1. An enclosure within which workers, prisoners, or soldiers are confined. 
2. An enclosure for secure storage. 
3. A group of buildings situated close together, e.g. for a school or block of offices. 
4. Anything made by combining several things. 
5. (chemistry) A substance formed by chemical bonding of two or more elements in definite proportions by weight. 
6. (chemistry, dated) A substance made from any combination of ingredients. 
7. (linguistics) A lexeme that consists of more than one stem. 
8. (linguistics) A lexeme that consists of more than one stem or an affix, e.g. bookshop, high school or non-standard. 
9. (rail transport) A compound locomotive, a steam locomotive with both high-pressure and low-pressure cylinders. 
10. Short for compound exercise.  

### Adjective
1. Composed of elements; not simple. 
2. (mathematics) Dealing with numbers of various denominations of quantity, or with processes more complex than the simple process. 
3. (music) An octave higher than originally (i.e. a compound major second is equivalent to a major ninth). 

### Verb
1. (transitive) To form (a resulting mixture) by combining different elements, ingredients, or parts; to mingle with something else. 
2. (transitive, law) To settle by agreeing on less than the claim, or on different terms than those stipulated. 
3. (transitive) To settle amicably; to adjust by agreement. 
4. (intransitive) To come to terms of agreement; to settle by a compromise. 
5. (transitive, obsolete) To compose; to constitute. 
6. (intransitive, finance) To increase in value with interest, where the interest is earned on both the principal sum and prior earned interest. 
7. (transitive, see usage notes) To worsen a situation. 
8. (horse racing, intransitive) Of a horse: to fail to maintain speed. 

## Synonyms
[[complex]] | [[combine]] | [[conjugate]] | [[cleft]] | [[colonial]] | [[intensify]] | [[heighten]]