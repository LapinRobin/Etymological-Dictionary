# chortle

## Etymology
- Perhaps a blend of chuckle +‎ snort. Coined by Lewis Carroll in his poem Jabberwocky, first published in 1855 but only introduced to the public in his 1871 novel Through the Looking-Glass.


## Definition
### Noun
1. A joyful, somewhat muffled laugh, rather like a snorting chuckle. 
2. A similar sounding vocalisation of various birds. 

### Verb
1. (intransitive) To laugh with a chortle or chortles. 

## Synonyms
[[chuckle]]