# indigenous

## Etymology
- Borrowed from Late Latin indigenus (“native, born in a country”), from indi- (indu-), an old derivative of in (“in”), gen- the root of gignō (“give birth to”), and English -ous. Compare indigene, Ancient Greek ἐνδογενής (endogenḗs, “born in the house”), and the separately formed endogenous.


## Definition
### Adjective
1. Born or originating in, native to a land or region, especially before an intrusion. 
2. In particular, of or relating to a people (or their language or culture) that inhabited a region prior to the arrival of people of other cultures which became dominant (e.g., through colonialism), and which maintains a distinct culture. 
3. Innate, inborn. 
4. Alternative letter-case form of indigenous (“native, relating to the native inhabitants of a land”)  

## Synonyms
[[endemic]] | [[native]] | [[autochthonous]]