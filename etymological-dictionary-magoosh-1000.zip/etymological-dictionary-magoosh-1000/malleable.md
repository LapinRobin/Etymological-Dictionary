# malleable

## Etymology
- From Middle French malléable, borrowed from Late Latin malleābilis, derived from Latin malleāre (“to hammer”), from malleus (“hammer”), from Proto-Indo-European *mal-ni- (“crushing”), an extended variant of *melh₂- (“crush, grind”).


## Definition
### Adjective
1. Able to be hammered into thin sheets; capable of being extended or shaped by beating with a hammer, or by the pressure of rollers. 
2. (figuratively) Flexible, liable to change. 
3. (cryptography, of an algorithm) in which an adversary can alter a ciphertext such that it decrypts to a related plaintext 

## Synonyms
[[pliable]] | [[elastic]] | [[ductile]] | [[pliant]] | [[tractable]] | [[tensile]]