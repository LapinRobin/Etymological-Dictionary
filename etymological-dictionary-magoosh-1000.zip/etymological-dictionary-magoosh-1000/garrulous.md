# garrulous

## Etymology
- Borrowed from Latin garrulus (“talkative”), from the verb garriō (“I chatter”).


## Definition
### Adjective
1. Excessively or tiresomely talkative. 
2. (of something written or performed) Excessively wordy and rambling. 

## Synonyms
[[loquacious]] | [[voluble]] | [[talkative]]