# capricious

## Etymology
- Borrowed from French capricieux, from Italian capriccioso, from capriccio.


## Definition
### Adjective
1. Impulsive and unpredictable; determined by chance, impulse, or whim. 

## Synonyms
[[arbitrary]] | [[whimsical]] | [[impulsive]] | [[unpredictable]]