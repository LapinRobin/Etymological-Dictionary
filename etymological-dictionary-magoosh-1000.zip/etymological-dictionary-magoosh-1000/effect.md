# effect

## Etymology
- For noun: from Middle English effect, from Old French effect (modern French effet), from Latin effectus (“an effect, tendency, purpose”), from efficiō (“accomplish, complete, effect”); see effect as a verb. Replaced Old English fremming, fremednes from fremman.


## Definition
### Noun
1. The result or outcome of a cause. 
2. Impression left on the mind; sensation produced. 
3. Execution; performance; realization; operation. 
4. (uncountable) The state of being binding and enforceable, as in a rule, policy, or law. 
5. (cinematography, computer graphics, demoscene) An illusion produced by technical means (as in "special effect") 
6. (sound engineering) An alteration, or device for producing an alteration, in sound after it has been produced by an instrument. 
7. (physics, psychology, etc.) A scientific phenomenon, usually named after its discoverer. 
8. (usually in the plural) Belongings, usually as personal effects. 
9. Consequence intended; purpose; meaning; general intent; with to. 
10. (obsolete) Reality; actual meaning; fact, as distinguished from mere appearance. 
11. (obsolete) Manifestation; expression; sign. 

### Verb
1. (transitive) To make or bring about; to implement. 
2. Misspelling of affect  

## Synonyms
[[force]] | [[issue]] | [[core]] | [[essence]] | [[gist]] | [[burden]] | [[consequence]] | [[result]] | [[impression]] | [[outcome]] | [[set up]] | [[upshot]] | [[carry out]] | [[effectuate]]