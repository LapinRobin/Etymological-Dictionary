# proselytize

## Etymology
- proselyte +‎ -ize


## Definition
### Verb
1. (transitive, intransitive, broadly) To advertise one’s religious beliefs; to convert (someone) to one’s own faith or religious movement or encourage them to do so. 
2. (transitive, intransitive, strictly) To coerce into religious conversion. 
3. (by extension, transitive, intransitive) To advertise a non-religious belief, way of living, cause, point of view, (scientific) hypothesis, social or other position, political party, or other organization; to convince someone to join such a cause or organization or support such a position; to recruit someone. 

## Synonyms
