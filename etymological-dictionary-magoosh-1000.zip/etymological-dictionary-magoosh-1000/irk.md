# irk

## Etymology
- From Middle English irken (“to tire, grow weary”), from Old Norse yrkja (“to work”), from Proto-Germanic *wurkijaną (“to work”), from Proto-Indo-European *werǵ- (“to work”). Cognate with Icelandic yrkja (“to compose”), Swedish yrka (“to urge, argue”), Old English wyrċan (“to work”). More at work.


## Definition
### Verb
1. (transitive) to irritate; annoy; bother 

### Noun
1. A river in Greater Manchester, England, which joins the River Irwell in Manchester city centre. 

## Synonyms
[[gall]]