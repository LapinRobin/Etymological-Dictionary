# restive

## Etymology
- Modification of earlier restiff, from Middle English restyf, from Old French restif, from rester (“stay, remain”), from Latin restō.


## Definition
### Adjective
1. Impatient under delay, duress, or control. 
2. Resistant to control; stubborn. 
3. Refusing to move, especially in a forward direction. 

## Synonyms
[[tense]] | [[nervous]] | [[edgy]] | [[impatient]] | [[jittery]] | [[uptight]]