# fastidious

## Etymology
- From Latin fastīdiōsus (“passive: that feels disgust, disdainful, scornful, fastidious; active: that causes disgust, disgusting, loathsome”), from fastīdium (“a loathing, aversion, disgust, niceness of taste, daintiness, etc.”), perhaps for *fastutidium, from fastus (“disdain, haughtiness, arrogance, disgust”) + taedium (“disgust”). Cf. French fastidieux.


## Definition
### Adjective
1. Excessively particular, demanding, or fussy about details, especially about tidiness and cleanliness. 
2. Overly concerned about tidiness and cleanliness. 
3. Difficult to please; quick to find fault. 

## Synonyms
[[nice]] | [[particular]] | [[meticulous]] | [[fussy]] | [[dainty]] | [[finicky]] | [[prissy]] | [[squeamish]] | [[persnickety]] | [[exacting]]