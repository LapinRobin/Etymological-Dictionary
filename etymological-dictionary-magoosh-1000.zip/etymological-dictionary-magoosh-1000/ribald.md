# ribald

## Etymology
- From Middle English ribald, from Old French ribaud, ribauld (“rogue, scoundrel”) ( > English ribaud), from Old French riber (“to be licentious”), from Frankish *rīban (“to copulate, be in heat”, literally “to rub”), from Proto-Germanic *wrībaną (“to turn, twist, writhe”), from Proto-Indo-European *werp-, *werb- (“to turn, twist”) + Old French -aud, from Frankish *-wald.


## Definition
### Adjective
1. Coarsely, vulgarly, or lewdly amusing; referring to sexual matters in a rude or irreverent way. 

### Noun
1. An individual who is filthy or vulgar in nature. 

## Synonyms
[[dirty]] | [[bawdy]]