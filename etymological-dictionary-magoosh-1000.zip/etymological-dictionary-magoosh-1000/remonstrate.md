# remonstrate

## Etymology
- From (the participle stem of) Late Latin remōnstrō, from Latin re- + mōnstrō.


## Definition
### Verb
1. (intransitive) To object with in critical fashion; to express disapproval (with, against). 
2. (intransitive, chiefly historical) Specifically, to lodge an official objection (especially by means of a remonstrance) with a monarch or other ruling body. 
3. (transitive, often with an object consisting of direct speech or a clause beginning with that) To state or plead as an objection, formal protest, or expression of disapproval. 
4. To point out; to show clearly; to make plain or manifest; hence, to prove; to demonstrate. 

## Synonyms
[[check]] | [[rebuke]] | [[reprimand]] | [[chide]] | [[rag]] | [[scold]] | [[berate]] | [[lecture]] | [[jaw]] | [[lambast]] | [[lambaste]] | [[reproof]]