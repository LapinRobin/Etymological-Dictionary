# opulence

## Etymology
- From French opulence, from Latin opulentia.


## Definition
### Noun
1. wealth 
2. abundance, bounty, profusion 
3. ostentatious display of wealth and luxury; plushness. 

## Synonyms
[[luxury]]