# malodorous

## Etymology
- mal- +‎ odorous


## Definition
### Adjective
1. Having a bad odor. 
2. (figuratively) Highly improper. 

## Synonyms
[[high]] | [[foul]] | [[sour]] | [[noisome]] | [[funky]] | [[rancid]] | [[fetid]] | [[putrid]] | [[musty]]