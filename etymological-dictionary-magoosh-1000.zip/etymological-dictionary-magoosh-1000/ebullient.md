# ebullient

## Etymology
- Borrowing from Latin ēbulliēns, present participle of ēbulliō (“I boil”), from bulliō (“I bubble up”) (English boil). Compare bubbling, bubbly, and perky, which use a similar metaphor.


## Definition
### Adjective
1. Enthusiastic; high-spirited. 
2. (literally, of a liquid) Boiling or agitated as if boiling. 

## Synonyms
[[exuberant]] | [[spirited]]