# genteel

## Etymology
- Borrowed from French gentil (“gentile”), from Latin gentīlis (“of or belonging to the same people or nation”), from gēns (“clan; tribe; people, family”) + adjective suffix -īlis (“-ile”). Doublet of gentle and gentile. See also gens, gender, genus, and generation.


## Definition
### Adjective
1. Affectedly proper or refined; somewhat prudish refinement; excessively polite. 
2. Polite and well-mannered. 
3. Stylish or elegant. 
4. Aristocratic. 

## Synonyms
[[polite]] | [[refined]] | [[cultured]]