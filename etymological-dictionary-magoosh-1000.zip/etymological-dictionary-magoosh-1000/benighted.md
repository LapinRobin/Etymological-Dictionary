# benighted

## Etymology
- From benight +‎ -ed.


## Definition
### Adjective
1. (obsolete or poetic) Overtaken by night; especially of a traveller, etc.: caught out by oncoming night before reaching one's destination. 
2. (obsolete) Plunged into darkness. 
3. (figuratively) Lacking education or knowledge; unenlightened; also, lacking morality; immoral, unscrupulous. 
4. (figuratively, obsolete) Difficult to understand; abstruse, obscure. 

## Synonyms
[[dark]]