# nonchalant

## Etymology
- Borrowed from French nonchalant, from Old French nonchaloir (“to be unconcerned”), from non- (“not”) +‎ chaloir (“to have concern for”), from Latin
non (“not”) +‎ calēre (“to be warm”).


## Definition
### Adjective
1. Casually calm and relaxed. 
2. Indifferent; unconcerned; behaving as if detached. 

## Synonyms
[[casual]] | [[insouciant]]