# umbrage

## Etymology
- From Middle French ombrage (“umbrage”), from Old French ombrage, from Latin umbrāticus (“in the shade”), from umbra (“shadow, shade”).


## Definition
### Noun
1. A feeling of anger or annoyance caused by something offensive. 
2. A feeling of doubt. 
3. Leaves that provide shade, as the foliage of trees. 
4. (obsolete) Shadow; shade. 

### Verb
1. (transitive) To displease or cause offense. 
2. (transitive) To shade. 

## Synonyms
[[offense]]