# eponym

## Etymology
- Back-formation from eponymous. See also -onym.


## Definition
### Noun
1. A real or fictitious person's name that has given rise to the name of a particular item. 
2. A word formed from a real or fictive person’s name. 
3. (loosely, nonstandard, by extension) A word formed from a real or fictive place or thing. 

## Synonyms
