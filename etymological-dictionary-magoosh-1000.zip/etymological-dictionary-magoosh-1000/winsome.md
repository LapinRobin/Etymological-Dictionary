# winsome

## Etymology
- From Middle English wynsom, winsom, winsome, winsum, wunsum (“beautiful; agreeable, gracious, pleasant; generous; of situations: favourable, propitious”), from Old English wynsum (“joyful, merry, pleasant; winsome”), from Proto-West Germanic *wunnjusam (“joyful”); synchronically analyzable as winne (“delight, joy, pleasure”) +‎ -some.


## Definition
### Adjective
1. Charming, engaging, winning; inspiring approval and trust, especially if in an innocent manner. 

## Synonyms
[[attractive]]