# pugnacious

## Etymology
- Borrowed from Latin, from a derivative of pugnāx, from pugnō (“I fight”), from pugnus (“fist”).


## Definition
### Adjective
1. Naturally aggressive or hostile; combative; belligerent; bellicose. 

## Synonyms
[[tough]] | [[aggressive]] | [[rough]]