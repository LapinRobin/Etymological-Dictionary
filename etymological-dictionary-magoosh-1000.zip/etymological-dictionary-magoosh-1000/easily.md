# easily

## Etymology
- From Middle English esiliche, equivalent to easy +‎ -ly.


## Definition
### Adverb
1. Comfortably, without discomfort or anxiety. 
2. Without difficulty. 
3. (colloquial, not comparable) Absolutely, without question. 

## Synonyms
[[well]] | [[easy]]