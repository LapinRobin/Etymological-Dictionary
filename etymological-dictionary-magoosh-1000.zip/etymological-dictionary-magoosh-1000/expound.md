# expound

## Etymology
- From Middle English expounden, from Old French espondre, from Latin exponere. Doublet of expose.


## Definition
### Verb
1. (transitive) To set out the meaning of; to explain or discuss at length 
2. (intransitive) To make a statement, especially at length. 

## Synonyms
[[elaborate]] | [[expand]] | [[dilate]] | [[expatiate]] | [[enlarge]]