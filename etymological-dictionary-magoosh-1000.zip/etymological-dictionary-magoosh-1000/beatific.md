# beatific

## Etymology
- From beatify, from Latin beatificare (“make blessed”), from beatus (“blessed”) + ficare (“make”), variant of facere.


## Definition
### Adjective
1. Blessed, blissful, heavenly. 
2. Having a benign appearance. 

## Synonyms
[[good]] | [[joyful]] | [[angelic]]