# base

## Etymology
- From Middle English base, bas, baas, from Old French base, from Latin basis, from Ancient Greek βάσις (básis). Doublet of basis.

- From Middle English base, bas, from Old French bas, from Late Latin bassus (“low”). Cognate with Spanish bajo, Italian basso and base.

- Probably a specific use of Etymology 1, above; perhaps also a development of the plural of bar.

- Variant forms.


## Definition
### Noun
1. Something from which other things extend; a foundation. 
2. A supporting, lower or bottom component of a structure or object. 
3. The starting point of a logical deduction or thought; basis. 
4. A permanent structure for housing military personnel and material. 
5. The place where decisions for an organization are made; headquarters. 
6. (cooking, painting, pharmacy) A basic but essential component or ingredient. 
7. A substance used as a mordant in dyeing. 
8. (cosmetics) Foundation: a cosmetic cream to make the face appear uniform. 
9. (chemistry) Any of a class of generally water-soluble compounds, having bitter taste, that turn red litmus blue, and react with acids to form salts. 
10. A safe zone in the children's games of tag and hide-and-go-seek. 
11. (baseball) One of the four places that a runner can stand without being subject to being tagged out when the ball is in play. 
12. (architecture) The lowermost part of a column, between the shaft and the pedestal or pavement. 
13. (biology, biochemistry) A nucleotide's nucleobase in the context of a DNA or RNA biopolymer. 
14. (botany) The end of a leaf, petal or similar organ where it is attached to its support. 
15. (electronics) The name of the controlling terminal of a bipolar transistor (BJT). 
16. (geometry) The lowest side of a triangle or other polygon, or the lowest face of a cone, pyramid or other polyhedron laid flat. 
17. (heraldry) The lowest third of a shield or escutcheon. 
18. (heraldry) The lower part of the field. See escutcheon. 
19. (mathematics) A number raised to the power of an exponent. 
20. (mathematics) Synonym of radix. 
21. (topology) The set of sets from which a topology is generated. 
22. (topology) A topological space, looked at in relation to one of its covering spaces, fibrations, or bundles. 
23. (group theory) A sequence of elements not jointly stabilized by any nontrivial group element. 
24. (acrobatics, cheerleading) In hand-to-hand balance, the person who supports the flyer; the person that remains in contact with the ground. 
25. (linguistics) A morpheme (or morphemes) that serves as a basic foundation on which affixes can be attached. 
26. (military, historical) The smallest kind of cannon. 
27. (archaic) The housing of a horse. 
28. (historical, sometimes in the plural) A kind of skirt (often of velvet or brocade, but sometimes of mail or other armour) which hung from the middle to about the knees, or lower. 
29. (obsolete) The lower part of a robe or petticoat. 
30. (obsolete) An apron. 
31. A line in a survey which, being accurately determined in length and position, serves as the origin from which to compute the distances and positions of any points or objects connected with it by a system of triangles. 
32. (politics) A group of voters who almost always support a single party's candidates for elected office. 
33. (Marxism) The forces and relations of production that produce the necessities and amenities of life. 
34. A material that holds paint or other materials together; a binder. 
35. (slang) freebase cocaine 
36. (now chiefly US, historical) The game of prisoners' bars. 
37. A surname transferred from the nickname. 
38. (aviation) Short for base leg.  
39. Alternative form of BASE 
40. Acronym of building, antenna-tower, span, earth.  

### Verb
1. (transitive) To give as its foundation or starting point; to lay the foundation of. 
2. (transitive) To be located (at a particular place). 
3. (acrobatics, cheerleading) To act as a base; to be the person supporting the flyer. 
4. (slang) To freebase. 

### Adjective
1. (obsolete) Low in height; short. 
2. Low in place or position. 
3. (obsolete) Of low value or degree. 
4. (archaic) Of low social standing or rank; vulgar, common. 
5. Morally reprehensible, immoral; cowardly. 
6. (now rare) Inferior; unworthy, of poor quality. 
7. (of a metal) Not considered precious or noble. 
8. Alloyed with inferior metal; debased. 
9. (obsolete) Of illegitimate birth; bastard. 
10. Not classical or correct. 
11. (law) Not held by honourable service. 
12. Obsolete form of bass.  

## Synonyms
[[home]] | [[stand]] | [[mean]] | [[bag]] | [[post]] | [[place]] | [[ground]] | [[root]] | [[foot]] | [[humble]] | [[radical]] | [[stem]] | [[station]] | [[establish]] | [[basis]] | [[foundation]] | [[floor]] | [[infrastructure]] | [[wrong]] | [[theme]] | [[send]] | [[basic]] | [[found]] | [[inferior]] | [[cornerstone]] | [[counterfeit]] | [[ignoble]] | [[pedestal]] | [[immoral]] | [[lowly]] | [[alkali]] | [[basal]] | [[groundwork]] | [[unethical]] | [[fundament]] | [[illegitimate]]