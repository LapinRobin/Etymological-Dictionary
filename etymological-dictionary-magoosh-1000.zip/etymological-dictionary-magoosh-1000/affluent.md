# affluent

## Etymology
- Borrowed from Middle French affluent, borrowed in turn from Latin affluentem, accusative singular of affluēns, present active participle of affluō (“flow to or towards; overflow with”), from ad (“to, towards”) + fluō (“flow”) (cognate via latter to fluid, flow). Sense of “wealthy” (plentiful flow of goods) c. 1600, which also led to nominalization affluence.


## Definition
### Noun
1. Somebody who is wealthy. 
2. A stream or river flowing into a larger river or into a lake; a tributary stream; a tributary. 

### Adjective
1. Abundant; copious; plenteous. 
2. (by extension) Abounding in goods or riches; having a moderate level of material wealth. 
3. (dated) Tributary. 
4. (obsolete) Flowing to; flowing abundantly. 

## Synonyms
[[flush]] | [[rich]] | [[wealthy]] | [[tributary]] | [[loaded]] | [[feeder]]