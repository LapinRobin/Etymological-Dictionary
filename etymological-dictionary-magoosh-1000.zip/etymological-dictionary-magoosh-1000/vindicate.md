# vindicate

## Etymology
- Borrowed from Latin vindicātus, perfect passive participle of vindicō (“lay legal claim to something; set free; protect, avenge, punish”), from vim, accusative singular of vīs (“force, power”), + dīcō (“say; declare, state”). See avenge.


## Definition
### Verb
1. (transitive) To clear of an accusation, suspicion or criticism. 
2. (transitive) To justify by providing evidence. 
3. (transitive) To maintain or defend (a cause) against opposition. 
4. (transitive) To provide justification for. 
5. (transitive) To lay claim to; to assert a right to; to claim. 
6. (transitive, obsolete) To liberate; to set free; to deliver. 
7. (transitive, obsolete) To avenge; to punish 

## Synonyms
[[justify]]