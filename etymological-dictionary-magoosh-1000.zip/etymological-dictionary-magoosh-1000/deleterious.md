# deleterious

## Etymology
- Borrowed (1640s, 1582 as deletorious) from Medieval Latin deleterius, deletorius, from Ancient Greek δηλητήριος (dēlētḗrios, “noxious, deleterious”), from δηλητήρ (dēlētḗr, “a destroyer”), from δηλέομαι (dēléomai, “I hurt, damage, spoil, waste”).


## Definition
### Adjective
1. Harmful often in a subtle or unexpected way. 
2. (genetics) Having lower fitness. 

## Synonyms
[[noxious]] | [[harmful]]