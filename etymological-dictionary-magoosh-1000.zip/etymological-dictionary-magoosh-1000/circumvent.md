# circumvent

## Etymology
- Latin circum (“about”) + venire (“to come”)


## Definition
### Verb
1. (transitive) to avoid or get around something; to bypass 
2. (transitive) to surround or besiege 
3. (transitive) to outwit or outsmart 

## Synonyms
[[beat]] | [[duck]] | [[hedge]] | [[elude]] | [[dodge]] | [[skirt]] | [[fudge]] | [[evade]] | [[surround]] | [[parry]] | [[besiege]] | [[put off]] | [[sidestep]] | [[overreach]]