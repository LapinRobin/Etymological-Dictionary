# demure

## Etymology
- From Middle English demure, demwre, of uncertain formation, but probably from Old French meur (Modern French mûr) from Latin mātūrus. The "de-" is "of", as in "of maturity".


## Definition
### Adjective
1. (usually of women) Quiet, modest, reserved, sober, or serious. 
2. Affectedly modest, decorous, or serious; making a show of gravity. 

### Verb
1. (obsolete) To look demurely. 

## Synonyms
[[coy]] | [[modest]]