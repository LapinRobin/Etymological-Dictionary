# consummate

## Etymology
- From Latin cōnsummātus, past participle of cōnsummāre (“to sum up, finish, complete”), from com- (“together”) + summa (“the sum”) (see sum, summation).


## Definition
### Adjective
1. Complete in every detail, perfect, absolute. 
2. Supremely skilled and experienced; highly accomplished; fully qualified. 

### Verb
1. (transitive) To bring (a task, project, goal etc.) to completion; to accomplish. 
2. (transitive) To make perfect, achieve, give the finishing touch. 
3. (transitive) To make (a marriage) complete by engaging in first sexual intercourse. 
4. (intransitive) To become perfected, receive the finishing touch. 

## Synonyms
[[perfect]] | [[complete]] | [[gross]] | [[pure]] | [[stark]] | [[utter]] | [[arrant]] | [[virtuoso]] | [[everlasting]] | [[staring]]