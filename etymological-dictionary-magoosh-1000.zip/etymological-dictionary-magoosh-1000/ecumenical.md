# ecumenical

## Etymology
- From ecumenic +‎ -al.


## Definition
### Adjective
1. (ecclesiastical) Pertaining to the universal Church, representing the entire Christian world; interdenominational; sometimes by extension, interreligious. 
2. (rare) General, universal, worldwide. 

## Synonyms
[[comprehensive]] | [[general]] | [[universal]] | [[cosmopolitan]] | [[worldwide]]