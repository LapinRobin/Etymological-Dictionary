# pecuniary

## Etymology
- From Latin pecūniārius, from pecūnia (“money”), itself from pecū (“cattle”) and thus related to fee.


## Definition
### Adjective
1. Of, or relating to, money; monetary, financial. 

## Synonyms
[[monetary]]