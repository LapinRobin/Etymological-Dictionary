# egotist

## Etymology
- ego + t (“inserted to avoid hiatus, or after the analogy of dramatist, epigrammatist, etc.”) +‎ -ist


## Definition
### Noun
1. A person who talks excessively about themself. 
2. A person who believes in his or her own importance or superiority. 
3. (nonstandard, by confusion of the similar words) An egoist (advocate of egoism). 

## Synonyms
