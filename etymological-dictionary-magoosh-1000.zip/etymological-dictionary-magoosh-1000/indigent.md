# indigent

## Etymology
- Circa 1400, Middle French, from Latin indigēns, present participle of indigeō (“to need”), from indu (“in, within”) + egeō (“to be in need, want”).


## Definition
### Adjective
1. Poor; destitute; in need. 
2. (archaic) Utterly lacking or in need of something specified. 

### Noun
1. A person in need, or in poverty. 

## Synonyms
[[poor]] | [[destitute]] | [[needy]] | [[impoverished]]