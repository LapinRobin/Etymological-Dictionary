# palaver

## Etymology
- Originally nautical slang, from Portuguese palavra (“word”), from Late Latin parabola (“parable, speech”). The term's use (especially in Africa) mimics the evolution of the word moot. As such, for sense development, see moot. Doublet of parable, parole, and parabola.


## Definition
### Noun
1. (Africa) A village council meeting. 
2. (North America, archaic British) Talk, especially unnecessary talk; chatter.  
3. (Britain) Mentally-draining activity, either physical or fuss. 
4. A meeting at which there is much talk; a debate; a moot. 
5. (informal) Disagreement. 
6. Talk intended to deceive.  

### Verb
1. (intransitive) To discuss with much talk. 
2. (transitive) To flatter. 

## Synonyms
[[rhetoric]] | [[cajole]] | [[coax]] | [[inveigle]] | [[chatter]] | [[wheedle]] | [[prattle]] | [[prate]] | [[twaddle]] | [[tattle]] | [[clack]]