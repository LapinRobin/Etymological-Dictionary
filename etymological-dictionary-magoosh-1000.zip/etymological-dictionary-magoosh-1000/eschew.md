# eschew

## Etymology
- From Middle English eschewen, from Anglo-Norman eschiver, (third-person present eschiu), from Frankish *skiuhijan (“to dread, shun, avoid”); thus a doublet of skew.


## Definition
### Verb
1. (transitive, formal) To avoid; to shun, to shy away from. 

## Synonyms
[[shun]]