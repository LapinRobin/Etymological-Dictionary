# pariah

## Etymology
- From Tamil பறையர் (paṟaiyar), from பறையன் (paṟaiyaṉ, “drummer”), from பறை (paṟai, “drum”) or from Malayalam പറയർ (paṟayaṟ), from പറയൻ (paṟayaṉ, “drummer”), from പറ (paṟa, “drum”). Parai in Tamil or Para in Malayalam refers to a type of large drum designed to announce the king’s notices to the public. The people who made a living using the parai were called paraiyar; in the caste-based society they were in the lower strata, hence the derisive paraiah and pariah.


## Definition
### Noun
1. Synonym of outcast: A person despised and excluded by their family, community, or society, especially a member of the untouchable castes in Indian society. 
2. (figuratively) A similarly despised group of people or species of animal. 
3. (zoology) Ellipsis of pariah dog: an Indian breed, any stray dog in Indian contexts.  

## Synonyms
[[outcast]]