# qualm

## Etymology
- Perhaps from Middle English qualm, cwalm (“death, sickness, plague”), which is from Old English cwealm (West Saxon: "death, disaster, plague"), ūtcwalm (Anglian: "utter destruction"), from Proto-West Germanic *kwalm (“killing, death, destruction”), from Proto-Indo-European *gʷelH- (“to stick, pierce; pain, injury, death”), whence also quell.  Although the sense development is possible, this has the problem that there are no attestations in intermediate senses before the appearance of "pang of apprehension, etc." in the 16th century. The alternative etymology is from Dutch kwalm or German Qualm (“steam, vapor, mist”) earlier “daze, stupefaction”, which is from the root of German quellen (“to stream, well up”). The sense “feeling of faintness” is from 1530; “uneasiness, doubt” from 1553; “scruple of conscience” from 1649.


## Definition
### Noun
1. A feeling of apprehension, doubt, fear etc. 
2. A sudden sickly feeling; queasiness. 
3. (now chiefly in the negative) A prick of the conscience; a moral scruple, a pang of guilt. 
4. (archaic, UK dialectal) Mortality; plague; pestilence. 
5. (archaic, UK dialectal) A calamity or disaster. 

### Verb
1. (intransitive) To have a sickly feeling. 

## Synonyms
[[scruple]] | [[misgiving]]