# iconoclast

## Etymology
- Borrowed from French iconoclaste, from Byzantine Greek εἰκονοκλάστης (eikonoklástēs, literally “image breaker”).


## Definition
### Noun
1. (historical, Christianity) One who destroys religious images or icons, especially an opponent of the Orthodox Church in the 8th and 9th centuries, or a Puritan during the European Reformation. 
2. One who opposes orthodoxy and religion; one who adheres to the doctrine of iconoclasm. 
3. (by extension) One who attacks cherished beliefs. 

## Synonyms
