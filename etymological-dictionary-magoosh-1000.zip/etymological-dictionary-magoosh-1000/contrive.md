# contrive

## Etymology
- From Middle English contreve (“to invent”), from Old French controver (Modern French controuver), from trover (“to find”) (French trouver).


## Definition
### Verb
1. To invent by an exercise of ingenuity; to devise 
2. To invent, to make devices; to form designs especially by improvisation. 
3. To project, cast, or set forth, as in a projection of light. 
4. (obsolete, transitive) To spend (time, or a period). 

## Synonyms
[[cast]] | [[plan]] | [[design]] | [[throw]] | [[project]] | [[forge]] | [[devise]] | [[formulate]] | [[invent]]