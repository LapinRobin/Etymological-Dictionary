# churlish

## Etymology
- From Middle English churlysshe, cherlissh, from late Old English ċeorlisċ, ċierlisċ (“of or pertaining to churls”), equivalent to churl +‎ -ish.


## Definition
### Adjective
1. Of or pertaining to a serf, peasant, or rustic. 
2. Rude, surly, ungracious. 
3. Stingy or grudging. 
4. (of soil) Difficult to till, lacking pliancy; unmanageable. 

## Synonyms
