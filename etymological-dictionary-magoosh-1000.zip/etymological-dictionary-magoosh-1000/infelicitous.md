# infelicitous

## Etymology
- From in- +‎ felicitous.


## Definition
### Adjective
1. Unhappy or unfortunate. 
2. Inappropriate or awkward; not well said, expressed, or done. 
3. (linguistics) Of a sentence or utterance: not semantically and pragmatically coherent. 

## Synonyms
[[awkward]] | [[cumbersome]] | [[inept]] | [[clumsy]] | [[inapt]] | [[unfortunate]]