# cohesive

## Etymology
- From Latin cohaesus, past participle of cohaereō, +‎ -ive.


## Definition
### Adjective
1. Having cohesion. 

### Noun
1. A substance that provides cohesion 
2. (linguistics) A device used to establish cohesion within a text 

## Synonyms
[[adhesive]] | [[united]]