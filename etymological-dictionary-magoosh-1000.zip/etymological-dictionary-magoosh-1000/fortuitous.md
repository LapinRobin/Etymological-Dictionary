# fortuitous

## Etymology
- From Latin fortuītus.


## Definition
### Adjective
1. Happening by chance; coincidental, accidental. 
2. Happening by a lucky chance; lucky or fortunate. 
3. (law) Happening independently of human will. 

## Synonyms
[[fortunate]]