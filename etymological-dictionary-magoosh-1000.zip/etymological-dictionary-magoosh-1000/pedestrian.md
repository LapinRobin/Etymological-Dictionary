# pedestrian

## Etymology
- Borrowed from Latin pedester, root pedestri- (from pedes) + -an (suffix forming adjectives).


## Definition
### Adjective
1. (not comparable) Of or intended for those who are walking. 
2. (comparable, figuratively) Ordinary, dull; everyday; unexceptional. 
3. (dance) Pertaining to ordinary, everyday movements incorporated in postmodern dance. 

### Noun
1. A walker; one who walks or goes on foot, especially as opposed to one who uses a vehicle. 
2. (dated) An expert or professional walker or runner; one who performs feats of walking or running. 

## Synonyms
[[prosaic]] | [[walker]]