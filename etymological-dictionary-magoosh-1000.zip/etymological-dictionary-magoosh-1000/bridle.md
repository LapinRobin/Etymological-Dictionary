# bridle

## Etymology
- From Middle English bridel, from Old English brīdel, from Proto-West Germanic *brigdil, from Proto-Germanic *brigdilaz (“strap, rein”), equivalent to braid +‎ -le.


## Definition
### Noun
1. The headgear with which a horse is directed and which carries a bit and reins. 
2. (figuratively) A restraint; a curb; a check. 
3. A length of line or cable attached to two parts of something to spread the force of a pull, as the rigging on a kite for attaching line. 
4. A mooring hawser. 
5. A piece in the interior of a gunlock which holds in place the tumbler, sear, etc. 
6. A gesture expressing pride or vanity. 

### Verb
1. (transitive) To put a bridle on. 
2. (transitive) To check, restrain, or control with, or as if with, a bridle; as in bridle your tongue. 
3. (intransitive) To show hostility or resentment. 
4. (intransitive) To hold up one's head proudly or affectedly. 

## Synonyms
[[check]] | [[curb]]