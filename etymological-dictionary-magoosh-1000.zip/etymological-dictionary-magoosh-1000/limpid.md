# limpid

## Etymology
- From French limpide, from Latin limpidus.


## Definition
### Adjective
1. Clear, transparent or bright. 

## Synonyms
[[clear]] | [[lucid]] | [[transparent]] | [[liquid]] | [[pellucid]] | [[perspicuous]] | [[crystalline]]