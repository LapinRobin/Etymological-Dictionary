# precedent

## Etymology
- From Middle French, from Old French, from Latin praecēdēns, present participle of praecēdere (“to precede”); See precede.


## Definition
### Noun
1. An act in the past which may be used as an example to help decide the outcome of similar instances in the future. 
2. (law) A decided case which is cited or used as an example to justify a judgment in a subsequent case. 
3. An established habit or custom. 
4. (obsolete, with definite article) The aforementioned (thing). 
5. The previous version. 
6. (obsolete) A rough draught of a writing which precedes a finished copy. 

### Adjective
1. Happening or taking place earlier in time; previous or preceding. 
2. (now rare) Coming before in a particular order or arrangement; preceding, foregoing. 

### Verb
1. (transitive, law) To provide precedents for. 
2. (transitive, law) To be a precedent for. 

## Synonyms
