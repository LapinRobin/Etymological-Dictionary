# meander

## Etymology
- From Latin Maeander, from Ancient Greek Μαίανδρος (Maíandros) – a river in Asia Minor (present day Turkey) known for its winding course (modern Turkish Menderes).


## Definition
### Noun
1. One of the turns of a winding, crooked, or involved course. 
2. A tortuous or intricate movement. 
3. (geography) one of a series of regular sinuous curves, bends, loops, turns, or windings in the channel of a river, stream, or other watercourse 
4. Fretwork. 
5. Perplexity. 
6. Synonym of Greek key, a decorative border. 
7. (mathematics) A self-avoiding closed curve which intersects a line a number of times. 

### Verb
1. (intransitive) To wind or turn in a course or passage; to be intricate. 
2. (transitive) To wind, turn, or twist; to make flexuous. 

## Synonyms
[[wind]] | [[weave]] | [[thread]]