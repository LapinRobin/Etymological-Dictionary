# phlegmatic

## Etymology
- From Middle English fleumatik, flewmatik, flematik, fleumatyke, flewmatyk, from Old French fleumatique, from Latin phlegmaticus, from Ancient Greek φλεγματικός (phlegmatikós), from φλέγμα (phlégma). Spelling later altered to resemble the word's Latin and Greek roots, with modern pronunciation following this new spelling.


## Definition
### Adjective
1. Not easily excited to action or passion; calm; sluggish. 
2. (archaic) Abounding in phlegm. 
3. Generating, causing, or full of phlegm. 

### Noun
1. One who has a phlegmatic disposition. 

## Synonyms
