# contentious

## Etymology
- From Middle French contentieux, from Latin contentiōsus (“quarrelsome, perverse”), from contentiō (“contention”), from contendere, past participle contentus (“to contend”). Equivalent to English contention + -ous.


## Definition
### Adjective
1. Marked by heated arguments or controversy. 
2. Given to struggling with others out of jealousy or discord. 

## Synonyms
[[aggressive]] | [[bellicose]] | [[controversial]] | [[litigious]] | [[combative]] | [[argumentative]]