# enumerate

## Etymology
- From Latin enumerātus, from enumerō.


## Definition
### Verb
1. To specify each member of a sequence individually in incrementing order. 
2. To determine the amount of. 

## Synonyms
[[number]] | [[count]]