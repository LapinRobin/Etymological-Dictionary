# detrimental

## Etymology
- From Medieval Latin *dētrīmentālis, from Latin dētrīmentum (“harm”), from dēterō (“to rub off, wear”), from dē- (“down, away”) + terō (“to rub or grab”).


## Definition
### Adjective
1. Causing damage or harm. 

## Synonyms
[[harmful]]