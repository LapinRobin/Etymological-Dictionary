# unstinting

## Etymology
- un- +‎ stinting


## Definition
### Adjective
1. generous and tireless with one's contributions of time, money, etc. 

## Synonyms
[[prodigal]] | [[lavish]] | [[generous]] | [[munificent]]