# edifying

## Definition
### Adjective
1. That educates, informs, illuminates or instructs. 
2. That enlightens or uplifts. 

### Noun
1. edification 

## Synonyms
