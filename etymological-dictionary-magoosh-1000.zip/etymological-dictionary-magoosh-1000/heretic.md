# heretic

## Etymology
- From Middle English heretyk, heretike, from Old French eretique, from Medieval Latin or Ecclesiastical Latin haereticus, from Ancient Greek αἱρετικός (hairetikós, “able to choose, factious”), itself from Ancient Greek αἱρέω (hairéō, “I choose”).


## Definition
### Noun
1. Someone who believes contrary to the fundamental tenets of a religion they claim to belong to. 
2. Someone who does not conform to generally accepted beliefs or practices 

### Adjective
1. (archaic) Heretical; of or pertaining to heresy or heretics. 

## Synonyms
