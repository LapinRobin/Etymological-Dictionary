# effervescence

## Etymology
- Borrowed from French effervescence.


## Definition
### Noun
1. The escape of gas from solution in a liquid, especially the escape of carbon dioxide from a carbonated drink. 
2. Vivacity. 
3. Foment. 

## Synonyms
