# junta

## Etymology
- Borrowed from Spanish junta, feminine form of junto, from Latin iunctus, perfect passive participle of iungō (“join”). Attested from 1623.


## Definition
### Noun
1. A council, convention, tribunal or assembly; especially, the grand council of state in Spain. 
2. The ruling council of a military dictatorship. 

## Synonyms
[[cabal]] | [[faction]]