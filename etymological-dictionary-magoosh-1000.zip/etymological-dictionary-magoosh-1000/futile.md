# futile

## Etymology
- From Middle French futile, from Latin fūtilis. Doublet of god.


## Definition
### Adjective
1. Incapable of producing results; doomed not to be successful; not worth attempting. 

## Synonyms
[[vain]] | [[otiose]] | [[useless]] | [[ineffectual]]