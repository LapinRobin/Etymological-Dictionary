# edification

## Etymology
- From Old French, from Latin aedificationem (“building, construction”), an accusative form of aedificatio, from aedificare.


## Definition
### Noun
1. The act of edifying, or the state of being edified or improved; a building process, especially morally, emotionally, or spiritually 
2. (archaic) A building or edifice. 

## Synonyms
[[sophistication]]