# sullen

## Etymology
- From Middle English solein, from Anglo-Norman soleyn (“alone”), from Old French sole (“single, sole, alone”), from Latin sōlus (“by oneself alone”). The change in meaning from "single" to morose occurred in Middle English.


## Definition
### Adjective
1. Having a brooding ill temper; sulky. 
2. Gloomy; dismal; foreboding. 
3. Sluggish; slow. 
4. (obsolete) Lonely; solitary; desolate. 
5. (obsolete) Mischievous; malignant; unpropitious. 
6. (obsolete) Obstinate; intractable. 

### Noun
1. (obsolete) One who is solitary, or lives alone; a hermit. 
2. (chiefly in the plural) Sullen feelings or manners; sulks; moroseness. 

## Synonyms
[[dark]] | [[morose]] | [[heavy]] | [[dour]] | [[sour]] | [[saturnine]] | [[moody]] | [[glum]] | [[cloudy]] | [[threatening]]