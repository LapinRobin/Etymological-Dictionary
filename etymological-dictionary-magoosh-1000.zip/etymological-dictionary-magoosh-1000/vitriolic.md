# vitriolic

## Etymology
- From vitriol +‎ -ic; or from French vitriolique (cognate with Italian vetriolico, Portuguese vitriolico, Spanish vitriolico).


## Definition
### Adjective
1. (chemistry, dated) Of or pertaining to vitriol; derived from or resembling vitriol. 
2. (figuratively) Bitterly scathing, caustic. 

## Synonyms
[[acid]] | [[bitter]] | [[acerbic]] | [[caustic]] | [[acrid]] | [[virulent]] | [[unpleasant]] | [[blistering]] | [[venomous]] | [[destructive]] | [[corrosive]]