# apogee

## Etymology
- From French apogée, from Latin apogaeum, apogeum, from Ancient Greek ἀπόγειον (apógeion, “away from Earth”), from ἀπό (apó, “away”) + γῆ (gê, “Earth”).


## Definition
### Noun
1. (astronomy) The point, in an orbit about the Earth, that is farthest from the Earth: the apoapsis of an Earth orbiter. 
2. (astronomy, more generally) The point, in an orbit about any planet, that is farthest from the planet: the apoapsis of any satellite. 
3. (possibly archaic outside astrology) The point, in any trajectory of an object in space, where it is farthest from the Earth. 
4. (figuratively) The highest point. 

## Synonyms
[[culmination]]