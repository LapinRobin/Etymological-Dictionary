# irresolute

## Etymology
- First attested in  1580. Borrowed from French irrésolu or composed from ir- +‎ resolute.


## Definition
### Adjective
1. Undecided or unsure how to act. 
2. Indecisive or lacking in resolution. 

## Synonyms
[[hesitant]] | [[infirm]] | [[indecisive]] | [[unstable]]