# echelon

## Etymology
- Borrowed from French échelon (“rung; echelon”), from échelle (“ladder”) + -on (“suffix forming diminutives”). Échelle is derived from Latin scāla (“ladder”), from scandō (“to ascend, climb”), from Proto-Indo-European *skend- (“to jump”).


## Definition
### Noun
1. A level or rank in an organization, profession, or society. 
2. (cycling) A line of riders seeking maximum drafting in a crosswind, resulting in a diagonal line across the road. 
3. (military) A formation of troops, ships, etc., in diagonal parallel rows. 
4. An international SIGINT network to monitor and gather intelligence from satellite trunk communications. 

### Verb
1. (transitive, military) To form troops into an echelon. 

### Adjective
1. (linear algebra) Of a matrix: having undergone Gaussian elimination with the result that the leading coefficient or pivot (that is, the first nonzero number from the left) of a nonzero row is to the right of the pivot of the row above it, giving rise to a stepped appearance in the matrix. 

## Synonyms
