# eagle-eyed

## Definition
### Adjective
1. Having great visual acuity, especially the ability to see at a distance. 
2. Keenly perceptive. 

## Synonyms
