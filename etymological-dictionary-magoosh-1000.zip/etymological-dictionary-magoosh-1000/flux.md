# flux

## Etymology
- From Old French flux, from Latin fluxus (“flow”).


## Definition
### Noun
1. The act of flowing; a continuous moving on or passing by, as of a flowing stream. 
2. A state of ongoing change. 
3. A chemical agent for cleaning metal prior to soldering or welding. 
4. (physics) The rate of transfer of energy (or another physical quantity), especially an electric or magnetic field, through a given surface. 
5. (archaic) A disease which causes diarrhea, especially dysentery. 
6. (archaic) Diarrhea or other fluid discharge from the body. 
7. The state of being liquid through heat; fusion. 

### Verb
1. (transitive) To use flux on. 
2. (transitive) To melt. 
3. (intransitive) To flow as a liquid. 

### Adjective
1. (uncommon) Flowing; unstable; inconstant; variable. 

## Synonyms
