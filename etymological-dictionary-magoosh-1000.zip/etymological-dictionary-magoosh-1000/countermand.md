# countermand

## Etymology
- From Old French contremander, from Medieval Latin contramandō, from contra + mandō (“I order; I command”).


## Definition
### Verb
1. To revoke (a former command); to cancel or rescind by giving an order contrary to one previously given. 
2. To recall a person or unit with such an order. 
3. To cancel an order for (some specified goods). 
4. (figuratively) To counteract, to act against, to frustrate. 
5. (obsolete) To prohibit (a course of action or behavior). 
6. (obsolete) To oppose or revoke the command of (someone). 
7. (obsolete) To maintain control of, to keep under command. 

### Noun
1. An order to the contrary of a previous one. 

## Synonyms
[[lift]] | [[reverse]] | [[rescind]] | [[revoke]] | [[repeal]] | [[annul]] | [[overturn]]