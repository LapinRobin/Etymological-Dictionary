# phantasmagorical

## Etymology
- phantasmagoric +‎ -al


## Definition
### Adjective
1. Alternative form of phantasmagoric  

## Synonyms
[[surreal]]