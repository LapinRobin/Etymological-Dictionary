# bemoan

## Etymology
- From Middle English bemenen, bimenen, from Old English bemǣnan (“to bemoan, bewail, lament”); equivalent to be- (“about, concerning”) +‎ moan. Alteration of vowel from Middle to Modern English due to analogy with moan.


## Definition
### Verb
1. (transitive) To moan or complain about (something). 
2. (transitive, reflexive) To be dismayed or worried about (someone), particularly because of their situation or what has happened to them. 

## Synonyms
[[lament]] | [[regret]] | [[deplore]] | [[bewail]]