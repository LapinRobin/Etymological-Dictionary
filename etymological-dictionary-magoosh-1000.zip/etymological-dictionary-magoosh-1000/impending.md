# impending

## Etymology
- From impend +‎ -ing.


## Definition
### Adjective
1. Approaching; drawing near; about to happen or expected to happen. 

### Noun
1. Something that impends or threatens; an expected event. 

## Synonyms
[[imminent]] | [[close]] | [[at hand]]