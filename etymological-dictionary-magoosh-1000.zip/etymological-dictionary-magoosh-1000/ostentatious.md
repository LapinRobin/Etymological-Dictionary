# ostentatious

## Etymology
- Originated 1650–60; ostentation +‎ -ious.


## Definition
### Adjective
1. Of ostentation. 
2. Intended to attract notice. 
3. Of tawdry display; kitsch. 

## Synonyms
[[pretentious]] | [[conspicuous]] | [[kitsch]]