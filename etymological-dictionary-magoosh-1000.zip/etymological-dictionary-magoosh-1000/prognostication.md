# prognostication

## Etymology
- From Old French pronosticacion, from Medieval Latin prognosticatio.


## Definition
### Noun
1. A statement about or prior knowledge of the future. 

## Synonyms
[[prophecy]]