# turgid

## Etymology
- From Latin turgidus (“swollen, inflated”), from turgeō (“to swell”).


## Definition
### Adjective
1. Distended beyond the natural state by some internal agent, especially fluid, or expansive force. 
2. (of language or style) Overly complex and difficult to understand; grandiloquent; bombastic. 

## Synonyms
[[large]] | [[rhetorical]] | [[bombastic]] | [[orotund]]