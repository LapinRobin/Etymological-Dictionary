# trenchant

## Etymology
- Borrowed into Middle English from Old French trenchant, the present participle of trenchier (“to cut”).


## Definition
### Adjective
1. (obsolete) Fitted to trench or cut; gutting; sharp. 
2. (figuratively) Keen; biting; vigorously articulate and effective; severe. 

## Synonyms
[[clear]] | [[effective]] | [[distinct]] | [[intelligent]] | [[efficacious]] | [[clear-cut]]