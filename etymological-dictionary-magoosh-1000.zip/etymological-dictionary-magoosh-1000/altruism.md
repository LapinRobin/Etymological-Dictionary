# altruism

## Etymology
- From French altruisme, which was coined in 1830 by Auguste Comte from autrui (“of or to others”) +‎ -isme, from Old French, from Latin alteri, dative of alter (“other”) (whence also English alter). Apparently inspired by the French Latin legal phrase l’autrui, from le bien, le droit d’autrui (“the good, the right of the other”). Introduced into English by George Henry Lewes in 1853, in his translation Comte’s Philosophy of the Sciences, 1, xxi.


## Definition
### Noun
1. Regard for others, both natural and moral without regard for oneself; devotion to the interests of others; brotherly kindness. 
2. (biology, sociobiology) Action or behaviour that benefits another or others at some cost to the performer. 

## Synonyms
