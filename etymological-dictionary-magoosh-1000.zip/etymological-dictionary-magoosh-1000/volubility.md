# volubility

## Etymology
- voluble +‎ -ity, from Latin volubilitas.


## Definition
### Noun
1. (uncountable) the state of being voluble 
2. (countable) the degree to which someone is voluble 

## Synonyms
