# sartorial

## Etymology
- From New Latin sartorius (“pertaining to a tailor”), from Late Latin sartor (“tailor”), from Latin sarcire (“to patch, mend”).


## Definition
### Adjective
1. (not comparable) Of or relating to the tailoring of clothing. 
2. Of or relating to the quality of dress. 
3. (anatomy) Of or relating to the sartorius muscle. 

## Synonyms
