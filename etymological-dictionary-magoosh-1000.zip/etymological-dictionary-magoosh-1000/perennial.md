# perennial

## Etymology
- The adjective is borrowed from Latin perennis (“lasting through the whole year or for several years, perennial; continual, everlasting, perpetual”) + English -al (suffix meaning ‘of or pertaining to’ forming adjectives). Perennis is derived from per- (“completive or intensifying prefix with the sense of doing something all the way through or entirely”) + annus (“year; season, time”) (possibly ultimately from Proto-Indo-European *h₂et- (“to go”)). The English word is analysable as per- +‎ -ennial.


## Definition
### Adjective
1. Lasting or remaining active throughout the year, or all the time. 
2. Continuing without cessation or intermission for several years, or for an undetermined or infinite period; neverending or never failing; perpetual, unceasing. 
3. Appearing or recurring again and again; recurrent. 
4. (botany) Of a plant: active throughout the year, or having a life cycle of more than two growing seasons. 

### Noun
1. (botany) A plant that is active throughout the year, or has a life cycle of more than two growing seasons. 
2. A thing that lasts forever. 
3. A person or thing (such as a problem) that appears or returns regularly. 

## Synonyms
[[long]] | [[recurrent]] | [[continual]]