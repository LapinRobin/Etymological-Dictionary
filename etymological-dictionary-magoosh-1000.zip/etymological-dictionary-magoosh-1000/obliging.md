# obliging

## Definition
### Adjective
1. Happy and ready to do favours for others. 

### Noun
1. The imposition of an obligation. 

## Synonyms
[[compliant]] | [[accommodating]] | [[complaisant]]