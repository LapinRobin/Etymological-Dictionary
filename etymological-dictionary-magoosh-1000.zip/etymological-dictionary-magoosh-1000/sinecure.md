# sinecure

## Etymology
- From Latin sine (“without”) + cūrā (“care”) in beneficium sine cūrā (“benefice without care”).


## Definition
### Noun
1. A position that requires no work but still gives an ample payment; a cushy job. 
2. (historical) An ecclesiastical benefice without the care of souls. 

### Adjective
1. Requiring no work for an ample reward. In general this usage is tautological and should be avoided. 
2. Having the appearance of functionality without being of any actual use or purpose. 

### Verb
1. (transitive) To put or place in a sinecure. 

## Synonyms
