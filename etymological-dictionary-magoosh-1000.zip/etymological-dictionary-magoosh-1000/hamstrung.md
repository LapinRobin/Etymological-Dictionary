# hamstrung

## Definition
### Adjective
1. (figuratively) Restricted as if by being crippled with a hamstring. 

## Synonyms
