# wanton

## Etymology
- From Middle English wantoun, wantowen, wantoȝen, wantowe (“uneducated; unrestrained; licentious; sportive; playful”), from wan- (“not, un-, mis-”) + towen, i-towen (“educated”, literally “towed; led; drawn”), from Old English togen, ġetogen, past participle of tēon (“to train, discipline”), equivalent to wan- +‎ towed.


## Definition
### Adjective
1. (archaic) Undisciplined, unruly; not able to be controlled. 
2. (obsolete) Playful, sportive; merry or carefree. 
3. Lewd, immoral; sexually open, unchaste. 
4. Capricious, reckless of morality, justice etc.; acting without regard for the law or the well-being of others; gratuitous. 
5. (archaic) Extravagant, unrestrained, excessive. 

### Noun
1. A pampered or coddled person. 
2. An overly playful person; a trifler. 
3. A self-indulgent person, fond of excess. 
4. (archaic) A lewd or immoral person, especially a prostitute. 

### Verb
1. (intransitive) To rove and ramble without restraint, rule, or limit; to revel; to play loosely; to frolic. 
2. (transitive) To waste or squander, especially in pleasure (most often with away). 
3. (intransitive) To act wantonly; to be lewd or lascivious. 

## Synonyms
[[light]] | [[loose]] | [[easy]] | [[trifle]] | [[promiscuous]]