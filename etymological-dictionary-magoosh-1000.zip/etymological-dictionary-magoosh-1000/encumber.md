# encumber

## Etymology
- From Middle English encombren, from Old French encombrer, from en- + combrer (“to hinder”); see cumber.


## Definition
### Verb
1. (transitive) to load down something with a burden 
2. (transitive) to restrict or block something with a hindrance or impediment 
3. (transitive) to burden with a legal claim or other obligation 

## Synonyms
[[constrain]] | [[restrain]]