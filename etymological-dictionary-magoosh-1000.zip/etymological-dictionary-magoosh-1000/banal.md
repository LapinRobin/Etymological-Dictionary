# banal

## Etymology
- Borrowed from French banal (“held in common, relating to feudal service, by extension commonplace”), from Old French banel, related to Medieval Latin bannālis (“subject to feudal authority”), from Latin bannus (“jurisdiction”), both ultimately from Proto-Germanic *bannaną (“to order, summon, forbid”). Equivalent to ban +‎ -al. See also ban, abandon.


## Definition
### Adjective
1. Common in a boring way, to the point of being predictable; containing nothing new or fresh. 
2. (uncommon, historical) Relating to a type of feudal jurisdiction or service. 

## Synonyms
[[stock]] | [[trite]] | [[trivial]] | [[ordinary]] | [[tired]] | [[hackneyed]] | [[commonplace]]