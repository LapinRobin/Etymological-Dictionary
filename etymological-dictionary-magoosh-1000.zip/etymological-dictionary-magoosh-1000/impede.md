# impede

## Etymology
- Borrowed from Latin impediō (“to shackle”), from pēs (“foot”) (compare pedestrian). First attested use as a verb was in William Shakespeare's Macbeth.


## Definition
### Verb
1. (transitive) To get in the way of; to hinder. 

## Synonyms
[[block]] | [[hinder]] | [[jam]] | [[obstruct]] | [[occlude]]