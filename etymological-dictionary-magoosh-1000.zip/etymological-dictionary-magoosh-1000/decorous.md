# decorous

## Etymology
- From Latin decōrus (“seemly, becoming”).


## Definition
### Adjective
1. Marked by proper behaviour. 

## Synonyms
[[decent]] | [[proper]] | [[staid]] | [[sedate]] | [[comely]]