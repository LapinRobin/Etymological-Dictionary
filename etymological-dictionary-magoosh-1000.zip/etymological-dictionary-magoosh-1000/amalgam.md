# amalgam

## Etymology
- From Medieval Latin amalgama (“mercury alloy”), from Arabic اَلْمَلْغَم‎ (al-malḡam, “emollient poultice or unguent for sores”), from Ancient Greek μάλαγμα (málagma, “emollient; malleable material”), from μαλάσσω (malássō, “to soften”), from μαλακός (malakós, “soft”). Doublet of malagma. For the verb, compare French amalgamer.


## Definition
### Noun
1. (metallurgy) An alloy containing mercury. 
2. A combination of different things. 
3. One of the ingredients in an alloy. 

### Verb
1. (archaic, transitive, intransitive) To amalgamate. 

## Synonyms
