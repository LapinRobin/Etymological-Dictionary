# voracious

## Etymology
- From Latin vorāx, from vorō (“I devour”).


## Definition
### Adjective
1. Wanting or devouring great quantities of food. 
2. Having a great appetite for anything. 

## Synonyms
[[rapacious]] | [[esurient]] | [[ravenous]]