# enmity

## Etymology
- From Middle English enemyte, from Old French enemisté, ennemistié, from Late Latin, Vulgar Latin *inimīcitās, *inimīcitātem, from Latin inimīcus (“enemy”); cognates: French inimitié, Portuguese inimizade, Spanish enemistad. Equivalent to enemy +‎ -ity.


## Definition
### Noun
1. The quality of being an enemy; hostile or unfriendly disposition. 
2. A state or feeling of opposition, hostility, hatred or animosity. 

## Synonyms
[[hostility]] | [[antagonism]]