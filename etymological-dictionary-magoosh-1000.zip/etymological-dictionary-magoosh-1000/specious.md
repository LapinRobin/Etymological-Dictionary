# specious

## Etymology
- From Latin speciōsus (“good-looking”).

- See speciose.


## Definition
### Adjective
1. Seemingly well-reasoned, plausible or true, but actually fallacious. 
2. Employing fallacious but deceptively plausible arguments; deceitful. 
3. Having an attractive appearance intended to generate a favorable response; deceptively attractive. 
4. (obsolete) Beautiful, pleasing to look at. 
5. Alternative form of speciose (“rich in species”).  

## Synonyms
[[spurious]] | [[meretricious]] | [[false]] | [[invalid]] | [[gilded]]