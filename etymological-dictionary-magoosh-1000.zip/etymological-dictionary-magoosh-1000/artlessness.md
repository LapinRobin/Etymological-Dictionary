# artlessness

## Etymology
- artless +‎ -ness


## Definition
### Noun
1. the state or quality of being artless 
2. the state or quality of being innocent; naïveté 

## Synonyms
[[innocence]]