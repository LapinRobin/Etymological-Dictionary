# spurious

## Etymology
- Borrowed from Late Latin spurius (“illegitimate, bastardly”), possibly related to sperno or from Etruscan.


## Definition
### Adjective
1. False, not authentic, not genuine. 
2. Extraneous; stray; not relevant or wanted. 
3. (archaic) bastardly, illegitimate 

## Synonyms
[[natural]] | [[specious]] | [[counterfeit]] | [[invalid]] | [[illegitimate]]