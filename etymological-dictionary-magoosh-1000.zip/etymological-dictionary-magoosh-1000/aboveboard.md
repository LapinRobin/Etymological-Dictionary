# aboveboard

## Definition
### Adjective
1. Alternative form of above-board  

## Synonyms
[[straight]] | [[straightforward]]