# confound

## Etymology
- From Middle English confounden (“destroy, ruin, perplex”), from Anglo-Norman cunfundre and Old French confondre, from Latin confundō (“to mingle, mix together”). Related to found (“to melt (metals in a foundry)”) (but not to found (“to start”), nor to find) and to fusion.


## Definition
### Verb
1. To perplex or puzzle. 
2. To stun or amaze. 
3. To fail to see the difference; to mix up; to confuse right and wrong. 
4. (sometimes proscribed) To make something worse. 
5. To combine in a confused fashion; to mingle so as to make the parts indistinguishable. 
6. To cause to be ashamed; to abash. 
7. To defeat, to frustrate, to thwart. 
8. (dated) To damn (a mild oath). 
9. (archaic) To destroy, ruin, or devastate; to bring to ruination. 

### Noun
1. (statistics) A confounding variable. 

## Synonyms
[[throw]] | [[mistake]] | [[fox]] | [[discombobulate]] | [[confuse]] | [[bedevil]]