# hodgepodge

## Etymology
- From Middle English hochepoche, a variation of hochepot, from Old French hochepot, from Middle Dutch hutspot (“beef or mutton cut into small pieces and mixed and boiled together in a pot”), from hotsen, hutsen (“to shake; jog; jolt”) + pot (“pot”), equivalent to hotch +‎ pot. Compare German Low German Hüttspott (“hodgepodge”).


## Definition
### Noun
1. A collection containing a variety of miscellaneous things. 
2. A confused mass of ingredients shaken or mixed together in the same pot. 

### Verb
1. (transitive, intransitive) To move or position in an erratic, disorganised manner. 

## Synonyms
[[farrago]] | [[melange]] | [[jumble]] | [[hotchpotch]] | [[omnium-gatherum]] | [[ragbag]]