# creditable

## Etymology
- From credit +‎ -able.


## Definition
### Adjective
1. Credible or believable. 
2. That brings credit or honour; respectable. 
3. That can be assigned; assignable. 

## Synonyms
[[worthy]]