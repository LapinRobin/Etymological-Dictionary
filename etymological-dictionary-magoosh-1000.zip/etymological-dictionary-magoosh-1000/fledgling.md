# fledgling

## Etymology
- From fledge (“prepare for flying”) +‎ -ling.


## Definition
### Adjective
1. Untried or inexperienced. 
2. Emergent or rising. 

### Noun
1. A young bird which has just developed its flight feathers (notably wings). 
2. An insect that has just fledged, i.e. undergone its final moult to become an adult or imago. 
3. (figuratively) An immature, naïve or inexperienced person. 

## Synonyms
[[neophyte]] | [[starter]] | [[freshman]]