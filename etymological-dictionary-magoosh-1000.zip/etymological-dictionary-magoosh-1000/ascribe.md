# ascribe

## Etymology
- From Middle English ascriben, from Old French ascrivre (“inscribe, attribute, impute”), from Latin āscrībere (“to state in writing”), equivalent to a- +‎ scribe.


## Definition
### Verb
1. (transitive) To attribute a cause or characteristic to someone or something. 
2. (transitive) To attribute a book, painting or any work of art or literature to a writer or creator. 
3. (nonstandard, with to) To believe in or agree with; subscribe. 

## Synonyms
[[attribute]] | [[assign]] | [[impute]] | [[arrogate]]