# perpetuate

## Etymology
- From Late Middle English perpetuate (adjective only), borrowed from Latin perpetuātus (“perpetuated”) + English -ate (suffix meaning ‘characterized by ’ forming adjectives, and ‘to act in ’ forming verbs). Perpetuātus is the perfect passive participle of perpetuō (“to cause to continue uninterruptedly, to proceed with continually, to make perpetual, perpetuate”), from perpetuus (“everlasting, perpetual”) (from per- (prefix meaning ‘very’) + petō (“to ask, request; to look for; to make for (somewhere)”) (ultimately from Proto-Indo-European *peth₂- (“to spread out; to fly”)) + -uus (suffix forming adjectives)) + -ō (suffix forming regular first-conjugation verbs).


## Definition
### Verb
1. (transitive) To make perpetual; to preserve from extinction or oblivion. 
2. (transitive) To prolong the existence of. 

### Adjective
1. Made perpetual; continued for an indefinite time. 

## Synonyms
