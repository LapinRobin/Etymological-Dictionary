# grandiloquent

## Etymology
- From Middle French grandiloquent, from Latin grandiloquus, from grandis (“great, full”) + loquēns, present participle of loquor (“I speak”). Compare eloquent.


## Definition
### Adjective
1. (of a person, their language or writing) Given to using language in a showy way by using an excessive number of difficult words to impress others; bombastic; turgid 

## Synonyms
[[pretentious]] | [[pompous]] | [[rhetorical]] | [[tall]] | [[portentous]]