# endemic

## Etymology
- From Ancient Greek ἐν (en, “in”) + δῆμος (dêmos, “people”). Possibly via ἔνδημος (éndēmos, “among one's people, at home, native”) and/or French endémique.


## Definition
### Adjective
1. Native to a particular area or culture; originating where it occurs. 
2. (especially of plants and animals) Peculiar to a particular area or region; not found in other places. 
3. (especially of diseases) Prevalent in a particular area or region. 

### Noun
1. An individual or species that is endemic to a region. 
2. A disease affecting a number of people simultaneously, so as to show a distinct connection with certain localities. 

## Synonyms
[[indigenous]] | [[native]] | [[autochthonous]]