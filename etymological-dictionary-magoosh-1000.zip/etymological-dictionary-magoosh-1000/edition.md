# edition

## Etymology
- From French édition, from Latin ēditiō, from ēdere (“to publish”).


## Definition
### Noun
1. (publishing) A written work edited and published, as by a certain editor or in a certain manner, or at a certain time. 
2. The whole number of copies of a work printed and published at one time. 
3. An instance of  or : 
4. (sports) A particular instance of an event. 

## Synonyms
