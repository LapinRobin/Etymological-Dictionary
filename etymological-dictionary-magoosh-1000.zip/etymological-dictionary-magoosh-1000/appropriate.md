# appropriate

## Etymology
- From Middle English appropriaten, borrowed from Latin appropriatus, past participle of approprio (“to make one's own”), from ad (“to”) + proprio (“to make one's own”), from proprius (“one's own, private”).


## Definition
### Adjective
1. Suitable or fit; proper. 
2. Suitable to the social situation or to social respect or social discreetness; socially correct; socially discreet; well-mannered; proper. 
3. (obsolete) Set apart for a particular use or person; reserved. 

### Verb
1. (transitive) To take to oneself; to claim or use, especially as by an exclusive right. 
2. (transitive) To set apart for, or assign to, a particular person or use, especially in exclusion of all others; with to or for. 
3. (transitive, Britain, ecclesiastical, law) To annex (for example a benefice, to a spiritual corporation, as its property). 
4. (transitive, archaic) To make suitable to; to suit. 

## Synonyms
[[fit]] | [[right]] | [[pertinent]] | [[due]] | [[apropos]] | [[reserve]] | [[expedient]] | [[seize]] | [[congruent]] | [[allow]] | [[apt]] | [[pat]] | [[proper]] | [[apposite]] | [[suitable]] | [[earmark]] | [[advantageous]] | [[harmonious]] | [[take over]]