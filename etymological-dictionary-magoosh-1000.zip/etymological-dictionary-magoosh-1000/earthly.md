# earthly

## Etymology
- From Middle English erthely, erthlich, ierðlich, from Old English eorþlīċ, corresponding to earth +‎ -ly. Cognate with Old Norse jarðligr (“earthly”).


## Definition
### Adjective
1. Relating to the earth or this world, as opposed to heaven; terrestrial. 
2. (negative, informal) Used for emphasis 
3. (obsolete) Made of earth; earthy. 

### Noun
1. (collective or in the plural) That which is of the earth or earthly; a terrestrial being. 
2. (UK, colloquial) A slightest chance (of success etc.) or idea (about something). 

### Adverb
1. in an earthly manner. 

## Synonyms
[[mundane]] | [[temporal]] | [[terrestrial]]