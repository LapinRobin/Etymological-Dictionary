# flippant

## Etymology
- 1595, from Northern English dialectal flippand (“prattling, babbling, glib”), present participle of flip (“to babble”), of North Germanic origin. Cognate with Icelandic fleipa (“to babble, prattle”), Swedish dialectal flepa (“to talk nonsense”). Alteration of -and suffix (a variant of the participial -ing) to -ant probably due to influence from words in -ant.


## Definition
### Adjective
1. Showing disrespect through a casual attitude, levity, and a lack of due seriousness; pert. 
2. (archaic) glib; speaking with ease and rapidity 
3. (chiefly dialectal) nimble; limber. 

## Synonyms
[[frivolous]]