# rescind

## Etymology
- From the Latin rescindō (“I cut back”), from re- (“back”) + scindō (“I cut”).


## Definition
### Verb
1. (transitive) To repeal, annul, or declare void; to take (something such as a rule or contract) out of effect. 
2. (transitive) To cut away or off. 

## Synonyms
[[lift]] | [[reverse]] | [[revoke]] | [[repeal]] | [[annul]] | [[overturn]]