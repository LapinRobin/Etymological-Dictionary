# edifice

## Etymology
- From Middle English edifice, from Old French edifice, a classical borrowing of Latin aedificium (“building”), derived from aedificāre (“to build, establish”) (whence also English edify).


## Definition
### Noun
1. A building; a structure; an architectural fabric, especially a large and spectacular one 
2. An abstract structure; a school of thought. 

## Synonyms
[[building]]