# conundrum

## Etymology
- A word of unknown origin with several variants, gaining popularity for its burlesque imitation of scholastic Latin, as hocus-pocus or panjandrum. If there is more to its origin than a nonce coinage, Anatoly Liberman suggests the best theory is that connecting it with the Conimbricenses, 16th c. scholastic commentaries on Aristotle by the Jesuits of Coimbra which indulge heavily in arguments relying on multiple significations of words.


## Definition
### Noun
1. A difficult question or riddle, especially one using a play on words in the answer. 
2. A difficult choice or decision that must be made. 

## Synonyms
[[enigma]] | [[riddle]]