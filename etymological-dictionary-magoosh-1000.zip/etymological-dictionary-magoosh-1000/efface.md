# efface

## Etymology
- From Middle French effacer (“erase”), from Old French esfacier (“remove the face”).


## Definition
### Verb
1. (transitive) To erase (as anything impressed or inscribed upon a surface); to render illegible or indiscernible. 
2. (transitive) To cause to disappear as if by rubbing out or striking out. 
3. (reflexive) To make oneself inobtrusive as if due to modesty or diffidence. 
4. (medicine) Of the cervix during pregnancy, to thin and stretch in preparation for labor. 

## Synonyms
[[obliterate]] | [[wipe]] | [[erase]]