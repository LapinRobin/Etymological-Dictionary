# effervescent

## Etymology
- From French effervescent, from Latin effervēscō (“boil up”).


## Definition
### Adjective
1. (of a liquid) Giving off bubbles; fizzy. 
2. Vivacious and enthusiastic. 

## Synonyms
[[lively]] | [[scintillating]] | [[bubbly]] | [[frothy]] | [[charged]] | [[sparkling]]