# obscure

## Etymology
- From Middle English obscure, from Old French obscur, from Latin obscūrus (“dark, dusky, indistinct”), from ob- +‎ *scūrus, from Proto-Italic *skoiros, from Proto-Indo-European *(s)ḱeh₃-. Doublet of oscuro.


## Definition
### Adjective
1. Dark, faint or indistinct. 
2. Hidden, out of sight or inconspicuous. 
3. Difficult to understand. 
4. Not well-known. 
5. Unknown or uncertain; unclear. 

### Verb
1. (transitive) To render obscure; to darken; to make dim; to keep in the dark; to hide; to make less visible, intelligible, legible, glorious, beautiful, or illustrious. 
2. (transitive) To hide, put out of sight etc. 
3. (intransitive, obsolete) To conceal oneself; to hide. 

## Synonyms
[[cloud]] | [[hide]] | [[apart]] | [[dark]] | [[vague]] | [[mist]] | [[blur]] | [[obliterate]] | [[fog]] | [[confuse]] | [[hidden]] | [[isolated]] | [[invisible]] | [[indeterminate]] | [[unknown]] | [[incomprehensible]] | [[inconspicuous]] | [[concealed]]