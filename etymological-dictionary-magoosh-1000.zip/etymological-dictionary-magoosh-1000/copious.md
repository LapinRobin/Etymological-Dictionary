# copious

## Etymology
- From Middle English copious, from Latin copiosus, from copia (“abundance”), equivalent to co- + ops (“wealth”) + -osus (“full of”). By surface analysis, copy +‎ -ous.


## Definition
### Adjective
1. Vast in quantity or number, profuse, abundant; taking place on a large scale. 
2. Having an abundant supply. 
3. Full of thought, information, or matter; exuberant in words, expression, or style. 

## Synonyms
[[rich]] | [[extensive]] | [[abundant]] | [[ample]] | [[plentiful]]