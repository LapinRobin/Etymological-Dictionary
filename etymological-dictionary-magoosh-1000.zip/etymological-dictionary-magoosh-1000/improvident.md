# improvident

## Etymology
- From the Latin improvidens, equivalent to in- +‎ provident.


## Definition
### Adjective
1. failing to provide for the future; reckless 
2. incautious; prone to rashness 

## Synonyms
[[short]] | [[prodigal]] | [[imprudent]]