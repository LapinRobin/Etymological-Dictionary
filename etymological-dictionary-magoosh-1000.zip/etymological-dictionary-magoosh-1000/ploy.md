# ploy

## Etymology
- Possibly from a shortened form of employ or deploy. Or from earlier ploye, from Middle English, borrowed from Middle French ployer (compare modern plier), from Latin plicāre.

- Probably abbreviated from deploy.


## Definition
### Noun
1. A tactic, strategy, or scheme. 
2. (UK, Scotland, dialect) Sport; frolic. 
3. (obsolete) Employment. 

### Verb
1. (military) To form a column from a line of troops on some designated subdivision. 

## Synonyms
[[gambit]] | [[stratagem]]