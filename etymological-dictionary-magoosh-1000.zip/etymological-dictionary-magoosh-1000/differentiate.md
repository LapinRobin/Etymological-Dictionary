# differentiate

## Etymology
- From New Latin differentiātus, past participle of differentiō, from Latin differentia (“difference”); see difference.


## Definition
### Verb
1. (transitive) To show, or be the distinction between two things. 
2. (intransitive) To perceive the difference between things; to discriminate. 
3. (transitive, intransitive) To modify, or be modified. 
4. (transitive, mathematics) To calculate the derivative of a function. 
5. (transitive, mathematics) To calculate the differential of a function of multiple variables. 
6. (intransitive, biology) To produce distinct organs or to achieve specific functions by a process of development called differentiation. 

### Noun
1. (geology) Something that has been differentiated or stratified. 

## Synonyms
[[mark]] | [[tell]] | [[separate]] | [[distinguish]]