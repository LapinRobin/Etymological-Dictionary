# pyrrhic

## Etymology
- From Latin pyrrhichius, from Ancient Greek πυρρίχιος (purrhíkhios), from πυρρίχη (purrhíkhē, “war dance”).


## Definition
### Adjective
1. (prosody) Of or characterized by pyrrhics (metrical feet with two short syllables). 
2. Relating to Pyrrhus, a Macedonian king, or some of his costly victories he had while fighting Rome. 
3. (not comparable) Of or relating to Pyrrhus (319/318–272 BC), Greek general and statesman. 
4. Achieved at too great a cost or detriment to have been worthwhile (as a victory, accomplishment, etc). 
5. Alternative letter-case form of Pyrrhic (“achieved at too great a cost”)  

### Noun
1. An Ancient Greek war dance. 
2. (prosody) A metric foot with two short or unaccented syllables. 

## Synonyms
