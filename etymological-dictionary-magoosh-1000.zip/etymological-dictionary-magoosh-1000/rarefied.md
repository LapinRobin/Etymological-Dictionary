# rarefied

## Definition
### Adjective
1. Distant from the lives and everyday concerns of ordinary people; esoteric, exclusive, select. 
2. Elevated in style or nature, sublime; of high intellectual or moral value. 
3. (of a gas etc.) Less dense than usual; thin. 

## Synonyms
[[noble]] | [[rare]] | [[thin]] | [[lofty]] | [[reserved]] | [[exalted]] | [[idealistic]]