# inexorable

## Etymology
- From Middle French inexorable, from Latin inexōrābilis (“relentless, inexorable”) (or directly from the Latin word), from in- (prefix meaning ‘not’) + exōrābilis (“that may be moved or persuaded by entreaty; exorable”). Exōrābilis is derived from exōrāre (from exōrō (“to persuade, win over; to beg, entreat, plead”), from ex- (prefix meaning ‘out of’) + ōrō (“to beg, entreat, plead, pray; to deliver a speech, orate”), from ōs (“mouth”), from Proto-Indo-European *h₃éh₁os (“mouth”)) + -bilis (suffix forming adjectives indicating a capacity or worth of being acted upon).


## Definition
### Adjective
1. Impossible to prevent or stop; inevitable. 
2. Unable to be persuaded; relentless; unrelenting. 
3. Adamant; severe. 

## Synonyms
[[adamant]] | [[stern]] | [[relentless]] | [[grim]] | [[intransigent]] | [[implacable]] | [[adamantine]] | [[unrelenting]] | [[inflexible]]