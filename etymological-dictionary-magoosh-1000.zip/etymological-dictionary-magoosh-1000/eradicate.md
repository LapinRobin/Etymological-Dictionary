# eradicate

## Etymology
- Borrowed from Latin ērādīcātus, past participle of ērādīcō (“uproot”), from ē- (“out”) + rādīx (“root”). Also see: radish.


## Definition
### Verb
1. (transitive) To pull up by the roots; to uproot. 
2. (transitive) To destroy completely; to reduce to nothing radically; to put an end to; to extirpate. 

## Synonyms
[[eliminate]] | [[decimate]] | [[annihilate]] | [[extirpate]] | [[extinguish]]