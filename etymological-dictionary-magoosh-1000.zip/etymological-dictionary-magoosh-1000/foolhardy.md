# foolhardy

## Etymology
- From Middle English folehardy, foolhardi, folherdi, from Old French fol hardi (“foolishly bold”), from Old French fol (“foolish, silly; insane, mad”) (from Latin follis (“bellows; purse, sack; inflated ball; belly, paunch”), ultimately from Proto-Indo-European *bʰelǵʰ- (“to swell”)) + Old French hardi (“durable, hardy, tough”) (past tense of hardir (“to harden”), from the unattested Frankish *hartjan, from Proto-Germanic *harduz (“hard; brave”)), equivalent to fool +‎ hardy. Compare fool-bold, fool-large, etc.


## Definition
### Adjective
1. Marked by unthinking recklessness with disregard for danger; boldly rash; hotheaded. 

### Noun
1. A person who is foolhardy. 

## Synonyms
[[bold]] | [[rash]] | [[reckless]]