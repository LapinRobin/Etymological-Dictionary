# glib

## Etymology
- A shortening of either English glibbery (“slippery”) or its source, Low German glibberig, glibberich (“slippery”) / Dutch glibberig (“slippery”).

- From Irish glib.

- Compare Old English and dialectal English lib (“to castrate, geld”), dialectal Danish live, Low German and Old Dutch lubben.


## Definition
### Adjective
1. Having a ready flow of words but lacking thought or understanding; superficial; shallow. 
2. (dated) Smooth or slippery. 
3. Artfully persuasive but insincere in nature; smooth-talking, honey-tongued, silver-tongued. 
4. (US) Snarky or unserious in a disrespectful way. 

### Verb
1. (transitive) To make smooth or slippery. 
2. (obsolete) To castrate; to geld; to emasculate. 

### Noun
1. (historical) A mass of matted hair worn down over the eyes, formerly used in Ireland. 

## Synonyms
[[plausible]] | [[pat]] | [[superficial]] | [[slick]] | [[persuasive]]