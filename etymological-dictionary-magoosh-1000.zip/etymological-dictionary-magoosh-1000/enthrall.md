# enthrall

## Etymology
- From Middle English enthrallen, equivalent to en- +‎ thrall.


## Definition
### Verb
1. (transitive) To hold spellbound. 
2. (transitive, rare) To make subservient. 

## Synonyms
[[transport]] | [[delight]] | [[ravish]] | [[enchant]]