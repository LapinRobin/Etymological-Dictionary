# earnestness

## Etymology
- earnest +‎ -ness


## Definition
### Noun
1. The quality of being earnest; sincerity; seriousness. 

## Synonyms
[[sincerity]]