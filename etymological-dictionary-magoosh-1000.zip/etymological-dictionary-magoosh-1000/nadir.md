# nadir

## Etymology
- From Medieval Latin nadir, from Arabic نَظِير السَّمْت‎ (naẓīr as-samt), composed of نَظِير‎ (naẓīr, “counterpart, corresponding to”) and السَّمْت‎ (as-samt, “the zenith”)


## Definition
### Noun
1. The point of the celestial sphere, directly opposite the zenith; inferior pole of the horizon; point of the celestial sphere directly under the place of observation. 
2. (figuratively) The lowest point; time of greatest depression. 
3. (astronomy) The axis of a projected conical shadow; the direction of the force of gravity at a location; down. 
4. (beekeeping, archaic) An empty box added beneath a full one in a beehive to give the colony more room to expand or store honey. 
5. A male given name. 
6. A surname. 

### Verb
1. (transitive, beekeeping) To extend (a beehive) by adding an empty box at the base. 

## Synonyms
