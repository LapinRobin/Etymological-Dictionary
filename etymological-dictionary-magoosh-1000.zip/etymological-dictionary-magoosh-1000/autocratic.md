# autocratic

## Etymology
- From autocrat +‎ -ic, equivalent to auto- +‎ -cratic.


## Definition
### Adjective
1. Of or pertaining to autocracy or to an autocrat; absolute; holding independent and arbitrary powers of government. 
2. (derogatory) Of or pertaining to the manner of an autocrat. 

## Synonyms
[[peremptory]] | [[bossy]] | [[authoritarian]] | [[despotic]] | [[magisterial]]