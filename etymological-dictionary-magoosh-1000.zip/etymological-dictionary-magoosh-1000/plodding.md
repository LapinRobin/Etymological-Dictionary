# plodding

## Definition
### Adjective
1. Progressing slowly and laboriously. 

### Noun
1. Slow, laborious progress. 

## Synonyms
[[grind]] | [[drudgery]]