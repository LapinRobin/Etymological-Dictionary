# tact

## Etymology
- Borrowed from Latin tāctus. Sense “keen perception” developed in French tact.


## Definition
### Noun
1. The sense of touch; feeling. 
2. (music) The stroke in beating time. 
3. Sensitive mental touch; special skill or faculty; keen perception or discernment; ready power of appreciating and doing what is required by circumstances; the ability to say the right thing. 
4. (psychology) A verbal operant which is controlled by a nonverbal stimulus (such as an object, event, or property of an object) and is maintained by nonspecific social reinforcement (praise). 
5. (slang) Clipping of tactic.  

### Verb
1. (psychology) To use a tact (a kind of verbal operant; see noun sense). 

## Synonyms
