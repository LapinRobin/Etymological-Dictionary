# elicit

## Etymology
- Borrowed from Latin elicitus from eliciō (“draw forth”).


## Definition
### Verb
1. To evoke, educe (emotions, feelings, responses, etc.); to generate, obtain, or provoke as a response or answer. 
2. To draw out, bring out, bring forth (something latent); to obtain information from someone or something. 
3. To use logic to arrive at truth; to derive by reason 

### Adjective
1. (obsolete) Elicited; drawn out; made real; open; evident. 

## Synonyms
[[fire]] | [[raise]] | [[extract]] | [[evoke]] | [[kindle]] | [[provoke]] | [[arouse]] | [[educe]]