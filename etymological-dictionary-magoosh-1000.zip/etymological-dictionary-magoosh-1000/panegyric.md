# panegyric

## Etymology
- From French panégyrique, from Ancient Greek πανηγυρικός (panēgurikós).


## Definition
### Noun
1. A formal speech publicly praising someone or something. 
2. Someone who writes or delivers such a speech. 

### Adjective
1. panegyrical 

## Synonyms
[[complimentary]] | [[paean]] | [[eulogy]] | [[encomium]] | [[pean]]