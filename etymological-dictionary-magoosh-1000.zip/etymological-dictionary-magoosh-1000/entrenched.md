# entrenched

## Definition
### Adjective
1. established firmly and securely
2. dug in

## Synonyms
[[established]]