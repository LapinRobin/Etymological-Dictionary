# apathy

## Etymology
- From French apathie, from Latin apathīa, from Ancient Greek ἀπάθεια (apátheia, “impassibility”, “insensibility”, “freedom from emotion”), from ἀπαθής (apathḗs, “not suffering or having suffered”, “without experience of”), from ἀ- (a-, “not”) + πάθος (páthos, “anything that befalls one”, “incident”, “emotion”, “passion”). English a- +‎ -pathy.


## Definition
### Noun
1. Lack of emotion or motivation; lack of interest or enthusiasm towards something; disinterest (in something). 

## Synonyms
[[indifference]]