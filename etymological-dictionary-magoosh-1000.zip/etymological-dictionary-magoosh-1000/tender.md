# tender

## Etymology
- From Middle English tender, tendere, from Anglo-Norman tender, Old French tendre, from Latin tener, tenerum (“soft, delicate”).

- From Middle English tender, tendur, tendir, tendre, from the adjective (see above).

- From Middle English tendren, from the adjective (see above).

- From tend +‎ -er. Compare attender (“one who attends”).

- From Middle English tendren, from Old French tendre (“stretch out”).


## Definition
### Adjective
1. Sensitive or painful to the touch. 
2. Easily bruised or injured; not firm or hard; delicate. 
3. Physically weak; not able to endure hardship. 
4. (of food) Soft and easily chewed. 
5. Sensible to impression and pain; easily pained. 
6. Fond, loving, gentle, or sweet. 
7. Young and inexperienced. 
8. Adapted to excite feeling or sympathy; expressive of the softer passions; pathetic. 
9. Apt to give pain; causing grief or pain; delicate. 
10. (nautical) Heeling over too easily when under sail; said of a vessel. 
11. (obsolete) Exciting kind concern; dear; precious. 
12. (obsolete) Careful to keep inviolate, or not to injure; used with of. 

### Noun
1. (obsolete) Care, kind concern, regard. 
2. The inner flight muscle (pectoralis minor) of poultry. 
3. (obsolete) Someone who tends or waits on someone. 
4. (rail transport) A railroad car towed behind a steam engine to carry fuel and water. 
5. (nautical) A naval ship that functions as a mobile base for other ships. 
6. (nautical) A smaller boat used for transportation between a large ship and the shore. 
7. Anything which is offered, proffered, put forth or bid with the expectation of a response, answer, or reply. 
8. A means of payment such as a check or cheque, cash or credit card. 
9. (law) A formal offer to buy or sell something. 
10. Any offer or proposal made for acceptance. 

### Adverb
1. tenderly 

### Verb
1. (now rare) To make tender or delicate; to weaken. 
2. (archaic) To feel tenderly towards; to regard fondly or with consideration. 
3. To work on a tender. 
4. (formal) To offer, to give. 
5. to offer a payment, as at sales or auctions. 

## Synonyms
[[bid]] | [[short]] | [[vulnerable]] | [[offer]] | [[sore]] | [[sensitive]] | [[soft]] | [[crisp]] | [[delicate]] | [[fond]] | [[warm]] | [[young]] | [[crank]] | [[caring]] | [[sentimental]] | [[cranky]] | [[affectionate]] | [[flaky]] | [[immature]] | [[painful]] | [[crispy]] | [[loving]] | [[unstable]]