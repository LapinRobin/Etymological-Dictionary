# powwow

## Etymology
- From an Eastern Algonquian language, probably Massachusett pauwau (“he uses divination; he practices magic or sorcery”) or Narragansett powwáw (“sorcerer, shaman”), from Proto-Algonquian *pawe·wa (“one who dreams”).


## Definition
### Noun
1. A ritual conducted by a Native American shaman. 
2. A Native American shaman.  
3. A Native American council or meeting. 
4. (informal) A short, private conference.  
5. (Canada, US) A large gathering during which Indigenous songs and dances are showcased for an audience, essentially a recital or concert. Often also doubles as a fundraiser, or can be held in conjunction with a non-indigneous fair or exhibition in order to attract a large crowd, as at the Calgary Stampede and K-Days. 

### Verb
1. (intransitive, of Native Americans) To hold a meeting; to gather together in council. 
2. (intransitive, of Native Americans and by extension other groups, such as the Pennsylvania Dutch) To conduct a ritual in which magic is used. 
3. (informal, intransitive) To hold a private conference. 

## Synonyms
[[huddle]]