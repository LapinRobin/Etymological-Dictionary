# choleric

## Etymology
- From Middle English colerik, from Old French colerique, from Latin cholericus.


## Definition
### Adjective
1. (according to theories of the four humours or temperaments) Having a temperament characterized by an excess of choler; easily becoming angry. 
2. Showing or expressing anger. 
3. Of or relating to cholera (infectious disease). 
4. (obsolete) Causing an excess of choler. 

### Noun
1. A person with a choleric temperament. 
2. A person suffering from cholera (infectious disease). 

## Synonyms
[[short]] | [[angry]] | [[irascible]] | [[passionate]]