# earthling

## Etymology
- From Middle English erthling (“farmer, ploughman”)    (in glossaries), from Old English ierþling, eorþling (“farmer, husbandman, ploughman”) , from eorþe (“ground; dirt; planet Earth”) (ultimately from Proto-Indo-European *h₁er- (“earth”)) + -ling (suffix forming personal nouns). The English word is analysable as earth +‎ -ling.

- See Earthling.


## Definition
### Noun
1. An inhabitant of Earth, as opposed to one of heaven.  
2. (chiefly science fiction) An inhabitant of Earth, as opposed to one of another planet; specifically, a sentient member of any species native to Earth.  
3. (archaic) A person who is materialistic or worldly; a worldling.  
4. (obsolete except historical) One who tills the earth; a farmer, a husbandman, a ploughman. 
5. Alternative letter-case form of Earthling ] 

## Synonyms
