# stem

## Etymology
- From Middle English stem, stemme, stempne, stevin, from Old English stemn, from Proto-Germanic *stamniz, ultimately from Proto-Indo-European *steh₂- (“to stand, stay”).

- From Middle English stemmen, a borrowing from Old Norse stemma (“to stop, stem, dam”) (whence Danish stemme/stæmme (“to stem, dam up”)), from Proto-Germanic *stammijaną. Cognate with German stemmen, Middle Dutch stemmen, stempen. Compare stammer.

- stem (plural stems)

- Acronym of science, technology, engineering, (and) mathematics.

- Blend of stud +‎ femme


## Definition
### Noun
1. The stock of a family; a race or generation of progenitors. 
2. A branch of a family. 
3. An advanced or leading position; the lookout. 
4. (botany) The above-ground stalk (technically axis) of a vascular plant, and certain anatomically similar, below-ground organs such as rhizomes, bulbs, tubers, and corms. 
5. A slender supporting member of an individual part of a plant such as a flower or a leaf; also, by analogy, the shaft of a feather. 
6. A narrow part on certain man-made objects, such as a wine glass, a tobacco pipe, a spoon. 
7. (linguistics) The main part of an uninflected word to which affixes may be added to form inflections of the word. A stem often has a more fundamental root. Systematic conjugations and declensions derive from their stems. 
8. (slang) A person's leg. 
9. (slang) The penis. 
10. (typography) A vertical stroke of a letter. 
11. (music) A vertical stroke marking the length of a note in written music. 
12. (music) A premixed portion of a track for use in audio mastering and remixing. 
13. (nautical) The vertical or nearly vertical forward extension of the keel, to which the forward ends of the planks or strakes are attached. 
14. (cycling) A component on a bicycle that connects the handlebars to the bicycle fork. 
15. (anatomy) A part of an anatomic structure considered without its possible branches or ramifications. 
16. (slang) A crack pipe; or the long, hollow portion of a similar pipe (i.e. meth pipe) resembling a crack pipe. 
17. (chiefly Britain) A winder on a clock, watch, or similar mechanism. 
18. A lesbian, chiefly African-American, exhibiting both stud and femme traits. 
19. A surname. 
20. Alternative form of steem  
21. Alternative form of STEM 
22. (countable) Acronym of scanning transmission electron microscope.  
23. (uncountable) Acronym of science, technology, engineering, (and) mathematics.  

### Verb
1. To remove the stem from. 
2. To be caused or derived; to originate. 
3. To descend in a family line. 
4. To direct the stem (of a ship) against; to make headway against. 
5. (obsolete) To hit with the stem of a ship; to ram. 
6. To ram (clay, etc.) into a blasting hole. 
7. (transitive) To stop, hinder (for instance, a river or blood). 
8. (skiing) To move the feet apart and point the tips of the skis inward in order to slow down the speed or to facilitate a turn. 

## Synonyms
[[base]] | [[root]] | [[bow]] | [[radical]] | [[theme]] | [[halt]] | [[stalk]] | [[staunch]] | [[fore]] | [[shank]] | [[prow]] | [[stanch]]