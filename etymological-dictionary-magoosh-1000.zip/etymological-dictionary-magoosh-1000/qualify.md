# qualify

## Etymology
- Borrowed from Middle French qualifier (“to qualify”). Equivalent to quality + -fy.


## Definition
### Verb
1. To describe or characterize something by listing its qualities. 
2. To make someone, or to become competent or eligible for some position or task. 
3. To certify or license someone for something. 
4. To modify, limit, restrict or moderate something; especially to add conditions or requirements for an assertion to be true. 
5. (now rare) To mitigate, alleviate (something); to make less disagreeable. 
6. To compete successfully in some stage of a competition and become eligible for the next stage. 
7. To give individual quality to; to modulate; to vary; to regulate. 
8. (juggling) To throw and catch each object at least twice. 

### Noun
1. (juggling) An instance of throwing and catching each prop at least twice. 

## Synonyms
[[condition]] | [[dispose]] | [[stipulate]] | [[modify]] | [[specify]] | [[restrict]] | [[characterize]]