# educational

## Etymology
- education +‎ -al


## Definition
### Adjective
1. Of, or relating to education. 
2. Instructive, or helping to educate. 

### Noun
1. A free (or low cost) trip for travel consultants, provided by a travel operator or airline as a means of promoting their service. A fam trip 

## Synonyms
[[informative]]