# erratic

## Etymology
- From Middle English erratik, erratyk, from Latin errāticus; compare Old French erratique.


## Definition
### Adjective
1. Unsteady, random; prone to unexpected changes; not consistent. 
2. Deviating from normal opinions or actions; eccentric; odd. 

### Noun
1. (geology) A rock moved from one location to another, usually by a glacier. 
2. Anything that has erratic characteristics. 

## Synonyms
[[fickle]] | [[mercurial]] | [[temperamental]] | [[quicksilver]] | [[wandering]]