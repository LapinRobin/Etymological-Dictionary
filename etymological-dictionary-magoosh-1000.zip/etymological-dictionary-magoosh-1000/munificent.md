# munificent

## Etymology
- Back-formation from munificence, from Latin mūnificentia.


## Definition
### Adjective
1. (of a person or group) Very liberal in giving or bestowing. 
2. (of a gift, donation, etc.) Very generous; lavish. 

## Synonyms
[[prodigal]] | [[lavish]] | [[generous]]