# aberration

## Etymology
- A learned borrowing from Latin aberrātiō (“relief, diversion”), first attested in 1594, from aberrō (“wander away, go astray”), from ab (“away”) + errō (“wander”). Compare French aberration. Equivalent to aberrate +‎ -ion.


## Definition
### Noun
1. The act of wandering; deviation from truth, moral rectitude; abnormal; divergence from the straight, correct, proper, normal, or from the natural state. 
2. (optics) The convergence to different foci, by a lens or mirror, of rays of light emanating from one and the same point, or the deviation of such rays from a single focus; a defect in a focusing mechanism that prevents the intended focal point. 
3. (astronomy) A small periodical change of the apparent positions of the stars and other heavenly bodies, due to the combined effect of the motion of light and the motion of the observer. 
4. (astronomy, by extension) The tendency of light rays to preferentially strike the leading face of a moving object (the effect underlying the above phenomenon). 
5. A partial alienation of reason. 
6. A mental disorder, especially one of a minor or temporary character. 
7. (zoology, botany) A typical development or structure; deviation from the normal type; an aberrant organ. 
8. (medicine) A deviation of a tissue, organ or mental functions from what is considered to be within the normal range. 
9. (electronics) A defect in an image produced by an optical or electrostatic lens system. 

## Synonyms
[[distortion]]