# easy

## Etymology
- From Middle English esy, eesy, partly from Middle English ese (“ease”) + -y, equivalent to ease +‎ -y, and partly from Anglo-Norman eisé from Old French aisié (“eased, at ease, at leisure”), past participle of aisier (“to put at ease”), from aise (“empty space, elbow room, opportunity”), of uncertain origin. See ease. Merged with Middle English ethe, eathe (“easy”), from Old English īeþe, from Proto-Germanic *auþuz, from Proto-Indo-European *h₂éwtus (“empty, lonely”), from Proto-Indo-European *h₂ew-. Compare also Old Saxon ōþi, Old High German ōdi, Old Norse auðr, all meaning "easy, vacant, empty." More at ease, eath.


## Definition
### Adjective
1. (now rare except in certain expressions) Comfortable; at ease. 
2. Requiring little skill or effort. 
3. Causing ease; giving comfort, or freedom from care or labour. 
4. Free from constraint, harshness, or formality; unconstrained; smooth. 
5. (informal, derogatory, of a woman) Consenting readily to sex. 
6. Not making resistance or showing unwillingness; tractable; yielding; compliant. 
7. (finance, dated) Not straitened as to money matters; opposed to tight. 

### Adverb
1. In a relaxed or casual manner. 
2. In a manner without strictness or harshness. 
3. At the very least. 

### Noun
1. Something that is easy 

### Verb
1. (rowing) Synonym of easy-oar 

## Synonyms
[[light]] | [[loose]] | [[facile]] | [[simple]] | [[available]] | [[rich]] | [[lenient]] | [[smooth]] | [[wanton]] | [[soft]] | [[abundant]] | [[casual]] | [[comfortable]] | [[gentle]] | [[promiscuous]] | [[slow]] | [[prosperous]] | [[easygoing]] | [[elementary]] | [[easily]] | [[comfy]] | [[gradual]]