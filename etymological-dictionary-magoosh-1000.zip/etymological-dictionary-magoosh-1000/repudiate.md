# repudiate

## Etymology
- From Latin repudiātus, from repudiō (“I cast off, reject”), from repudium (“divorce”), 1540s.


## Definition
### Verb
1. (transitive) To reject the truth or validity of; to deny. 
2. (transitive) To refuse to have anything to do with; to disown. 
3. (transitive) To refuse to pay or honor (a debt). 
4. (intransitive) To be repudiated. 

## Synonyms
[[renounce]]