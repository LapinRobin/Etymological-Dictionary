# sanguine

## Etymology
- From Middle English sanguine, from Old French sanguin, ultimately from Latin sanguineus (“of blood”), from sanguis (“blood”), of uncertain origin, perhaps Proto-Indo-European *h₁sh₂-én-, from *h₁ésh₂r̥ (“blood”). Doublet of sanguineous.


## Definition
### Adjective
1. (literary) Having the colour of blood; blood red. 
2. (obsolete, physiology) Having a bodily constitution characterised by a preponderance of blood over the other bodily humours, thought to be marked by irresponsible mirth; indulgent in pleasure to the exclusion of important matters. 
3. Characterized by abundance and active circulation of blood. 
4. Warm; ardent. 
5. Anticipating the best; optimistic; confident; full of hope. 
6. (archaic) Full of blood; bloody. 
7. (archaic) Bloodthirsty. 

### Noun
1. Blood colour; red. 
2. Anything of a blood-red colour, as cloth. 
3. (heraldry) A tincture, seldom used, of a blood-red colour (not to be confused with murrey). 
4. Bloodstone. 
5. Red crayon. 

### Verb
1. To stain with blood; to impart the colour of blood to; to ensanguine. 

## Synonyms
[[healthy]] | [[optimistic]] | [[ruddy]]