# antiquated

## Etymology
- From antiquate +‎ -ed.


## Definition
### Adjective
1. old-fashioned, out of date 

## Synonyms
[[old]] | [[archaic]] | [[antediluvian]]