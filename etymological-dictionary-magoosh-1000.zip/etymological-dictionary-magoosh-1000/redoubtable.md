# redoubtable

## Etymology
- Borrowed from French redoutable (spelled redoubtable in early modern French).


## Definition
### Adjective
1. Eliciting respect or fear; imposing; awe-inspiring. 
2. (obsolete) Valiant. 

## Synonyms
[[formidable]] | [[proud]] | [[illustrious]] | [[glorious]] | [[unnerving]]