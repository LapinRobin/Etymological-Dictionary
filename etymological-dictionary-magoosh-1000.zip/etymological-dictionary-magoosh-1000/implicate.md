# implicate

## Etymology
- Borrowed from Latin implicatus < implico (“entangle, involve”), from plico (“fold”). Doublet of imply and employ.


## Definition
### Verb
1. (transitive, with “in”) To show to be connected or involved in an unfavorable or criminal way. 
2. (transitive, nonstandard) To imply, to have as a necessary consequence or accompaniment. 
3. (pragmatics) To imply without entailing; to have as an implicature. 
4. (archaic) To fold or twist together, intertwine, interlace, entangle, entwine. 

### Noun
1. (philosophy) The thing implied. 

## Synonyms
[[entail]]