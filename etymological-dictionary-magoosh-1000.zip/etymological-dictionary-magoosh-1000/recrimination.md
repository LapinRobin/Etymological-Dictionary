# recrimination

## Etymology
- From French récrimination.


## Definition
### Noun
1. The act of recriminating. 
2. A counter or mutual accusation. 

## Synonyms
