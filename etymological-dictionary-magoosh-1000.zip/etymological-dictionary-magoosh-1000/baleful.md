# baleful

## Etymology
- From Middle English baleful, balful, baluful, from Old English bealuful, which being equivalent to bealu +‎ -ful. By surface analysis, bale (“evil, woe”) +‎ -ful. See bale for further etymology.


## Definition
### Adjective
1. Portending evil; ominous. 
2. (obsolete) Miserable, wretched, distressed, suffering. 

## Synonyms
[[ominous]] | [[sinister]] | [[ugly]] | [[maleficent]] | [[menacing]] | [[threatening]]