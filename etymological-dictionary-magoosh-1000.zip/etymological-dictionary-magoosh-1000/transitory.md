# transitory

## Etymology
- From Middle French transitoire, from Old French, from Latin transitorius.


## Definition
### Adjective
1. Lasting only a short time; temporary. 
2. (law) Of an action: that may be brought in any county 

## Synonyms
[[ephemeral]] | [[transient]] | [[temporary]] | [[passing]]