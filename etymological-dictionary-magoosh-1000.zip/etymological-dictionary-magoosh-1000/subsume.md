# subsume

## Etymology
- From Late Latin subsumō, equivalent to the Latin sub- (“sub-”) and sūmō (“to take”), cf. the English consume.


## Definition
### Verb
1. To place (any one cognition) under another as belonging to it; to include or contain something else. 
2. To consider an occurrence as part of a principle or rule; to colligate 

## Synonyms
