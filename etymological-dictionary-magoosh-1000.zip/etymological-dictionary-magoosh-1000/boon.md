# boon

## Etymology
- From Middle English boon (“prayer”), from Old Norse bón (“prayer, petition”), from Proto-Germanic *bōniz (“supplication”), influenced by boon (“good, favorable”, adj). Doublet of ben; see there for more.

- From Middle English boon, bone, borrowed from Old Northern French boon, from Old French bon (“good”), from Latin bonus (“good”), from Old Latin duonus, dvenos, from Proto-Indo-European *dū- (“to respect”).

- From Middle English bone (“reed, stem, husk”), akin to or alteration of Old English bune (“reed; drinking cup”).

- boon (plural boons)


## Definition
### Noun
1. (obsolete) A prayer; petition. 
2. (archaic) That which is asked or granted as a benefit or favor; a gift or benefaction. 
3. A good thing; a blessing or benefit; a thing to be thankful for. 
4. (Britain, dialectal) An unpaid service due by a tenant to his lord. 
5. The woody portion of flax, separated from the fiber as refuse matter by retting, braking, and scutching. 
6. (slang) Clipping of sheboon.  

### Adjective
1. (obsolete) Good; prosperous. 
2. (archaic) Kind; bountiful; benign. 
3. (now only in boon companion) gay; merry; jovial; convivial. 

## Synonyms
[[close]] | [[blessing]]