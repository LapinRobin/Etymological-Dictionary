# debunk

## Etymology
- de- +‎ bunk (from bunkum, from Buncombe County) 1923


## Definition
### Verb
1. (transitive) To discredit, or expose to ridicule the falsehood or the exaggerated claims of something. 

## Synonyms
[[expose]]