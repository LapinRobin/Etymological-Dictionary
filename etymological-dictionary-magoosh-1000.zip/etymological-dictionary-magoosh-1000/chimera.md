# chimera

## Etymology
- Variant of Middle English chimere, chymere, & chymera under renewed Latin influence from the 16th century, from French chimère, from Latin Chimaera, from Ancient Greek Χίμαιρα (Khímaira, “fire-breathing mythological monster, fire-spewing Lycian or Cilician mountain”), from χίμαιρα (khímaira, “she-goat”), from χίμαρος (khímaros, “male goat”) + -α (-a), from Proto-Indo-European *ǵʰey-. In reference to the fish, directly from Latin Chimaera, used by Linnaeus. In reference to organisms with distinct areas of different genetic makeups, a calque of German Chimäre, used by Hans Winkler in 1907.


## Definition
### Noun
1. (mythology, art) Any fantastic creature combining parts from different animals. 
2. (figuratively) A foolish, incongruous, or vain thought or product of the imagination. 
3. (figuratively) Anything composed of very disparate parts. 
4. (architecture) A grotesque like a gargoyle, but without a spout for rainwater. 
5. (genetics) An organism with genetically distinct cells originating from two or more zygotes. 
6. (figuratively) Synonym of bogeyman: any terrifying thing, especially as an unreal, imagined threat. 
7. (Greek mythology) A supposed fire-breathing monster in Lycia with the head of a lion, body of a goat, and tail of a dragon or snake, killed by the hero Bellerophon. 
8. (geography, Ancient Greece) A fire-spewing mountain in Lycia or Cilicia, presumed to be an ancient name for the Yanartaş region of Turkey's Antalya Province. 
9. (geography, historical) Former name of Himara, a port town in southern Albania. 
10. (geography, historical) Former name of Ceraunian Mountains, the Albanian mountain range near Himara. 
11. (Greek mythology) Alternative letter-case form of Chimera, a supposed monster in Lycia with the head of a lion, body of a goat, and tail of a dragon or serpent, killed by the hero Bellerophon.  
12. (zoology) Alternative form of chimaera, a cartilaginous marine fish in the subclass Holocephali and especially the order Chimaeriformes, with a blunt snout, long tail, and a spine before the first dorsal fin.  

## Synonyms
