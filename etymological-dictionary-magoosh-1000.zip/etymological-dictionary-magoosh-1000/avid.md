# avid

## Etymology
- From French avide, from Latin avidus (“eager, desirous; greedy”), from aveō (“wish, desire, long for, crave”).


## Definition
### Adjective
1. enthusiastic; keen; eager; showing great interest in something or desire to do something 

## Synonyms
[[great]] | [[eager]] | [[enthusiastic]] | [[zealous]] | [[esurient]] | [[greedy]]