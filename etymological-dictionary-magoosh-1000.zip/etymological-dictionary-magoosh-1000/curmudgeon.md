# curmudgeon

## Etymology
- Numerous folk etymologies exist for this word.


## Definition
### Noun
1. An ill-tempered person full of stubborn ideas or opinions. 
2. (archaic) A miser. 

## Synonyms
