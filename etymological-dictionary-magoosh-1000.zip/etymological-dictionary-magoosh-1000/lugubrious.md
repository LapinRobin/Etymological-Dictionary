# lugubrious

## Etymology
- Borrowed from Latin lūgubris (“mournful; gloomy”), with the suffix -ious.


## Definition
### Adjective
1. Gloomy, mournful or dismal, especially to an exaggerated degree. 

## Synonyms
