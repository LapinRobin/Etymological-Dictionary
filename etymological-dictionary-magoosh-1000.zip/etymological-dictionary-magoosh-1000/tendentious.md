# tendentious

## Etymology
- From tendency +‎ -ious, after German tendenziös.


## Definition
### Adjective
1. Having a tendency; written or spoken with a partisan, biased or prejudiced purpose, especially a controversial one. 
2. Implicitly or explicitly slanted. 

## Synonyms
[[partisan]]