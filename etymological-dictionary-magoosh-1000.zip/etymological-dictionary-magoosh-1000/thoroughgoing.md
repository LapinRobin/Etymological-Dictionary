# thoroughgoing

## Etymology
- From thorough +‎ going (adjective).


## Definition
### Adjective
1. With great attention to detail; complete, thorough. 

## Synonyms
[[thorough]] | [[perfect]] | [[complete]] | [[gross]] | [[consummate]] | [[pure]] | [[stark]] | [[utter]] | [[arrant]] | [[exhaustive]] | [[everlasting]] | [[staring]]