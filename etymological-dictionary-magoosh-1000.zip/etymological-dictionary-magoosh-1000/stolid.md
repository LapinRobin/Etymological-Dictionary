# stolid

## Etymology
- From Middle French stolide, from Latin stolidus (“foolish, obtuse, slow”).


## Definition
### Adjective
1. Having or revealing little emotion or sensibility; dully or heavily stupid. 

## Synonyms
[[impassive]]