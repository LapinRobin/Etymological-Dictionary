# genial

## Etymology
- From Middle French génial, from Latin geniālis (“of or pertaining to marriage; festive, genial”), from genius (“guardian spirit”) + -ālis.

- From Ancient Greek γένειον (géneion, “chin”) + -al.


## Definition
### Adjective
1. Friendly and cheerful. 
2. (especially of weather) Pleasantly mild and warm. 
3. Marked by genius. 
4. (archaic) Contributing to, or concerned in, propagation or production; generative; procreative; productive. 
5. (obsolete) Belonging to one's genius or natural character; native; natural; inborn. 
6. (anatomy) Relating to the chin; genian. 

## Synonyms
[[kind]] | [[benign]] | [[amiable]] | [[cordial]] | [[affable]] | [[friendly]] | [[mental]]