# emulate

## Etymology
- From Latin aemulor (“to rival, emulate”).


## Definition
### Verb
1. (now rare) To attempt to equal or be the same as. 
2. To copy or imitate, especially a person. 
3. (obsolete) To feel a rivalry with; to be jealous of, to envy. 
4. (computing) of a program or device: to imitate another program or device 

### Adjective
1. (obsolete) Striving to excel; ambitious; emulous. 

## Synonyms
[[copy]]