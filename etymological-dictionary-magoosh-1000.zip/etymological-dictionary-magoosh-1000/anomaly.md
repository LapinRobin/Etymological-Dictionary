# anomaly

## Etymology
- From Latin anomalia, from Ancient Greek ἀνωμαλία (anōmalía, “irregularity, anomaly”), from ἀνώμαλος (anṓmalos, “irregular, uneven”), negating the meaning of ὁμαλός (homalós, “even”), from ὁμός (homós, “same”).


## Definition
### Noun
1. A deviation from a rule or from what is regarded as normal; an outlier. 
2. Something or someone that is strange or unusual. 
3. (sciences) Any event or measurement that is out of the ordinary regardless of whether it is exceptional or not. 
4. (astronomy) Any of various angular distances. 
5. (biology) A defect or malformation. 
6. (quantum mechanics) A failure of a classical symmetry due to quantum corrections. 
7. (dated) An irregularity or disproportion. 

## Synonyms
