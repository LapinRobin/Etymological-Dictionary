# insufferable

## Etymology
- From Late Middle English insufferable (“unbearably painful, intolerable”), and then either:


## Definition
### Adjective
1. Not sufferable; very difficult or impossible to endure; intolerable, unbearable. 

## Synonyms
[[impossible]]