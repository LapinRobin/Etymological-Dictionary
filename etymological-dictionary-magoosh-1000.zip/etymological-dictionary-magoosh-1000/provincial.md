# provincial

## Etymology
- From Old French provincial, from Latin provincialis (“province”).


## Definition
### Adjective
1. Of or pertaining to a province. 
2. Constituting a province. 
3. Exhibiting the ways or manners of a province; characteristic of the inhabitants of a province. 
4. Not cosmopolitan; backwoodsy, hick, yokelish, countrified; not polished; rude 
5. Narrow; illiberal. 
6. Of or pertaining to an ecclesiastical province, or to the jurisdiction of an archbishop; not ecumenical. 
7. Limited in outlook; narrow. 
8. (obsolete) Of or pertaining to Provence; Provençal. 

### Noun
1. A person belonging to a province; one who is provincial. 
2. (Roman Catholicism) A monastic superior, who, under the general of his order, has the direction of all the religious houses of the same fraternity in a given district, called a province of the order. 
3. (obsolete) A constitution issued by the head of an ecclesiastical province. 
4. A country bumpkin. 

## Synonyms
[[bucolic]] | [[parochial]] | [[rustic]] | [[insular]] | [[peasant]]