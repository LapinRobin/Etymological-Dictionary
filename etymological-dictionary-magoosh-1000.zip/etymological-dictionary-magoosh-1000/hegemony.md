# hegemony

## Etymology
- From Ancient Greek ἡγεμονία (hēgemonía, “supremacy or leadership, chief command”), from ἡγεμών (hēgemṓn, “a leader, guide, commander, chief”), from ἡγέομαι (hēgéomai, “to lead”).  Early 19th-century usage influenced by German Hegemonie.


## Definition
### Noun
1. (formal) Domination, influence, or authority over another, especially by one political group over a society or by one nation over others. 
2. Dominance of one social group over another, such that the ruling group or hegemon acquires some degree of consent from the subordinate, as opposed to dominance purely by force. 

## Synonyms
