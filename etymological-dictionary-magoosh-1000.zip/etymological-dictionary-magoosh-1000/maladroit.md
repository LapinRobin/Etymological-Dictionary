# maladroit

## Etymology
- From French maladroit, from mal- (“bad, badly”) + adroit (“skilful”).


## Definition
### Adjective
1. Not adroit; awkward, clumsy, inept. 

### Noun
1. Somebody who is inept, or lacking in skill, or talent. 

## Synonyms
[[inept]]