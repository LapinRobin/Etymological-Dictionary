# disinterested

## Etymology
- Corruption of the adjective disinterest/disinteressed.


## Definition
### Adjective
1. Having no stake or interest in the outcome; free of bias, impartial. 
2. (proscribed) Uninterested, lacking interest. 

## Synonyms
[[fair]] | [[impartial]]