# debonair

## Etymology
- Old French debonaire, from the phrase de bon aire (“of good stock, noble”).


## Definition
### Adjective
1. (obsolete) Gracious, courteous. 
2. Suave, urbane and sophisticated. 
3. (especially of men) Charming, confident, and carefully dressed. 

### Noun
1. (obsolete) Debonaire behaviour; graciousness. 

## Synonyms
[[suave]] | [[cheerful]] | [[jaunty]] | [[refined]] | [[chipper]]