# dearth

## Etymology
- First attested at least as early as the late 1300s, and appearing in Tyndale’s Pentateuch (1530) as well as the Coverdale Bible (1535). From Middle English derth, derthe, derþe, probably from Old English *dīerþ, *dīerþu, from Proto-West Germanic *diuriþu, from Proto-Germanic *diuriþō (“costliness, preciousness, honour”); corresponding to dear +‎ -th. Cognate with Old Saxon diuriða (“glory, honour; preciousness”), West Frisian djoerte (“love, dearness, value, worth”), Dutch duurte (“dearness; scarcity, dearth”), Icelandic dýrð (“honour, glory”).


## Definition
### Noun
1. A period or condition when food is rare and hence expensive; famine. 
2. (by extension) Scarcity; a lack or short supply. 
3. (obsolete) Dearness; the quality of being rare or costly. 

## Synonyms
[[paucity]] | [[famine]] | [[shortage]]