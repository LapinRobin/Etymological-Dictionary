# apothegm

## Etymology
- From French apophthegme or Medieval Latin apothegma, from Ancient Greek ἀπόφθεγμα (apóphthegma), from ἀποφθέγγομαι (apophthéngomai, “speak out”).


## Definition
### Noun
1. A short, witty, instructive saying; an aphorism or maxim. 

## Synonyms
[[aphorism]]