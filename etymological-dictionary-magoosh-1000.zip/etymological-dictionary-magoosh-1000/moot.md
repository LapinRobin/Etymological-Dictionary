# moot

## Etymology
- From Middle English mōt, ȝemōt, from Old English *mōt, ġemōt (“meeting”), from Proto-Germanic , from Proto-Indo-European *meh₂d- (“to encounter, come”). Cognate with Scots mut, mote (“meeting, assembly”), Low German Mööt (“meeting”), Moot (“meeting”), archaic Dutch (ge)moet (“meeting”), Danish møde (“meeting”), Swedish möte (“meeting”), Norwegian møte (“meeting”), Icelandic mót (“meeting, tournament, meet”). Related to meet.

- From Middle English moten (“to speak, talk, converse, discuss”), from Old English mōtian (“to speak, converse, discuss”). See also mutter (which is a frequentative of moot).

- Unknown.

- From Dutch moot (“piece”).

- Clipping of mutual with humorously altered pronunciation.


## Definition
### Adjective
1. (current in UK, rare in the US) Subject to discussion (originally at a moot); arguable, debatable, unsolved or impossible to solve. 
2. (Canada, US, chiefly law) Being an exercise of thought; academic. 
3. (Canada, US) Having no practical consequence or relevance. 

### Noun
1. A moot court. 
2. A system of arbitration in many areas of Africa in which the primary goal is to settle a dispute and reintegrate adversaries into society rather than assess penalties. 
3. (Scouting) A gathering of Rovers, usually in the form of a camp lasting 2 weeks. 
4. (paganism) A social gathering of pagans, normally held in a public house. 
5. (historical) An assembly (usually for decision-making in a locality). 
6. (shipbuilding) A ring for gauging wooden pins. 
7. (Scotland, Northern England) A whisper, or an insinuation, also gossip or rumors. 
8. (Scotland, Northern England, rural) Talk. 
9. (Australia) Vagina. 
10. (West Country) The stump of a tree; the roots and bottom end of a felled tree. 
11. (Internet slang, endearing) A mutual follower on a social media platform. 

### Verb
1. To bring up as a subject for debate, to propose. 
2. To discuss or debate. 
3. (US) To make or declare irrelevant. 
4. To argue or plead in a supposed case. 
5. (regional, obsolete) To talk or speak. 
6. (Scotland, Northern England) To say, utter, also insinuate. 
7. (West Country) To take root and begin to grow. 
8. (West Country) To turn up soil or dig up roots, especially an animal with a snout. 

## Synonyms
[[consider]] | [[deliberate]] | [[controversial]] | [[debate]]