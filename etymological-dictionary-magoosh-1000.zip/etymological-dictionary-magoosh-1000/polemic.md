# polemic

## Etymology
- From French polémique, from Ancient Greek πολεμικός (polemikós, “of war”), from πόλεμος (pólemos, “war”).


## Definition
### Noun
1. A person who writes in support of one opinion, doctrine, or system, in opposition to another; one skilled in polemics; a controversialist; a disputant. 
2. An argument or controversy. 
3. A strong verbal or written attack on someone or something. 

### Adjective
1. Having the characteristics of a polemic. 

## Synonyms
[[controversial]] | [[polemical]]