# apocryphal

## Etymology
- From apocrypha +‎ -al.


## Definition
### Adjective
1. (Christianity) Of, or pertaining to, the Apocrypha. 
2. (by extension) Of doubtful authenticity, or lacking authority; not regarded as canonical. 
3. (by extension) Of dubious veracity; of questionable accuracy or truthfulness; anecdotal or in the nature of an urban legend. 
4. (Christianity) Of or relating to the Apocrypha. 

## Synonyms
[[questionable]]