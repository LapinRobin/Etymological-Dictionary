# ecosystem

## Etymology
- From eco- +‎ system. Coined by English botanist Arthur Tansley in 1935 in a paper titled "The Use and Abuse of Vegetational Concepts" in the journal Ecology.


## Definition
### Noun
1. A system formed by an ecological community and its environment that functions as a unit. 
2. The interconnectedness of organisms (plants, animals, microbes) with each other and their environment. 
3. (by extension) A network of interconnected people or organisations that resembles a natural ecosystem due to the complex interdependencies. 

## Synonyms
