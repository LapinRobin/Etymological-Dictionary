# paradoxical

## Etymology
- paradox +‎ -ical


## Definition
### Adjective
1. Having self-contradictory properties. 

## Synonyms
[[inexplicable]] | [[incomprehensible]]