# elaborate

## Etymology
- 1575, from Late Latin ēlabōrātus (“worked out”), past participle of ēlabōrō (“to work out”), from ē- (“out, forth, fully”) + labor (“work, toil, exertion”). More at e-, labour.


## Definition
### Adjective
1. Complex, detailed, or sophisticated. 
2. Intricate, fancy, flashy, or showy. 

### Verb
1. (transitive) to develop in detail or complexity 
2. (intransitive) (sometimes followed by on or upon, and then the object of the preposition) to expand/enlarge in detail 

## Synonyms
[[fancy]] | [[intricate]] | [[expand]] | [[expound]] | [[careful]] | [[refine]] | [[work out]] | [[dilate]] | [[detailed]] | [[expatiate]] | [[enlarge]]