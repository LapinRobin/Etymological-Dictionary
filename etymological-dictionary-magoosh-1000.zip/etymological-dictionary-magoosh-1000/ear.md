# ear

## Etymology
- From Middle English ere, eare, from Old English ēare (“ear”), from Proto-West Germanic *auʀā, from the voiced Verner alternant of Proto-Germanic *ausô (“ear”) (compare Scots ear, West Frisian ear, Dutch oor, German Ohr, Swedish öra, Danish øre), from Proto-Indo-European *h₂ṓws (compare Old Irish áu, Latin auris, Lithuanian ausìs, Russian у́хо (úxo), Albanian vesh, Ancient Greek οὖς (oûs), Old Armenian ունկն (unkn), and Persian گوش‎ (gôš)).

- 
From Middle English eere, er, from Old English ēar (Northumbrian dialect æhher), from Proto-West Germanic *ahaʀ, from Proto-Germanic *ahaz, from Proto-Indo-European *h₂eḱ- (“sharp”).

- From Middle English eren, from Old English erian, from Proto-West Germanic *arjan, from Proto-Germanic *arjaną, from Proto-Indo-European *h₂erh₃- (“to plough”).


## Definition
### Noun
1. (countable) The organ of hearing, consisting of the pinna, auditory canal, eardrum, malleus, incus, stapes and cochlea. 
2. (countable) The external part of the organ of hearing, the auricle. 
3. (countable, slang) A police informant. 
4. The sense of hearing; the perception of sounds; skill or good taste in listening to music. 
5. The privilege of being kindly heard; favour; attention. 
6. That which resembles in shape or position the ear of an animal; a prominence or projection on an object, usually for support or attachment; a lug; a handle. 
7. (architecture) An acroterium. 
8. (architecture) A crossette. 
9. (journalism) A space to the left or right of a publication's front-page title, used for advertising, weather, etc. 
10. (countable) The fruiting body of a grain plant. 
11. (programming) Initialism of Enterprise Application Archive (a file format used to package Java applications) 
12. (nutrition) Initialism of estimated average requirements. 

### Verb
1. (humorous) To take in with the ears; to hear. 
2. To hold by the ears. 
3. (intransitive) To put forth ears in growing; to form ears, as grain does. 
4. (archaic) To plough. 

## Synonyms
[[spike]] | [[auricle]]