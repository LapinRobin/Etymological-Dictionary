# easel

## Etymology
- Borrowed from Dutch ezel (“donkey; easel”), from Middle Dutch esel (“donkey”), from Proto-West Germanic *asil, from Latin asellus (“young ass or small donkey”), diminutive of asinus (“ass, donkey”), ultimately from an unknown source in Asia Minor. Essentially, the stand that a painting is placed on is being likened to a donkey carrying a burden; compare horse (“a frame with legs used to support something”), as in clotheshorse and sawhorse.


## Definition
### Noun
1. An upright frame, typically on three legs, for displaying or supporting something, such as an artist's canvas. 

## Synonyms
