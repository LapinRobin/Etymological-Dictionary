# rakish

## Etymology
- rake (“man habituated to immoral conduct”) +‎ -ish.


## Definition
### Adjective
1. Dashingly, carelessly, or sportingly unconventional or stylish; jaunty; characterized by a devil-may-care unconventionality; having a somewhat disreputable quality or appearance. 
2. (dated) Like a rake; dissolute; profligate. 

## Synonyms
[[smart]] | [[spruce]] | [[dapper]] | [[jaunty]] | [[fashionable]] | [[snappy]] | [[raffish]] | [[stylish]] | [[unconventional]] | [[natty]] | [[dashing]]