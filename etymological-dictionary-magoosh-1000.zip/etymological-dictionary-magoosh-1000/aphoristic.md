# aphoristic

## Etymology
- From Ancient Greek ἀφορῐστικος (aphoristikos), equivalent to aphorist +‎ -ic.


## Definition
### Adjective
1. Of, relating to, or containing aphorisms, maxims or epigrams; gnomic. 

## Synonyms
[[concise]] | [[axiomatic]]