# sanction

## Etymology
- From Middle French sanction, from Latin sanctio.


## Definition
### Noun
1. An approval, by an authority, generally one that makes something valid. 
2. A penalty, punishment, or some coercive measure, intended to ensure compliance; especially one adopted by several nations, or by an international body. 
3. A law, treaty, or contract, or a clause within a law, treaty, or contract, specifying any of the above. 

### Verb
1. (transitive) To ratify; to make valid. 
2. (transitive) To give official authorization or approval to; to countenance. 
3. (transitive) To penalize (a state etc.) with sanctions. 

## Synonyms
[[authority]] | [[warrant]] | [[countenance]] | [[imprimatur]] | [[ok]] | [[approve]] | [[endorsement]] | [[okay]]