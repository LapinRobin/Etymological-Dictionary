# culpability

## Etymology
- Middle French culpabilité


## Definition
### Noun
1. The degree of one's blameworthiness in the commission of a crime or offence. 

## Synonyms
