# censor

## Etymology
- The noun is borrowed from Latin cēnsor (“magistrate; critic”), from cēnseō (“to give an opinion, judge; to assess, reckon; to decree, determine”) + -sor (variant of -tor (suffix forming masculine agent nouns)). Cēnseō is derived from Proto-Italic *kensēō, ultimately from Proto-Indo-European *ḱens- (“to announce, proclaim; to put in order”). The English word is cognate with Late Middle English sensour, Proto-Iranian *cánhati (“to declare; to explain”), Sanskrit शंसति (śaṃsati, “to declare”).

- From an incorrect translation of German Zensur (“censorship”).


## Definition
### Noun
1. (Ancient Rome, historical) One of the two magistrates who originally administered the census of citizens, and by Classical times (between the 8th century B.C.E. and the 6th century C.E.) was a high judge of public behaviour and morality. 
2. (Ancient China, historical) A high-ranking official who was responsible for the supervision of subordinate government officials. 
3. An official responsible for the removal or suppression of objectionable material (for example, if obscene or likely to incite violence) or sensitive content in books, films, correspondence, and other media. 
4. (education) A college or university official whose duties vary depending on the institution. 
5. (obsolete) One who censures or condemns. 
6. (psychology) A hypothetical subconscious agency which filters unacceptable thought before it reaches the conscious mind. 

### Verb
1. (transitive) To review for, and if necessary to remove or suppress, content from books, films, correspondence, and other media which is regarded as objectionable (for example, obscene, likely to incite violence, or sensitive). 

## Synonyms
[[ban]]