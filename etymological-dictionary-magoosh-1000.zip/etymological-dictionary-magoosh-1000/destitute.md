# destitute

## Etymology
- From Middle English destitute, destitut, from Latin dēstitūtus.

- From Middle English destituten, from the adjective (see above).


## Definition
### Adjective
1. (followed by the preposition "of") Lacking something; devoid 
2. lacking money; poor, impoverished 

### Verb
1. (transitive) To impoverish; to strip of wealth, resources, etc. 

## Synonyms
[[poor]] | [[indigent]] | [[needy]] | [[impoverished]]