# proponent

## Etymology
- From Latin prōpōnēns, present participle of prōpōnō (“to put forward; propose”).


## Definition
### Noun
1. One who supports something; an advocate 
2. One who makes a proposal or proposition. 
3. (law) One who propounds a will for probate. 

### Adjective
1. Making proposals; proposing. 

## Synonyms
[[advocate]] | [[exponent]]