# imponderable

## Etymology
- From im- +‎ ponderable.


## Definition
### Adjective
1. Not ponderable; without sensible or appreciable weight; incapable of being weighed. 
2. Difficult or impossible to comprehend or evaluate. 

### Noun
1. (physics) An imponderable substance or body; specifically, in the plural, a name formerly applied to heat, light, electricity, and magnetism. 
2. An imponderable question. 
3. A factor that cannot be anticipated. 

## Synonyms
