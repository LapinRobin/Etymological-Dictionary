# ignominious

## Etymology
- From French or Old French ignominieux, from Latin ignōminiōsus (“disgraceful”), from ignōminia (“loss of a good name, ignominy”), from ig- (“not”) + nomen (“name”) (prefix assimilated form of in-). Surface analysis ignominy +‎ -ious.


## Definition
### Adjective
1. Marked by great dishonor, shame, disgrace or humiliation; shameful, disgraceful 

## Synonyms
[[black]]