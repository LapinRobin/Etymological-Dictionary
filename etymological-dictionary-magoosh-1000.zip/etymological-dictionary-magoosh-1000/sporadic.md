# sporadic

## Etymology
- From Medieval Latin sporadicus (whence also French sporadique, Italian sporadico, Spanish esporádico), from Ancient Greek σποραδικός (sporadikós), from σποράς (sporás, “scattered, dispersed”), from σπορά (sporá), σπόρος (spóros, “a sowing ”).


## Definition
### Adjective
1. (archaic) (of diseases) occurring in isolated instances; not epidemic. 
2. Rare and scattered in occurrence. 
3. Exhibiting random behavior; patternless. 

## Synonyms
[[intermittent]] | [[stray]] | [[irregular]] | [[isolated]] | [[unpredictable]] | [[scattered]] | [[periodic]]