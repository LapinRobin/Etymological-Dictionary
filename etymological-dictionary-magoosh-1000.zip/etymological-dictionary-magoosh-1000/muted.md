# muted

## Definition
### Adjective
1. Not expressed strongly or openly. 
2. (of a sound) Quiet or soft. 
3. (of color) Subdued. 

## Synonyms
[[quiet]] | [[dull]] | [[soft]] | [[subdued]]