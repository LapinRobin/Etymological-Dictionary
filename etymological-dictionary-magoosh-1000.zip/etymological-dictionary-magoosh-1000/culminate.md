# culminate

## Etymology
- Recorded since 1647, from Medieval Latin culminatus, the past participle of culminare (“to crown”), from Latin culmen (“peak, the highest point”), older form columen (“top, summit”), from Proto-Italic *kolamen, from a Proto-Indo-European base *kol-, *kelH- (“to project, rise; peak, summit, top”), whence also English hill and holm.


## Definition
### Verb
1. (intransitive, astronomy) Of a heavenly body, to be at the highest point, reach its greatest altitude. 
2. (intransitive) To reach the (physical or figurative) summit, highest point, peak etc. 
3. (intransitive, figuratively) To reach a climax; to come to a decisive point, especially an end or conclusion. 
4. (US, military, of an offensive, etc) To reach a point at which continued progress is not possible. 
5. (transitive) To finalize, bring to a conclusion, form the climax of. 

### Adjective
1. (anatomy) Relating to the culmen 

## Synonyms
[[climax]]