# craven

## Etymology
- From Middle English cravant, either borrowed from Old French cravanté (“defeated”), past participle of cravanter, or a modification of creaunt (“defeated”) after craven (“to crave”).


## Definition
### Adjective
1. Unwilling to fight; lacking even the rudiments of courage; extremely cowardly. 

### Noun
1. A coward. 
2. A surname. 
3. A local government district in North Yorkshire, England. 
4. A village in the Rural Municipality of Longlaketon No. 219, Saskatchewan, Canada. 

### Verb
1. To make craven. 

## Synonyms
[[poltroon]] | [[fearful]] | [[cowardly]] | [[recreant]]