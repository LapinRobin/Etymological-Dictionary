# raffish

## Etymology
- From late 18th century raff (“persons among the lowest class in society”) +‎ -ish, still retained in contemporary English with riffraff. From Old French raffer (“to wear away”), of Germanic origin. Compare German raffen. Compare rip (“to tear”), rap (“to snatch”).


## Definition
### Adjective
1. Characterized by careless unconventionality; rakish. 
2. Low-class; disreputable; vulgar. 

## Synonyms
[[smart]] | [[spruce]] | [[dapper]] | [[jaunty]] | [[rakish]] | [[fashionable]] | [[snappy]] | [[stylish]] | [[unconventional]] | [[natty]] | [[dashing]]