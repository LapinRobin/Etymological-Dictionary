# arrant

## Etymology
- A variant of errant, from Middle English erraunt , from Anglo-Norman erraunt, from Old French errant, the present participle of errer (“to walk (to); to wander (to); (figuratively) to travel, voyage”), and then:


## Definition
### Adjective
1. (chiefly with a negative connotation, dated) Complete; downright; utter. 
2. (by extension, dated) Very bad; despicable. 
3. Obsolete form of errant (“roving around; wandering”).  

### Noun
1. A surname. 

## Synonyms
[[perfect]] | [[complete]] | [[gross]] | [[consummate]] | [[pure]] | [[stark]] | [[utter]] | [[everlasting]] | [[staring]]