# empathetic

## Etymology
- Derived from empathic, modified to sound more similar to sympathetic.


## Definition
### Adjective
1. Showing empathy for others, and recognizing their feelings; empathic. 

## Synonyms
[[sympathetic]] | [[empathic]]