# incongruous

## Etymology
- From Latin incongruus, from in- (“not”) + congruus (“congruent”).


## Definition
### Adjective
1. Not similar or congruent; not matching or fitting in. 
2. (mathematics) Of two numbers, with respect to a third, such that their difference can not be divided by it without a remainder. 

## Synonyms
[[absurd]] | [[ironic]] | [[inappropriate]] | [[inconsistent]] | [[incompatible]]