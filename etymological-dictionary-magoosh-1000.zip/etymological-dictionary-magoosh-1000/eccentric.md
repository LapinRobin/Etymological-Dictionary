# eccentric

## Etymology
- From Middle French excentrique, from Medieval Latin eccentricus, from Ancient Greek ἔκκεντρος (ékkentros, “not having the earth as the center of an orbit”), from ἐκ (ek, “out”) + κέντρον (kéntron, “point”). Equivalent to ex- +‎ -centric.


## Definition
### Adjective
1. Not at or in the centre; away from the centre. 
2. Not perfectly circular; elliptical. 
3. Having a different center; not concentric. 
4. (of a person) Deviating from the norm; behaving unexpectedly or differently; unconventional and slightly strange. 
5. (physiology, of a motion) Against or in the opposite direction of contraction of a muscle (such as results from flexion of the lower arm (bending of the elbow joint) by an external force while contracting the triceps and other elbow extensor muscles to control that movement; opening of the jaw while flexing the masseter). 
6. Having different goals or motives. 

### Noun
1. One who does not behave like others. 
2. (slang) A kook; a person of bizarre habits or beliefs. 
3. (geometry) A circle not having the same centre as another. 
4. (engineering) A disk or wheel with its axis off centre, giving a reciprocating motion. 
5. (physiology) An exercise that goes against or in the opposite direction of contraction of a muscle. 

## Synonyms
[[case]] | [[character]] | [[type]] | [[bizarre]] | [[geek]] | [[outre]] | [[outlandish]] | [[flaky]] | [[unconventional]] | [[oddball]] | [[freaky]]