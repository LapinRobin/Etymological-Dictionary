# audacity

## Etymology
- From late Middle English audacite, from Medieval Latin audacitas, from Latin audax (“bold”), from audeō (“I am bold, I dare”).


## Definition
### Noun
1. Insolent boldness, especially when imprudent or unconventional. 
2. Fearlessness, intrepidity or daring, especially with confident disregard for personal safety, conventional thought, or other restrictions. 

## Synonyms
[[temerity]] | [[chutzpah]]