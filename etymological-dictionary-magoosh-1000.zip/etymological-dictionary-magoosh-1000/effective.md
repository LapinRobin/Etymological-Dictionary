# effective

## Etymology
- From French effectif, from Latin effectīvus (“productive; effective”), from efficiō (“I make; I bring about”).


## Definition
### Adjective
1. Having the power to produce a required effect or effects. 
2. Producing a decided or decisive effect. 
3. Efficient, serviceable, or operative, available for useful work. 
4. Actually in effect. 
5. (geometry, of a cycle or divisor) Having no negative coefficients. 
6. (physics, for any effective theory) approximate; Not describing the fundamental dynamic changes in some system as they happen. 

### Noun
1. (military) a soldier fit for duty 

## Synonyms
[[good]] | [[efficient]] | [[competent]] | [[trenchant]] | [[impressive]] | [[actual]] | [[efficacious]] | [[operative]] | [[telling]] | [[operational]] | [[existent]]