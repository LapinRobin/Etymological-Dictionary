# irascible

## Etymology
- From French irascible, from Late Latin īrāscibilis.


## Definition
### Adjective
1. Easily provoked to outbursts of anger; irritable. 

## Synonyms
[[short]] | [[angry]] | [[choleric]]