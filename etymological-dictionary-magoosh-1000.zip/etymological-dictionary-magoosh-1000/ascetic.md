# ascetic

## Etymology
- 17th century, from Medieval Latin asceticus, from Ancient Greek ἀσκητικός (askētikós), from ἀσκητής (askētḗs, “monk, hermit”), from ἀσκέω (askéō, “I exercise”).


## Definition
### Adjective
1. Of or relating to ascetics 
2. Characterized by rigorous self-denial or self-discipline; austere; abstinent; involving a withholding of physical pleasure. 

### Noun
1. One who is devoted to the practice of self-denial, either through seclusion or stringent abstinence. 

## Synonyms
[[austere]] | [[abstemious]] | [[spartan]]