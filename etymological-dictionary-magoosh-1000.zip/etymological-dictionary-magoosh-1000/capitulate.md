# capitulate

## Etymology
- From the participle stem of Medieval Latin capitulare (“draw up under headings”), from Latin capitulum (“heading, chapter, title”), diminutive of caput (“head”).


## Definition
### Verb
1. (intransitive) To surrender; to end all resistance, to give up; to go along with or comply. 
2. (transitive, obsolete) To draw up in chapters; to enumerate. 
3. (transitive, obsolete) To draw up the articles of treaty with; to treat, bargain, parley. 

## Synonyms
