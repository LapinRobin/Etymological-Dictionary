# abrogate

## Etymology
- First attested in 1526, from Middle English abrogat (“abolished”), from Latin abrogātus, perfect passive participle of abrogō (“repeal”), formed from ab (“away”) + rogō (“ask, inquire, propose”). See rogation.


## Definition
### Verb
1. (transitive, law) To annul by an authoritative act; to abolish by the authority of the maker or her or his successor; to repeal; — applied to the repeal of laws, decrees, ordinances, the abolition of customs, etc. 
2. (transitive) To put an end to; to do away with. 
3. (molecular biology, transitive) To block a process or function. 

### Adjective
1. (archaic) Abrogated; abolished. 

## Synonyms
