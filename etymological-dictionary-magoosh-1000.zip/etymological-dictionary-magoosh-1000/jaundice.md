# jaundice

## Etymology
- From Middle English jaundis, jaunis, from Middle French jaunisse, from jaune (“yellow”) + -isse (“-ness”). Jaune, from Old French jalne, from Latin galbinus (“yellowish”), from galbus (“yellow”).


## Definition
### Noun
1. (pathology) A morbid condition, characterized by yellowness of the eyes, skin, and urine. 
2. (figuratively) A feeling of bitterness, resentment or jealousy. 

### Verb
1. (transitive) To affect with jaundice; to color by prejudice or envy; to prejudice. 

## Synonyms
[[acrimony]] | [[bitterness]]