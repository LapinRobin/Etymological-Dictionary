# lambast

## Definition
### Verb
1. (UK) Alternative form of lambaste  

## Synonyms
[[check]] | [[rebuke]] | [[reprimand]] | [[chide]] | [[rag]] | [[scold]] | [[berate]] | [[cane]] | [[lecture]] | [[jaw]] | [[flog]] | [[remonstrate]] | [[lambaste]] | [[reproof]]