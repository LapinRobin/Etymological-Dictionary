# dispensation

## Etymology
- From Old French despensacion, from Latin dispensātiō.


## Definition
### Noun
1. The act of dispensing or dealing out; distribution 
2. The distribution of good and evil by God to man. 
3. That which is dispensed, dealt out, or given; that which is bestowed on someone 
4. A system of principles, promises, and rules ordained and administered; scheme; economy 
5. The relaxation of a law in a particular case; permission to do something forbidden, or to omit doing something enjoined; exemption. 
6. (Catholicism) In the Roman Catholic Church, an exemption from some ecclesiastical law, or from an obligation to God which a person has incurred of his own free will (oaths, vows, etc.). 

## Synonyms
