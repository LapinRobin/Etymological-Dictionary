# construe

## Etymology
- From Middle English construen, from Late Latin construo, construere (“to relate grammatically”), from Latin construo (“pile together”); doublet of construct.


## Definition
### Noun
1. A translation. 
2. An interpretation. 

### Verb
1. (transitive) To interpret or explain the meaning of something. 
2. (grammar, transitive) To analyze the grammatical structure of a clause or sentence; to parse. 
3. (grammar, ergative) To admit of grammatical analysis. 
4. (transitive) To translate. 
5. To infer. 

## Synonyms
[[interpret]]