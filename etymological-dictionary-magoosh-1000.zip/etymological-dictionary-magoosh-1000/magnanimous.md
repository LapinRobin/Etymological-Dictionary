# magnanimous

## Etymology
- From Latin magnanimus, from magnus (“great”) + animus (“soul, mind”). Displaced native Old English miċelmōd (literally “big-minded”).


## Definition
### Adjective
1. Noble and generous in spirit. 

## Synonyms
[[big]] | [[large]] | [[noble]] | [[generous]]