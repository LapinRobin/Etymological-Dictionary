# degrade

## Etymology
- From Middle French dégrader.


## Definition
### Verb
1. (transitive) To lower in value or social position. 
2. (intransitive, ergative) To reduce in quality or purity. 
3. (transitive, geology) To reduce in altitude or magnitude, as hills and mountains; to wear down. 

## Synonyms
[[demean]] | [[disgrace]] | [[put down]]