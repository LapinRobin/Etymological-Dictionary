# quail

## Etymology
- From Middle English quaylen, from Middle Dutch queilen, quēlen, from Old Dutch *quelan, from Proto-West Germanic *kwelan, from Proto-Germanic *kwelaną (“to suffer”). Doublet of queal.

- From Middle English quayle, quaile, quaille, from Anglo-Norman quaille, from Late Latin quaccola (“quail”).

- From Middle English quaylen, qwaylen, from Old French quaillier, coaillier, from Latin coāgulāre. Doublet of coagulate.


## Definition
### Verb
1. (intransitive) To waste away; to fade, to wither. 
2. (transitive, now rare) To daunt or frighten (someone). 
3. (intransitive) To lose heart or courage; to be daunted or fearful. 
4. (intransitive) Of courage, faith, etc.: to slacken, to give way. 
5. (obsolete) To curdle or coagulate, as milk does. 

### Noun
1. Any of various small game birds of the genera Coturnix, Anurophasis or Perdicula in the Old World family Phasianidae or of the New World family Odontophoridae. 
2. (uncountable) The meat from this bird eaten as food. 
3. (obsolete) A prostitute, so called because the quail was thought to be a very amorous bird. 
4. A surname from Scottish Gaelic. 

## Synonyms
[[shrink]] | [[cringe]] | [[funk]] | [[flinch]] | [[recoil]] | [[wince]]