# pithy

## Etymology
- pith +‎ -y


## Definition
### Adjective
1. Concise and meaningful. 
2. Of, like, or abounding in pith; spongy or having small holes or pits. 

## Synonyms
[[concise]] | [[sententious]]