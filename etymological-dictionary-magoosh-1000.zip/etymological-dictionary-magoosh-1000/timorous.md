# timorous

## Etymology
- Borrowed into late Middle English from Old French temoros, from Medieval Latin timorosus, from Latin timor (“fear”), from timeō (“I fear”). Doublet of timoroso.


## Definition
### Adjective
1. Fearful; afraid; timid. 

## Synonyms
[[timid]] | [[fearful]]