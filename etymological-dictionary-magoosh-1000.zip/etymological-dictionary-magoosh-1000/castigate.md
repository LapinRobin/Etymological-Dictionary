# castigate

## Etymology
- Early 17th cent., borrowed from Latin castīgātus, past participle of castīgō (“I reprove”), from castus (“pure, chaste”), from Proto-Indo-European *ḱes- (“cut”). Doublet of chastise and chasten, taken through Old French. See also chaste.


## Definition
### Verb
1. (transitive, formal) To punish or reprimand someone severely. 
2. (transitive, formal) To execrate or condemn something in a harsh manner, especially by public criticism. 
3. (transitive, rare) To revise or make corrections to a publication. 

## Synonyms
[[correct]] | [[chastise]] | [[chasten]]