# obtain

## Etymology
- From Middle English obteinen, from Anglo-Norman obtenir, optiner et al., and Middle French obtenir, from Latin obtinēre (“to gain, achieve, succeed, possess”), from ob- + tenēre (“to hold”).


## Definition
### Verb
1. (transitive) To get hold of; to gain possession of, to procure; to acquire, in any way. 
2. (intransitive, obsolete) To secure (that) a specific objective or state of affairs be reached. 
3. (intransitive, obsolete) To prevail, be victorious; to succeed. 
4. (transitive, obsolete) To hold; to keep, possess or occupy. 
5. (intransitive, archaic) To exist or be the case; to hold true, be in force. 

## Synonyms
[[get]] | [[hold]] | [[find]] | [[incur]] | [[receive]] | [[prevail]]