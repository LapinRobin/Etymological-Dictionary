# obdurate

## Etymology
- Mid-15th century, from Latin obduratus (“hardened”), form of obdūrō (“harden”), from ob- (“against”) + dūrō (“harden, render hard”), from durus (“hard”). Compare durable, endure.


## Definition
### Adjective
1. Stubbornly persistent, generally in wrongdoing; refusing to reform or repent. 
2. (obsolete) Physically hardened, toughened. 
3. Hardened against feeling; hard-hearted. 

### Verb
1. (transitive, obsolete) To harden; to obdure. 

## Synonyms
[[obstinate]]