# cryptic

## Etymology
- From Late Latin crypticus, from Ancient Greek κρυπτικός (kruptikós), from κρυπτός (kruptós, “hidden”), from κρύπτω (krúptō, “to hide”). Compare cryptology.


## Definition
### Adjective
1. Having hidden meaning. 
2. Mystified or of an obscure nature. 
3. Involving use of a code or cipher. 
4. Of a crossword puzzle, or a clue in such a puzzle, using, in addition to definitions, wordplay such as anagrams, homophones and hidden words to indicate solutions. 
5. (zoology) Well camouflaged; having good camouflage. 
6. (zoology) Serving as camouflage. 
7. (biology, not comparable) Apparently identical, but actually genetically distinct. 
8. (zoology) Living in a cavity or small cave. 

### Noun
1. (informal) A cryptic crossword puzzle. 

## Synonyms
[[esoteric]] | [[deep]] | [[concise]] | [[inscrutable]] | [[mysterious]] | [[inexplicable]] | [[incomprehensible]]