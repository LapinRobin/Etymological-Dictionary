# loath

## Etymology
- From Middle English lōth (“loath; averse, hateful”), from Old English lāð, lāþ (“evil; loathsome”), or Old Norse leið, leiðr (“uncomfortable; tired”) from Proto-Germanic *laiþaz (“loath; hostile; sad, sorry”), ultimately from Proto-Indo-European *h₂leyt- (“to do something abhorrent or hateful”).

- loath (third-person singular simple present loaths, present participle loathing, simple past and past participle loathed)


## Definition
### Adjective
1. Averse, disinclined; reluctant, unwilling. 
2. (obsolete) Angry, hostile. 
3. (obsolete) Loathsome, unpleasant. 

### Verb
1. Obsolete spelling of loathe  

## Synonyms
[[averse]] | [[reluctant]] | [[loth]]