# cornucopia

## Etymology
- Borrowed from Latin cornūcōpia (“mythical horn of plenty”), from cornū (“horn”) + cōpia (“abundance”).


## Definition
### Noun
1. (Greek mythology) A goat's horn endlessly overflowing with fruit, flowers and grain; or full of whatever its owner wanted: or, an image of a such a horn, either in two or three dimensions. 
2. A hollow horn- or cone-shaped object, filled with edible or useful things. 
3. An abundance or plentiful supply. 

## Synonyms
[[profusion]]