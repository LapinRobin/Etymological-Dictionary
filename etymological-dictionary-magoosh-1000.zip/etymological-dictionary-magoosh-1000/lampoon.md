# lampoon

## Etymology
- From French lampon (“satire, mockery, ridicule”), built on French lampons (“let us drink — a popular refrain for scurrilous songs”), from lamper (“to quaff, to swig”).


## Definition
### Noun
1. A written attack or other work ridiculing a person, group, or institution. 

### Verb
1. To satirize or poke fun at. 

## Synonyms
[[parody]] | [[travesty]] | [[charade]] | [[spoof]] | [[burlesque]] | [[mockery]] | [[takeoff]]