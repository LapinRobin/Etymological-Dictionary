# eerie

## Etymology
- From Middle English eri (“fearful”), from Old English earg (“cowardly, fearful”), from Proto-Germanic *argaz. Akin to Scots ergh, argh from the same Old English source. Doublet of argh.


## Definition
### Adjective
1. Strange, weird, fear-inspiring, especially in a shadowy or mysterious way. 
2. (Scotland) Frightened, timid. 

## Synonyms
[[strange]] | [[unusual]] | [[spooky]]