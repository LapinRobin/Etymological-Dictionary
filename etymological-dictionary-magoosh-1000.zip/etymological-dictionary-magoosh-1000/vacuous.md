# vacuous

## Etymology
- Latin vacuus (“empty, vacant”)


## Definition
### Adjective
1. Empty; void; lacking meaningful content. 
2. Showing a lack of thought or intelligence; vacant. 

## Synonyms
[[inane]] | [[asinine]] | [[hollow]] | [[fatuous]] | [[empty]] | [[foolish]] | [[meaningless]]