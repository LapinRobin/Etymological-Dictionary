# credence

## Etymology
- From Middle English credence, from Old French credence, from Medieval Latin crēdentia (“belief, faith”), from Latin crēdēns, present active participle of crēdō (“loan, confide in, trust, believe”). Compare French croyance, French créance, Italian credenza, Portuguese crença, Romanian credință, Spanish creencia.


## Definition
### Noun
1. (uncountable) Acceptance of a belief or claim as true, especially on the basis of evidence. 
2. (rare, uncountable) Credential or supporting material for a person or claim. 
3. (religion, countable) A small table or credenza used in certain Christian religious services. 
4. (countable) A cupboard, sideboard, or cabinet, particularly one intended for the display of rich vessels or plate on open shelves. 
5. (countable) A subjective probability estimate of a belief or claim. 

### Verb
1. (obsolete) To give credence to; to believe. 

## Synonyms
[[acceptance]] | [[credenza]]