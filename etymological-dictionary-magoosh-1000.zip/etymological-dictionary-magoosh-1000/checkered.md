# checkered

## Definition
### Adjective
1. Divided into squares, or into light and dark patches. 
2. (figuratively) Changeable; inconsistent; having variations or uncertainty; marked by many problems or failures. 

## Synonyms
