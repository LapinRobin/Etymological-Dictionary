# importuned

## Definition
### Verb
1. To bother, irritate, trouble. 
2. To harass with persistent requests. 
3. To approach to offer one's services as a prostitute, or otherwise make improper proposals. 
4. (obsolete) To import; to signify. 

### Adjective
1. (obsolete) Grievous, severe, exacting. 
2. (obsolete) Inopportune; unseasonable. 
3. (obsolete) Troublesome; vexatious; persistent. 

## Synonyms
