# temerity

## Etymology
- temer(arious) +‎ -ity, from Middle English temerite, temeryte, from Old French temerité, from Latin temeritās (“chance, accident, rashness”), from temerē (“by chance, casually, rashly”).


## Definition
### Noun
1. (uncountable) Reckless boldness; foolish bravery. 
2. (countable) An act or case of reckless boldness. 
3. (uncountable) Effrontery; impudence. 

## Synonyms
[[audacity]]