# antithetical

## Etymology
- From antithetic +‎ -al.


## Definition
### Adjective
1. Pertaining to antithesis, or opposition of words and sentiments; containing, or of the nature of, antithesis; contrasted. 

## Synonyms
[[different]]