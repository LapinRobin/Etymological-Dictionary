# eats

## Definition
### Noun
1. (colloquial) Food. 

## Synonyms
[[chuck]] | [[grub]] | [[chow]]