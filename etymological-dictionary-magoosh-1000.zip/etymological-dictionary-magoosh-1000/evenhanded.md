# evenhanded

## Etymology
- even- +‎ handed


## Definition
### Adjective
1. fair and having no partiality; unbiased; just. 

## Synonyms
[[just]] | [[equitable]]