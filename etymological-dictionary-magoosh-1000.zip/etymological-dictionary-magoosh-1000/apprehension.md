# apprehension

## Etymology
- Borrowed from Latin apprehensio, apprehensionis, compare with French appréhension. See apprehend.


## Definition
### Noun
1. (rare) The physical act of seizing or taking hold of (something); seizing. 
2. (law) The act of seizing or taking by legal process; arrest. 
3. Perception; the act of understanding using one's intellect without affirming, denying, or passing any judgment 
4. Opinion; conception; sentiment; idea. 
5. The faculty by which ideas are conceived or by which perceptions are grasped; understanding. 
6. Anticipation, especially of unfavorable things such as dread or fear or the prospect of something unpleasant in the future. 

## Synonyms
[[catch]] | [[savvy]] | [[collar]] | [[dread]] | [[understanding]] | [[arrest]] | [[discernment]] | [[pinch]] | [[misgiving]]