# amiable

## Etymology
- From Middle English amyable, from Old French amiable, from Late Latin amīcābilis (“friendly”), from Latin amīcus (“friend”), from amō (“love”, verb). The meaning has been influenced by French amiable and Latin amābilis (“loveable”). Compare with amicable, amorous, amability.


## Definition
### Adjective
1. Friendly; kind; sweet; gracious 
2. Of a pleasant and likeable nature; kind-hearted; easy to like 

## Synonyms
[[cordial]] | [[affable]] | [[friendly]] | [[genial]]