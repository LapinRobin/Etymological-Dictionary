# galvanize

## Etymology
- From French galvaniser, from galvanisme, named after Italian physiologist Luigi Aloisio Galvani (1737–1798).


## Definition
### Verb
1. (chemistry) To coat with a thin layer of metal by electrochemical means. 
2. To coat with rust-resistant zinc. 
3. (figuratively) To shock or stimulate into sudden activity, as if by electric shock. 
4. (archaic) To electrify. 
5. (historical, US) To switch sides between Union and Confederate in the American Civil War. 

## Synonyms
[[startle]]