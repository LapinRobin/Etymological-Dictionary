# spurn

## Etymology
- From Middle English spurnen, spornen, from Old English spurnan (“to strike against, kick, spurn, reject; stumble”), from Proto-Germanic *spurnaną (“to tread, kick, knock out”), from Proto-Indo-European *sperH-.


## Definition
### Verb
1. (transitive, intransitive) To reject disdainfully; contemn; scorn. 
2. (transitive) To reject something by pushing it away with the foot. 
3. (transitive) To waste; fail to make the most of (an opportunity) 
4. (intransitive, obsolete) To kick or toss up the heels. 

### Noun
1. An act of spurning; a scornful rejection. 
2. A kick; a blow with the foot. 
3. (obsolete) Disdainful rejection; contemptuous treatment. 
4. (mining) A body of coal left to sustain an overhanging mass. 

## Synonyms
[[disdain]] | [[scorn]] | [[reject]]