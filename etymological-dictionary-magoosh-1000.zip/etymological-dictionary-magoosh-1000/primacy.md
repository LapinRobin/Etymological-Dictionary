# primacy

## Etymology
- From Old French primacie, from Medieval Latin primatia (“office of a church primate”), from Latin primas plus a suffix corresponding to -acy.


## Definition
### Noun
1. The state or condition of being prime or first, as in time, place, rank, etc. 
2. (archaic) excellence; supremacy. 
3. (religion) The office, rank, or character of a primate, it being the chief ecclesiastical station or dignity in a national church 
4. (religion) the office or dignity of an archbishop 

## Synonyms
