# summit

## Etymology
- From Late Middle English somete, from early Middle French somete, from Old French sommette, somet (compare modern French sommet), a diminutive of som (“highest part, top of a hill”), from Latin summum. This etymology is incomplete. You can help Wiktionary by elaborating on the origins of this term.

- From Middle English *summit, *sumwit, *sumwiht, variant of sum wiht, som wiht (“some thing”, literally “some wight”). More at some, wight.


## Definition
### Noun
1. (countable) A peak; the topmost point or surface, as of a mountain. 
2. (countable) A gathering or assembly of leaders. 
3. A surname. 

### Verb
1. (transitive, intransitive, hiking, climbing, colloquial) To reach the summit of a mountain. 

## Synonyms
[[top]] | [[tip]] | [[peak]] | [[crown]] | [[crest]] | [[pinnacle]] | [[acme]] | [[height]] | [[superlative]] | [[elevation]]