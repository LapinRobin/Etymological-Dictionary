# cerebral

## Etymology
- Borrowing from French cérébral, from Latin cerebrum (“a brain”); equivalent to cerebrum +‎ -al.

- Semantic loan from Sanskrit मूर्धन्य (mūrdhanya, “pertaining to the head”).


## Definition
### Adjective
1. (anatomy, relational) Of, or relating to the brain, cerebrum, or cerebral cortex. 
2. Intellectual rather than emotional or physical. 
3. (linguistics, obsolete) Retroflex. 

## Synonyms
[[intellectual]]