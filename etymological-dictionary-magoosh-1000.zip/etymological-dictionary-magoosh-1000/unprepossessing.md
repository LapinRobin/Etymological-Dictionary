# unprepossessing

## Etymology
- un- +‎ prepossessing


## Definition
### Adjective
1. Unimpressive or unremarkable; dull and ordinary; nondescript. 

## Synonyms
