# effortless

## Etymology
- effort +‎ -less


## Definition
### Adjective
1. Without effort. 

## Synonyms
[[easy]] | [[facile]] | [[casual]]