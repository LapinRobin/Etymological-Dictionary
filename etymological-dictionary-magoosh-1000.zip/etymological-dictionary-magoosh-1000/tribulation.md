# tribulation

## Etymology
- From Middle English tribulation, from Old French tribulacion, from Late Latin trībulātiō (“distress, trouble, tribulation, affliction”), from Latin tribulāre (“to press, probably also thresh out grain”), from trībulum (“a sledge consisting of a wooden block studded with sharp pieces of flint or with iron teeth, used for threshing grain”), from terēre (“to rub”); see trite.


## Definition
### Noun
1. Any adversity; a trying period or event. 
2. (Christian eschatology) (A period of) persecution before the Second Coming, lasting seven years, which Christians will experience worldwide which will purify and strengthen them. 

## Synonyms
[[trial]]