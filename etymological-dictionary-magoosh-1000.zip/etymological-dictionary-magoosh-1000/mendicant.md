# mendicant

## Etymology
- From Latin mendīcāns, present participle of mendīcō (“beg”). Compare French mendiant.


## Definition
### Adjective
1. Depending on alms for a living. 
2. Of or pertaining to a beggar. 
3. Of or pertaining to a member of a religious order forbidden to own property, and who must beg for a living. 

### Noun
1. A pauper who lives by begging. 
2. A religious friar, forbidden to own personal property, who begs for a living. 

## Synonyms
[[beggar]] | [[friar]]