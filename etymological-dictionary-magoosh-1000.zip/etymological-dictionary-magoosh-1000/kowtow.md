# kowtow

## Etymology
- From Sinitic 叩頭／叩头 (Cantonese 叩頭／叩头 (kau3 tau4) / Mandarin 叩頭／叩头 (kòutóu)), literally "knock head".


## Definition
### Verb
1. (intransitive, figuratively) To grovel, act in a very submissive manner. 
2. (intransitive, historical) To kneel and bow low enough to touch one’s forehead to the ground. 
3. (intransitive) To bow very deeply. 
4. (by extension) To bow to or show obeisance to. 

### Noun
1. The act of kowtowing. 

## Synonyms
[[scrape]] | [[fawn]] | [[toady]] | [[genuflect]]