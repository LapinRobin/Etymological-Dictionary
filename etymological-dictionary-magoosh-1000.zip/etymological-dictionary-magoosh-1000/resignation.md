# resignation

## Etymology
- From Middle English resignacion, resignacioun, from Old French resignation, from Medieval Latin resignātiōnem, accusative of resignātio. Equivalent to resign +‎ -ation.


## Definition
### Noun
1. The act of resigning. 
2. A written or oral declaration that one resigns. 
3. An uncomplaining acceptance of something undesirable but unavoidable. 
4. (Scotland, law, historical) The form by which a vassal returns the feu into the hands of a superior. 

## Synonyms
[[surrender]]