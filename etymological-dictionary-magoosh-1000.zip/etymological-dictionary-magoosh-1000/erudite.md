# erudite

## Etymology
- From Latin ērudītus, participle of ērudiō (“educate, train”), from e- (“out of”) + rudis (“rude, unskilled”). Doublet of erudit.


## Definition
### Adjective
1. Learned, scholarly, with emphasis on knowledge gained from books. 

### Noun
1. a learned or scholarly person 

## Synonyms
[[learned]] | [[scholarly]]