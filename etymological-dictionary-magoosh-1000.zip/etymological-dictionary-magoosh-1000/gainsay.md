# gainsay

## Etymology
- From Middle English gainsayen, ȝeinseggen (“to say against, say in opposition to”), equivalent to gain- +‎ say. Compare Old Danish gensige (“to speak against; gainsay”), Swedish gensaga (“a speaking against; protest”).


## Definition
### Verb
1. (transitive, formal) To say something in contradiction to. 

## Synonyms
[[challenge]] | [[dispute]]