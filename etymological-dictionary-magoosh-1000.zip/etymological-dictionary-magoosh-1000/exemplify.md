# exemplify

## Etymology
- From Medieval Latin exemplificare, from Latin exemplum (“example”).


## Definition
### Verb
1. (transitive) To show or illustrate by example. 
2. (transitive) To be an instance of or serve as an example. 
3. (transitive) To make an attested copy or transcript of (a document) under seal. 
4. (transitive) To prove by such an attested copy or transcript. 

## Synonyms
[[instance]] | [[represent]] | [[illustrate]]