# precocious

## Etymology
- From Latin praecox (“premature, precocious, ripe before time, early ripe”), from praecoquere (“to ripen beforehand, ripen fully, also boil beforehand”), from prae (“before”) + coquere (“to cook, boil, ripen”).


## Definition
### Adjective
1. Characterized by exceptionally early development or maturity. 
2. Exhibiting advanced skills and aptitudes at an abnormally early age. 

## Synonyms
[[advanced]] | [[early]] | [[talented]] | [[gifted]]