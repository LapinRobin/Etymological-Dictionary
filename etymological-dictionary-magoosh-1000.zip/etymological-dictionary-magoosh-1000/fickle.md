# fickle

## Etymology
- From Middle English fikil, fikel, from Old English ficol (“fickle, cunning, tricky, deceitful”), equivalent to fike +‎ -le. More at fike.

- From Middle English fikelen, from fikel (“fickle”); see above. Cognate with Low German fikkelen (“to deceive, flatter”), German ficklen, ficheln (“to deceive, flatter”).


## Definition
### Adjective
1. Quick to change one’s opinion or allegiance; insincere; not loyal or reliable. 
2. (figuratively) Changeable. 

### Verb
1. (transitive) To deceive, flatter. 
2. (transitive, UK dialectal) To puzzle, perplex, nonplus. 

### Noun
1. A surname. 

## Synonyms
[[volatile]] | [[mercurial]] | [[erratic]] | [[quicksilver]]