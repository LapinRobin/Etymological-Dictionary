# fawn

## Etymology
- From Middle English fawne, fowne, foun, from Old French faon, foon, feon, from Vulgar Latin *fētōnem, from Latin fētus (“offspring, young”), from Proto-Indo-European *dʰeh₁(y)- (“to suckle, nurse”). Displaced native Old English hindċealf (literally “deer calf”). Doublet of fetus.

- 
From Middle English fawnen, from Old English fagnian, related to Old English fæġnian (“to celebrate”), whence Middle English fainen, English fain. Cognate with Old Norse fagna. See also fain.


## Definition
### Noun
1. A young deer. 
2. A pale brown colour tinted with yellow, like that of a fawn. 
3. (obsolete) The young of an animal; a whelp. 
4. (rare) A servile cringe or bow. 
5. Base flattery. 

### Adjective
1. Of the fawn colour. 

### Verb
1. (intransitive) To give birth to a fawn. 
2. (intransitive) To exhibit affection or attempt to please. 
3. (intransitive) To seek favour by flattery and obsequious behaviour (with on or upon). 
4. (intransitive, of a dog) To show devotion or submissiveness by wagging its tail, nuzzling, licking, etc. 

## Synonyms
[[creep]] | [[cringe]] | [[dun]] | [[crawl]] | [[grovel]] | [[cower]] | [[kowtow]] | [[toady]]