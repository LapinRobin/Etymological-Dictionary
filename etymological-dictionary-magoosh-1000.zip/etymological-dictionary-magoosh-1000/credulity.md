# credulity

## Etymology
- Inherited from Middle English credulite (“faith, belief”), borrowed from Middle French credulité (French crédulité), from Latin crēdulitās. Corresponding to credulous +‎ -ity (compare credulosity).


## Definition
### Noun
1. (now nonstandard) Faith, credence; acceptance or maintenance of a belief. 
2. A willingness to believe in someone or something in the absence of reasonable proof; credulousness. 

## Synonyms
