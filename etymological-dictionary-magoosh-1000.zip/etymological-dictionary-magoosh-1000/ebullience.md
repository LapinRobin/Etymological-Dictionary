# ebullience

## Etymology
- Borrowed from Latin ēbullientem + English -ence (suffix meaning ‘having the state or condition of’). Ēbullientem is the accusative feminine or masculine singular of ēbulliēns (“boiling”), the present participle of ēbulliō (“to boil”) (from ē- (prefix meaning ‘out, away’) + bulliō (“to bubble; to boil”) (from bulla (“bubble; bubble-shaped object”), ultimately from Proto-Indo-European *bʰew- (“to blow; to inflate”))) + -ēns.


## Definition
### Noun
1. A boiling or bubbling up; an ebullition. 
2. (figuratively) The quality of enthusiastic or lively expression of feelings and thoughts. 

## Synonyms
[[enthusiasm]] | [[exuberance]]