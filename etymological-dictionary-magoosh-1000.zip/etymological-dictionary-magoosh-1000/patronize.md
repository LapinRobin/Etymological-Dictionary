# patronize

## Etymology
- From patron +‎ -ize (verb ending); or from Old French patroniser, from Medieval Latin patronisāre (“to lead a galley as patron”).


## Definition
### Verb
1. (transitive) To act as a patron of; to defend, protect, or support. 
2. (transitive) To make oneself a customer of a business, especially a regular customer. 
3. (transitive) To assume a tone of unjustified superiority toward; to talk down to, to treat condescendingly. 
4. (transitive, obsolete) To blame, to reproach. 

## Synonyms
[[support]] | [[shop]] | [[patronage]] | [[sponsor]] | [[condescend]] | [[frequent]]