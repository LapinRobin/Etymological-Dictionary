# placid

## Etymology
- From French placide, from Latin placidus (“peaceful, calm, placid”), from placeō (“please, satisfy”).


## Definition
### Adjective
1. calm and quiet; peaceful; tranquil 

## Synonyms
[[still]] | [[quiet]] | [[calm]] | [[tranquil]] | [[easygoing]]