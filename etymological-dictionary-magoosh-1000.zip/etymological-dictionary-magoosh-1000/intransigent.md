# intransigent

## Etymology
- Borrowed from French intransigeant, from Spanish intransigente, from Latin in- (“un-, not”) + trānsigēns, present participle of trānsigō (“to come to an understanding”), from trāns (“across”) +‎ agō (“to do”).


## Definition
### Adjective
1. Unwilling to compromise or moderate a position; unreasonable 

### Noun
1. A person who is intransigent. 

## Synonyms
[[adamant]] | [[inexorable]] | [[adamantine]] | [[inflexible]]