# effusive

## Etymology
- From the stem of Latin effundēre  +‎ -ive, from ex- (“out of”) +‎ fundō (“pour”), 1660s.


## Definition
### Adjective
1. Gushy; unrestrained, extravagant or excessive (in emotional expression). 
2. (archaic) Pouring, spilling out freely; overflowing. 
3. (geology, of igneous rock) Extrusive; having solidified after being poured out as molten lava. 

## Synonyms
[[lively]] | [[emotional]] | [[demonstrative]]