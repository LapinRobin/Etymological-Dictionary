# deter

## Etymology
- Borrowed from Latin dēterreō (“deter, discourage”), from de (“from”) + terreō (“I frighten”).


## Definition
### Verb
1. (transitive) To prevent something from happening. 
2. (transitive) To persuade someone not to do something; to discourage. 
3. (transitive) To distract someone from something. 

### Noun
1. A surname from German. 

## Synonyms
[[dissuade]] | [[discourage]]