# cadaverous

## Etymology
- From Latin cadāverōsus; compare Middle English cadaverous (“gangrenous, mortified”).


## Definition
### Adjective
1. Corpselike; hinting of death; imitating a cadaver. 

## Synonyms
[[lean]] | [[thin]] | [[haggard]] | [[emaciated]] | [[gaunt]] | [[bony]]