# uncanny

## Etymology
- From un- +‎ canny; thus “beyond one's ken,” or outside one's familiar knowledge or perceptions. Compare Middle English unkanne (“unknown”). In the noun sense a translation of Sigmund Freud's usage of German unheimlich (Das Unheimliche, 1919).


## Definition
### Adjective
1. Strange, and mysteriously unsettling (as if supernatural); weird. 
2. (UK dialectal) Careless. 

### Noun
1. (psychology, psychoanalysis, Freud) Something that is simultaneously familiar and strange, typically leading to feelings of discomfort. 

## Synonyms
[[weird]] | [[supernatural]] | [[eldritch]]