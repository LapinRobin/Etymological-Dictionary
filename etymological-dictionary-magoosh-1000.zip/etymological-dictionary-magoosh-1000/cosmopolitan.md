# cosmopolitan

## Etymology
- From cosmopolite +‎ -an. Compare metropolitan and megalopolitan.


## Definition
### Adjective
1. Inclusive; affecting the whole world. 
2. (of a place or institution) Composed of people from all over the world. 
3. (of a person) At ease in any part of the world; familiar with many cultures. 
4. (biology, ecology) Growing or living in many parts of the world; widely distributed. 

### Noun
1. A cosmopolitan person; a cosmopolite. 
2. A cocktail containing vodka, triple sec, lime juice and cranberry juice. 
3. The butterfly Vanessa cardui. 

## Synonyms
[[comprehensive]] | [[general]] | [[sophisticated]] | [[universal]] | [[ecumenical]] | [[urbane]] | [[worldwide]]