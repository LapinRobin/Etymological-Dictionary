# pedantic

## Etymology
- From pedant +‎ -ic.


## Definition
### Adjective
1. Being overly concerned with formal rules and trivial points of learning, like a pedant. 
2. Being finicky or fastidious, especially with language. 
3. Being showy of one’s knowledge, often in a boring manner. 

## Synonyms
[[academic]] | [[scholarly]]