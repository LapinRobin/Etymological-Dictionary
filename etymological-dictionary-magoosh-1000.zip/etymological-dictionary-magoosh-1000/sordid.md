# sordid

## Etymology
- From Middle English sordide, from Latin sordidus.


## Definition
### Adjective
1. Distasteful, ignoble, vile, or contemptible. 
2. Dirty or squalid. 
3. Morally degrading. 
4. Grasping; stingy; avaricious. 
5. Of a dull colour. 

## Synonyms
[[corrupt]] | [[dirty]] | [[sleazy]] | [[seedy]] | [[squalid]]