# illicit

## Etymology
- Borrowed from French illicite, from Latin illicitus, from in- (“not”) + licitus (“allowed, permitted”), from licet (“it is allowed”).


## Definition
### Adjective
1. (law) Not approved by law, but not invalid. 
2. Breaking social norms. 
3. Unlawful. 

### Noun
1. A banned or unlawful item. 

## Synonyms
[[outlaw]] | [[illegal]] | [[extracurricular]] | [[illegitimate]]