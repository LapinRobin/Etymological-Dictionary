# ineluctable

## Etymology
- From Middle French inéluctable, from Latin inēlūctābilis, from in- + ēlūctor (“struggle out”) + -bilis.


## Definition
### Adjective
1. Impossible to avoid or escape; inescapable, irresistible. 

## Synonyms
[[inevitable]]