# derelict

## Etymology
- Latin derelictus, perfect passive participle of dērelinquō (“to forsake, abandon”) from dē- + relinquō (“to abandon, relinquish, leave (behind)”), from rē- + linquō (“to leave, quit, forsake, depart from”).


## Definition
### Adjective
1. Abandoned, forsaken; given up by the natural owner or guardian; (of a ship) abandoned at sea, dilapidated, neglected; (of a spacecraft) abandoned in outer space. 
2. Negligent in performing a duty. 
3. Lost; adrift; hence, wanting; careless; neglectful; unfaithful. 

### Noun
1. Property abandoned by its former owner, especially a ship abandoned at sea. 
2. (dated) An abandoned or forsaken person; an outcast. 
3. A homeless and/or jobless person; a person who is (perceived as) negligent in their personal affairs and hygiene. (This sense is a modern development of the preceding sense.) 

## Synonyms
[[remiss]] | [[delinquent]] | [[negligent]] | [[forsaken]]