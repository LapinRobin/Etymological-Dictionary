# portentous

## Etymology
- Borrowed from Latin portentōsus, from portentus (“predicted”) +‎ -ōsus; equivalent to portent +‎ -ous.


## Definition
### Adjective
1. Of momentous or ominous significance. 
2. Ominously prophetic. 
3. Puffed up with vanity. 

## Synonyms
[[pretentious]] | [[important]] | [[significant]] | [[pompous]] | [[prodigious]] | [[foreboding]] | [[prophetic]]