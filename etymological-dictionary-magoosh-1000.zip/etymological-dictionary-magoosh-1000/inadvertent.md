# inadvertent

## Etymology
- Back-formation from inadvertence and inadvertency.


## Definition
### Adjective
1. Not intentional; not on purpose; not conscious. 
2. (obsolete) Inattentive. 

## Synonyms
[[accidental]]