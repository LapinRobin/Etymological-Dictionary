# exonerate

## Etymology
- From Middle English exoneraten (attested in past participle exonerated), from Latin exonerāt-, the participle stem of exonerāre, from exonerō (“to discharge, unload; to exonerate”), from ex- (prefix denoting privation) + onerō (“to burden, lade; to load”) (from onus (“burden, load”), from Proto-Indo-European *h₃énh₂os (“burden, load”), from *h₃enh₂- (“to charge, onerate”)). The English word is cognate with French exonérer.


## Definition
### Verb
1. (transitive, archaic) To relieve (someone or something) of a load; to unburden (a load). 
2. (obsolete, reflexive) Of a body of water: to discharge or empty (itself). 
3. (transitive) To free (someone) from an obligation, responsibility or task. 
4. (transitive) To free (someone) from accusation or blame. 

### Adjective
1. (archaic) Freed from an obligation; freed from accusation or blame; acquitted, exonerated. 

## Synonyms
[[clear]] | [[discharge]] | [[acquit]] | [[exculpate]]