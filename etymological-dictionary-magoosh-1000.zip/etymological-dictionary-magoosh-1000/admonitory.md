# admonitory

## Etymology
- From Latin admonitōrium (“admonition, reminder”).


## Definition
### Adjective
1. Of or pertaining to an admonition; serving to reprove, warn or advise. 

## Synonyms
[[exemplary]] | [[warning]] | [[cautionary]]