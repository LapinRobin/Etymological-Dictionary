# verisimilitude

## Etymology
- From Middle French vérisimilitude, from Latin vērīsimilitūdō (“likeness to truth”), more correctly written separately as vērī similitūdō; from vērī, genitive singular of vērus (“true, real”), + similitūdō (“likeness, resemblance”).


## Definition
### Noun
1. The property of seeming true, of resembling reality; resemblance to reality, realism. 
2. A statement which merely appears to be true. 
3. (in composing a fiction): Faithfulness to its own rules; internal cohesion. 

## Synonyms
