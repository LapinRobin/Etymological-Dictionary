# vicissitude

## Etymology
- From Middle French vicissitude, from Latin vicissitūdō (“change”), from vicissim (“on the other hand, in turn”), from vicis (“change, vicissitude”), whence Spanish vez and French fois (“time (as in "next time"), occurrence”).


## Definition
### Noun
1. Regular change or succession from one thing to another, or one part of a cycle to the next; alternation; mutual succession; interchange. 
2. (often in the plural) A change, especially in one's life or fortunes. 

## Synonyms
