# magisterial

## Etymology
- From Late Latin magisterialis, from Latin magisterium.


## Definition
### Adjective
1. Befitting the status or skill of a magister or master; authoritative, masterly. 
2. Of or pertaining to a master, magistrate, the magisterium, or one in authority. 
3. Pertaining to, produced by, or of the nature of, magistery. 

## Synonyms
[[peremptory]] | [[distinguished]] | [[autocratic]] | [[bossy]] | [[dignified]] | [[imposing]]