# complaisant

## Etymology
- From French complaisant (“willing to please”), from complaire, from Latin complacēre, present active infinitive of complaceō (“please well”), from com- (“with”) + placeō (“please”).


## Definition
### Adjective
1. Compliant. 
2. Willing to do what pleases others; obliging. 
3. (archaic) Polite; showing respect. 

## Synonyms
[[accommodating]]