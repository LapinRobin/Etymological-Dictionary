# sedulous

## Etymology
- From Latin sēdulus (“diligent, industrious, sedulous; solicitous; unremitting; zealous”) + English -ous. Sēdulus is probably derived from sēdulō (“diligently; carefully; purposely; zealously”) (possibly from sē- (prefix meaning ‘without’) + dolō (singular of dolus (“deceit, deception; evil intent, malice”), ultimately from Proto-Indo-European *del- (“to count, reckon”))) + -us (suffix forming adjectives).


## Definition
### Adjective
1. Of a person: diligent in application or pursuit; constant and persevering in business or in endeavours to effect a goal; steadily industrious. 
2. Of an activity: carried out with diligence. 

## Synonyms
[[diligent]] | [[assiduous]]