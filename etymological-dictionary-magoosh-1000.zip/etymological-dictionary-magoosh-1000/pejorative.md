# pejorative

## Etymology
- French 1882 péjorative (“depreciative, disparaging”), from Late Latin pēiōrātus, past participle of pēiōrāre (“make worse”), from Latin pēior (“worse”). Compare English 1644 pejorate (“to worsen”), from the same etymology.


## Definition
### Adjective
1. Disparaging, belittling or derogatory. 

### Noun
1. A disparaging, belittling, or derogatory word or expression. 

## Synonyms
