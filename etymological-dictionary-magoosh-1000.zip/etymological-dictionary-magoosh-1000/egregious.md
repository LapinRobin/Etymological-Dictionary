# egregious

## Etymology
- From Latin ēgregius, from e- (“out of”), + grex (“flock”), + English adjective suffix -ous, from Latin suffix -osus (“full of”); reflecting the positive connotations of "standing out from the flock".


## Definition
### Adjective
1. Conspicuous, exceptional, outstanding; usually in a negative sense. 
2. Outrageously bad; shocking. 

## Synonyms
[[gross]] | [[rank]] | [[conspicuous]] | [[obvious]] | [[flagrant]] | [[glaring]]