# cataclysm

## Etymology
- From French cataclysme, from Latin cataclysmus, from Ancient Greek κατακλυσμός (kataklusmós, “deluge, flood”), from κατακλύζω (kataklúzō, “to dash over, flood, deluge, inundate”), from κατά (katá, “downwards, towards”) + κλύζω (klúzō, “to wash off, to wash away, to dash over”).


## Definition
### Noun
1. A sudden, violent event. 
2. (geology) A sudden and violent change in the earth's crust. 
3. A great flood. 

## Synonyms
[[disaster]] | [[calamity]] | [[catastrophe]] | [[tragedy]]