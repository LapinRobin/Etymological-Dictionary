# philistine

## Etymology
- The noun is derived from Philistine, influenced by philister, Philister (“(historical) in German universities: person not associated with the university; person who lacks appreciation of or is antagonistic towards art or culture”), from German Philister (“person from ancient Philistia; (figurative, dated) person not associated with a university; (figurative) person who lacks appreciation of or is antagonistic towards art or culture”), from Late Latin Philistaeus, Philisteus (compare Philistinus and see further at Philistine) + German -er (suffix forming nouns indicating an inhabitant of a place, or a person originating from a place). The figurative senses of the German word are often said to have derived from a 1693 sermon by the ecclesiastical superintendent Georg Heinrich Götze (1667–1728) on the passage “Philister über dir, Simson!” (“The Philistines are upon you, Samson!”; Judges 16:9, 12, 14, and 20) at the funeral of a student from the University of Jena in Jena, Thuringia, Germany, who had died as the result of a town and gown dispute (that is, one between the townspeople and university students), but the Oxford English Dictionary notes that the word was already used in Jena in these senses in 1687.


## Definition
### Noun
1. (historical) A non-Semitic person from ancient Philistia, a region in the southwest Levant in the Middle East. 
2. (figuratively, frequently humorous, usually in the plural) An opponent (of the speaker, writer, etc); an enemy, a foe. 
3. (university slang, historical) In German universities: a person not associated with the university; a non-academic or non-student; a townsperson. 
4. (derogatory) A person who is ignorant or uneducated; specifically, a person who lacks appreciation of or is antagonistic towards art or culture, and who has pedestrian tastes. 
5. Alternative letter-case form of philistine (“a person who is ignorant or uneducated; specifically, a person who lacks appreciation of or is antagonistic towards art or culture, and who has pedestrian tastes”)  

### Adjective
1. (historical) Originating from ancient Philistia; of or pertaining to the ancient Philistines. 
2. (derogatory) Ignorant or uneducated; specifically, lacking appreciation for or antagonistic towards art or culture, and having pedestrian tastes. 
3. Alternative letter-case form of philistine (“ignorant or uneducated; specifically, lacking appreciation for or antagonistic towards art or culture, and having pedestrian tastes”).  

## Synonyms
