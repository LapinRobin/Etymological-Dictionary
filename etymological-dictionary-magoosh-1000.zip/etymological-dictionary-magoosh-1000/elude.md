# elude

## Etymology
- From Latin ēlūdō (“evade, elude”), from ē (“out of”), short form of ex, + lūdō (“play; trick”).


## Definition
### Verb
1. (transitive) To evade or escape from (someone or something), especially by using cunning or skill. 
2. (transitive) To shake off (a pursuer); to give someone the slip. 
3. (transitive) To escape being understandable to; to be incomprehensible to. 
4. (transitive) To escape someone's memory, to slip someone's mind. 

## Synonyms
[[duck]] | [[hedge]] | [[escape]] | [[circumvent]] | [[dodge]] | [[skirt]] | [[fudge]] | [[evade]] | [[parry]] | [[bilk]] | [[put off]] | [[sidestep]]