# splenetic

## Etymology
- The adjective form of spleen, borrowed from Late Latin spleneticus, from Latin splen. Anger was traditionally believed to originate from the fluids of the spleen.


## Definition
### Adjective
1. Bad-tempered, irritable, peevish, spiteful, habitually angry. 
2. (biology) Related to the spleen. 

### Noun
1. (archaic) A person affected with spleen. 

## Synonyms
[[prickly]]