# schadenfreude

## Etymology
- Unadapted borrowing from German Schadenfreude (“joy in the misfortune of others”), from Schaden (“damage, misfortune”) + Freude (“joy”). The word gained popularity in English in the late 20th c. and likely entered mainstream usage through an episode of The Simpsons (more in citations).


## Definition
### Noun
1. Malicious enjoyment derived from observing someone else's misfortune. 

## Synonyms
[[gloat]] | [[glee]]