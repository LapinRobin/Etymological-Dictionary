# equivocal

## Etymology
- From Late Latin aequivocus +‎ -al, from aequus +‎ vocō.


## Definition
### Adjective
1. Having two or more equally applicable meanings; capable of double or multiple interpretation. 
2. Capable of being ascribed to different motives, or of signifying opposite feelings, purposes, or characters; deserving to be suspected. 
3. Uncertain, as an indication or sign. 

### Noun
1. (philosophy) A word or expression capable of different meanings; an ambiguous term. 

## Synonyms
[[ambiguous]] | [[ambivalent]] | [[double]] | [[evasive]] | [[indeterminate]] | [[questionable]]