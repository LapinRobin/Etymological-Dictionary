# impeccable

## Etymology
- From Middle French impeccable, from Latin impeccabilis (“not liable to sin”), from im- (“not”) + peccare (“to err, to sin”). 


## Definition
### Adjective
1. Perfect, without faults, flaws or errors 
2. Incapable of wrongdoing or sin; immaculate 

## Synonyms
[[perfect]] | [[virtuous]] | [[immaculate]]