# sybarite

## Etymology
- The noun is a learned borrowing from Latin Sybarīta + English -ite (suffix forming demonyms). Sybarīta is derived from from Ancient Greek Σῠβᾰρῑ́της (Subarī́tēs, “(noun) inhabitant of Sybaris; (adjective) decadent; self-indulgent”), from Σῠ́βᾰρῐς (Súbaris, “Sybaris”) + -ῑ́της (-ī́tēs, suffix forming demonyms)). Sybaris, a city of Magna Graecia (the coastal parts of Sicily and southern Italy once colonized by Greek settlers), was known for its wealth and the excesses and hedonism of its inhabitants.


## Definition
### Noun
1. A person devoted to luxury and pleasure; a hedonist. 
2. A native or inhabitant of Sybaris. 

### Adjective
1. Synonym of sybaritic (“of or having the qualities of a sybarite; dedicated to excessive comfort and enjoyment; decadent, hedonistic, self-indulgent”) 

## Synonyms
