# rapprochement

## Etymology
- Borrowed from French rapprochement (“act or process of getting closer together; link (between two things)”).


## Definition
### Noun
1. The reestablishment of cordial relations, particularly between two countries; a reconciliation. 

## Synonyms
[[reconciliation]]