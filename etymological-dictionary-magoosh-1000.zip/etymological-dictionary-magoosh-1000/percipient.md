# percipient

## Etymology
- From Latin percipiēns, present participle of percipiō (“to perceive”).


## Definition
### Adjective
1. Having the ability to perceive, especially to perceive quickly. 
2. (psychology, education, dated) Perceiving events only in the moment, without reflection, as a very young child. 

### Noun
1. (philosophy, psychology) One who perceives something. 
2. (parapsychology) One who has perceived a paranormal event. 

## Synonyms
[[clear]] | [[discerning]]