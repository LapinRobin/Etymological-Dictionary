# jejune

## Etymology
- Borrowed from Latin iēiūnus (“fasting”).


## Definition
### Adjective
1. (dated, now rare) Not nutritious. 
2. (by extension, of a speech or an argument) Lacking matter; empty; devoid of substance. 
3. Naive; simplistic. 

## Synonyms
[[insipid]] | [[puerile]] | [[adolescent]] | [[juvenile]] | [[immature]]