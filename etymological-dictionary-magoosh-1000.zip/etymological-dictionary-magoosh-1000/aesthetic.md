# aesthetic

## Etymology
- From German Ästhetik or French esthétique, both from New Latin aesthēticus, itself borrowed from Ancient Greek αἰσθητικός (aisthētikós, “of sense perception”), from αἰσθάνομαι (aisthánomai, “I feel”); Analysable as aesthe(sis) +‎ -tic. 


## Definition
### Adjective
1. Concerned with beauty, artistic impact, or appearance. 
2. (nonstandard) Beautiful or appealing to one's sense of beauty and/or art. 

### Noun
1. The study of art or beauty. 
2. That which appeals to the senses. 
3. The artistic motifs defining a collection of things, especially works of art; more broadly, their vibe. 

## Synonyms
[[beautiful]] | [[cosmetic]] | [[esthetic]] | [[sensuous]] | [[artistic]]