# lachrymose

## Etymology
- Borrowed from Latin lacrimōsus, from lacrima (“tear”) + -osus (“-ful”), from Old Latin dacrima, from Proto-Indo-European *dakru-, cognate with English tear.


## Definition
### Adjective
1. Tearful, sorrowful, sad, pertaining to tears, weeping, causing tears or crying. 

## Synonyms
