# prevail

## Etymology
- From Middle English prevailen, from Old French prevaler, from Latin praevaleō (“be very able or more able, be superior, prevail”), from prae (“before”) + valeō (“be able or powerful”). Displaced native Old English rīcsian.


## Definition
### Verb
1. (intransitive) To be superior in strength, dominance, influence or frequency; to have or gain the advantage over others; to have the upper hand; to outnumber others. 
2. (intransitive) To be current, widespread or predominant; to have currency or prevalence. 
3. (intransitive) To succeed in persuading or inducing. 
4. (transitive, obsolete) To avail. 

## Synonyms
[[run]] | [[hold]] | [[rule]] | [[endure]] | [[obtain]] | [[reign]] | [[persist]] | [[triumph]] | [[dominate]] | [[predominate]]