# abjure

## Etymology
- From Middle English abjuren, from Latin abiūrō (“deny upon oath”) (possibly via Middle French abjurer), formed from ab (“from, away from”) + iūro (“swear or take an oath”), from iūs (“law, right, duty”).


## Definition
### Verb
1. (transitive) To renounce upon oath; to forswear; to disavow. 
2. (transitive, obsolete, historical) To cause one to renounce or recant. 
3. (transitive) To reject with solemnity; to abandon forever; to repudiate; to disclaim. 
4. (transitive) To abstain from; to avoid; to shun. 

## Synonyms
[[recant]] | [[retract]]