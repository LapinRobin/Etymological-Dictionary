# flummox

## Etymology
- Uncertain, probably risen out of a British dialect (OED finds candidate words in Herefordshire, Gloucestershire, southern Cheshire, and Sheffield). "The formation seems to be onomatopœic, expressive of the notion of throwing down roughly and untidily" .


## Definition
### Verb
1. (intransitive) To confuse; to fluster; to flabbergast. 
2. (intransitive, uncommon) To give in, to give up, to collapse. 

## Synonyms
[[beat]] | [[get]] | [[baffle]] | [[puzzle]] | [[gravel]] | [[perplex]] | [[amaze]] | [[bewilder]] | [[trounce]] | [[nonplus]] | [[stupefy]]