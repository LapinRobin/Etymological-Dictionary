# panacea

## Etymology
- From Latin panacēa, from Ancient Greek πανάκεια (panákeia), from πανακής (panakḗs, “all-healing”), from πᾶν (pân, “all”) (equivalent to English pan-) + ἄκος (ákos, “cure”).


## Definition
### Noun
1. A remedy believed to cure all disease and prolong life that was originally sought by alchemists; a cure-all. 
2. A solution to all problems. 
3. (obsolete) The plant allheal (Valeriana officinalis), believed to cure all ills. 
4. (Greek mythology) The goddess/personification of healing, remedies, cures and panaceas (medicines, salves, ointments and other curatives). She is a daughter of Asclepius and Epione. 

## Synonyms
[[nostrum]]