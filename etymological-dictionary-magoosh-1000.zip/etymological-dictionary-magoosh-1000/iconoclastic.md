# iconoclastic

## Etymology
- iconoclast +‎ -ic.


## Definition
### Adjective
1. Characterized by attack on established and accepted beliefs, customs, or institutions; of or pertaining to iconoclasm. 

## Synonyms
[[unorthodox]]