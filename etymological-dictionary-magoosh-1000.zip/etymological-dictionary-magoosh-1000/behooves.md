# behooves

## Definition
### Verb
1. (transitive, chiefly US) To befit, be appropriate or necessary to somebody. Alternative form of behove. 
2. (intransitive) To be fitting. 

## Synonyms
