# surreptitious

## Etymology
- Borrowed from Latin surrēptīcius (“furtive, clandestine”), from surrēpō (“to creep along”).


## Definition
### Adjective
1. Stealthy, furtive, well hidden, covert (especially movements). 

## Synonyms
[[secret]] | [[sneak]] | [[covert]] | [[clandestine]] | [[furtive]] | [[sneaky]] | [[underground]] | [[stealthy]] | [[lurking]] | [[concealed]]