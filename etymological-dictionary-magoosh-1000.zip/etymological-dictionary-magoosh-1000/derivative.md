# derivative

## Etymology
- From Middle French dérivatif, from Latin dērīvātus, perfect passive participle of dērīvō (“I derive”). Related with derive; By surface analysis, derive +‎ -ative.


## Definition
### Adjective
1. Obtained by derivation; not radical, original, or fundamental. 
2. Imitative of the work of someone else. 
3. (law, copyright law) Referring to a work, such as a translation or adaptation, based on another work that may be subject to copyright restrictions. 
4. (finance) Having a value that depends on an underlying asset of variable value. 
5. Lacking originality. 

### Noun
1. Something derived. 
2. (linguistics) A word that derives from another one. 
3. (finance) A financial instrument whose value depends on the valuation of an underlying asset; such as a warrant, an option etc. 
4. (chemistry) A chemical derived from another. 
5. (Of a function of a single variable f(x)) The derived function of f(x): the function giving the instantaneous rate of change of f; equivalently, the function giving the slope of the line tangent to the graph of f. Written f'(x) or (df)/(dx) in Leibnitz's notation, ̇f(x) in Newton's notation (the latter used particularly when the independent variable is time). 
6. The value of such a derived function for a given value of its independent variable: the rate of change of a function at a point in its domain. 
7. (Of more general classes of functions) Any of several related generalizations of the derivative: the directional derivative, partial derivative, Fréchet derivative, functional derivative, etc. 
8. (generally) The linear operator that maps functions to their derived functions, usually written D; the simplest differential operator. 

## Synonyms
[[differential]] | [[derived]]