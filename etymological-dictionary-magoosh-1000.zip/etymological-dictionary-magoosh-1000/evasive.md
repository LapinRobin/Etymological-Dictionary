# evasive

## Etymology
- From French évasif, from Latin ēvādō.


## Definition
### Adjective
1. Tending to avoid speaking openly or making revelations about oneself. 
2. Directed towards avoidance or escape; evasive action. 

## Synonyms
[[ambiguous]] | [[elusive]] | [[equivocal]] | [[artful]]