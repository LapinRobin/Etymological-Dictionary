# robust

## Etymology
- Learned borrowing from Latin rōbustus.


## Definition
### Adjective
1. Evincing strength and health; strong. 
2. Violent; rough; rude. 
3. Requiring strength or vigor. 
4. Sensible (of intellect etc.); straightforward, not given to or confused by uncertainty or subtlety. 
5. (systems engineering) Designed or evolved in such a way as to be resistant to total failure despite partial damage. 
6. (software engineering) Resistant or impervious to failure regardless of user input or unexpected conditions. 
7. (statistics) Not greatly influenced by errors in assumptions about the distribution of sample errors. 
8. (chiefly zoology, anthropology, paleontology) Of an individual or skeletal element: strongly built; muscular; not gracile. 

## Synonyms
[[iron]] | [[strong]] | [[rich]] | [[stalwart]] | [[stout]] | [[vigorous]] | [[sturdy]] | [[rugged]] | [[hardy]] | [[husky]] | [[burly]]