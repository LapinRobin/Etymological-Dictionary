# badger

## Etymology
- From Middle English bageard (“marked by a badge”), from bage (“badge”), referring to the animal's badge-like white blaze, equivalent to badge +‎ -ard. Displaced earlier brock, from Old English brocc.

- Unknown (Possibly from "bagger". "Baggier" is cited by the OED in 1467-8)


## Definition
### Noun
1. Any mammal of three subfamilies, which belong to the family Mustelidae: Melinae (Eurasian badgers), Mellivorinae (ratel or honey badger), and Taxideinae (American badger). 
2. A native or resident of the American state, Wisconsin. 
3. (obsolete) A brush made of badger hair. 
4. (in the plural, obsolete, cant) A crew of desperate villains who robbed near rivers, into which they threw the bodies of those they murdered. 
5. (obsolete) An itinerant licensed dealer in commodities used for food; a hawker; a huckster; -- formerly applied especially to one who bought grain in one place and sold it in another. 
6. A native or resident of the American state of Wisconsin. 
7. A village in Shropshire, England. 
8. A town in Newfoundland, Newfoundland and Labrador, Canada. 
9. A habitational surname from Old English. 
10. A child member of the St John Ambulance medical volunteering organisation. 

### Verb
1. To pester, to annoy persistently; press. 

## Synonyms
[[bug]] | [[tease]] | [[harass]] | [[pester]]