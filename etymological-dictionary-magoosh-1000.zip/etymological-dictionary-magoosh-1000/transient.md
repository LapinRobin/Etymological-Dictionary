# transient

## Etymology
- From Late Latin transiēnt- (for classical transeunt-), stem of transiēns, present participle of transire (“to go over, to pass”).


## Definition
### Adjective
1. Passing or disappearing with time; transitory. 
2. Remaining for only a brief time. 
3. (physics) Decaying with time, especially exponentially. 
4. (mathematics, stochastic processes, of a state) having a positive probability of being left and never being visited again. 
5. Occasional; isolated; one-off 
6. Passing through; passing from one person to another. 
7. (music) Intermediate. 
8. (philosophy) Operating beyond itself; having an external effect. 

### Noun
1. Something that is transient. 
2. (physics) A transient phenomenon, especially an electric current; a very brief surge. 
3. (acoustics) A relatively loud, non-repeating signal in an audio waveform that occurs very quickly, such as the attack of a snare drum. 
4. A person who passes through a place for a short time; a traveller; a migrant worker. 
5. A homeless person. 
6. (programming, historical) A module that generally remains in memory only for a short time. 
7. (Philippines) homestay 

## Synonyms
[[ephemeral]] | [[temporary]] | [[passing]] | [[transitory]]