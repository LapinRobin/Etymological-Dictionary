# tantamount

## Etymology
- From Anglo-Norman tant amount, from amunter, from tant (“as much”) amonter (“to amount to”).


## Definition
### Adjective
1. Equivalent in meaning or effect; amounting to the same thing in practical terms, even if being technically distinct. 

### Verb
1. (obsolete) To amount to as much; to be equivalent. 

### Noun
1. (obsolete) Something which has the same value or amount (as something else). (attributive use passing into adjective, below) 

## Synonyms
