# ostracize

## Etymology
- From Ancient Greek ὀστρακίζω (ostrakízō, “to banish from a city by ostracism”), from ὄστρᾰκον (óstrakon, “earthenware vessel; fragment of such a vessel, potsherd”) (from the fact that when voting was held to decide whether to banish people, their names were inscribed on potsherds) + -ῐ́ζω (-ízō, suffix forming verbs)). The English word is cognate with French ostraciser.


## Definition
### Verb
1. (transitive, Ancient Greece, historical) To ban a person from a city for five or ten years through the procedure of ostracism. 
2. (by extension) To exclude a person from a community or from society by not communicating with them or by refusing to acknowledge their presence; to refuse to associate with or talk to; to shun. 

## Synonyms
[[ban]] | [[shun]] | [[banish]] | [[blackball]]