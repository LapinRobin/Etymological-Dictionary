# exacerbate

## Etymology
- From Latin exacerbo (“to provoke”); ex (“out of; thoroughly”) + acerbo (“to embitter, harshen or worsen”).


## Definition
### Verb
1. (transitive) To make worse (a problem, bad situation, negative feeling, etc.); aggravate; exasperate. 

## Synonyms
[[aggravate]] | [[exasperate]]