# gregarious

## Etymology
- From Latin gregārius.


## Definition
### Adjective
1. (of a person) Describing one who enjoys being in crowds and socializing. 
2. (zoology) Of animals that travel in herds or packs. 
3. (botany) Growing in open clusters or colonies; not matted together. 
4. Pertaining to a flock or crowd. 

## Synonyms
[[social]]