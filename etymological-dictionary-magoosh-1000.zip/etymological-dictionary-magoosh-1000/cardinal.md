# cardinal

## Etymology
- From Middle French cardinal, from Latin cardinālis (“pertaining to a hinge, hence applied to that on which something turns or depends, important, principal, chief”), from cardō (“hinge”) + -ālis, adjectival suffix.


## Definition
### Adjective
1. Of fundamental importance; crucial, pivotal. 
2. (nautical) Of or relating to the cardinal directions (north, south, east and west). 
3. Describing a "natural" number used to indicate quantity (e.g., zero, one, two, three), as opposed to an ordinal number indicating relative position. 
4. Having a bright red color (from the color of a Catholic cardinal's cassock). 

### Noun
1. (Roman Catholicism) One of the officials appointed by the pope in the Roman Catholic Church, ranking only below the pope and the patriarchs, constituting the special college which elects the pope. (See Wikipedia article on Catholic cardinals.) 
2. Any of a genus of songbirds of the finch family, Cardinalis. 
3. Any of various related passerine birds of the family Cardinalidae (See Wikipedia article on cardinals) and other similar birds that were once considered to be related. 
4. (color) A deep red color, somewhat less vivid than scarlet, the traditional colour of a Catholic cardinal's cassock. (same as cardinal red) 
5. (now historical) A woman's short cloak with a hood, originally made of scarlet cloth. 
6. (obsolete) Mulled red wine. 
7. (baseball) A player on the St. Louis Cardinals team. 
8. (American football) A player on the Arizona Cardinals team. 
9. A player on a sports team at Stanford University. 
10. A student or player on a sports team at the University of Louisville. 
11. (mathematics) Short for cardinal number, a number indicating quantity, or the size of a set (e.g., 0, 1, 2, 3). (See Cardinal_number.)  
12. (grammar) Short for cardinal numeral, a word used to represent a cardinal number.  
13. Short for cardinal flower (Lobelia cardinalis), a flowering plant.  
14. Short for cardinal tetra (Paracheirodon axelrodi), a freshwater fish.  

## Synonyms
[[one]] | [[i]] | [[key]] | [[c]] | [[score]] | [[d]] | [[ii]] | [[important]] | [[m]] | [[fundamental]] | [[iii]] | [[five]] | [[l]] | [[k]] | [[1]] | [[2]] | [[eight]] | [[primal]] | [[four]] | [[nine]] | [[seven]] | [[iv]] | [[dozen]] | [[central]] | [[hundred]] | [[ninety]] | [[forty]] | [[million]] | [[billion]] | [[eleven]] | [[carmine]] | [[11]] | [[ix]] | [[ane]] | [[3]] | [[100]] | [[fifty]]