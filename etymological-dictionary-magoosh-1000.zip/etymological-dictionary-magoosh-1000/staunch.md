# staunch

## Etymology
- From Middle English staunch, staunche (“(adjective) in good condition or repair; solidly made, firm; watertight; of a person or wound: not bleeding; certain; intact; (adverb) firmly, soundly”) , from Anglo-Norman estaunche, Old French estanche (“firm; watertight”) (modern French étanche (“airtight; watertight”)), a variant of estanc (“a pond”), from estanchier (“to stop the flow of a liquid (blood, water, etc.); to make (something) watertight; to quench (thirst)”) (modern French étancher), possibly from one of the following:

- From Middle English staunchen, staunche (“to stop the flow of blood, diarrhoea, or other bodily fluids; to alleviate, ease; to appease, assuage, satisfy; to cure; to overcome; to put an end to; to repress, suppress; of a river or stream: to stop flowing; of waters, wind, or weather: to become calm, subside; to extinguish or put out (a fire)”) , from Anglo-Norman estauncher, estaunchier, estanger, Old French estancher, estanchier (verb) ; see further at etymology 1 and at stanch.

- Either:

- See stanch (etymology 4).


## Definition
### Adjective
1. Loyal, trustworthy, reliable. 
2. Dependable, persistent. 

### Verb
1. (transitive) To stop the flow of (blood). 
2. (transitive) To stop, check, or deter an action. 

## Synonyms
[[stem]] | [[constant]] | [[halt]] | [[steadfast]] | [[stanch]]