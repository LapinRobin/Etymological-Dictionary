# callow

## Etymology
- From Middle English calwe (“bald”), from Old English calu (“bare, bald, callow”), from Proto-West Germanic *kalu, from Proto-Germanic *kalwaz (“bare, naked, bald”), from Proto-Indo-European *gel(H)wo- (“bare, naked, bald”). Cognate with West Frisian keal (“bald”), Dutch kaal (“bald”), German Low German kahl (“bald”), German kahl (“bald”), Swedish kal and kalka (“bald”), Russian го́лый (gólyj, “bare, naked, nude”). 


## Definition
### Adjective
1. Bald, hairless, bare. 
2. Unfledged (of a young bird), featherless. 
3. (by extension, life-cycle developmental stage) Newly emerged or hatched, juvenile. 
4. (by extension) Immature, lacking in life experience. 
5. Lacking color or firmness (of some kinds of insects or other arthropods, such as spiders, just after ecdysis); teneral. 
6. Shallow or weak-willed. 
7. (of a brick) Unburnt. 
8. Of land: low-lying and liable to be submerged. 

### Noun
1. A callow young bird. 
2. A callow or teneral phase of an insect or other arthropod, typically shortly after ecdysis, while the skin still is hardening, the colours have not yet become stable, and as a rule, before the animal is able to move effectively. 
3. An alluvial flat. 
4. A surname. 

## Synonyms
[[naive]] | [[immature]]