# becoming

## Definition
### Noun
1. (chiefly philosophy) The act or process by which something becomes. 

### Adjective
1. pleasingly suitable; fit; congruous; beautiful 
2. decent, respectable 

## Synonyms
[[decent]] | [[proper]] | [[comely]] | [[decorous]]