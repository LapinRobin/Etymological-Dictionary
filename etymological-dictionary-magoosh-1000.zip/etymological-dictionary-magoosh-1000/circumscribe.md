# circumscribe

## Etymology
- From Latin circumscrībō, from circum (“around”) + scrībō (“write”). Surface analysis: circum- +‎ scribe.


## Definition
### Verb
1. To draw a line around; to encircle. 
2. To limit narrowly; to restrict. 
3. (geometry) To draw the smallest circle or higher-dimensional sphere that has (a polyhedron, polygon, etc.) in its interior. 

## Synonyms
[[limit]] | [[confine]]