# peevish

## Etymology
- From Middle English pevische, pevisse, pevysse, peivesshe, also peyuesshe, peeuish, of obscure origin. Perhaps from Middle English pew, pue (“a plaintive cry, the cry of a bird”), equivalent to pue +‎ -ish. Cognate with Scots pevis, pevess, pevych, pevach (“peevish”), Scots pew, peu (“to cry in a plaintive manner”). See pue.


## Definition
### Adjective
1. Characterized by or exhibiting petty bad temper, bad-tempered, moody, cross. 
2. Constantly complaining, whining; childishly fretful. 
3. Easily annoyed, especially by things that are not important; irritable, querulous. 
4. (obsolete, Northern England) Clever, expert. 
5. (obsolete, Canada, Northern England) Sharp, piercing, bitter (of the wind); windy, blustery (of the weather). 
6. (chiefly obsolete) Perverse, refractory; headstrong, obstinate; capricious, skittish; (also) coy. 
7. (obsolete) Silly, senseless, foolish. 
8. (obsolete) Beside oneself; out of one's senses; mad. 
9. (obsolete) Spiteful, malignant, mischievous, harmful. 
10. (obsolete) Hateful, distasteful, horrid. 

### Adverb
1. (obsolete) Peevishly. 

## Synonyms
[[petulant]] | [[fractious]] | [[cranky]] | [[irritable]] | [[testy]] | [[peckish]]