# complementary

## Etymology
- complement +‎ -ary


## Definition
### Adjective
1. Acting as a complement; making up a whole with something else. 
2. (genetics) Of the specific pairings of the bases in DNA and RNA. 
3. (physics) Pertaining to pairs of properties in quantum mechanics that are inversely related to each other, such as speed and position, or energy and time. (See also Heisenberg uncertainty principle.) 

### Noun
1. A complementary colour. 
2. (obsolete) One skilled in compliments. 
3. An angle which adds with another to equal 90 degrees. 

## Synonyms
[[reciprocal]]