# malingerer

## Etymology
- malinger +‎ -er


## Definition
### Noun
1. A person who malingers. 

## Synonyms
