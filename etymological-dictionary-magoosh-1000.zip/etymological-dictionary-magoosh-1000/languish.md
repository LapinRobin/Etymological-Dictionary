# languish

## Etymology
- From Middle English languysshen, from the present participle stem of Anglo-Norman and Middle French languir, from Late Latin languīre, alteration of Latin languēre (“to be faint, unwell”).


## Definition
### Verb
1. (intransitive) To lose strength and become weak; to be in a state of weakness or sickness. 
2. (intransitive) To pine away in longing for something; to have low spirits, especially from lovesickness. 
3. (intransitive) To live in miserable or disheartening conditions. 
4. (intransitive) To be neglected; to make little progress, be unsuccessful. 
5. (transitive, obsolete) To make weak; to weaken, devastate. 
6. (intransitive, now rare) To affect a languid air, especially disingenuously. 

## Synonyms
[[pine]] | [[long]] | [[waste]] | [[ache]] | [[fade]] | [[yearn]] | [[yen]]