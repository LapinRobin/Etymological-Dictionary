# indifference

## Etymology
- From Middle French indifférence, from Late Latin indifferentia.


## Definition
### Noun
1. The state of being indifferent. 
2. Unbiased impartiality. 
3. Unemotional apathy. 
4. A lack of enthusiasm. 
5. Unconcerned nonchalance. 
6. (philosophy) Self-identity defined through the negation of difference, non-difference. 

## Synonyms
[[apathy]] | [[phlegm]]