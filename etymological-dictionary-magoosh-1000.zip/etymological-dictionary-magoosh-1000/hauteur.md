# hauteur

## Etymology
- From French hauteur.


## Definition
### Noun
1. Haughtiness or arrogance; loftiness. 

## Synonyms
