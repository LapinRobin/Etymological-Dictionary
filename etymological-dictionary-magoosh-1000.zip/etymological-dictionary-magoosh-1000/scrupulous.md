# scrupulous

## Etymology
- From Middle French scrupuleux, from Latin scrupulosus.


## Definition
### Adjective
1. Exactly and carefully conducted. 
2. Having scruples or compunctions. 
3. Precise; exact or strict. 
4. Wrongly feeling guilt or anxiety about one’s morality; suffering from scrupulosity. 

## Synonyms
[[conscientious]] | [[careful]] | [[religious]] | [[painstaking]]