# obsequious

## Etymology
- From Middle English obsequyous, from Latin obsequiōsus (“complaisant, obsequious”) , from obsequium (“compliance”), from obsequor (“comply with, yield to”), from ob (“in the direction of, towards”) + sequor (“follow”) (cf. sequel).


## Definition
### Adjective
1. Excessively eager and attentive to please or to obey instructions; fawning, subservient, servile. 
2. (archaic) Obedient; compliant with someone else's orders or wishes. 
3. (obsolete) Of or pertaining to obsequies, funereal. 

## Synonyms
[[servile]] | [[sycophantic]] | [[fawning]]