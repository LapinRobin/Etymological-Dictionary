# pristine

## Etymology
- From Middle French pristin, borrowed from Latin prīstinus.

- From Ancient Greek πρίστης (prístēs, “a saw, one that saws”).


## Definition
### Adjective
1. Unspoiled; still with its original purity; uncorrupted or unsullied. 
2. Primitive, pertaining to the earliest state of something. 
3. Perfect. 
4. Relating to sawfishes of the family Pristidae. 

## Synonyms
[[clean]] | [[pure]]