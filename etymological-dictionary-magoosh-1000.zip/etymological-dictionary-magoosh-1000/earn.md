# earn

## Etymology
- From Middle English ernen, from Old English earnian, from Proto-West Germanic *aʀanōn, from Proto-Germanic *azanōną. This verb is denominal from the noun *azaniz (“harvest”). 

- Probably either:

- A variant of yearn.

- earn (plural earns)


## Definition
### Verb
1. (transitive) To gain (success, reward, recognition) through applied effort or work. 
2. (transitive) To receive payment for work. 
3. (intransitive) To receive payment for work. 
4. (transitive) To cause (someone) to receive payment or reward. 
5. (transitive) To achieve by being worthy of. 
6. (transitive, archaic) To curdle (milk), especially in the cheesemaking process. 
7. (intransitive, obsolete) Of milk: to curdle, espcially in the cheesemaking process. 
8. (transitive, obsolete) To strongly long or yearn (for something or to do something). 
9. (intransitive, obsolete) To grieve. 

### Noun
1. A river in Scotland which flows into the tidal River Tay. 
2. Alternative form of erne  
3. Initialism of European Academic and Research Network: a former computer network connecting universities and research institutions across Europe. 

## Synonyms
[[clear]] | [[make]] | [[realize]] | [[garner]] | [[gain]] | [[take in]]