# sentimental

## Etymology
- sentiment +‎ -al


## Definition
### Adjective
1. Characterized by sentiment, sentimentality or excess emotion. 
2. Derived from emotion rather than reason; of or caused by sentiment. 
3. Romantic. 

## Synonyms
[[tender]] | [[maudlin]] | [[mawkish]] | [[emotional]] | [[mushy]]