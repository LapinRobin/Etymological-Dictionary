# semblance

## Etymology
- From Middle English semblaunce, from Old French semblance, from semblant, present participle of sembler.


## Definition
### Noun
1. likeness, similarity; the quality of being similar. 
2. the way something looks; appearance; form 

## Synonyms
[[color]] | [[illusion]] | [[colour]] | [[likeness]]