# blatant

## Etymology
- Coined by  Edmund Spenser in 1596 (“blatant beast”). Probably a variation of *blatand (Scots blaitand (“bleating”)), present participle of blate, a variation of bleat, equivalent to blate +‎ -and. See bleat.


## Definition
### Adjective
1. Obvious, on show; unashamed; loudly obtrusive or offensive. 
2. (archaic) Bellowing; disagreeably clamorous; sounding loudly and harshly. 

## Synonyms
[[open]] | [[conspicuous]] | [[strident]] | [[vociferous]] | [[blazing]] | [[noisy]] | [[clamant]]