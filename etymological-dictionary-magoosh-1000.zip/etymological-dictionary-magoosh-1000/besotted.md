# besotted

## Etymology
- besot + ed


## Definition
### Adjective
1. Infatuated. 
2. Intellectually or morally blinded. 
3. (archaic) Intoxicated, drunk. 

## Synonyms
[[blind]] | [[wet]] | [[tight]] | [[stiff]] | [[drunk]] | [[loaded]] | [[potty]] | [[tipsy]] | [[inebriated]]