# malapropism

## Etymology
- From the name of Mrs. Malaprop, a character in the play The Rivals (1775) by Richard Brinsley Sheridan + -ism. As dramatic characters in English comic plays of this time often had allusive names, it is likely that Sheridan fashioned the name from malapropos (“inappropriate; inappropriately”), from French mal à propos. Mrs. Malaprop is perhaps the best-known example of a familiar comedic character archetype who unintentionally substitutes inappropriate but like-sounding words that take on a ludicrous meaning when used incorrectly.


## Definition
### Noun
1. (uncountable) The blundering use of an absurdly inappropriate word or expression in place of a similar-sounding one. 
2. (countable) An instance of this; malaprop. 

## Synonyms
