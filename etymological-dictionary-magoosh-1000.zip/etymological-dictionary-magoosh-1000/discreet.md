# discreet

## Etymology
- From Middle English discrete, from Old French discret, from Latin discrētus, from past participle of discernere. Doublet of discrete.


## Definition
### Adjective
1. Respectful of privacy or secrecy; exercising caution in order to avoid causing embarrassment; quiet; diplomatic. 
2. Not drawing attention, anger or challenge; inconspicuous. 

## Synonyms
[[prudent]] | [[modest]] | [[circumspect]] | [[discerning]] | [[tactful]]