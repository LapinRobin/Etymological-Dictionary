# editorial

## Etymology
- editor +‎ -ial


## Definition
### Adjective
1. Of or relating to an editor, editing or an editorial. 
2. (fashion) Appropriate for high fashion magazines. 

### Noun
1. An article in a publication giving the opinion of its editors on a given topic or current event. 
2. A similar commentary on radio or television. 

## Synonyms
[[column]]