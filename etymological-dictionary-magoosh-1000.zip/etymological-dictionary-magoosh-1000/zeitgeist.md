# zeitgeist

## Etymology
- Unadapted borrowing from German Zeitgeist (literally “time-spirit”).


## Definition
### Noun
1. The spirit of the age; the taste, outlook, and spirit characteristic of a period. 
2. Alternative letter-case form of zeitgeist  

## Synonyms
