# afford

## Etymology
- From Middle English afforthen, aforthen, avorthien, from earlier iforthen, iforthien, ȝeforthien, from Old English forþian, ġeforþian (“to further, accomplish, afford”), from Proto-Germanic *furþōną, from Proto-Germanic *furþą (“forth, forward”), equivalent to a- +‎ forth. Cognate with Old Norse forða (“to forward oneself, save oneself, escape danger”), Icelandic forða (“to save, rescue”).


## Definition
### Verb
1. To incur, stand, or bear without serious detriment, as an act which might under other circumstances be injurious; (usually after an expression of ability, as could, able, difficult) to be able or rich enough. 
2. (obsolete) To offer, provide, or supply, as in selling, granting or expending, with profit, or without too great a loss. 
3. (rare) To give forth; to supply, yield, or produce as the natural result, fruit, or issue. 
4. To give, grant, or confer, with a remoter reference to its being the natural result; to provide; to furnish. 

## Synonyms
[[give]] | [[yield]] | [[open]]