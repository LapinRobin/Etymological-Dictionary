# pinnacle

## Etymology
- From Middle English, borrowed from Old French pinacle, pinnacle, from Late Latin pinnaculum (“a peak, pinnacle”), double diminutive of Latin pinna (“a pinnacle”); see pin. Doublet of panache.


## Definition
### Noun
1. The highest point. 
2. (geology) A tall, sharp and craggy rock or mountain. 
3. (figuratively) An all-time high; a point of greatest achievement or success. 
4. (architecture) An upright member, generally ending in a small spire, used to finish a buttress, to constitute a part in a proportion, as where pinnacles flank a gable or spire. 

### Verb
1. (transitive) To place on a pinnacle. 
2. (transitive) To build or furnish with a pinnacle or pinnacles. 

## Synonyms
[[top]] | [[peak]] | [[summit]] | [[acme]] | [[height]] | [[superlative]] | [[elevation]]