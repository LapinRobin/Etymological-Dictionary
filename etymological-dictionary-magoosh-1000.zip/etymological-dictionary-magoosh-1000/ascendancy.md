# ascendancy

## Etymology
- ascend +‎ -ancy or ascendant +‎ -cy. The use in ecology is due to Robert Ulanowicz.


## Definition
### Noun
1. Supremacy; dominant control; the quality of being in the ascendant. 
2. (historical, Ireland, sometimes capitalized) A class of Protestant landowners and professionals that dominated political and social life in Ireland up to the early 20th century 
3. (ecology) A quantitative attribute of an ecosystem, defined as a function of the ecosystem's trophic network, and intended to indicate its ability to prevail against disturbance by virtue of its combined organization and size. 

## Synonyms
[[control]] | [[dominance]]