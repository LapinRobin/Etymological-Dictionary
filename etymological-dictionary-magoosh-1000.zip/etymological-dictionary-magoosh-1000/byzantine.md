# byzantine

## Definition
### Adjective
1. Of or pertaining to Byzantium. 
2. (historical) Belonging to the civilization of the Eastern Roman empire between 331, when its capital was moved to Constantinople, and 1453, when that capital was conquered by the Turks and ultimately renamed Istanbul. 
3. (architecture) Of a style of architecture prevalent in the Eastern Empire down to 1453, marked by the round arch springing from columns or piers, the dome supported upon pendentives, capitals elaborately sculptured, mosaic or other encrustations, etc. 
4. (figuratively) Overly complex or intricate. 
5. Of a devious, usually stealthy, manner or practice. 
6. (Eastern Orthodoxy, Catholicism) of or relating to the Byzantine Rite or any of the many Eastern Orthodox churches and Greek Catholic churches that use this rite for their liturgical celebrations 
7. Alternative spelling of Byzantine  

### Noun
1. (historical) A native of Byzantium (modern-day Istanbul) or of the Byzantine empire 
2. (color) A dark, metallic shade of violet. 
3. (historical) A byzant (coin). 
4. (numismatics) Alternative form of byzantine (coin)  

## Synonyms
[[complex]] | [[intricate]] | [[convoluted]] | [[involved]] | [[tortuous]] | [[artful]] | [[knotty]]