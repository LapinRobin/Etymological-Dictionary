# diligent

## Etymology
- From Middle English diligent, from Old French diligent, from Latin dīligēns (“careful, attentive, diligent”), present participle of dīligō (“to love, esteem much, literally to choose, select”), from dī-, dis- (“apart”) + legō (“to choose”); see elect and select.


## Definition
### Adjective
1. Performing with industrious concentration; hard-working and focused. 

## Synonyms
[[patient]] | [[assiduous]] | [[industrious]] | [[sedulous]] | [[hardworking]]