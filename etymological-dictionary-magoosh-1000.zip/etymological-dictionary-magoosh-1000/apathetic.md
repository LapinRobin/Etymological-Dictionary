# apathetic

## Etymology
- apathy +‎ -etic


## Definition
### Adjective
1. Void of feeling; not susceptible of deep emotion. 
2. Of, or pertaining to apatheism. 

## Synonyms
[[indifferent]]