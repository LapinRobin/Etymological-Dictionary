# demur

## Etymology
- From Middle English demuren, from Anglo-Norman demorer (French demeurer), from Vulgar Latin demorō, Latin demoror (“to tarry”), from de- + moror (“to delay”).


## Definition
### Verb
1. (intransitive, obsolete) To linger; to stay; to tarry 
2. (intransitive) To delay; to pause; to suspend proceedings or judgment in view of a doubt or difficulty; to hesitate; to put off the determination or conclusion of an affair. 
3. (intransitive) To scruple or object; to take exception; to oppose; to balk 
4. (intransitive, law) To interpose a demurrer. 
5. (transitive, obsolete) To suspend judgment concerning; to doubt of or hesitate about 
6. (transitive, obsolete) To cause delay to; to put off 

### Noun
1. An act of hesitation as to proceeding; a scruple; also, a suspension of action or decision; a pause, a stop. 

## Synonyms
[[except]]