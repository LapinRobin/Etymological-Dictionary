# proscribe

## Etymology
- From Middle English proscriben, from Latin prōscrībō (“to proclaim, forbid, banish”).


## Definition
### Verb
1. (transitive) To forbid or prohibit. 
2. (transitive) To denounce. 
3. (transitive) To banish or exclude. 

## Synonyms
[[forbid]] | [[veto]] | [[interdict]] | [[prohibit]]