# sardonic

## Etymology
- From French sardonique, from Latin sardonius, from Ancient Greek σαρδόνιος (sardónios), alternative form of σαρδάνιος (sardánios, “bitter or scornful laughter”), which is often cited as deriving from the Sardinian plant (Ranunculus sardous or possibly Oenanthe crocata), known as either σαρδάνη (sardánē) or σαρδόνιον (sardónion). When eaten, it would cause the eater's face to contort in a look resembling scorn (generally followed by death). It might also be related to σαίρω (saírō, “I grin”).


## Definition
### Adjective
1. Scornfully mocking or cynical. 
2. Disdainfully or ironically humorous. 

## Synonyms
[[wry]] | [[sarcastic]]