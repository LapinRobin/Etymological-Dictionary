# relegate

## Etymology
- First attested in 1561, borrowed from Latin relēgātus, the past participle of relēgō (“to dispatch, banish”).

- First attested circa 1550: from the Classical Latin relēgātus (“banished person, exile”), the nominative singular masculine substantive form of relēgātus, the past participle of relēgō (“to dispatch, banish”).

- First attested circa 1425: from the Classical Latin relēgātus, the perfect passive participle of relēgō (“I dispatch”, “I banish”).


## Definition
### Verb
1. (transitive, done to a person) Exile or banish to a particular place. 
2. (reflexive, obsolete, rare) Remove (oneself) to a distance from something or somewhere. 
3. (transitive, historical, Ancient Rome, done to a person) Banish from proximity to Rome for a set time; compare relegate. 
4. (transitive, figuratively) Remove or send to a place far away. 
5. Consign (a person or thing) to a place, position, or role of obscurity, insignificance, oblivion, lower rank or (especially) inferiority. 
6. Assign (a thing) to an appropriate place or situation based on appraisal or classification. 
7. (sports, chiefly soccer) Transfer (a sports team) to a lower-ranking league division. 
8. Refer (a point of contention) to an authority in deference to the judgment thereof. 
9. Submit (something) to someone else for appropriate action thereby; compare delegate. 
10. (now rare) Submit or refer (someone) to someone or something else for some reason or purpose. 

### Noun
1. (historical, obsolete) A person who has been banished from proximity to Rome for a set time, but without losing his civil rights. 

### Adjective
1. (archaic) Relegated; exiled. 

## Synonyms
[[bar]] | [[break]] | [[submit]] | [[bump]] | [[banish]] | [[demote]]