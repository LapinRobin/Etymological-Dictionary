# antic

## Etymology
- Probably from Italian antico (“ancient”), used to describe ancient wall paintings from classical times, from Latin antiquus (“venerable”). See also grottesco (“grotesque”). Doublet of antique.

- From anticipation.


## Definition
### Adjective
1. Playful, funny, absurd. 
2. (architecture, art) Grotesque, incongruous. 
3. (archaic) Grotesque, bizarre 
4. Obsolete form of antique.  

### Noun
1. (architecture, art, obsolete) A grotesque representation of a figure; a gargoyle. 
2. A caricature. 
3. (often in the plural) A ludicrous gesture or act; ridiculous behaviour; caper. 
4. A grotesque performer or clown, buffoon. 
5. (animation) A pose, often exaggerated, in anticipation of an action; for example, a brief squat before jumping 

### Verb
1. (intransitive) To perform antics, to caper. 
2. (obsolete) To make a fool of, to cause to look ridiculous. 
3. (transitive, rare) To perform (an action) as an antic; to mimic ridiculously. 

## Synonyms
[[trick]] | [[fantastic]] | [[joke]] | [[caper]] | [[strange]] | [[grotesque]] | [[prank]] | [[clown]] | [[unusual]]