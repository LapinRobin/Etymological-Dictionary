# dog

## Etymology
- From Middle English dogge (whence also Scots dug (“dog”)), from Old English dogga, docga, of uncertain origin.

- Clipping of dogshit.


## Definition
### Noun
1. The species Canis familiaris (sometimes designated Canis lupus familiaris), domesticated for thousands of years and of highly variable appearance because of human breeding. 
2. Any member of the family Canidae, including domestic dogs, wolves, coyotes, jackals, foxes, and their relatives (extant and extinct); canid. 
3. (often attributive) A male dog, wolf, or fox, as opposed to a bitch or vixen. 
4. The meat of this animal, eaten as food: 
5. (slang, derogatory) A dull, unattractive girl or woman. 
6. (slang) A man, guy, chap. 
7. (derogatory) Someone who is cowardly, worthless, or morally reprehensible. 
8. (slang) A sexually aggressive man. 
9. Any of various mechanical devices for holding, gripping, or fastening something, particularly with a tooth-like projection. 
10. A click or pallet adapted to engage the teeth of a ratchet wheel, to restrain the back action. 
11. A metal support for logs in a fireplace. 
12. (cartomancy) The eighteenth Lenormand card. 
13. A hot dog: a frankfurter, wiener, or similar sausage; or a sandwich made from this. 
14. (poker slang) Underdog. 
15. (slang, almost always in the plural) Foot. 
16. (Cockney rhyming slang) (from "dog and bone") Phone or mobile phone. 
17. One of the cones used to divide up a racetrack when training horses. 
18. (informal) Something that performs poorly. 
19. (film) A flop; a film that performs poorly at the box office. 
20. (humorous) The language supposedly spoken by dogs 
21. The eleventh of the 12-year cycle of animals which appear in the Chinese zodiac related to the Chinese calendar. 
22. (Tyneside, slang) Newcastle Brown Ale 
23. Initialism of digital on-screen graphic. 
24. Initialism of digitally originated graphic. 

### Verb
1. (transitive) To pursue with the intent to catch. 
2. (transitive) To follow in an annoying or harassing way. 
3. (transitive, nautical) To fasten a hatch securely. 
4. (intransitive, emerging usage in Britain) To watch, or participate, in sexual activity in a public place. 
5. (intransitive, transitive) To intentionally restrict one's productivity as employee; to work at the slowest rate that goes unpunished. 
6. (transitive) To criticize. 
7. (transitive, military) To divide (a watch) with a comrade. 

### Adjective
1. (slang) Of inferior quality; dogshit. 

## Synonyms
[[track]] | [[trail]] | [[chase]] | [[tag]] | [[heel]] | [[tail]] | [[hound]] | [[cad]] | [[click]] | [[pawl]] | [[detent]] | [[andiron]] | [[bounder]] | [[blackguard]]