# forthright

## Etymology
- From Middle English forþright, forþriʒt, forþriht, from Old English forþriht (“direct, plain”); equivalent to forth +‎ right.

- From Middle English forthright, forþriʒt, forthricte, from Old English forþrihte (“straightway, at once, plainly”), from forþriht +‎ -e (“adverbial suffix”).


## Definition
### Adjective
1. Straightforward; not evasive; candid and direct. 
2. Frank, outspoken. 
3. Markedly simple. 
4. Fixed; settled; decided. 
5. (archaic) Proceeding straight forth. 

### Noun
1. (archaic) A straight path. 

### Adverb
1. Expressly, frankly, unhesitatingly. 
2. At once, forthwith. 
3. Swiftly. 
4. (archaic) Straight forward, in a straight direction. 

## Synonyms
[[direct]] | [[candid]] | [[blunt]] | [[frank]] | [[outspoken]]