# ease

## Etymology
- From Middle English ese, eise, aise, from Anglo-Norman ese (“ease”), from Old French eise, aise (“elbow room; opportunity”), of uncertain and obscure origin. Apparently related to Provençal ais, Italian agio and asio,  Sicilian aciu and  Portuguese azo. Sometimes ascribed to Vulgar Latin *āsia or *āsium, possibly from Latin ānsa (“handle, haft”) or Frankish *ansiju (“handle, loophole, eyelet; cup-handle; arms akimbo, elbow room”), but more often derived from Vulgar Latin *adjace(m), from Latin adjacēns (“adjacent, neighbouring”), present participle of adjaceō (“lie next to, border on”), though the forms and senses are difficult to trace clearly. 


## Definition
### Noun
1. Ability, the means to do something, particularly: 
2. Skill, dexterity, facility. 
3. Freedom from pain, hardship, and annoyance, sometimes (derogatory, archaic) idleness, sloth. 
4. Freedom from worry and concern; peace; sometimes (derogatory, archaic) indifference. 
5. Freedom from difficulty. 
6. Freedom from effort, leisure, rest. 
7. Freedom from financial effort or worry; affluence. 
8. Freedom from embarrassment or awkwardness; grace. 
9. Followed by of or from: release from or reduction of pain, hardship, or annoyance. 
10. (euphemistic, obsolete) Release from intestinal discomfort: defecation. 
11. Release from constraint, obligation, or a constrained position. 
12. (clothing) Additional space provided to allow greater movement. 
13. (obsolete) A convenience; a luxury. 
14. (obsolete) A relief; an easement. 

### Verb
1. (transitive) To free (something) from pain, worry, agitation, etc. 
2. (transitive) To alleviate, assuage or lessen (pain). 
3. (transitive) To give respite to (someone). 
4. (nautical, transitive) To loosen or slacken the tension on a line. 
5. (transitive) To reduce the difficulty of (something). 
6. (transitive) To move (something) slowly and carefully. 
7. (intransitive) To lessen in intensity. 
8. (intransitive) To proceed with little effort. 

## Synonyms
[[facilitate]] | [[relief]] | [[rest]] | [[still]] | [[alleviate]] | [[comfort]] | [[repose]] | [[allay]] | [[relieve]] | [[simplicity]]