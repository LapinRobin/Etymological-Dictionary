# entice

## Etymology
- From Middle English enticen, from Old French enticier (“to stir up or excite”), from a Vulgar Latin *intitiāre (“I set on fire”), from in- +‎ titiō (“firebrand (tool)”), from Proto-Italic *tītjō (“heating”), possibly from Proto-Indo-European *teih₁- (“to become hot, melt or to end”).


## Definition
### Verb
1. (transitive) To lure; to attract by arousing desire or hope. 

## Synonyms
[[lure]] | [[tempt]]