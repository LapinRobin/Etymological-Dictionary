# diabolical

## Etymology
- From diabolic +‎ -al.


## Definition
### Adjective
1. Extremely wicked or cruel. 
2. Of or concerning the devil; satanic. 

## Synonyms
[[evil]] | [[wicked]] | [[infernal]]