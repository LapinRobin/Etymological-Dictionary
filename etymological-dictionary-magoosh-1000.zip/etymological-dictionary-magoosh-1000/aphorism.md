# aphorism

## Etymology
- From Middle French aphorisme, from Late Latin aphorismus, from Ancient Greek ἀφορισμός (aphorismós, “pithy phrase containing a general truth”), from ἀφορίζω (aphorízō, “I define, mark off or determine”), from ἀπό (apó, “off”) + ὁρίζω (horízō, “I divide, bound”), from ὅρος (hóros, “boundary”).


## Definition
### Noun
1. A concise, terse, laconic, or memorable expression of a general truth or principle. 

### Verb
1. To speak or write aphorisms. 

## Synonyms
