# presumption

## Etymology
- Borrowed from Middle French presumption, from Old French presumption, from Latin praesumptiō.


## Definition
### Noun
1. the act of presuming, or something presumed 
2. the belief of something based upon reasonable evidence, or upon something known to be true 
3. the condition upon which something is presumed 
4. (dated) arrogant behaviour; the act of venturing beyond due bounds of reverence or respect 
5. (law) An inference that a trier of fact is either permitted or required to draw under certain factual circumstances (as prescribed by statute or case law) unless the party against whom the inference is drawn is able to rebut it with admissible, competent evidence. 

## Synonyms
[[assumption]] | [[given]]