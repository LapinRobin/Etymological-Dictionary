# maudlin

## Etymology
- From Middle English Maudelen, a dialectal form of Mary Magdalene (typically depicted weeping), from Old French Madelaine, from Late Latin Magdalena.


## Definition
### Noun
1. (obsolete, Christianity) The Magdalene; Mary Magdalene. 
2. (historical) Either of two aromatic plants, costmary or sweet yarrow. 
3. (obsolete) A Magdalene house; a brothel. 
4. A surname. 
5. Alternative form of Magdalen (“Magdalen College, Oxford”)  

### Adjective
1. Affectionate or sentimental in an effusive, tearful, or foolish manner, especially because of drunkenness. 
2. Extravagantly or excessively sentimental; mawkish, self-pitying. 
3. (obsolete) Tearful, lachrymose. 

## Synonyms
[[mawkish]] | [[sentimental]] | [[emotional]] | [[mushy]]